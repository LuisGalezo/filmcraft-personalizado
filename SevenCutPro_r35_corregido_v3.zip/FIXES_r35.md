# Correcciones aplicadas a Seven Cut Pro r35

Se modificó el código fuente del ZIP r35 proporcionado:

1. `HardwareInfo.kt`: se renombró la función auxiliar que convertía bytes a megabytes enteros de `megabytes(Long): Long` a `wholeMegabytes(Long): Long`, y se actualizaron sus dos usos. Esto elimina la colisión/ambigüedad con `Models.kt`, que ya define `megabytes(Long): String`.
2. `MediaCodecH264.kt`: se cambió la referencia de los modos VBR/CBR a `MediaCodecInfo.EncoderCapabilities` mediante el import `EncoderCapabilities`, que es la clase que define esas constantes.

## Verificación

No se pudo ejecutar la compilación: el Gradle Wrapper intentó descargar Gradle 9.5.1 desde `services.gradle.org`, pero el entorno no tiene acceso de red (`UnknownHostException`). Por tanto, estas correcciones están aplicadas al código, pero no están compiladas ni verificadas en Android/GitHub Actions.

## Diferencia respecto al log de GitHub

El ZIP recibido contiene `MediaCodecH264.kt`, no `CodeH264.kt`. La captura del workflow menciona `CodeH264.kt` y también señala otras llamadas ambiguas a `megabytes`. Por ello, el ZIP corregido puede no ser idéntico al commit exacto que produjo ese log. Si el workflow sigue compilando otra versión/archivo, habrá que aplicar el mismo ajuste en el repositorio actual.
