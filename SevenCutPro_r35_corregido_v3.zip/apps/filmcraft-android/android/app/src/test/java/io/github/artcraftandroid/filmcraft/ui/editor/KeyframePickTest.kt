package io.github.artcraftandroid.filmcraft.ui.editor

import org.junit.Assert.assertEquals
import org.junit.Test

class KeyframePickTest {
    @Test fun touchNearAKeyPicksIt() {
        assertEquals(1, KeyframePick.pick(listOf(100f, 200f, 300f), 215f, 40f))
    }

    @Test fun touchTooFarPicksNothing() {
        assertEquals(-1, KeyframePick.pick(listOf(100f, 200f), 150f, 40f))
    }

    @Test fun theNearerNeighbourWins() {
        assertEquals(0, KeyframePick.pick(listOf(100f, 120f), 105f, 40f))
        assertEquals(1, KeyframePick.pick(listOf(100f, 120f), 112f, 40f))
    }

    @Test fun noKeysNoPick() {
        assertEquals(-1, KeyframePick.pick(emptyList(), 10f, 40f))
    }

    @Test fun movedKeyStaysInsideTheClip() {
        assertEquals(1_001L, KeyframePick.movedTo(500, -9_999, 1_000, 5_000))
        assertEquals(5_999L, KeyframePick.movedTo(3_000, 99_999, 1_000, 5_000))
        assertEquals(3_500L, KeyframePick.movedTo(3_000, 500, 1_000, 5_000))
    }
}
