package io.github.artcraftandroid.filmcraft.ui.editor

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class KeyEaseTest {
    @Test
    fun everyTypeStartsAtZeroAndEndsAtOne() {
        for (k in KeyEase.entries) {
            assertEquals(k.name, 0.0, k.at(0.0), 1e-6)
            assertEquals(k.name, 1.0, k.at(1.0), 1e-6)
        }
    }

    @Test
    fun linearIsSteadyAndHoldStaysUntilTheNextKey() {
        assertEquals(0.3, KeyEase.Linear.at(0.3), 1e-9)
        assertEquals(0.0, KeyEase.Hold.at(0.99), 0.0)
    }

    @Test
    fun easeOutStartsSlowAndEaseInArrivesSlow() {
        assertTrue(KeyEase.EaseOut.at(0.25) < 0.25)
        assertTrue(KeyEase.EaseIn.at(0.75) > 0.75)
        // the other end of each is not eased
        assertTrue(KeyEase.EaseOut.at(0.9) < 1.0)
    }

    @Test
    fun theBezierKindsAreSymmetricAndNeverGoBackwards() {
        for (k in listOf(KeyEase.Bezier, KeyEase.AutoBezier, KeyEase.ContinuousBezier, KeyEase.EaseIn, KeyEase.EaseOut)) {
            var last = -1.0
            for (i in 0..100) {
                val y = k.at(i / 100.0)
                assertTrue("${k.name} at $i: $y after $last", y >= last - 1e-9)
                last = y
            }
        }
        assertEquals(0.5, KeyEase.Bezier.at(0.5), 1e-6)
        assertEquals(1.0 - KeyEase.Bezier.at(0.3), KeyEase.Bezier.at(0.7), 1e-6)
    }

    @Test
    fun idsRoundTripAndMatchTheEngine() {
        assertEquals(
            listOf("linear", "bezier", "auto_bezier", "continuous_bezier", "hold", "ease_in", "ease_out"),
            KeyEase.entries.map { it.id },
        )
        for (k in KeyEase.entries) assertEquals(k, KeyEase.of(k.id))
        assertNull(KeyEase.of("nonsense"))
    }

    @Test
    fun theStretchShownIsTheOneTheTypeShapes() {
        // keys at 100 and 400, then 700 (the next key); the one being edited is 400
        assertEquals(400L to 700L, keyPreviewSpan(KeyEase.EaseOut, 400, 100, 700, 10))
        assertEquals(400L to 700L, keyPreviewSpan(KeyEase.Linear, 400, 100, 700, 10))
        assertEquals(100L to 400L, keyPreviewSpan(KeyEase.EaseIn, 400, 100, 700, 10))
        // Ease In on the first key has no stretch before it: the one after is shown
        assertEquals(100L to 400L, keyPreviewSpan(KeyEase.EaseIn, 100, -1, 400, 10))
        // nothing to play when the next key is (almost) on top of it
        assertNull(keyPreviewSpan(KeyEase.Hold, 400, 100, 404, 10))
    }
}
