package io.github.artcraftandroid.filmcraft.engine

import java.util.Date
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class HardwareInfoTest {
    @Test
    fun vulkan_versions_are_read_the_way_android_declares_them() {
        assertEquals("1.0.0", formatVulkanVersion(0x400000))
        assertEquals("1.1.0", formatVulkanVersion(0x401000))
        assertEquals("1.3.0", formatVulkanVersion(0x403000))
        assertEquals("1.1.82", formatVulkanVersion(0x401000 or 82))
    }

    @Test
    fun opengl_es_versions_are_major_dot_minor() {
        assertEquals("3.0", formatGlesVersion(0x30000))
        assertEquals("3.2", formatGlesVersion(0x30002))
        assertEquals("2.0", formatGlesVersion(0x20000))
    }

    @Test
    fun megabytes_round_down() {
        assertEquals(0, megabytes(1_048_575))
        assertEquals(1, megabytes(1_048_576))
        assertEquals(8192, megabytes(8L * 1024 * 1024 * 1024))
    }

    private val info = HardwareInfo(listOf("Dispositivo" to "Acme Phone", "OpenGL ES" to "3.2"), listOf("c2.acme.avc.encoder: AVC, hardware, hasta 4096x2304, 100 Mbit/s"))
    private val working = listOf(Triple("Vista previa del editor", "CPU", "Siempre en CPU por ahora."), Triple("Codificación de vídeo H.264 (exportación)", "MediaCodec", "1080x1920."))

    @Test
    fun the_report_has_every_section_and_says_which_system_does_what() {
        val text = buildReportText("0.1.0+10001", Date(0), info, working, "usable: c2.acme.avc.encoder", "selected: Adreno 740 on vulkan\n")
        for (needle in listOf(
            "SEVEN CUT PRO — Diagnóstico y aceleración de hardware", "Versión de la app: 0.1.0+10001", "== Dispositivo ==", "Dispositivo: Acme Phone", "OpenGL ES: 3.2",
            "== Sistema en uso (CPU, GPU o MediaCodec) ==", "- Vista previa del editor: CPU. Siempre en CPU por ahora.", "- Codificación de vídeo H.264 (exportación): MediaCodec. 1080x1920.",
            "c2.acme.avc.encoder: AVC, hardware", "usable: c2.acme.avc.encoder", "== Diagnóstico GPU (wgpu) ==", "selected: Adreno 740 on vulkan",
        )) assertTrue("the report lacks \"$needle\":\n$text", text.contains(needle))
    }

    @Test
    fun a_report_before_any_data_says_so_instead_of_failing() {
        val text = buildReportText("x", Date(0), null, emptyList(), "", null)
        assertTrue(text.contains("(sin datos todavía)"))
        assertTrue(text.contains("(ninguno listado)"))
        assertTrue(text.contains("Aún no se ha ejecutado el diagnóstico GPU."))
    }
}
