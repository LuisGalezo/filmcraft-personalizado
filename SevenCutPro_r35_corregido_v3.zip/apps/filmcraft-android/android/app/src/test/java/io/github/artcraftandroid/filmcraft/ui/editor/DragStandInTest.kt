package io.github.artcraftandroid.filmcraft.ui.editor

import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class DragStandInTest {
    private fun between(sx: Double, sy: Double, ss: Double, sr: Double, nx: Double, ny: Double, ns: Double, nr: Double, k: Double = 1.0) =
        DragStandIn.between(sx, sy, ss, sr, nx, ny, ns, nr, 1080.0, 1920.0, k)

    @Test
    fun staying_put_changes_nothing() {
        val t = between(540.0, 960.0, 1.0, 0.0, 540.0, 960.0, 1.0, 0.0)
        assertEquals(0f, t.translationX, 0f)
        assertEquals(0f, t.translationY, 0f)
        assertEquals(1f, t.scale, 0f)
        assertEquals(0f, t.rotationDeg, 0f)
        assertEquals(0.5f, t.originX, 1e-6f)
        assertEquals(0.5f, t.originY, 1e-6f)
    }

    @Test
    fun a_move_is_the_distance_in_screen_pixels() {
        val t = between(540.0, 960.0, 1.0, 0.0, 640.0, 910.0, 1.0, 0.0, k = 0.5)
        assertEquals(50f, t.translationX, 1e-4f)
        assertEquals(-25f, t.translationY, 1e-4f)
    }

    @Test
    fun scale_and_turn_are_relative_to_where_the_finger_found_the_layer() {
        val t = between(300.0, 400.0, 0.5, 30.0, 300.0, 400.0, 1.0, 75.0)
        assertEquals(2f, t.scale, 1e-6f)
        assertEquals(45f, t.rotationDeg, 1e-4f)
        assertEquals(300f / 1080f, t.originX, 1e-6f)
        assertEquals(400f / 1920f, t.originY, 1e-6f)
    }

    /** What a GPU layer does: scale and turn about the pivot, then shift. */
    private fun gpu(t: DragStandIn.Transform, px: Double, py: Double, w: Double, h: Double): Pair<Double, Double> {
        val ox = t.originX * w
        val oy = t.originY * h
        val a = Math.toRadians(t.rotationDeg.toDouble())
        val dx = (px - ox) * t.scale
        val dy = (py - oy) * t.scale
        return Pair(ox + dx * cos(a) - dy * sin(a) + t.translationX, oy + dx * sin(a) + dy * cos(a) + t.translationY)
    }

    /** A corner of a layer `lw` x `lh` placed at (x, y) with scale and rotation, as the engine's outline computes it. */
    private fun corner(x: Double, y: Double, scale: Double, rot: Double, lw: Double, lh: Double, sx: Double, sy: Double): Pair<Double, Double> {
        val a = Math.toRadians(rot)
        val cx = sx * lw * scale / 2
        val cy = sy * lh * scale / 2
        return Pair(x + cx * cos(a) - cy * sin(a), y + cx * sin(a) + cy * cos(a))
    }

    @Test
    fun the_stand_in_lands_exactly_where_the_placed_layer_will_be() {
        val (lw, lh) = 400.0 to 120.0
        val (sx, sy, ss, sr) = listOf(300.0, 500.0, 0.8, 10.0)
        val (nx, ny, ns, nr) = listOf(620.0, 380.0, 1.7, 63.0)
        val frameW = 1080.0
        val frameH = 1920.0
        val k = 0.4
        val t = DragStandIn.between(sx, sy, ss, sr, nx, ny, ns, nr, frameW, frameH, k)
        for ((cxs, cys) in listOf(-1.0 to -1.0, 1.0 to -1.0, 1.0 to 1.0, -1.0 to 1.0)) {
            // the corner in the stand-in (the layer at the start placement), in screen pixels, moved by the GPU
            val (bx, by) = corner(sx, sy, ss, sr, lw, lh, cxs, cys)
            val (gx, gy) = gpu(t, bx * k, by * k, frameW * k, frameH * k)
            // the corner of the layer at the placement it is given now, in screen pixels
            val (wx, wy) = corner(nx, ny, ns, nr, lw, lh, cxs, cys)
            assertTrue("x ${gx} vs ${wx * k}", abs(gx - wx * k) < 1e-3)
            assertTrue("y ${gy} vs ${wy * k}", abs(gy - wy * k) < 1e-3)
        }
    }

    @Test
    fun a_broken_start_scale_does_not_blow_up() {
        val t = between(0.0, 0.0, 0.0, 0.0, 10.0, 10.0, 2.0, 0.0)
        assertEquals(1f, t.scale, 0f)
    }
}
