package io.github.artcraftandroid.filmcraft.ui.editor

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertSame
import org.junit.Assert.assertTrue
import org.junit.Test

class TopBarControlsTest {
    // ---- the wheel
    @Test fun aLockedWheelDoesNotScroll() {
        assertTrue(WheelRule.canScroll(false))
        assertFalse(WheelRule.canScroll(true))
    }

    @Test fun theKeyframesViewGoesBackWithoutALayerUnlessLocked() {
        assertEquals(WheelRule.UNDO_REDO, WheelRule.settle(WheelRule.KEYFRAMES, nothingSelected = true, locked = false))
        assertEquals(WheelRule.KEYFRAMES, WheelRule.settle(WheelRule.KEYFRAMES, nothingSelected = true, locked = true))
        assertEquals(WheelRule.KEYFRAMES, WheelRule.settle(WheelRule.KEYFRAMES, nothingSelected = false, locked = false))
        assertEquals(WheelRule.UNDO_REDO, WheelRule.settle(WheelRule.UNDO_REDO, nothingSelected = true, locked = false))
    }

    // ---- keyframes on the timeline
    @Test fun aKeyIsUnderThePlayheadWithinHalfAFrame() {
        assertTrue(KeyframePick.onPlayhead(1_000, 1_000, 50))
        assertTrue(KeyframePick.onPlayhead(1_000, 1_050, 50))
        assertTrue(KeyframePick.onPlayhead(1_000, 950, 50))
        assertFalse(KeyframePick.onPlayhead(1_000, 1_051, 50))
        assertFalse(KeyframePick.onPlayhead(1_000, 900, 50))
    }

    @Test fun aDraggedKeyFollowsTheFingerAtOnceAndStaysInsideTheClip() {
        // the first pixel of a drag already moves it, and it never leaves the clip or lands on its ends
        assertEquals(1_100L, KeyframePick.movedTo(1_000, 100, 0, 5_000))
        assertEquals(1L, KeyframePick.movedTo(1_000, -9_999, 0, 5_000))
        assertEquals(4_999L, KeyframePick.movedTo(1_000, 9_999, 0, 5_000))
    }

    // ---- curve presets
    private val a = KeyCurve(0.2, 0.0, 0.8, 1.0)
    private val b = KeyCurve(0.4, 0.1, 0.6, 0.9)

    @Test fun savingAPresetAddsItUnderTheNextFreeName() {
        val one = CurveStore.add(emptyList(), a)
        assertEquals(1, one.size)
        assertEquals("Curve 2", CurveStore.add(one, b).last().name)
    }

    @Test fun savingTheSameCurveTwiceMakesNoDuplicate() {
        val one = CurveStore.add(emptyList(), a)
        assertSame(one, CurveStore.add(one, a))
    }

    @Test fun aFullListTakesNoMore() {
        var list = emptyList<SavedCurve>()
        for (i in 0 until CurveStore.MAX_CURVES) list = CurveStore.add(list, KeyCurve(0.1 + i * 0.03, 0.0, 0.9, 1.0))
        assertEquals(CurveStore.MAX_CURVES, list.size)
        assertSame(list, CurveStore.add(list, KeyCurve(0.5, 0.5, 0.6, 0.6)))
    }

    @Test fun deletingAPresetTakesOnlyThatOneAndSurvivesStorage() {
        val list = CurveStore.add(CurveStore.add(emptyList(), a), b)
        val rest = list - list[0]
        assertEquals(listOf(list[1]), rest)
        assertEquals(rest, CurveStore.decode(CurveStore.encode(rest)).map { SavedCurve(it.name, it.curve) })
    }
}
