package io.github.artcraftandroid.filmcraft.ui.editor

import kotlinx.coroutines.delay
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** The live edit queue: a control being dragged shows its newest value fast, in order, and never loses the last one. */
class LiveEditQueueTest {
    /** A slider event stream of [n] steps, [gapMs] apart, against an engine that needs [applyMs] per edit. */
    private fun drag(n: Int, gapMs: Long, applyMs: Long): Triple<List<Int>, Int, Long> = runBlocking {
        val applied = ArrayList<Int>()
        val q = LiveEditQueue<Int>(this) { v -> delay(applyMs); applied += v }
        val start = System.currentTimeMillis()
        for (i in 1..n) {
            q.submit("opacity", i)
            delay(gapMs)
        }
        // wait for the worker to finish what is left
        while (q.pending > 0 || applied.lastOrNull() != n) delay(5)
        Triple(applied, applied.size, System.currentTimeMillis() - start)
    }

    @Test
    fun aFastDragAppliesFarFewerEditsThanTouchEventsAndEndsOnTheLastValue() {
        // 100 touch events 4 ms apart (250 Hz) against an engine that needs 20 ms per edit
        val (applied, count, _) = drag(n = 100, gapMs = 4, applyMs = 20)
        assertEquals(100, applied.last())
        assertTrue("applied $count edits for 100 events", count < 40)
        assertEquals("applied values only ever move forward", applied.sorted(), applied)
    }

    @Test
    fun theFinalValueLandsRightAfterTheFingerStops() {
        // old behaviour: every event queued its own edit, so the last one waited for all 100 (100 x 20 ms)
        val (_, _, total) = drag(n = 100, gapMs = 4, applyMs = 20)
        val fingerStopped = 100 * 4L
        assertTrue("finished ${total - fingerStopped} ms after the finger stopped", total - fingerStopped < 200)
    }

    @Test
    fun differentControlsAreAllAppliedAndAnOlderValueOfOneIsReplaced() = runBlocking {
        val applied = ArrayList<String>()
        val q = LiveEditQueue<String>(this) { v -> delay(10); applied += v }
        q.submit("opacity", "o1")
        q.submit("volume", "v1")
        q.submit("opacity", "o2") // replaces o1 if it has not started
        q.submit("opacity", "o3")
        while (q.pending > 0) delay(5)
        delay(40)
        assertTrue(applied.contains("v1"))
        assertEquals("o3", applied.last { it.startsWith("o") })
        assertTrue("o2 never applied: ${applied}", !applied.contains("o2"))
    }

    @Test
    fun takePendingHandsOverWhatWaitsSoALaterEditRunsAfterIt() = runBlocking {
        val applied = ArrayList<String>()
        val q = LiveEditQueue<String>(this) { v -> delay(30); applied += v }
        q.submit("a", "a1")       // starts the worker ...
        delay(5)                  // ... which is now applying a1
        q.submit("b", "b1")       // waits
        q.submit("c", "c1")       // waits
        val waiting = q.takePending()
        assertEquals(listOf("b1", "c1"), waiting)
        assertEquals(0, q.pending)
        delay(80)
        assertEquals(listOf("a1"), applied) // nothing is applied twice or after being handed over
    }

    @Test
    fun anEditTakenBeforeTheWorkerStartedIsHandedOverWholeAndNotAppliedTwice() = runBlocking {
        val applied = ArrayList<String>()
        val q = LiveEditQueue<String>(this) { v -> delay(5); applied += v }
        q.submit("a", "a1") // the worker is launched but has not run yet
        assertEquals(listOf("a1"), q.takePending())
        delay(40)
        assertEquals(emptyList<String>(), applied)
    }

    @Test
    fun theWorkerRestartsForTheNextDrag() = runBlocking {
        val applied = ArrayList<Int>()
        val q = LiveEditQueue<Int>(this) { v -> delay(5); applied += v }
        q.submit("k", 1)
        delay(40)
        q.submit("k", 2)
        delay(40)
        assertEquals(listOf(1, 2), applied)
    }

    @Test
    fun anEditThatFailsDoesNotStopTheQueue() = runBlocking {
        val applied = ArrayList<Int>()
        val q = LiveEditQueue<Int>(this) { v ->
            delay(5)
            try { if (v == 1) error("boom") else applied += v } catch (_: IllegalStateException) { }
        }
        q.submit("a", 1)
        q.submit("b", 2)
        delay(60)
        assertEquals(listOf(2), applied)
    }
}
