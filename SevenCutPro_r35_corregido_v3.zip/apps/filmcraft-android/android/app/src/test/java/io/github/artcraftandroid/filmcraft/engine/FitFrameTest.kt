package io.github.artcraftandroid.filmcraft.engine

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class FitFrameTest {
    @Test fun usualFramesAreKeptAsTheyAre() {
        assertEquals(1920 to 1080, Projects.fitFrame(1920, 1080))
        assertEquals(1080 to 1920, Projects.fitFrame(1080, 1920))
        assertEquals(1280 to 720, Projects.fitFrame(1280, 720))
    }

    @Test fun unusualShapesAreKeptExactly() {
        assertEquals(1700 to 500, Projects.fitFrame(1700, 500))
        assertEquals(1000 to 1000, Projects.fitFrame(1000, 1000))
    }

    @Test fun oddSidesBecomeEvenAndBigFramesAreScaledToTheLimit() {
        assertEquals(1920 to 1080, Projects.fitFrame(1921, 1081))
        assertEquals(4096 to 2160, Projects.fitFrame(7680, 4050))
    }

    @Test fun unreadableSizesGiveNothing() {
        assertNull(Projects.fitFrame(0, 1080))
        assertNull(Projects.fitFrame(1920, -1))
    }
}
