package io.github.artcraftandroid.filmcraft.ui.editor

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class LayerGlideTest {
    @Test fun viewToTheLeftGoesToTheStart() = assertEquals(5_000L, LayerGlide.target(1_000, 5_000, 4_000, 10))
    @Test fun viewToTheRightGoesToTheLastFrame() = assertEquals(8_990L, LayerGlide.target(20_000, 5_000, 4_000, 10))
    @Test fun insideTheLayerNothingMoves() {
        assertNull(LayerGlide.target(6_000, 5_000, 4_000, 10))
        assertNull(LayerGlide.target(5_000, 5_000, 4_000, 10))
    }
    @Test fun theEndItselfCountsAsRight() = assertEquals(8_990L, LayerGlide.target(9_000, 5_000, 4_000, 10))
    @Test fun durationIsModerate() {
        assertEquals(160L, LayerGlide.millis(0f))
        assertEquals(320L, LayerGlide.millis(100_000f))
        assertTrue(LayerGlide.millis(400f) in 160L..320L)
    }
    @Test fun easeRunsFromZeroToOneWithoutOvershoot() {
        assertEquals(0f, LayerGlide.ease(0f), 0f)
        assertEquals(1f, LayerGlide.ease(1f), 0f)
        var prev = 0f
        for (i in 1..20) { val v = LayerGlide.ease(i / 20f); assertTrue(v >= prev && v <= 1f); prev = v }
    }
}
