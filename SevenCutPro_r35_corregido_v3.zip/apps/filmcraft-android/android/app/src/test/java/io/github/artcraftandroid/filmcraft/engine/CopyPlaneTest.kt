package io.github.artcraftandroid.filmcraft.engine

import java.nio.ByteBuffer
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.fail
import org.junit.Test

class CopyPlaneTest {
    private val sentinel: Byte = 0x7F

    @Test
    fun a_plain_plane_goes_row_by_row_and_the_padding_is_left_alone() {
        // 4x2 samples, rows 8 bytes apart (4 bytes of padding)
        val dst = ByteArray(16) { sentinel }
        copyPlane(byteArrayOf(1, 2, 3, 4, 5, 6, 7, 8), 0, 4, 2, ByteBuffer.wrap(dst), 8, 1)
        assertArrayEquals(byteArrayOf(1, 2, 3, 4, sentinel, sentinel, sentinel, sentinel, 5, 6, 7, 8, sentinel, sentinel, sentinel, sentinel), dst)
    }

    @Test
    fun the_source_offset_picks_the_plane() {
        val src = byteArrayOf(9, 9, 9, 9, 1, 2, 3, 4) // an 8-sample "picture": the plane starts at 4
        val dst = ByteArray(4)
        copyPlane(src, 4, 2, 2, ByteBuffer.wrap(dst), 2, 1)
        assertArrayEquals(byteArrayOf(1, 2, 3, 4), dst)
    }

    @Test
    fun interleaved_chroma_planes_do_not_overwrite_each_other() {
        // NV12-style: U and V share memory; U at even bytes, V at odd bytes; 4x2 chroma samples, rows 8 bytes apart
        val mem = ByteArray(16) { sentinel }
        val u = ByteBuffer.wrap(mem)
        val v = ByteBuffer.wrap(mem, 1, 15).slice()
        val us = byteArrayOf(1, 2, 3, 4, 5, 6, 7, 8)
        val vs = byteArrayOf(11, 12, 13, 14, 15, 16, 17, 18)
        copyPlane(us, 0, 4, 2, u, 8, 2)
        copyPlane(vs, 0, 4, 2, v, 8, 2)
        assertArrayEquals(byteArrayOf(1, 11, 2, 12, 3, 13, 4, 14, 5, 15, 6, 16, 7, 17, 8, 18), mem)
    }

    @Test
    fun a_destination_that_cannot_hold_the_whole_plane_is_an_error_and_nothing_is_written() {
        val dst = ByteArray(6) { sentinel } // too small for 4x2 with stride 4 (needs 8)
        try {
            copyPlane(byteArrayOf(1, 2, 3, 4, 5, 6, 7, 8), 0, 4, 2, ByteBuffer.wrap(dst), 4, 1)
            fail("a partly written picture was accepted")
        } catch (e: IllegalStateException) {
            assertEquals(true, e.message!!.contains("needed"))
        }
        assertEquals(List(6) { sentinel }, dst.toList())
    }

    @Test
    fun the_last_row_does_not_need_its_padding() {
        // 4x2, stride 8: rows at 0 and 8, the second row only needs 4 bytes -> 12 bytes are enough
        val dst = ByteArray(12) { sentinel }
        copyPlane(byteArrayOf(1, 2, 3, 4, 5, 6, 7, 8), 0, 4, 2, ByteBuffer.wrap(dst), 8, 1)
        assertArrayEquals(byteArrayOf(1, 2, 3, 4, sentinel, sentinel, sentinel, sentinel, 5, 6, 7, 8), dst)
    }

    @Test
    fun a_source_that_is_too_short_or_a_stride_that_is_too_small_is_an_error() {
        try {
            copyPlane(byteArrayOf(1, 2, 3), 0, 2, 2, ByteBuffer.allocate(16), 4, 1)
            fail("short source accepted")
        } catch (e: IllegalStateException) {
        }
        try {
            copyPlane(ByteArray(8), 0, 4, 2, ByteBuffer.allocate(16), 2, 1)
            fail("stride smaller than the row accepted")
        } catch (e: IllegalStateException) {
        }
    }
}
