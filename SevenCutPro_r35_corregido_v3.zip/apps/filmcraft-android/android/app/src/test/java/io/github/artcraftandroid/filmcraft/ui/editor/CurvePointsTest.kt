package io.github.artcraftandroid.filmcraft.ui.editor

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** Curves with several points: the maths (same as the engine's), adding, moving and removing points, and saving them. */
class CurvePointsTest {
    private val third = 1.0 / 3.0
    private val flatEase = KeyCurve(third, 0.0, 2 * third, 1.0)

    private fun pt(x: Double, y: Double, dx: Double) = CurvePt(x, y, x - dx, y, x + dx, y)

    private fun assertNear(want: Double, got: Double, eps: Double = 1e-5, msg: String = "") =
        assertTrue("$msg want $want got $got", kotlin.math.abs(want - got) < eps)

    @Test fun aCurveWithoutPointsIsTheOldCubic() {
        for (c in listOf(flatEase, KeyCurve(0.2, -0.4, 0.9, 1.5), KeyCurve(0.7, 0.0, 0.3, 1.0))) {
            for (i in 0..40) {
                val u = i / 40.0
                assertNear(KeyEase.bezierY(c.x1, c.y1, c.x2, c.y2, u), c.at(u), 1e-9, "u=$u")
            }
        }
    }

    @Test fun theValuesMatchTheReferenceImplementation() {
        // reference values from an independent implementation (the one the engine's tests use too)
        val a = KeyCurve(third, 0.0, 2 * third, 1.0, listOf(pt(0.5, 0.8, 0.1)))
        val tableA = listOf(0.0 to 0.0, 0.1 to 0.026507, 0.25 to 0.197116, 0.5 to 0.8, 0.75 to 0.950721, 0.9 to 0.993373, 1.0 to 1.0)
        for ((u, want) in tableA) assertNear(want, a.at(u), msg = "A u=$u")
        val b = KeyCurve(third, third, 2 * third, 2 * third, listOf(pt(0.3, 0.9, 0.1), pt(0.7, 0.1, 0.1)))
        val tableB = listOf(0.0 to 0.0, 0.1 to 0.126989, 0.25 to 0.71619, 0.5 to 0.5, 0.75 to 0.28381, 0.9 to 0.873011, 1.0 to 1.0)
        for ((u, want) in tableB) assertNear(want, b.at(u), msg = "B u=$u")
    }

    @Test fun addingAPointKeepsTheShapeOfTheCurve() {
        val curves = listOf(
            flatEase,
            KeyCurve(0.2, -0.4, 0.9, 1.5),
            KeyCurve(0.9, 0.1, 0.1, 0.9), // crossed handles
            KeyCurve(third, 0.0, 2 * third, 1.0, listOf(pt(0.4, 0.6, 0.1))),
        )
        for (c0 in curves) {
            var c = c0
            for (x in listOf(0.5, 0.25, 0.8, 0.65)) {
                val before = (0..50).map { c.at(it / 50.0) }
                val added = CurveMath.addPoint(c, x) ?: continue
                c = added.first
                val after = (0..50).map { c.at(it / 50.0) }
                for (i in before.indices) assertNear(before[i], after[i], 1e-6, "x=$x i=$i")
            }
        }
    }

    @Test fun theSplitOfTheMiddleHasTheKnownHandles() {
        val (c, index) = CurveMath.addPoint(flatEase, 0.5)!!
        assertEquals(0, index)
        assertNear(0.166667, c.x1)
        assertNear(0.0, c.y1)
        assertNear(0.833333, c.x2)
        assertNear(1.0, c.y2)
        val p = c.mid.single()
        assertNear(0.5, p.x); assertNear(0.5, p.y)
        assertNear(0.333333, p.inX); assertNear(0.25, p.inY)
        assertNear(0.666667, p.outX); assertNear(0.75, p.outY)
    }

    @Test fun pointsStayApartAndAreLimited() {
        val (c, _) = CurveMath.addPoint(flatEase, 0.5)!!
        assertNull("too close to a point", CurveMath.addPoint(c, 0.51))
        assertNull("too close to the start", CurveMath.addPoint(flatEase, 0.01))
        assertNull("too close to the end", CurveMath.addPoint(flatEase, 0.99))
        var full = flatEase
        for (k in 1..CurveMath.MAX_POINTS) full = CurveMath.addPoint(full, k / 17.0)!!.first
        assertEquals(CurveMath.MAX_POINTS, full.mid.size)
        assertNull("the 17th does not fit", CurveMath.addPoint(full, 0.033))
    }

    @Test fun pointsKeepTheirOrderAndGetTheRightIndex() {
        var c = flatEase
        c = CurveMath.addPoint(c, 0.7)!!.first
        val second = CurveMath.addPoint(c, 0.3)!!
        assertEquals("the new point is before the other one", 0, second.second)
        assertEquals(listOf(0.3, 0.7), second.first.mid.map { it.x }.map { Math.round(it * 100) / 100.0 })
    }

    @Test fun aPointMovesWithItsHandlesAndStaysBetweenItsNeighbours() {
        val c = KeyCurve(third, 0.0, 2 * third, 1.0, listOf(pt(0.3, 0.4, 0.1), pt(0.7, 0.6, 0.1)))
        val moved = CurveMath.movePoint(c, 0, 0.35, 0.9)
        assertEquals(0.35, moved.mid[0].x, 1e-9)
        assertEquals(0.9, moved.mid[0].y, 1e-9)
        assertEquals(0.25, moved.mid[0].inX, 1e-9)
        assertEquals(0.45, moved.mid[0].outX, 1e-9)
        // it cannot pass its neighbour, nor leave the stretch, nor the value limits
        assertEquals(0.7 - CurveMath.MIN_GAP, CurveMath.movePoint(c, 0, 0.95, 0.5).mid[0].x, 1e-9)
        assertEquals(CurveMath.MIN_GAP, CurveMath.movePoint(c, 0, -3.0, 0.5).mid[0].x, 1e-9)
        assertEquals(KeyCurve.MAX_Y, CurveMath.movePoint(c, 1, 0.7, 9.0).mid[1].y, 1e-9)
        // a bad index changes nothing
        assertEquals(c, CurveMath.movePoint(c, 5, 0.5, 0.5))
    }

    @Test fun aHandleStaysOnItsSideOfItsPoint() {
        val c = KeyCurve(third, 0.0, 2 * third, 1.0, listOf(pt(0.5, 0.5, 0.1)))
        val i = CurveMath.movePointHandle(c, 0, true, 0.9, 0.2).mid[0]
        assertEquals("the in handle cannot pass its point", 0.5, i.inX, 1e-9)
        val o = CurveMath.movePointHandle(c, 0, false, -1.0, 0.2).mid[0]
        assertEquals("the out handle cannot pass its point", 0.5, o.outX, 1e-9)
        assertEquals(0.2, o.outY, 1e-9)
    }

    @Test fun removingAPointReshapesTheCurve() {
        val c = KeyCurve(third, 0.0, 2 * third, 1.0, listOf(pt(0.3, 0.9, 0.1), pt(0.7, 0.1, 0.1)))
        val r = CurveMath.removePoint(c, 0)
        assertEquals(1, r.mid.size)
        assertEquals(0.7, r.mid[0].x, 1e-9)
        assertTrue(CurveMath.removePoint(r, 0).mid.isEmpty())
        assertEquals(c, CurveMath.removePoint(c, 4))
    }

    @Test fun sanitizeKeepsWhatTheEngineKeeps() {
        val wild = listOf(
            CurvePt(0.7, 9.0, -3.0, 0.5, 9.0, 0.5),
            pt(0.3, 0.4, 0.1),
            pt(0.3005, 0.4, 0.1),
            pt(0.0, 0.0, 0.0),
            pt(1.5, 0.0, 0.0),
            CurvePt(Double.NaN, 0.0, 0.0, 0.0, 0.0, 0.0),
        )
        val clean = CurveMath.sanitize(wild)
        assertEquals(listOf(0.3, 0.7), clean.map { it.x })
        assertEquals(2.0, clean[1].y, 1e-12)
        assertEquals(0.0, clean[1].inX, 1e-12)
        assertEquals(1.0, clean[1].outX, 1e-12)
        val many = (1 until 40).map { pt(it / 40.0, 0.5, 0.005) }
        assertEquals(CurveMath.MAX_POINTS, CurveMath.sanitize(many).size)
    }

    @Test fun theEngineNumbersGoThereAndBack() {
        val c = KeyCurve(0.2, 0.1, 0.8, 0.9, listOf(pt(0.4, 0.6, 0.1), pt(0.6, 0.2, 0.05)))
        assertEquals(12, c.midFlat().size)
        assertEquals(c.mid, KeyCurve.pointsFromFlat(c.midFlat()))
        assertTrue(KeyCurve.pointsFromFlat(listOf(0.1, 0.2, 0.3)).isEmpty())
    }

    @Test fun sameAsLooksAtThePointsToo() {
        val a = KeyCurve(third, 0.0, 2 * third, 1.0, listOf(pt(0.5, 0.5, 0.1)))
        assertTrue(a.sameAs(a.copy()))
        assertFalse(a.sameAs(flatEase))
        assertFalse(a.sameAs(a.copy(mid = listOf(pt(0.5, 0.6, 0.1)))))
    }

    @Test fun savedCurvesWithPointsSurviveStorageAndOldOnesStillRead() {
        val withPoints = SavedCurve("Dos puntos", KeyCurve(0.2, 0.1, 0.8, 0.9, listOf(pt(0.4, 0.6, 0.1), pt(0.6, 0.2, 0.05))))
        val plain = SavedCurve("Simple", KeyCurve(0.3, 0.0, 0.7, 1.0))
        val back = CurveStore.decode(CurveStore.encode(listOf(plain, withPoints)))
        assertEquals(2, back.size)
        assertTrue(back[0].curve.sameAs(plain.curve) && back[0].curve.mid.isEmpty())
        assertTrue(back[1].curve.sameAs(withPoints.curve))
        // a line from before points existed: five fields
        val old = CurveStore.decode("Vieja|0.25|0.0|0.75|1.0")
        assertEquals(1, old.size)
        assertTrue(old[0].curve.mid.isEmpty())
        // a plain curve is still written in the old five-field form
        assertEquals(5, CurveStore.encode(listOf(plain)).split('|').size)
        // damaged lines are skipped, not half read
        assertTrue(CurveStore.decode("Rota|0.2|0.1|0.8|0.9|0.5|0.5").isEmpty())
    }
}
