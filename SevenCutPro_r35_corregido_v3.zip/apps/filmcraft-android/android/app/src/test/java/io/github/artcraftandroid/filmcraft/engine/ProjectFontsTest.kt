package io.github.artcraftandroid.filmcraft.engine

import java.io.File
import java.nio.file.Files
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ProjectFontsTest {
    private fun dir(): File = Files.createTempDirectory("fonts").toFile().also { it.deleteOnExit() }

    /** Stand-in "font" files: the test reads family names from the first line, like the engine would from the file. */
    private fun font(dir: File, name: String, family: String, filler: String = ""): File =
        File(dir, name).apply { writeText("$family\n$filler") }

    private val familiesOf: suspend (ByteArray) -> List<String> = { listOf(String(it).lineSequence().first()) }

    @Test
    fun a_font_is_copied_into_the_project_and_a_second_copy_is_not_made() {
        val a = dir()
        val b = dir()
        val src = font(a, "Fancy.ttf", "Fancy")
        val first = ProjectFonts.copyInto(src, b)
        assertNotNull(first)
        assertEquals("Fancy", first!!.readText().lineSequence().first())
        assertNull(ProjectFonts.copyInto(src, b)) // already there
        assertEquals(1, ProjectFonts.fontFiles(b).size)
    }

    @Test
    fun the_same_bytes_under_another_name_count_as_already_there() {
        val a = dir()
        val b = dir()
        font(b, "Old Name.ttf", "Fancy")
        assertNull(ProjectFonts.copyInto(font(a, "New Name.ttf", "Fancy"), b))
    }

    @Test
    fun a_different_font_with_the_same_file_name_is_kept_apart_not_overwritten() {
        val a = dir()
        val b = dir()
        font(b, "Fancy.ttf", "Fancy", "mine")
        val other = font(a, "Fancy.ttf", "Fancy", "theirs")
        val copy = ProjectFonts.copyInto(other, b)
        assertNotNull(copy)
        assertEquals("Fancy (1).ttf", copy!!.name)
        assertTrue(File(b, "Fancy.ttf").readText().endsWith("mine"))
        assertTrue(copy.readText().endsWith("theirs"))
    }

    @Test
    fun copyAll_brings_every_font_and_ignores_other_files() {
        val a = dir()
        val b = dir()
        font(a, "One.ttf", "One")
        font(a, "Two.OTF", "Two")
        File(a, "notes.txt").writeText("x")
        File(a, ".Three.ttf.tmp").writeText("half written")
        assertEquals(2, ProjectFonts.copyAll(a, b).size)
        assertEquals(listOf("One.ttf", "Two.OTF"), ProjectFonts.fontFiles(b).map { it.name })
    }

    @Test
    fun carry_finds_only_the_wanted_families_and_stops_when_all_are_found() = runBlocking {
        val others = dir()
        val mine = dir()
        val one = font(others, "a.ttf", "One")
        val two = font(others, "b.ttf", "Two")
        val three = font(others, "c.ttf", "Three")
        val carried = ProjectFonts.carry(listOf("two", "ONE"), listOf(one, two, three), mine, familiesOf) // names match without case
        assertEquals(setOf("One", "Two"), carried.flatMap { it.families }.toSet())
        assertEquals(2, ProjectFonts.fontFiles(mine).size)
        // "Three" was never wanted, so it was not copied
        assertTrue(ProjectFonts.fontFiles(mine).none { it.readText().startsWith("Three") })
    }

    @Test
    fun carry_with_nothing_found_copies_nothing_and_does_not_fail() = runBlocking {
        val others = dir()
        val mine = dir()
        val carried = ProjectFonts.carry(listOf("Nobody Has It"), listOf(font(others, "a.ttf", "One")), mine, familiesOf)
        assertTrue(carried.isEmpty())
        assertTrue(ProjectFonts.fontFiles(mine).isEmpty())
    }

    @Test
    fun carry_survives_a_file_the_engine_cannot_read() = runBlocking {
        val others = dir()
        val mine = dir()
        val bad = font(others, "bad.ttf", "Broken")
        val good = font(others, "good.ttf", "Fine")
        val reader: suspend (ByteArray) -> List<String> = { bytes -> if (String(bytes).startsWith("Broken")) error("unreadable") else listOf("Fine") }
        val carried = ProjectFonts.carry(listOf("Fine"), listOf(bad, good), mine, reader)
        assertEquals(1, carried.size)
    }
}
