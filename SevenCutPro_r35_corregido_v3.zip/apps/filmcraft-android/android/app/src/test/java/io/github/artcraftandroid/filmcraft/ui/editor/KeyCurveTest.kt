package io.github.artcraftandroid.filmcraft.ui.editor

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class KeyCurveTest {
    @Test fun linearHandlesMakeAStraightLine() {
        for (i in 0..10) assertEquals(i / 10.0, KeyCurve.LINEAR.at(i / 10.0), 1e-6)
    }

    @Test fun standardShapesMatchTheKeyEaseTiles() {
        for (kind in KeyEase.entries) {
            val c = KeyCurve.of(kind) ?: continue
            for (i in 0..10) assertEquals("$kind at $i", kind.at(i / 10.0), c.at(i / 10.0), 1e-9)
        }
        assertNull(KeyCurve.of(KeyEase.Hold))
    }

    @Test fun endpointsAreAlwaysZeroAndOne() {
        val wild = KeyCurve(0.2, 1.8, 0.7, -0.9)
        assertEquals(0.0, wild.at(0.0), 1e-9)
        assertEquals(1.0, wild.at(1.0), 1e-9)
    }

    @Test fun aHandleAboveOneOvershoots() {
        val c = KeyCurve(0.3, 0.0, 0.6, 1.6)
        assertTrue((0..100).maxOf { c.at(it / 100.0) } > 1.0)
    }

    @Test fun fastStartSoftEndIsAheadOfLinear() {
        assertTrue(KeyCurve(0.1, 0.9, 0.5, 1.0).at(0.25) > 0.5)
        assertTrue(KeyCurve(0.5, 0.0, 0.9, 0.1).at(0.25) < 0.25)
    }

    @Test fun clampingMatchesTheEngineLimits() {
        val c = KeyCurve(5.0, -9.0, -3.0, 9.0).clamped()
        assertEquals(1.0, c.x1, 0.0); assertEquals(-1.0, c.y1, 0.0); assertEquals(0.0, c.x2, 0.0); assertEquals(2.0, c.y2, 0.0)
        assertEquals(0.01, KeyCurve(0.0, 0.0, 0.5, 0.5).clamped().x1, 0.0)
        assertEquals(0.99, KeyCurve(0.5, 0.0, 1.0, 0.5).clamped().x2, 0.0)
    }

    @Test fun savedCurvesRoundTrip() {
        val list = listOf(SavedCurve("Bounce", KeyCurve(0.3, 0.0, 0.6, 1.6)), SavedCurve("Fast out", KeyCurve(0.1, 0.9, 0.5, 1.0)))
        val back = CurveStore.decode(CurveStore.encode(list))
        assertEquals(list.map { it.name }, back.map { it.name })
        for (i in list.indices) assertTrue(list[i].curve.sameAs(back[i].curve))
    }

    @Test fun badOrEmptyStoredTextIsIgnored() {
        assertTrue(CurveStore.decode(null).isEmpty())
        assertTrue(CurveStore.decode("").isEmpty())
        val ok = CurveStore.decode("junk\nA|0.1|0.2|0.3|0.4\nB|x|1|2|3\nC|1|2|3\n|0.1|0.1|0.2|0.2")
        assertEquals(listOf("A"), ok.map { it.name })
    }

    @Test fun namesAreCleanedAndNumbersClamped() {
        val s = CurveStore.encode(listOf(SavedCurve("a|b\nc", KeyCurve(9.0, 9.0, 9.0, 9.0))))
        val back = CurveStore.decode(s)
        assertEquals(1, back.size)
        assertFalse(back[0].name.contains('|'))
        assertEquals(2.0, back[0].curve.y1, 0.0)
    }

    @Test fun nextNameIsFree() {
        assertEquals("Curve 1", CurveStore.nextName(emptyList()))
        assertEquals("Curve 3", CurveStore.nextName(listOf(SavedCurve("Curve 2", KeyCurve.LINEAR), SavedCurve("x", KeyCurve.LINEAR))))
    }

    @Test fun listIsCapped() {
        val many = (1..40).map { SavedCurve("c$it", KeyCurve.LINEAR) }
        assertEquals(CurveStore.MAX_CURVES, CurveStore.decode(CurveStore.encode(many)).size)
    }

    // ---- r24: presets window and named presets ----

    @Test fun everyBuiltInPresetIsWithinTheEngineLimitsAndHasAUniqueNameAndId() {
        val all = CurvePresets.all
        assertEquals(all.size, all.map { it.id }.toSet().size)
        assertEquals(all.size, all.map { it.label }.toSet().size)
        for (p in all) {
            val c = p.curve ?: continue
            assertTrue(p.id, c.clamped().sameAs(c))
            assertEquals(p.id, 0.0, c.at(0.0), 1e-9)
            assertEquals(p.id, 1.0, c.at(1.0), 1e-9)
        }
        // the six named in the request come first, in that order
        assertEquals(listOf("Ninguna", "Lineal", "Suavizado", "Entrada suave", "Salida suave", "Entrada y salida suave"), all.take(6).map { it.label })
        assertNull(all.first { it.id == "none" }.curve)
    }

    @Test fun standardPresetsKeepTheEngineTypesSoOlderKeyframesStayRecognised() {
        val byId = CurvePresets.all.associateBy { it.id }
        assertEquals(KeyEase.Linear, byId.getValue("linear").kind)
        assertEquals(KeyEase.EaseIn, byId.getValue("ease_in").kind)
        assertEquals(KeyEase.EaseOut, byId.getValue("ease_out").kind)
        assertEquals(KeyEase.Bezier, byId.getValue("ease_in_out").kind)
        assertEquals(KeyEase.Hold, byId.getValue("none").kind)
        // every type the engine knows still has a tile
        for (k in KeyEase.entries) assertTrue(k.toString(), CurvePresets.all.any { it.kind == k })
    }

    @Test fun aPresetIsActiveOnlyWhenTheKeyframeIsThatPreset() {
        val lin = CurvePresets.all.first { it.id == "linear" }
        val smooth = CurvePresets.all.first { it.id == "smooth" }
        assertTrue(CurvePresets.isActive(lin, "linear", false, KeyCurve.LINEAR))
        assertFalse("an edited linear is no longer Lineal", CurvePresets.isActive(lin, "linear", true, KeyCurve(0.2, 0.2, 0.7, 0.7)))
        assertFalse(CurvePresets.isActive(lin, "ease_in", false, KeyCurve.LINEAR))
        assertTrue(CurvePresets.isActive(smooth, "bezier", true, smooth.curve!!))
        assertFalse(CurvePresets.isActive(smooth, "bezier", false, smooth.curve!!))
        assertFalse(CurvePresets.isActive(smooth, "bezier", true, KeyCurve(0.3, 0.1, 0.25, 1.0)))
        assertTrue(CurvePresets.isActive(CurvePresets.all.first { it.id == "none" }, "hold", false, KeyCurve.LINEAR))
    }

    @Test fun savingUnderANameAddsReplacesAndRespectsTheLimit() {
        val a = KeyCurve(0.3, 0.0, 0.6, 1.6)
        val b = KeyCurve(0.1, 0.9, 0.5, 1.0)
        val one = CurveStore.addNamed(emptyList(), "  Mi curva ", a)
        assertEquals(SaveResult.Added, one.result)
        assertEquals("Mi curva", one.name)
        val two = CurveStore.addNamed(one.list, "mi CURVA", b)
        assertEquals(SaveResult.Replaced, two.result)
        assertEquals(1, two.list.size)
        assertTrue(two.list[0].curve.sameAs(b))
        assertEquals("Mi curva", two.list[0].name)
        // a blank name gets the next free "Curve N"
        assertEquals("Curve 2", CurveStore.addNamed(one.list, "   ", a).name)
        // names are cleaned like the stored ones, and a full list is left as it is
        assertEquals("a b c", CurveStore.addNamed(emptyList(), "a|b\nc", a).name)
        val full = (1..CurveStore.MAX_CURVES).map { SavedCurve("N$it", a) }
        val over = CurveStore.addNamed(full, "Otra", b)
        assertEquals(SaveResult.Full, over.result)
        assertEquals(full, over.list)
        // what was saved survives the store's text format
        val back = CurveStore.decode(CurveStore.encode(one.list))
        assertEquals("Mi curva", back[0].name)
        assertTrue(back[0].curve.sameAs(a.clamped()))
    }

    @Test fun everyCardHasAShortUniqueNameThatFitsOneLine() {
        val shorts = CurvePresets.all.map { it.short }
        assertEquals(shorts.size, shorts.toSet().size)
        for (p in CurvePresets.all) {
            assertTrue(p.id, p.short.isNotBlank() && p.short != p.id)
            assertTrue("${p.short} is too long for a card", p.short.length <= 11)
        }
        assertEquals(listOf("Ninguna", "Lineal", "Suave", "Entrada", "Salida", "Ent./Sal."), CurvePresets.all.take(6).map { it.short })
        // only "Ninguna" (a step) has no curve to adjust
        assertEquals(listOf("none"), CurvePresets.all.filter { !it.adjustable }.map { it.id })
    }

    @Test fun everyPresetDrawsADifferentCurveExceptTheBezierTypesThatShareOne() {
        // Bezier, Auto Bezier and Continuous Bezier are the same shape between two keys by design (the engine differs in how the
        // neighbouring keys are handled): their cards tell them apart with a mark on the middle key, not with another curve.
        val shared = setOf("ease_in_out", "auto_bezier", "continuous_bezier")
        val us = (0..40).map { it / 40.0 }
        val all = CurvePresets.all
        for (a in all.indices) for (b in a + 1 until all.size) {
            val (p, q) = all[a] to all[b]
            if (p.id in shared && q.id in shared) continue
            val gap = us.maxOf { u -> kotlin.math.abs(p.at(u) - q.at(u)) }
            assertTrue("${p.id} and ${q.id} look alike (max gap $gap)", gap >= 0.05)
        }
    }
}
