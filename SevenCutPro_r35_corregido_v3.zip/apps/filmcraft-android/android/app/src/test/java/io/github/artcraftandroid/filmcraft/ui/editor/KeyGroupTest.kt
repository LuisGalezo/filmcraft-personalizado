package io.github.artcraftandroid.filmcraft.ui.editor

import org.junit.Assert.assertEquals
import org.junit.Test

class KeyGroupTest {
    @Test fun audioClipOrSoundToolsUseAudio() {
        assertEquals(KeyGroup.AUDIO, KeyGroup.of(clipIsAudio = true, soundToolOpen = false))
        assertEquals(KeyGroup.AUDIO, KeyGroup.of(clipIsAudio = false, soundToolOpen = true))
        assertEquals(KeyGroup.TRANSFORM, KeyGroup.of(clipIsAudio = false, soundToolOpen = false))
    }

    @Test fun eachGroupSeesOnlyItsOwnKeys() {
        val t = listOf(10L, 20L)
        val a = listOf(20L, 30L)
        assertEquals(t, KeyGroup.keys(KeyGroup.TRANSFORM, t, a))
        assertEquals(a, KeyGroup.keys(KeyGroup.AUDIO, t, a))
        assertEquals(KeyGroup.TRANSFORM, KeyGroup.other(KeyGroup.AUDIO))
        assertEquals(KeyGroup.AUDIO, KeyGroup.other(KeyGroup.TRANSFORM))
    }
}
