package io.github.artcraftandroid.filmcraft.ui.editor

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** First tap, second tap and double tap on timeline layers (selection, deselection, double-tap actions). */
class TapTrackerTest {
    private val timeout = 300L

    /**
     * The editor's side of a tap, driven by the same [TapTracker] and [clipTapEffect] the timeline
     * uses: which clip is selected, and what was opened.
     */
    private class Editor(val composition: Set<ULong> = emptySet(), val text: Set<ULong> = emptySet()) {
        val taps = TapTracker()
        var selected: ULong? = null
        var textEditorsOpened = 0
        var compositionsOpened = 0
        var selectCalls = 0

        fun tap(id: ULong, now: Long) {
            val r = taps.tap(id, selected == id, now, 300L)
            when (clipTapEffect(r, id in composition, id in text)) {
                ClipTapEffect.Deselect -> { selectCalls++; selected = null }
                ClipTapEffect.Select -> { selectCalls++; selected = id }
                ClipTapEffect.OpenComposition -> { selectCalls++; selected = id; compositionsOpened++ }
                ClipTapEffect.EditText -> { selectCalls++; selected = id; textEditorsOpened++ }
            }
        }
    }

    @Test
    fun firstTapSelectsSecondTapOnTheSameLayerDeselects() {
        val e = Editor()
        e.tap(1uL, 0)
        assertEquals(1uL, e.selected)
        e.tap(1uL, 1000) // well after the double-tap window: a second, separate tap
        assertEquals(null, e.selected)
        e.tap(1uL, 2000)
        assertEquals(1uL, e.selected)
    }

    @Test
    fun tappingAnotherLayerSelectsItNormally() {
        val e = Editor()
        e.tap(1uL, 0)
        e.tap(2uL, 1000)
        assertEquals(2uL, e.selected)
        // and the first one is again a first tap, not a deselect
        e.tap(1uL, 2000)
        assertEquals(1uL, e.selected)
    }

    @Test
    fun quickTapOnAnotherLayerAndBackIsNotADoubleTap() {
        val e = Editor(text = setOf(1uL))
        e.tap(1uL, 0)
        e.tap(2uL, 100)
        e.tap(1uL, 200) // the last tap was on 2, so this is a plain first tap on 1
        assertEquals(1uL, e.selected)
        assertEquals(0, e.textEditorsOpened)
    }

    @Test
    fun doubleTapOnATextOpensItsEditorOnceAndLeavesItSelected() {
        val e = Editor(text = setOf(7uL))
        e.tap(7uL, 0)
        e.tap(7uL, 150)
        assertEquals(7uL, e.selected)
        assertEquals(1, e.textEditorsOpened)
    }

    @Test
    fun doubleTapOnAnAlreadySelectedTextDoesNotDeselectIt() {
        val e = Editor(text = setOf(7uL))
        e.tap(7uL, 0) // selected
        // a later double tap: its first tap deselects (a separate tap on the selected layer) ...
        e.tap(7uL, 2000)
        assertEquals(null, e.selected)
        // ... and its second tap, within the window, selects it again and opens the editor, once
        e.tap(7uL, 2150)
        assertEquals(7uL, e.selected)
        assertEquals(1, e.textEditorsOpened)
    }

    @Test
    fun doubleTapWhoseFirstTapIsStillInFlightEndsSelected() {
        // The engine confirms a selection a moment later, so when the second tap lands the timeline may
        // still say "not selected" (or "selected" while a deselect is on its way). Either way the double
        // tap asks for a selection, never a deselect.
        for (reportedSelected in listOf(false, true)) {
            val t = TapTracker()
            t.tap(7uL, reportedSelected, 0, timeout)
            val second = t.tap(7uL, reportedSelected, 120, timeout)
            assertTrue(second.doubleTap)
            assertEquals(TapAction.Select, second.action)
            assertEquals(ClipTapEffect.EditText, clipTapEffect(second, composition = false, text = true))
        }
    }

    @Test
    fun aDoubleTapIsOneDoubleTapNotTwo() {
        val e = Editor(text = setOf(7uL))
        e.tap(7uL, 0)
        e.tap(7uL, 100)
        e.tap(7uL, 200) // a third quick tap is a new first tap on a selected layer: it deselects
        assertEquals(1, e.textEditorsOpened)
        assertEquals(null, e.selected)
    }

    @Test
    fun doubleTapOnACompositionOpensItAndOnAPlainClipIsJustASelection() {
        val e = Editor(composition = setOf(3uL))
        e.tap(3uL, 0)
        e.tap(3uL, 100)
        assertEquals(1, e.compositionsOpened)
        assertEquals(3uL, e.selected)

        val plain = Editor()
        plain.tap(5uL, 0)
        plain.tap(5uL, 100)
        assertEquals(5uL, plain.selected)
        assertEquals(0, plain.textEditorsOpened + plain.compositionsOpened)
    }

    @Test
    fun theDoubleTapWindowIsInclusiveAndEndsAfterIt() {
        val t = TapTracker()
        t.tap(1uL, false, 1000, timeout)
        assertTrue(t.tap(1uL, true, 1300, timeout).doubleTap)
        t.reset()
        t.tap(1uL, false, 1000, timeout)
        assertFalse(t.tap(1uL, true, 1301, timeout).doubleTap)
    }

    @Test
    fun aDragOrPinchBetweenTapsBreaksTheDoubleTap() {
        val t = TapTracker()
        t.tap(1uL, false, 0, timeout)
        t.reset() // what the timeline does when the finger scrubs, scrolls, pinches or holds
        val r = t.tap(1uL, true, 100, timeout)
        assertFalse(r.doubleTap)
        assertEquals(TapAction.Deselect, r.action)
    }

    @Test
    fun aClockThatGoesBackwardsIsNeverADoubleTap() {
        val t = TapTracker()
        t.tap(1uL, false, 5000, timeout)
        assertFalse(t.tap(1uL, true, 4000, timeout).doubleTap)
    }
}
