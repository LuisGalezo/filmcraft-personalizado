package io.github.artcraftandroid.filmcraft.ui.editor

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.PI
import kotlin.math.sin

class FadeCurveTest {
    private val sec = TPS

    @Test fun noFadeIsFullLevelEverywhere() {
        for (t in listOf(0L, sec, 2 * sec, 4 * sec)) assertEquals(1.0, FadeCurve.gain(t, 4 * sec, 0, 0), 1e-9)
    }

    @Test fun fadeInRisesFromSilenceToFull() {
        assertEquals(0.0, FadeCurve.gain(0, 4 * sec, sec, 0), 1e-9)
        assertEquals(sin(PI / 4), FadeCurve.gain(sec / 2, 4 * sec, sec, 0), 1e-9)
        assertEquals(1.0, FadeCurve.gain(sec, 4 * sec, sec, 0), 1e-9)
        assertEquals(1.0, FadeCurve.gain(2 * sec, 4 * sec, sec, 0), 1e-9)
        var last = -1.0
        for (i in 0..20) { val g = FadeCurve.gain(i * sec / 20, 4 * sec, sec, 0); assertTrue(g >= last); last = g }
    }

    @Test fun fadeOutFallsToSilenceAtTheEnd() {
        assertEquals(1.0, FadeCurve.gain(3 * sec, 4 * sec, 0, sec), 1e-9)
        assertEquals(sin(PI / 4), FadeCurve.gain(3 * sec + sec / 2, 4 * sec, 0, sec), 1e-9)
        assertEquals(0.0, FadeCurve.gain(4 * sec, 4 * sec, 0, sec), 1e-9)
    }

    @Test fun bothFadesOnOneClip() {
        val d = 4 * sec
        assertEquals(0.0, FadeCurve.gain(0, d, sec, sec), 1e-9)
        assertEquals(1.0, FadeCurve.gain(2 * sec, d, sec, sec), 1e-9)
        assertEquals(0.0, FadeCurve.gain(d, d, sec, sec), 1e-9)
    }
}
