package io.github.artcraftandroid.filmcraft.ui.editor

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

/**
 * The edits a finger makes while it is still moving a control (a slider, the preview's move/scale/
 * turn, typing), applied "newest wins": while one edit is being applied, any number of newer changes
 * of the same control (same [key]) collapse into the last one. One worker applies them one at a time
 * through [apply], so a fast drag costs one engine round trip and one picture per step the engine can
 * keep up with, instead of a queue that grows with every touch event and makes the preview trail the
 * finger. The last value of every control is always applied.
 *
 * Pure Kotlin (no Android, no Compose) so it is tested off the phone ([LiveEditQueueTest]). Call it
 * from one thread only (the UI thread): [scope] must run on that thread too.
 */
class LiveEditQueue<T : Any>(
    private val scope: CoroutineScope,
    private val apply: suspend (T) -> Unit,
) {
    private val latest = LinkedHashMap<String, T>()
    private var running = false

    /** Number of controls with a change waiting. */
    val pending: Int get() = latest.size

    /** A new value for control [key]; it replaces one still waiting for the same control. */
    fun submit(key: String, edit: T) {
        latest[key] = edit
        if (running) return
        running = true
        scope.launch {
            try {
                while (true) {
                    val next = latest.entries.firstOrNull() ?: break
                    latest.remove(next.key)
                    apply(next.value)
                }
            } finally {
                running = false
            }
        }
    }

    /**
     * Take what is waiting, so a later (non-live) edit can run right after it and the order the user
     * made them in is kept. Edits already being applied are ahead of it in the engine's queue.
     */
    fun takePending(): List<T> {
        if (latest.isEmpty()) return emptyList()
        val all = latest.values.toList()
        latest.clear()
        return all
    }
}
