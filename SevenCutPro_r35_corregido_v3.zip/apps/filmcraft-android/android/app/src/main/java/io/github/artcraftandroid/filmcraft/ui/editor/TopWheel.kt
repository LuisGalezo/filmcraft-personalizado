package io.github.artcraftandroid.filmcraft.ui.editor

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.PagerState
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import io.github.artcraftandroid.filmcraft.ui.Fc
import io.github.artcraftandroid.filmcraft.ui.FcIconButton
import io.github.artcraftandroid.filmcraft.ui.LucideIcons
import io.github.artcraftandroid.filmcraft.ui.glyph

/** When the top bar's wheel may turn and where it settles; kept apart from Compose so it can be tested. */
object WheelRule {
    const val UNDO_REDO = 0
    const val KEYFRAMES = 1

    /** A swipe changes the view only while the wheel is not locked. */
    fun canScroll(locked: Boolean): Boolean = !locked

    /** The view the wheel rests on: the Keyframes view means nothing without a selected layer, so it goes back to Undo / Redo (unless locked). */
    fun settle(page: Int, nothingSelected: Boolean, locked: Boolean): Int =
        if (nothingSelected && !locked && page == KEYFRAMES) UNDO_REDO else page
}

/**
 * The top bar's wheel: one slot that scrolls vertically between two views, like a clock's wheel, with a fade at its
 * top and bottom edge while it moves.
 *  - view 1 (the one it starts on): Undo and Redo;
 *  - view 2: Keyframes and Curves.
 * Next to it a small strip shows which view is on (two dots, the active one bright) and holds the lock: an empty
 * circle lets a swipe change the view, a filled one keeps the view that is showing so it cannot move by accident.
 * It is always [size] × 2 wide plus the strip, so the Play button beside it never moves.
 */
@Composable
fun KeyUndoWheel(
    ed: EditorController,
    size: Dp,
    iconSize: Dp,
    undoTag: String,
    redoTag: String,
    modifier: Modifier = Modifier,
) {
    val st = ed.status
    val pager = rememberPagerState(initialPage = ed.wheelPage.coerceIn(0, 1), pageCount = { 2 })
    // the page the wheel is on is kept in the controller, so a rotation or a layout change reopens on the same view
    LaunchedEffect(pager) { snapshotFlow { pager.currentPage }.collect { ed.wheelPage = it } }
    // without a selected layer there is nothing to show on the keyframes view: back to Undo / Redo (unless locked)
    val nothingSelected = ed.selectedClip == null
    LaunchedEffect(nothingSelected, ed.wheelLocked) {
        val target = WheelRule.settle(pager.currentPage, nothingSelected, ed.wheelLocked)
        if (target != pager.currentPage) pager.animateScrollToPage(target)
    }
    Row(modifier, verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.width(size * 2).height(size).testTag("editor_wheel")) {
            VerticalPager(
                state = pager,
                userScrollEnabled = WheelRule.canScroll(ed.wheelLocked),
                modifier = Modifier.width(size * 2).height(size),
            ) { page ->
                Row(Modifier.width(size * 2).height(size), verticalAlignment = Alignment.CenterVertically) {
                    if (page == 0) {
                        FcIconButton(LucideIcons.Undo2.glyph(), "Undo", { ed.undo() }, enabled = st?.canUndo == true, size = size, iconSize = iconSize, modifier = Modifier.testTag(undoTag))
                        FcIconButton(LucideIcons.Redo2.glyph(), "Redo", { ed.redo() }, enabled = st?.canRedo == true, size = size, iconSize = iconSize, modifier = Modifier.testTag(redoTag))
                    } else {
                        KeyframeButton(ed, size)
                        KeyframeEaseButton(ed, size)
                    }
                }
            }
            WheelEdges(pager, size)
        }
        WheelLock(ed, pager, size)
    }
}

/** The soft fade at the wheel's top and bottom edge: strongest where a view is leaving, gone when it rests. */
@Composable
private fun WheelEdges(pager: PagerState, size: Dp) {
    // how far from resting the wheel is: 0 at rest, 1 half way between the two views
    val moving = (pager.currentPageOffsetFraction.let { kotlin.math.abs(it) } * 2f).coerceIn(0f, 1f)
    val edge = size * 0.32f
    Box(Modifier.fillMaxWidth().height(size)) {
        Box(
            Modifier.align(Alignment.TopCenter).fillMaxWidth().height(edge).alpha(0.35f + 0.65f * moving)
                .background(Brush.verticalGradient(listOf(Fc.Black, Color.Transparent))),
        )
        Box(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(edge).alpha(0.35f + 0.65f * moving)
                .background(Brush.verticalGradient(listOf(Color.Transparent, Fc.Black))),
        )
    }
}

/** Two dots (which view is on) around the lock circle (empty: the wheel turns; filled: it is held where it is). */
@Composable
private fun WheelLock(ed: EditorController, pager: PagerState, size: Dp) {
    val haptic = LocalHapticFeedback.current
    val locked = ed.wheelLocked
    val label = if (locked) "Unlock the wheel" else "Lock the wheel on this view"
    Box(
        Modifier
            .width(22.dp)
            .height(size)
            .clickable(role = Role.Button, onClickLabel = label) {
                ed.wheelLocked = !ed.wheelLocked
                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
            }
            .testTag("editor_wheel_lock")
            .semantics { contentDescription = label },
        contentAlignment = Alignment.Center,
    ) {
        Canvas(Modifier.size(width = 14.dp, height = 32.dp)) {
            val cx = this.size.width / 2
            val cy = this.size.height / 2
            val dot = 2.5.dp.toPx()
            val gap = 12.dp.toPx()
            val page = pager.currentPage
            drawCircle(Color.White.copy(alpha = if (page == 0) 1f else 0.3f), dot, Offset(cx, cy - gap))
            drawCircle(Color.White.copy(alpha = if (page == 1) 1f else 0.3f), dot, Offset(cx, cy + gap))
            val r = 5.dp.toPx()
            if (locked) drawCircle(Color.White, r, Offset(cx, cy)) else drawCircle(Color.White.copy(alpha = 0.85f), r, Offset(cx, cy), style = Stroke(1.5.dp.toPx()))
        }
    }
}
