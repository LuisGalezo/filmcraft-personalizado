package io.github.artcraftandroid.filmcraft.ui.editor

/**
 * Where a dragged layer's stand-in picture goes while a finger moves, scales or turns it.
 *
 * The stand-in is the layer drawn alone at the placement the finger found it at (`start`). The picture
 * of the layer at the placement it has now (`now`) is that picture scaled by `now.scale / start.scale` and turned by the
 * rotation difference, both about the layer's start centre, then shifted by how far the centre moved. That is
 * exactly what a GPU layer does with `transformOrigin`, `scale`, `rotationZ` and `translation`, so the screen
 * shows the layer where the engine will put it, with no engine call. Pure Kotlin, tested off the phone.
 *
 * All positions are in frame pixels (the sequence's size); [pxPerFramePx] turns a distance into screen pixels.
 */
object DragStandIn {
    class Transform(
        /** The pivot as a fraction of the frame (0..1 across, 0..1 down). */
        val originX: Float,
        val originY: Float,
        /** Screen pixels. */
        val translationX: Float,
        val translationY: Float,
        val scale: Float,
        /** Degrees, clockwise. */
        val rotationDeg: Float,
    )

    fun between(
        startX: Double, startY: Double, startScale: Double, startRotation: Double,
        nowX: Double, nowY: Double, nowScale: Double, nowRotation: Double,
        frameWidth: Double, frameHeight: Double, pxPerFramePx: Double,
    ): Transform {
        val ratio = if (startScale > 0.0 && nowScale.isFinite()) nowScale / startScale else 1.0
        return Transform(
            originX = (startX / frameWidth.coerceAtLeast(1.0)).toFloat(),
            originY = (startY / frameHeight.coerceAtLeast(1.0)).toFloat(),
            translationX = ((nowX - startX) * pxPerFramePx).toFloat(),
            translationY = ((nowY - startY) * pxPerFramePx).toFloat(),
            scale = ratio.toFloat(),
            rotationDeg = (nowRotation - startRotation).toFloat(),
        )
    }
}
