package io.github.artcraftandroid.filmcraft.ui.export

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder

/**
 * Keeps the app alive while a video is being exported, so the export carries on when the user leaves
 * the editor or switches to another app. It does NOT export anything itself: the export is the engine's
 * own (started and followed by `AppViewModel.startExport`); this service only holds the process in the
 * foreground and shows the progress notification with a Cancel action.
 *
 * Start it with [begin] (while the app is on screen, as Android requires), feed it with [progress], and
 * end it with [finished] or [stop]. [onCancel] is what the notification's Cancel button runs.
 */
class ExportService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_CANCEL -> {
                // the export's owner stops it and ends this service; with no owner (the process was recreated) there is nothing to cancel
                val handler = onCancel
                if (handler != null) handler() else stopSelf()
            }
            else -> promote()
        }
        // never restarted by the system: a killed export is not silently resumed
        return START_NOT_STICKY
    }

    /** Android 15 ends a foreground service of this kind after a long time: stop cleanly instead of being killed. */
    override fun onTimeout(startId: Int, fgsType: Int) {
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        running = false
        super.onDestroy()
    }

    private fun promote() {
        ensureChannel(this)
        val n = build(this, lastPercent, indeterminate = lastPercent <= 0)
        if (Build.VERSION.SDK_INT >= 29) {
            // media processing exists from Android 15; before that the closest type is data sync
            val type = if (Build.VERSION.SDK_INT >= 35) ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROCESSING else ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
            startForeground(ONGOING_ID, n, type)
        } else {
            startForeground(ONGOING_ID, n)
        }
        running = true
    }

    companion object {
        private const val CHANNEL = "export"
        private const val ONGOING_ID = 4101
        private const val FINAL_ID = 4102
        private const val ACTION_CANCEL = "io.github.artcraftandroid.filmcraft.EXPORT_CANCEL"

        @Volatile private var running = false
        @Volatile private var lastPercent = 0

        /** What the notification's Cancel button runs (set while an export is going). */
        @Volatile var onCancel: (() -> Unit)? = null

        /** Whether the service is up (used to avoid starting a second one). */
        val isRunning: Boolean get() = running

        /** Start the foreground service for an export; [cancel] stops that export. Safe to call twice. */
        fun begin(context: Context, cancel: () -> Unit) {
            onCancel = cancel
            lastPercent = 0
            runCatching {
                val i = Intent(context, ExportService::class.java)
                if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(i) else context.startService(i)
            }
        }

        /** Update the percentage (0..100); the notification changes only when the number does. */
        fun progress(context: Context, percent: Int) {
            val p = percent.coerceIn(0, 100)
            if (p == lastPercent || !running) return
            lastPercent = p
            runCatching { manager(context).notify(ONGOING_ID, build(context, p, indeterminate = false)) }
        }

        /** The engine has finished and the file is being copied into Movies: say so instead of sitting at 95 %. */
        fun saving(context: Context) {
            if (!running) return
            lastPercent = 96
            runCatching { manager(context).notify(ONGOING_ID, build(context, 96, indeterminate = true, text = "Saving to Movies…")) }
        }

        /** Stop the service and remove its notification. */
        fun stop(context: Context) {
            onCancel = null
            lastPercent = 0
            runCatching { context.stopService(Intent(context, ExportService::class.java)) }
        }

        /** End with a message the user can read later ("Export finished" / the error). Replaces the ongoing notification. */
        fun finished(context: Context, ok: Boolean, message: String?) {
            ensureChannel(context)
            val open = context.packageManager.getLaunchIntentForPackage(context.packageName)?.let {
                PendingIntent.getActivity(context, 0, it, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            }
            val b = notificationBuilder(context)
                .setSmallIcon(if (ok) android.R.drawable.stat_sys_download_done else android.R.drawable.stat_notify_error)
                .setContentTitle(if (ok) "Export finished" else "Export failed")
                .setContentText(message ?: if (ok) "Your video is saved in Movies." else "The export did not finish.")
                .setAutoCancel(true)
                .setOngoing(false)
            if (open != null) b.setContentIntent(open)
            runCatching { manager(context).notify(FINAL_ID, b.build()) }
        }

        private fun manager(context: Context) = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        private fun ensureChannel(context: Context) {
            if (Build.VERSION.SDK_INT < 26) return
            val m = manager(context)
            if (m.getNotificationChannel(CHANNEL) == null) {
                // quiet: no sound or vibration for a progress bar
                m.createNotificationChannel(NotificationChannel(CHANNEL, "Video export", NotificationManager.IMPORTANCE_LOW))
            }
        }

        @Suppress("DEPRECATION")
        private fun notificationBuilder(context: Context): Notification.Builder =
            if (Build.VERSION.SDK_INT >= 26) Notification.Builder(context, CHANNEL) else Notification.Builder(context)

        private fun build(context: Context, percent: Int, indeterminate: Boolean, text: String? = null): Notification {
            val cancel = PendingIntent.getService(
                context, 1, Intent(context, ExportService::class.java).setAction(ACTION_CANCEL),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
            )
            val open = context.packageManager.getLaunchIntentForPackage(context.packageName)?.let {
                PendingIntent.getActivity(context, 0, it, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            }
            val b = notificationBuilder(context)
                .setSmallIcon(android.R.drawable.stat_sys_upload)
                .setContentTitle("Exporting video")
                .setContentText(text ?: if (indeterminate) "Starting…" else "$percent%")
                .setProgress(100, percent, indeterminate)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .addAction(Notification.Action.Builder(null, "Cancel", cancel).build())
            if (open != null) b.setContentIntent(open)
            if (Build.VERSION.SDK_INT >= 31) b.setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE)
            return b.build()
        }
    }
}
