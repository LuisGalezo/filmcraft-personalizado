package io.github.artcraftandroid.filmcraft.engine

import android.content.ContentResolver
import android.content.Context
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import android.provider.OpenableColumns
import android.system.Os
import android.webkit.MimeTypeMap
import java.io.File
import java.io.InputStream
import java.io.OutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import java.text.DateFormat
import java.util.Date
import java.util.UUID
import java.security.MessageDigest
import org.json.JSONArray
import org.json.JSONObject

/** One project on the Home screen. */
data class ProjectEntry(
    val id: String,
    val name: String,
    /** Last opened, ms since the epoch: Home lists the newest first. */
    val opened: Long,
    val created: Long,
    /** Length in ticks. */
    val duration: Long,
    val width: Int,
    val height: Int,
    val dir: File,
) {
    val projectFile: File get() = File(dir, PROJECT_FILE)
    val poster: File get() = File(dir, POSTER_FILE)
    val mediaDir: File get() = File(dir, MEDIA_DIR)
    /** Fonts bundled with this project; global fonts remain supported for older projects. */
    val fontsDir: File get() = File(dir, FONTS_DIR)

    companion object {
        const val PROJECT_FILE = "project.fcproj"
        const val POSTER_FILE = "poster.jpg"
        const val MEDIA_DIR = "media"
        const val FONTS_DIR = "fonts"
        const val META_FILE = "meta.json"
    }
}

/**
 * The projects in the app's storage: each a folder `projects/<id>/` holding the engine's project
 * file, `meta.json` (name and dates), a poster frame and a `media/` folder with copies of the
 * files it uses (so a project keeps working when the originals move).
 */
class Projects(private val context: Context) {
    private val root = File(context.filesDir, "projects").apply { mkdirs() }

    /** Where the app kept custom fonts before every project had its own `fonts/` folder (still read, never written). */
    val legacyFontsDir: File get() = File(context.filesDir, "custom_fonts")

    /** Every project, last opened first. */
    @Synchronized
    fun list(): List<ProjectEntry> =
        root.listFiles { f -> f.isDirectory }.orEmpty().mapNotNull { read(it) }.sortedByDescending { it.opened }

    fun find(id: String): ProjectEntry? = read(File(root, id))

    private fun read(dir: File): ProjectEntry? {
        val meta = File(dir, ProjectEntry.META_FILE)
        if (!meta.isFile) return null
        return runCatching {
            val j = JSONObject(meta.readText())
            ProjectEntry(
                id = dir.name,
                name = j.optString("name", "Untitled"),
                opened = j.optLong("opened", 0L),
                created = j.optLong("created", 0L),
                duration = j.optLong("duration", 0L),
                width = j.optInt("width", 1080),
                height = j.optInt("height", 1920),
                dir = dir,
            )
        }.getOrNull()
    }

    @Synchronized
    fun write(p: ProjectEntry) {
        val j = JSONObject()
            .put("name", p.name)
            .put("opened", p.opened)
            .put("created", p.created)
            .put("duration", p.duration)
            .put("width", p.width)
            .put("height", p.height)
        require(p.dir.isDirectory || p.dir.mkdirs()) { "Could not create the project folder." }
        val f = File(p.dir, ProjectEntry.META_FILE)
        val tmp = File(p.dir, ProjectEntry.META_FILE + ".tmp")
        try {
            // Persist the complete new metadata before replacing the visible file. A direct
            // write to meta.json as a fallback could truncate the last valid listing if the
            // process or device stopped halfway through the write.
            java.io.FileOutputStream(tmp, false).use { stream ->
                stream.write(j.toString().toByteArray(Charsets.UTF_8))
                stream.flush()
                stream.fd.sync()
            }
            // POSIX rename within the same directory atomically replaces the old metadata.
            // If it fails, keep the previous meta.json intact and report the save failure.
            Os.rename(tmp.absolutePath, f.absolutePath)
        } finally {
            if (tmp.exists()) tmp.delete()
        }
    }

    /** A new, empty project folder named [name] (made unique among the others). */
    @Synchronized
    fun create(name: String, width: Int, height: Int): ProjectEntry {
        val id = UUID.randomUUID().toString()
        val dir = File(root, id).apply { mkdirs() }
        try {
            require(dir.isDirectory) { "Could not create the project folder." }
            require(File(dir, ProjectEntry.MEDIA_DIR).mkdirs() || File(dir, ProjectEntry.MEDIA_DIR).isDirectory) {
                "Could not create the project's media folder."
            }
            val now = System.currentTimeMillis()
            val p = ProjectEntry(id, uniqueName(name), now, now, 0L, width, height, dir)
            write(p)
            return p
        } catch (t: Throwable) {
            dir.deleteRecursively()
            throw t
        }
    }

    /**
     * Write a portable .filmcraft archive. The package contains the editable engine project,
     * metadata, poster and every resource stored in the project's directory (including media
     * and project-local custom fonts). App-wide fonts are excluded because they are not project
     * dependencies. It is an editable archive, not a rendered video.
     */
    @Synchronized
    fun exportPackage(p: ProjectEntry, output: OutputStream) {
        require(p.projectFile.isFile) { "The editable project file is missing." }
        val projectFiles = p.dir.walkTopDown().filter { it.isFile }.toList()
        val entries = JSONArray()
        projectFiles.forEach { file ->
            val relative = file.relativeTo(p.dir).invariantSeparatorsPath
            entries.put(JSONObject().put("path", "project/$relative").put("size", file.length()).put("sha256", sha256(file)))
        }
        val manifest = JSONObject()
            .put("format", "filmcraft-project")
            .put("applicationName", "Seven Cut Pro")
            .put("displayName", "Cut Pro")
            .put("publisher", "Seven")
            .put("schemaVersion", PACKAGE_SCHEMA_VERSION)
            .put("appVersion", appVersion())
            .put("projectId", p.id)
            .put("projectName", p.name)
            .put("sourceRoot", p.dir.absolutePath)
            .put("entries", entries)
        ZipOutputStream(output.buffered()).use { zip ->
            zip.putNextEntry(ZipEntry("package.json"))
            zip.write(manifest.toString().toByteArray(Charsets.UTF_8))
            zip.closeEntry()
            projectFiles.forEach { file ->
                val relative = file.relativeTo(p.dir).invariantSeparatorsPath
                zip.putNextEntry(ZipEntry("project/$relative"))
                file.inputStream().buffered().use { it.copyTo(zip) }
                zip.closeEntry()
            }
            zip.finish()
        }
    }

    /** Safely import a .filmcraft archive as a separate editable project. */
    @Synchronized
    fun importPackage(input: InputStream): ProjectEntry {
        val staging = File(root, ".import-${UUID.randomUUID()}").apply { mkdirs() }
        var destination: File? = null
        try {
            var manifest: JSONObject? = null
            var total = 0L
            var entryCount = 0
            val seen = mutableSetOf<String>()
            val actual = mutableMapOf<String, Pair<Long, String>>()
            ZipInputStream(input.buffered()).use { zip ->
                while (true) {
                    val entry = zip.nextEntry ?: break
                    val name = entry.name.replace('\\', '/')
                    entryCount++
                    require(entryCount <= MAX_PACKAGE_ENTRIES) { "Project package contains too many files." }
                    val pathParts = name.trimEnd('/').split('/')
                    require(name.isNotBlank() && '\u0000' !in name && !name.startsWith("/") &&
                        !Regex("^[A-Za-z]:").containsMatchIn(name) &&
                        pathParts.none { it == ".." || it == "." || it.isBlank() }) {
                        "Invalid project package path."
                    }
                    if (entry.isDirectory) { zip.closeEntry(); continue }
                    require(seen.add(name)) { "The project package contains duplicate files." }
                    if (name == "package.json") {
                        val bytes = java.io.ByteArrayOutputStream()
                        val buffer = ByteArray(4096)
                        while (true) {
                            val n = zip.read(buffer)
                            if (n < 0) break
                            require(bytes.size() + n <= 64 * 1024) { "Project package manifest is too large." }
                            bytes.write(buffer, 0, n)
                        }
                        manifest = JSONObject(String(bytes.toByteArray(), Charsets.UTF_8))
                    } else if (name.startsWith("fonts/")) {
                        val fontName = name.removePrefix("fonts/")
                        require(fontName.isNotBlank() && '/' !in fontName && fontName == safeName(fontName)) { "Invalid font resource name." }
                        val fontDir = File(staging, "__package_fonts").apply { mkdirs() }
                        val fontFile = File(fontDir, fontName)
                        val digest = MessageDigest.getInstance("SHA-256")
                        var size = 0L
                        fontFile.outputStream().buffered().use { stream ->
                            val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
                            while (true) {
                                val n = zip.read(buffer)
                                if (n < 0) break
                                total += n; size += n
                                require(total <= MAX_PACKAGE_BYTES) { "Project package exceeds the import size limit." }
                                digest.update(buffer, 0, n); stream.write(buffer, 0, n)
                            }
                        }
                        actual[name] = size to digest.digest().toHex()
                    } else if (name.startsWith("project/") || name.startsWith("extras/")) {
                        val relative = name.removePrefix("project/").let { if (name.startsWith("extras/")) name else it }
                        require(relative.isNotBlank()) { "Invalid project package entry." }
                        val out = File(staging, relative).canonicalFile
                        require(out.toPath().startsWith(staging.canonicalFile.toPath())) { "Invalid project package path." }
                        out.parentFile?.mkdirs()
                        val digest = MessageDigest.getInstance("SHA-256")
                        var size = 0L
                        out.outputStream().buffered().use { stream ->
                            val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
                            while (true) {
                                val n = zip.read(buffer)
                                if (n < 0) break
                                total += n; size += n
                                require(total <= MAX_PACKAGE_BYTES) { "Project package exceeds the import size limit." }
                                digest.update(buffer, 0, n); stream.write(buffer, 0, n)
                            }
                        }
                        actual[name] = size to digest.digest().toHex()
                    } else {
                        require(name == "package.json") { "Unsupported project package entry: $name" }
                    }
                    zip.closeEntry()
                }
            }
            val m = requireNotNull(manifest) { "This is not a supported editable project package." }
            require(m.optString("format") == "filmcraft-project") { "Unsupported project package format." }
            val schema = m.optInt("schemaVersion", -1)
            require(schema in 1..PACKAGE_SCHEMA_VERSION) { "This project was made with an unsupported package version." }
            if (m.has("entries")) {
                val declared = mutableMapOf<String, Pair<Long, String>>()
                val array = m.optJSONArray("entries") ?: error("Invalid package manifest.")
                for (i in 0 until array.length()) {
                    val item = array.getJSONObject(i)
                    val path = item.getString("path")
                    require(path.startsWith("project/") || path.startsWith("fonts/") || path.startsWith("extras/")) { "Invalid manifest resource path." }
                    require(path.split('/').none { it == ".." || it.isBlank() }) { "Invalid manifest resource path." }
                    require(declared.put(path, item.getLong("size") to item.getString("sha256")) == null) {
                        "The manifest contains duplicate resources."
                    }
                }
                require(declared == actual) { "Project resources are missing, unexpected, or have failed integrity checks." }
            }
            val projectFile = File(staging, ProjectEntry.PROJECT_FILE)
            val metaFile = File(staging, ProjectEntry.META_FILE)
            require(projectFile.isFile && metaFile.isFile) { "The package is missing editable project data." }
            val oldRoot = m.optString("sourceRoot")
            val id = UUID.randomUUID().toString()
            destination = File(root, id)
            // Prepare and validate the complete project inside the hidden staging directory.
            // The final project directory is published only after every rewrite and metadata
            // operation succeeds, so Home can never discover a half-installed import.
            if (oldRoot.isNotBlank()) {
                val f = File(staging, ProjectEntry.PROJECT_FILE)
                val oldEscaped = oldRoot.replace("\\", "\\\\")
                val newEscaped = destination.absolutePath.replace("\\", "\\\\")
                f.writeText(f.readText().replace(oldEscaped, newEscaped))
            }
            val oldMeta = JSONObject(File(staging, ProjectEntry.META_FILE).readText())
            val now = System.currentTimeMillis()
            val stagedEntry = ProjectEntry(
                id = id,
                name = uniqueName(m.optString("projectName", oldMeta.optString("name", "Imported project"))),
                opened = now,
                created = now,
                duration = oldMeta.optLong("duration", 0L),
                width = oldMeta.optInt("width", 1080),
                height = oldMeta.optInt("height", 1920),
                dir = staging,
            )
            write(stagedEntry)
            // Older packages stored fonts at the archive root in fonts/. Keep them with
            // this imported project instead of merging them into the app-wide font directory.
            val bundledFonts = File(staging, "__package_fonts")
            if (bundledFonts.isDirectory) {
                val projectFonts = stagedEntry.fontsDir.apply { mkdirs() }
                bundledFonts.listFiles()?.filter { it.isFile }?.forEach { font ->
                    val target = uniqueFile(projectFonts, font.name)
                    font.copyTo(target, overwrite = false)
                }
                bundledFonts.deleteRecursively()
            }
            require(staging.renameTo(destination)) { "Could not install the imported project." }
            return stagedEntry.copy(dir = destination)
        } catch (e: Exception) {
            staging.deleteRecursively()
            destination?.deleteRecursively()
            throw e
        }
    }

    private fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        file.inputStream().buffered().use { input ->
            val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
            while (true) {
                val n = input.read(buffer)
                if (n < 0) break
                digest.update(buffer, 0, n)
            }
        }
        return digest.digest().toHex()
    }

    private fun ByteArray.toHex(): String = joinToString("") { "%02x".format(it) }

    private fun appVersion(): String = runCatching {
        context.packageManager.getPackageInfo(context.packageName, 0).versionName.orEmpty()
    }.getOrDefault("")

    /** Today's date in the medium style ("Oct 13, 2026"): what a new project is called. */
    fun todaysName(): String = DateFormat.getDateInstance(DateFormat.MEDIUM).format(Date())

    /** [base], or "[base] (1)", "[base] (2)"… whichever no project has. */
    fun uniqueName(base: String, except: String? = null): String {
        val taken = list().filter { it.id != except }.map { it.name }.toSet()
        if (base !in taken) return base
        var i = 1
        while ("$base ($i)" in taken) i++
        return "$base ($i)"
    }

    fun rename(p: ProjectEntry, name: String): ProjectEntry {
        val r = p.copy(name = name.trim())
        write(r)
        return r
    }

    /** A copy of [p] named "<name> copy", with its own media. */
    @Synchronized
    fun duplicate(p: ProjectEntry): ProjectEntry {
        val id = UUID.randomUUID().toString()
        val dir = File(root, id)
        p.dir.copyRecursively(dir, overwrite = true)
        // the project file names its media by absolute path: point it at the copies
        val file = File(dir, ProjectEntry.PROJECT_FILE)
        if (file.isFile) {
            val old = p.dir.absolutePath.replace("\\", "\\\\")
            val new = dir.absolutePath.replace("\\", "\\\\")
            file.writeText(file.readText().replace(old, new))
        }
        val now = System.currentTimeMillis()
        val r = p.copy(id = id, name = uniqueName("${p.name} copy"), opened = now, created = now, dir = dir)
        write(r)
        return r
    }

    @Synchronized
    fun delete(p: ProjectEntry) {
        p.dir.deleteRecursively()
    }

    fun touch(p: ProjectEntry): ProjectEntry {
        val r = p.copy(opened = System.currentTimeMillis())
        write(r)
        return r
    }

    fun savePoster(p: ProjectEntry, bitmap: Bitmap) {
        runCatching {
            val tmp = File(p.dir, ProjectEntry.POSTER_FILE + ".tmp")
            tmp.outputStream().use { bitmap.compress(Bitmap.CompressFormat.JPEG, 85, it) }
            tmp.renameTo(p.poster)
        }
    }

    /**
     * Copy a picked file into [p]'s media folder and return its path. Pictures are decoded (which
     * applies their orientation and reads HEIC), scaled down to at most [MAX_STILL] pixels on the
     * long side and stored as JPEG (PNG when transparent); videos and sounds are copied as they are.
     */
    fun importUri(p: ProjectEntry, uri: Uri): File {
        val resolver = context.contentResolver
        val name = displayName(resolver, uri)
        val type = resolver.getType(uri) ?: MimeTypeMap.getSingleton().getMimeTypeFromExtension(name.substringAfterLast('.', "").lowercase()) ?: ""
        val dir = p.mediaDir.apply { mkdirs() }
        if (type.startsWith("image/")) {
            val bitmap = decodeStill(resolver, uri)
            try {
                val png = bitmap.hasAlpha()
                val out = uniqueFile(dir, safeName(name).substringBeforeLast('.') + if (png) ".png" else ".jpg")
                try {
                    val format = if (png) Bitmap.CompressFormat.PNG else Bitmap.CompressFormat.JPEG
                    check(out.outputStream().use { bitmap.compress(format, 92, it) }) { "The image could not be saved." }
                    return out
                } catch (e: Exception) {
                    out.delete()
                    throw e
                }
            } finally {
                bitmap.recycle()
            }
        }
        val out = uniqueFile(dir, safeName(name))
        try {
            resolver.openInputStream(uri)?.use { input -> out.outputStream().use { input.copyTo(it) } }
                ?: throw java.io.FileNotFoundException("The file could not be read.")
            return out
        } catch (e: Exception) {
            out.delete()
            throw e
        }
    }

    /**
     * The exact frame of the picture or video at [uri] (width, height), turned by its orientation,
     * with even sides and the long side at most [MAX_FRAME]; null when it can't be read. A project
     * made from this media takes this size as it is, whatever its shape (17:5 included).
     */
    fun mediaFrame(uri: Uri): Pair<Int, Int>? {
        val resolver = context.contentResolver
        var w = 0
        var h = 0
        val type = resolver.getType(uri).orEmpty()
        runCatching {
            if (type.startsWith("image/")) {
                val o = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
                resolver.openInputStream(uri)?.use { android.graphics.BitmapFactory.decodeStream(it, null, o) }
                w = o.outWidth
                h = o.outHeight
                // pictures turned by their orientation tag swap sides
                resolver.openInputStream(uri)?.use {
                    val rot = androidx.exifinterface.media.ExifInterface(it).rotationDegrees
                    if (rot == 90 || rot == 270) w = h.also { h = w }
                }
            } else {
                val r = android.media.MediaMetadataRetriever()
                try {
                    r.setDataSource(context, uri)
                    w = r.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
                    h = r.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
                    val rot = r.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
                    if (rot == 90 || rot == 270) w = h.also { h = w }
                } finally {
                    r.release()
                }
            }
        }
        return fitFrame(w, h)
    }

    /** Remove only files created by a failed import operation, and only when they belong to this project's media folder. */
    fun rollbackImportedFiles(p: ProjectEntry, paths: Collection<String>) {
        val mediaRoot = p.mediaDir.canonicalFile.toPath()
        paths.forEach { path ->
            runCatching {
                val file = File(path).canonicalFile
                if (file.toPath().startsWith(mediaRoot) && file.isFile) file.delete()
            }
        }
    }

    private fun decodeStill(resolver: ContentResolver, uri: Uri): Bitmap {
        val src = ImageDecoder.createSource(resolver, uri)
        return ImageDecoder.decodeBitmap(src) { d, info, _ ->
            val w = info.size.width
            val h = info.size.height
            val long = maxOf(w, h)
            if (long > MAX_STILL) {
                val k = MAX_STILL.toFloat() / long
                d.setTargetSize((w * k).toInt().coerceAtLeast(1), (h * k).toInt().coerceAtLeast(1))
            }
            d.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
        }
    }

    companion object {
        /** The longest side a picture is kept at. */
        const val MAX_STILL = 4096
        /** The longest side of a frame made from media (the same limit pictures are kept at). */
        const val MAX_FRAME = MAX_STILL

        /**
         * A frame for media of [w] × [h]: the same shape, even sides, long side at most
         * [MAX_FRAME]. Null for sizes that are not positive.
         */
        fun fitFrame(w: Int, h: Int): Pair<Int, Int>? {
            if (w <= 0 || h <= 0) return null
            val k = minOf(1.0, MAX_FRAME.toDouble() / maxOf(w, h))
            fun even(x: Double) = maxOf(2, (Math.round(x * k) / 2 * 2).toInt())
            return even(w.toDouble()) to even(h.toDouble())
        }

        const val PACKAGE_SCHEMA_VERSION = 1
        const val MAX_PACKAGE_BYTES = 2L * 1024L * 1024L * 1024L
        /** Bounds ZIP metadata and filesystem work even when entries are empty. */
        const val MAX_PACKAGE_ENTRIES = 50_000

        fun displayName(resolver: ContentResolver, uri: Uri): String {
            val n = runCatching {
                resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
            }.getOrNull()
            return n ?: uri.lastPathSegment?.substringAfterLast('/') ?: "media"
        }

        fun safeName(name: String): String = name.replace(Regex("[^A-Za-z0-9._ -]"), "_").trim().ifBlank { "media" }.take(80)

        fun uniqueFile(dir: File, name: String): File {
            var f = File(dir, name)
            var i = 1
            val stem = name.substringBeforeLast('.')
            val ext = name.substringAfterLast('.', "")
            while (f.exists()) {
                f = File(dir, if (ext.isEmpty()) "$stem ($i)" else "$stem ($i).$ext")
                i++
            }
            return f
        }
    }
}
