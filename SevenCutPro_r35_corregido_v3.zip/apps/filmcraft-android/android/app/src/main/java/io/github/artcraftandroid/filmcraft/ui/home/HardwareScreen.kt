package io.github.artcraftandroid.filmcraft.ui.home

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import io.github.artcraftandroid.filmcraft.core.GpuAdapterView
import io.github.artcraftandroid.filmcraft.core.GpuDiagnosis
import io.github.artcraftandroid.filmcraft.ui.AppViewModel
import io.github.artcraftandroid.filmcraft.ui.Fc
import io.github.artcraftandroid.filmcraft.ui.FcType
import io.github.artcraftandroid.filmcraft.ui.HardwareModel
import io.github.artcraftandroid.filmcraft.ui.PrimaryButton
import io.github.artcraftandroid.filmcraft.ui.SelectChip

/**
 * Settings > Diagnóstico y aceleración de hardware. Says which system is working (CPU, GPU or MediaCodec), runs the GPU diagnosis on
 * the phone and shows it, holds the two hardware switches, and shares the report without opening Android/data.
 */
@Composable
fun HardwareScreen(vm: AppViewModel) {
    val hw = vm.hardware
    val context = LocalContext.current
    LaunchedEffect(Unit) { hw.refresh() }
    LaunchedEffect(hw.message) {
        val m = hw.message
        if (m != null) {
            vm.messages.trySend(m)
            hw.clearMessage()
        }
    }
    Page("Diagnóstico y aceleración de hardware", { vm.back() }, "screen_hardware") {
        Note("La GPU y MediaCodec son cosas distintas. La GPU compondría las imágenes (todavía no está implementada: todo se compone en CPU). MediaCodec es el codificador de vídeo por hardware del teléfono, con el codificador por software como respaldo automático.")
        SystemInUseSection(hw)
        MediaCodecSection(hw)
        GpuSection(hw)
        DeviceSection(hw)
        Section("Informe") {
            Note("Comparte o copia el informe completo (teléfono, sistema en uso, MediaCodec y diagnóstico GPU) sin tener que abrir Android/data.")
            PrimaryButton("Compartir informe", { hw.share(context) }, tag = "hardware_share")
            Spacer(Modifier.height(8.dp))
            PrimaryButton("Copiar informe", { hw.copy() }, tag = "hardware_copy")
        }
    }
}

@Composable
private fun Section(title: String, content: @Composable () -> Unit) {
    Spacer(Modifier.height(20.dp))
    Text(title, style = FcType.Label, color = Fc.Secondary, modifier = Modifier.padding(horizontal = 4.dp, vertical = 6.dp))
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Fc.Raised).padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) { content() }
}

@Composable
private fun Note(text: String) {
    Text(text, style = FcType.BodySmall, color = Fc.Secondary)
}

@Composable
private fun KV(key: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(key, style = FcType.BodySmall, color = Fc.Secondary, modifier = Modifier.weight(0.45f))
        Text(value, style = FcType.BodySmall, color = Fc.Body, modifier = Modifier.weight(0.55f))
    }
}

/** A coloured label for the system doing a step: CPU, GPU, MediaCodec or Software. */
@Composable
private fun SystemTag(system: String) {
    val color = when {
        system.startsWith("GPU") -> Fc.Accent
        system == "MediaCodec" -> Fc.AccentLight
        system == "CPU" || system == "Software" -> Fc.Chip
        else -> Fc.Divider
    }
    Text(system, style = FcType.Caption, color = Fc.Title, modifier = Modifier.clip(RoundedCornerShape(8.dp)).background(color).padding(horizontal = 10.dp, vertical = 4.dp))
}

@Composable
private fun SwitchRow(title: String, detail: String, checked: Boolean, enabled: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Column(Modifier.weight(1f)) {
            Text(title, style = FcType.Body, color = Fc.Title)
            Text(detail, style = FcType.BodySmall, color = Fc.Secondary)
        }
        Switch(
            checked = checked,
            onCheckedChange = onChange,
            enabled = enabled,
            colors = SwitchDefaults.colors(checkedTrackColor = Fc.Accent, checkedThumbColor = Color.White),
        )
    }
}

@Composable
private fun SystemInUseSection(hw: HardwareModel) {
    Section("Sistema en uso") {
        val s = hw.status
        if (s == null) {
            Note("Leyendo el estado…")
        } else {
            for (r in s.rows) {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        SystemTag(r.system)
                        Text(r.stage, style = FcType.BodySmall, color = Fc.Title, modifier = Modifier.weight(1f))
                    }
                    Text(r.detail, style = FcType.Caption, color = Fc.Secondary)
                }
            }
        }
        SelectChip("Actualizar", false, { hw.refresh() })
    }
}

@Composable
private fun MediaCodecSection(hw: HardwareModel) {
    Section("Codificación por hardware (MediaCodec)") {
        SwitchRow(
            "Usar MediaCodec al exportar",
            "Activado por defecto. Si el teléfono no lo admite o falla, se usa el codificador por software automáticamente.",
            hw.mediaCodecEnabled,
            true,
        ) { hw.setMediaCodec(it) }
        val encoders = hw.info?.encoders.orEmpty()
        Text("Codificadores de vídeo del teléfono", style = FcType.Label, color = Fc.Secondary)
        if (encoders.isEmpty()) Note("Ninguno listado.") else encoders.forEach { Text(it, style = FcType.Caption, color = Fc.Body) }
        if (hw.encoderReport.isNotBlank()) {
            Text("Detección para exportar (perfil High + VBR)", style = FcType.Label, color = Fc.Secondary)
            Text(hw.encoderReport, style = FcType.Caption, color = Fc.Body)
        }
    }
}

@Composable
private fun GpuSection(hw: HardwareModel) {
    Section("Aceleración GPU (wgpu)") {
        val d = hw.diagnosis
        SwitchRow(
            "Aceleración GPU (experimental)",
            when {
                hw.gpuRequested -> "Solicitada. Mientras el motor no tenga compositor GPU, todo se sigue componiendo en CPU."
                hw.canEnableGpu -> "Desactivada por defecto. Este teléfono ha pasado el diagnóstico: puedes activarla."
                else -> "Desactivada por defecto. Se podrá activar cuando el diagnóstico encuentre una GPU utilizable."
            },
            hw.gpuRequested,
            hw.gpuRequested || hw.canEnableGpu,
        ) { hw.setGpuRequested(it) }

        PrimaryButton(if (hw.running) "Ejecutando diagnóstico…" else "Ejecutar diagnóstico GPU", { hw.runDiagnosis() }, enabled = !hw.running, tag = "hardware_run_gpu")
        if (hw.running) CircularProgressIndicator(color = Fc.Accent, modifier = Modifier.size(28.dp))
        if (d == null) {
            Note("Aún no se ha ejecutado. Tarda unos segundos: pregunta a la GPU qué admite y reserva unas texturas de prueba. No dibuja nada.")
        } else {
            GpuResult(hw, d)
        }
    }
}

@Composable
private fun GpuResult(hw: HardwareModel, d: GpuDiagnosis) {
    when {
        !d.wgpuCompiled -> Note("Este APK se compiló sin wgpu (-Pfilmcraft.gpuProbe=false), así que no puede sondear la GPU. Vuelve a compilarlo con el valor por defecto para diagnosticarla.")
        d.status != "ran" -> {
            Text(d.status.replace("skipped: ", "No se ejecutó: ").replace("timed_out: ", "Sin respuesta a tiempo: "), style = FcType.BodySmall, color = Fc.Negative)
            if (d.status.contains("never finished")) SelectChip("Borrar bloqueo y reintentar", false, { hw.resetBlock() })
        }
        d.usable -> Text("GPU utilizable: ${d.selected}", style = FcType.Body, color = Fc.Title)
        else -> Text("Ninguna GPU utilizable: todo se queda en CPU.", style = FcType.Body, color = Fc.Negative)
    }
    if (d.status != "ran") return
    KV("Duración", "${d.elapsedMs} ms")
    KV("Memoria RAM del teléfono", if (d.systemRamMb > 0u) "${d.systemRamMb} MB" else "desconocida")
    d.budget?.let { b ->
        Text("Memoria y límites", style = FcType.Label, color = Fc.Secondary)
        KV("Presupuesto para la GPU", "${b.budgetMb} MB")
        KV("Fotograma máximo", if (b.maxFrameSide > 0u) "${b.maxFrameSide} px de lado largo" else "ninguno")
        KV("Compositores a la vez", "${b.maxCompositors}")
        KV("Un compositor a 1080p (f16)", "${b.compositor1080pF16Mb} MB")
        if (b.softwareRenderer) Note("La GPU es un rasterizador por software: no se recomienda.")
    }
    for (backend in d.backends) {
        Text("${backend.name}: ${backend.adapters.size} adaptador(es)", style = FcType.Label, color = Fc.Secondary)
        if (backend.error.isNotBlank()) Note(backend.error)
        backend.adapters.forEach { AdapterBlock(it) }
    }
    Text("Funciones que se podrían acelerar", style = FcType.Label, color = Fc.Secondary)
    d.features.forEach { f ->
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(levelMark(f.level), style = FcType.BodySmall, color = levelColor(f.level))
            Column(Modifier.weight(1f)) {
                Text(f.title, style = FcType.BodySmall, color = Fc.Title)
                Text(f.reason, style = FcType.Caption, color = Fc.Secondary)
            }
        }
    }
    Text("Integración progresiva", style = FcType.Label, color = Fc.Secondary)
    d.stages.forEach { s ->
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(levelMark(s.deviceLevel), style = FcType.BodySmall, color = levelColor(s.deviceLevel))
            Column(Modifier.weight(1f)) {
                Text(s.title, style = FcType.BodySmall, color = Fc.Title)
                Text(s.note, style = FcType.Caption, color = Fc.Secondary)
            }
        }
    }
    if (d.issues.isNotEmpty()) {
        Text("Avisos y errores", style = FcType.Label, color = Fc.Secondary)
        d.issues.forEach { Text(it, style = FcType.Caption, color = Fc.Body) }
    }
}

@Composable
private fun AdapterBlock(a: GpuAdapterView) {
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).background(Fc.Chip).padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text("${a.name}${if (a.selected) "  (la que se usaría)" else ""}", style = FcType.BodySmall, color = Fc.Title)
        Text("${a.deviceType}, ${a.driver}", style = FcType.Caption, color = Fc.Secondary)
        Text(if (a.deviceOk) "Dispositivo creado" else "Dispositivo NO creado: ${a.error}", style = FcType.Caption, color = if (a.deviceOk) Fc.Body else Fc.Negative)
        a.limits.forEach { Text("${it.key}: ${it.value}", style = FcType.Caption, color = Fc.Body) }
        Text("Formatos de textura", style = FcType.Caption, color = Fc.Secondary)
        a.formats.forEach { f ->
            val flags = listOfNotNull(
                if (f.sampled) "muestreo" else null,
                if (f.render) "dibujo" else null,
                if (f.blendable) "mezcla" else null,
                if (f.filterable) "filtrado" else null,
                if (f.copySrc) "copia" else null,
            ).joinToString(", ").ifEmpty { "no disponible" }
            Text("${f.name}${if (f.required) " (necesario)" else ""}: $flags", style = FcType.Caption, color = Fc.Body)
        }
        if (a.allocations.isNotEmpty()) {
            Text("Reservas de prueba", style = FcType.Caption, color = Fc.Secondary)
            a.allocations.forEach { Text("${it.key}: ${it.value}", style = FcType.Caption, color = Fc.Body) }
        }
    }
}

private fun levelMark(level: String) = when (level) {
    "supported" -> "✓"
    "limited" -> "~"
    else -> "✕"
}

private fun levelColor(level: String) = when (level) {
    "supported" -> Fc.Title
    "limited" -> Fc.Secondary
    else -> Fc.Negative
}

@Composable
private fun DeviceSection(hw: HardwareModel) {
    Section("Dispositivo") {
        val info = hw.info
        if (info == null) Note("Leyendo…") else info.device.forEach { KV(it.first, it.second) }
    }
}
