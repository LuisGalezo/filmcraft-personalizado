package io.github.artcraftandroid.filmcraft

import android.app.Application
import android.content.ComponentCallbacks2
import android.system.Os
import io.github.artcraftandroid.filmcraft.core.MobileSession
import io.github.artcraftandroid.filmcraft.core.gpuProbe
import io.github.artcraftandroid.filmcraft.core.initLogging
import io.github.artcraftandroid.filmcraft.core.setHardwareH264
import io.github.artcraftandroid.filmcraft.core.trimMemory
import io.github.artcraftandroid.filmcraft.engine.Engine
import io.github.artcraftandroid.filmcraft.engine.MediaCodecH264
import java.io.File
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.launch

class FilmcraftApplication : Application() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    /** The engine, loaded once per process on a background thread and shared by the screens. */
    val engine: Deferred<Result<Engine>> by lazy {
        scope.async {
            runCatching {
                // Rust's temporary folder and home on Android are not the app's own: point them
                // at it before the library first reads them (it can't set them itself).
                val data = File(filesDir, "engine").apply { mkdirs() }
                Os.setenv("TMPDIR", cacheDir.absolutePath, true)
                Os.setenv("HOME", filesDir.absolutePath, true)
                Os.setenv("FILMCRAFT_DATA_DIR", data.absolutePath, true)
                initLogging()
                // The phone's hardware H.264 encoder for exports. Nothing is probed yet (that happens with the first export);
                // when it cannot do a job, or fails, the engine's software encoder does it.
                runCatching { setHardwareH264(hardwareEncoder) }
                    .onFailure { android.util.Log.w("SevenCutHW", "hardware encoder not registered: ${it.message}") }
                val session = MobileSession()
                session.start(data.absolutePath)
                // Re-register fonts imported by the user in earlier app sessions.
                val customFonts = File(filesDir, "custom_fonts").apply { mkdirs() }
                customFonts.listFiles()?.filter { it.isFile && it.extension.lowercase() in setOf("ttf", "otf") }?.forEach { font ->
                    runCatching { session.addCustomFontData(font.readBytes()) }
                }
                engineLoaded = true
                startGpuDiagnostics()
                Engine(session)
            }
        }
    }

    /** The phone's hardware H.264 encoder (MediaCodec); the diagnostics screen asks it what the phone offers. */
    val hardwareEncoder: MediaCodecH264 by lazy { MediaCodecH264(File(filesDir, "hardware_encoder_report.txt")) }

    @Volatile
    private var engineLoaded = false

    /**
     * Optional GPU diagnosis at start-up, for testing without opening the screen: only when a file named gpu_probe.enable sits in the app's
     * external files folder (Android/data/<app>/files). The normal way is Settings > Diagnóstico y aceleración de hardware, which runs it on demand:
     * the phone's GPU is probed once per start, on a low-priority thread, and the report is written next to that file
     * (gpu_report.txt, gpu_report.json) and to the log (tag FilmcraftGpu). It changes nothing in the editor, the export or the
     * CPU renderer, and nothing renders with the GPU yet.
     */
    private fun startGpuDiagnostics() {
        val marker = getExternalFilesDir(null)?.let { File(it, "gpu_probe.enable") }
        if (marker?.isFile != true) return
        Thread(
            {
                runCatching {
                    val memory = android.app.ActivityManager.MemoryInfo()
                    (getSystemService(ACTIVITY_SERVICE) as android.app.ActivityManager).getMemoryInfo(memory)
                    val build = "${BuildConfig.VERSION_NAME}+${BuildConfig.VERSION_CODE}"
                    val result = gpuProbe(File(filesDir, "gpu").absolutePath, build, (memory.totalMem / (1024 * 1024)).toULong(), 20_000u)
                    val out = getExternalFilesDir(null) ?: filesDir
                    File(out, "gpu_report.json").writeText(result.json)
                    File(out, "gpu_report.txt").writeText(result.summary)
                    android.util.Log.i("FilmcraftGpu", "status=${result.status} wgpu=${result.wgpuCompiled} selected=${result.selected.ifEmpty { "none" }}")
                    android.util.Log.i("FilmcraftGpu", result.summary)
                }.onFailure { android.util.Log.w("FilmcraftGpu", "GPU diagnostics failed: ${it.message}") }
            },
            "gpu-diagnostics",
        ).apply {
            isDaemon = true
            priority = Thread.MIN_PRIORITY
            start()
        }
    }

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        // the engine's caches refill as they are needed: let go of them as soon as the phone runs low
        // while the editor is open (the timeline stays responsive), and again when the app is hidden
        if (level >= ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW) {
            if (engineLoaded) scope.launch { runCatching { trimMemory() } }
        }
        if (level >= ComponentCallbacks2.TRIM_MEMORY_UI_HIDDEN) {
            System.gc()
        }
    }
}
