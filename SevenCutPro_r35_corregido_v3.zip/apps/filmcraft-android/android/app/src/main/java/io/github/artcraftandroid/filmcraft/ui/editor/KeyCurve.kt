package io.github.artcraftandroid.filmcraft.ui.editor

/** A point inside a curve with its two handles, all in the stretch's space (see [KeyCurve]): the engine's `CurvePoint`. */
data class CurvePt(val x: Double, val y: Double, val inX: Double, val inY: Double, val outX: Double, val outY: Double)

/**
 * A keyframe curve between two keys, in (time, value) space: time runs 0..1 along the stretch, value 0 at the first key
 * and 1 at the next (it may leave 0..1). Its two END handles are the control points (x1, y1) and (x2, y2) of a cubic
 * Bezier from (0, 0) to (1, 1). With no [mid] points that is the whole curve (the usual curve of older versions); each
 * point in [mid] splits it into one more cubic piece (see [CurveMath]). The same numbers go to the engine
 * (`set_key_curve_points`), which keeps them within the same limits as [clamped].
 */
data class KeyCurve(val x1: Double, val y1: Double, val x2: Double, val y2: Double, val mid: List<CurvePt> = emptyList()) {
    /** The value (0 at the first key, 1 at the next) at [u] (0..1) along the stretch. */
    fun at(u: Double): Double = if (mid.isEmpty()) KeyEase.bezierY(x1, y1, x2, y2, u.coerceIn(0.0, 1.0)) else CurveMath.y(this, u)

    /** The engine's limits: handle time x1 in 0.01..1, x2 in 0..0.99; value -1..2; points as [CurveMath.sanitize]. */
    fun clamped(): KeyCurve = KeyCurve(x1.coerceIn(0.01, 1.0), y1.coerceIn(MIN_Y, MAX_Y), x2.coerceIn(0.0, 0.99), y2.coerceIn(MIN_Y, MAX_Y), CurveMath.sanitize(mid))

    fun withFirst(x: Double, y: Double) = copy(x1 = x, y1 = y).clamped()

    fun withSecond(x: Double, y: Double) = copy(x2 = x, y2 = y).clamped()

    /** Same curve within [eps] on every number, points included. */
    fun sameAs(o: KeyCurve, eps: Double = 1e-4): Boolean {
        fun near(a: Double, b: Double) = kotlin.math.abs(a - b) < eps
        if (!(near(x1, o.x1) && near(y1, o.y1) && near(x2, o.x2) && near(y2, o.y2)) || mid.size != o.mid.size) return false
        return mid.indices.all { i ->
            val p = mid[i]
            val q = o.mid[i]
            near(p.x, q.x) && near(p.y, q.y) && near(p.inX, q.inX) && near(p.inY, q.inY) && near(p.outX, q.outX) && near(p.outY, q.outY)
        }
    }

    /** The points as the six numbers each the engine takes: x, y, in x, in y, out x, out y. */
    fun midFlat(): List<Double> = mid.flatMap { listOf(it.x, it.y, it.inX, it.inY, it.outX, it.outY) }

    companion object {
        const val MIN_Y = -1.0
        const val MAX_Y = 2.0
        private const val THIRD = 1.0 / 3.0

        val LINEAR = KeyCurve(THIRD, THIRD, 2 * THIRD, 2 * THIRD)

        /** The points from the engine's flat list (six numbers each); a short or odd tail is ignored. */
        fun pointsFromFlat(flat: List<Double>): List<CurvePt> =
            flat.chunked(6).filter { it.size == 6 }.map { CurvePt(it[0], it[1], it[2], it[3], it[4], it[5]) }

        /** The handles of one of the seven standard shapes (Hold has none: it is a step). */
        fun of(kind: KeyEase): KeyCurve? = when (kind) {
            KeyEase.Linear -> LINEAR
            KeyEase.Hold -> null
            KeyEase.Bezier, KeyEase.AutoBezier, KeyEase.ContinuousBezier -> KeyCurve(THIRD, 0.0, 2 * THIRD, 1.0)
            KeyEase.EaseIn -> KeyCurve(THIRD, THIRD, 2 * THIRD, 1.0)
            KeyEase.EaseOut -> KeyCurve(THIRD, 0.0, 2 * THIRD, 2 * THIRD)
        }
    }
}

/**
 * The maths of a curve with points: the same as the engine's (`ease_through_points` in crates/project/src/keyframe.rs),
 * so what is drawn is what is played. The nodes are the start (0, 0), the points and the end (1, 1); between two
 * neighbours runs one cubic Bezier made of the first one's out handle and the second one's in handle.
 */
object CurveMath {
    const val MAX_POINTS = 16

    /** The closest two points may be in time when the user places or moves them. */
    const val MIN_GAP = 0.02

    /** The points a curve keeps: finite, strictly inside the stretch, each handle on its own side, values -1..2, sorted, 0.002 apart, at most 16. */
    fun sanitize(list: List<CurvePt>): List<CurvePt> {
        val ok = list
            .filter { p -> listOf(p.x, p.y, p.inX, p.inY, p.outX, p.outY).all { it.isFinite() } && p.x > 0.001 && p.x < 0.999 }
            .map { p ->
                CurvePt(
                    p.x, p.y.coerceIn(KeyCurve.MIN_Y, KeyCurve.MAX_Y),
                    p.inX.coerceIn(0.0, p.x), p.inY.coerceIn(KeyCurve.MIN_Y, KeyCurve.MAX_Y),
                    p.outX.coerceIn(p.x, 1.0), p.outY.coerceIn(KeyCurve.MIN_Y, KeyCurve.MAX_Y),
                )
            }
            .sortedBy { it.x }
        val kept = ArrayList<CurvePt>()
        for (p in ok) {
            if (kept.isNotEmpty() && p.x - kept.last().x < 0.002) continue
            kept.add(p)
        }
        return kept.take(MAX_POINTS)
    }

    /** Every node of [c] in time order: the start, the points, the end (the end ones carry only their one handle that matters). */
    fun nodes(c: KeyCurve): List<CurvePt> =
        listOf(CurvePt(0.0, 0.0, 0.0, 0.0, c.x1, c.y1)) + sanitize(c.mid) + CurvePt(1.0, 1.0, c.x2, c.y2, 1.0, 1.0)

    /** The value at time [x] of one cubic Bezier piece (any ends); the time runs forward along it, so it is found by bisection. */
    fun pieceY(p0x: Double, p0y: Double, p1x: Double, p1y: Double, p2x: Double, p2y: Double, p3x: Double, p3y: Double, x: Double): Double {
        if (p3x - p0x < 1e-9) return p3y
        var lo = 0.0
        var hi = 1.0
        repeat(60) {
            val s = (lo + hi) / 2
            val m = 1 - s
            val bx = m * m * m * p0x + 3 * m * m * s * p1x + 3 * m * s * s * p2x + s * s * s * p3x
            if (bx < x) lo = s else hi = s
        }
        val s = (lo + hi) / 2
        val m = 1 - s
        return m * m * m * p0y + 3 * m * m * s * p1y + 3 * m * s * s * p2y + s * s * s * p3y
    }

    private fun pieceAt(n: List<CurvePt>, x: Double): Int {
        var i = 0
        while (i < n.size - 2 && x > n[i + 1].x) i++
        return i
    }

    /** The value of [c] at time [u] (0..1). */
    fun y(c: KeyCurve, u: Double): Double {
        val n = nodes(c)
        val x = u.coerceIn(0.0, 1.0)
        val i = pieceAt(n, x)
        val a = n[i]
        val b = n[i + 1]
        return pieceY(a.x, a.y, a.outX, a.outY, b.inX, b.inY, b.x, b.y, x)
    }

    /**
     * [c] with a new point at time [x] ON the curve, the piece it falls in split exactly (de Casteljau), so the curve does
     * not change shape. Returns the new curve and the index of the new point, or null when the curve already has the
     * most points, or [x] is within [MIN_GAP] of the start, the end or another point.
     */
    fun addPoint(c: KeyCurve, x: Double): Pair<KeyCurve, Int>? {
        val n = nodes(c)
        if (n.size - 2 >= MAX_POINTS || n.any { kotlin.math.abs(it.x - x) < MIN_GAP }) return null
        val i = pieceAt(n, x)
        val a = n[i]
        val b = n[i + 1]
        var lo = 0.0
        var hi = 1.0
        repeat(60) {
            val s = (lo + hi) / 2
            val m = 1 - s
            val bx = m * m * m * a.x + 3 * m * m * s * a.outX + 3 * m * s * s * b.inX + s * s * s * b.x
            if (bx < x) lo = s else hi = s
        }
        val s = (lo + hi) / 2
        fun lerp(ax: Double, ay: Double, bx: Double, by: Double) = (ax + (bx - ax) * s) to (ay + (by - ay) * s)
        val ab = lerp(a.x, a.y, a.outX, a.outY)
        val bc = lerp(a.outX, a.outY, b.inX, b.inY)
        val cd = lerp(b.inX, b.inY, b.x, b.y)
        val d = lerp(ab.first, ab.second, bc.first, bc.second)
        val e = lerp(bc.first, bc.second, cd.first, cd.second)
        val f = lerp(d.first, d.second, e.first, e.second)
        val all = n.toMutableList()
        all[i] = a.copy(outX = ab.first, outY = ab.second)
        all[i + 1] = b.copy(inX = cd.first, inY = cd.second)
        all.add(i + 1, CurvePt(f.first, f.second, d.first, d.second, e.first, e.second))
        val first = all.first()
        val last = all.last()
        return KeyCurve(first.outX, first.outY, last.inX, last.inY, all.subList(1, all.size - 1)).clamped() to i
    }

    /** [c] without its point [index] (its neighbours keep their handles, so the curve reshapes). */
    fun removePoint(c: KeyCurve, index: Int): KeyCurve =
        if (index in c.mid.indices) c.copy(mid = c.mid.filterIndexed { i, _ -> i != index }).clamped() else c

    /** Point [index] moved to ([x], [y]) with its handles, kept in time between its neighbours and within the value limits. */
    fun movePoint(c: KeyCurve, index: Int, x: Double, y: Double): KeyCurve {
        val m = c.mid
        if (index !in m.indices) return c
        val lo = (if (index == 0) 0.0 else m[index - 1].x) + MIN_GAP
        val hi = (if (index == m.lastIndex) 1.0 else m[index + 1].x) - MIN_GAP
        if (lo > hi) return c
        val p = m[index]
        val nx = x.coerceIn(lo, hi)
        val ny = y.coerceIn(KeyCurve.MIN_Y, KeyCurve.MAX_Y)
        val moved = CurvePt(nx, ny, p.inX + (nx - p.x), p.inY + (ny - p.y), p.outX + (nx - p.x), p.outY + (ny - p.y))
        return c.copy(mid = m.toMutableList().also { it[index] = moved }).clamped()
    }

    /** One handle of point [index] ([isIn]: the one before it) moved to ([x], [y]), kept between the point and its neighbour. */
    fun movePointHandle(c: KeyCurve, index: Int, isIn: Boolean, x: Double, y: Double): KeyCurve {
        val m = c.mid
        if (index !in m.indices) return c
        val p = m[index]
        val ny = y.coerceIn(KeyCurve.MIN_Y, KeyCurve.MAX_Y)
        val np = if (isIn) {
            val lo = if (index == 0) 0.0 else m[index - 1].x
            p.copy(inX = x.coerceIn(lo, p.x), inY = ny)
        } else {
            val hi = if (index == m.lastIndex) 1.0 else m[index + 1].x
            p.copy(outX = x.coerceIn(p.x, hi), outY = ny)
        }
        return c.copy(mid = m.toMutableList().also { it[index] = np }).clamped()
    }
}

/** A curve the user kept, with its name. */
data class SavedCurve(val name: String, val curve: KeyCurve)

/**
 * The user's own curves as one line of text for the app's preferences: `name|x1|y1|x2|y2` (then six numbers per point) joined by
 * newlines. Names never contain the separators (they are replaced), numbers use a dot. Bad lines are skipped.
 */
object CurveStore {
    const val MAX_CURVES = 24
    const val MAX_NAME = 16

    fun cleanName(raw: String): String {
        val n = raw.replace('|', ' ').replace('\n', ' ').replace('\r', ' ').trim()
        return n.take(MAX_NAME)
    }

    fun encode(list: List<SavedCurve>): String = list.take(MAX_CURVES).joinToString("\n") {
        val c = it.curve.clamped()
        // older curves have the five fields; a curve with points adds six numbers per point after them
        val points = c.midFlat().joinToString("") { v -> "|$v" }
        "${cleanName(it.name)}|${c.x1}|${c.y1}|${c.x2}|${c.y2}$points"
    }

    fun decode(text: String?): List<SavedCurve> {
        if (text.isNullOrBlank()) return emptyList()
        return text.lines().mapNotNull { line ->
            val p = line.split('|')
            if (p.size < 5 || (p.size - 5) % 6 != 0) return@mapNotNull null
            val n = p.drop(1).map { it.toDoubleOrNull() ?: return@mapNotNull null }
            if (n.any { !it.isFinite() }) return@mapNotNull null
            val name = cleanName(p[0]).ifEmpty { return@mapNotNull null }
            SavedCurve(name, KeyCurve(n[0], n[1], n[2], n[3], KeyCurve.pointsFromFlat(n.drop(4))).clamped())
        }.take(MAX_CURVES)
    }

    /**
     * [list] with [curve] added under the next free name. Unchanged (same size) when the list is full or the same
     * curve is already in it, so saving twice never makes a duplicate.
     */
    fun add(list: List<SavedCurve>, curve: KeyCurve): List<SavedCurve> {
        val c = curve.clamped()
        if (list.size >= MAX_CURVES || list.any { it.curve.sameAs(c) }) return list
        return list + SavedCurve(nextName(list), c)
    }

    /** The next free name "Curve 1", "Curve 2"... */
    fun nextName(list: List<SavedCurve>): String {
        var i = list.size + 1
        while (list.any { it.name == "Curve $i" }) i++
        return "Curve $i"
    }
}

/**
 * One tile of the presets window. A preset with a [kind] is one of the engine's standard types (it is applied with
 * `set_key_interp`, so keyframes made before keep their type); the others are applied as two handles ([curve]).
 * [kind] Hold has no [curve]: a step has nothing to adjust.
 */
data class CurvePreset(val id: String, val label: String, val kind: KeyEase?, val curve: KeyCurve?) {
    /** The change from one key to the next at [u] (0..1): what the tile draws. */
    fun at(u: Double): Double = curve?.at(u) ?: kind?.at(u) ?: u

    /** A short name for the card (the full [label] is still the preset's name in the editor). */
    val short: String get() = CurvePresets.shortName(id)

    /** Whether the preset has a curve the advanced editor can adjust. */
    val adjustable: Boolean get() = curve != null
}

/** The built-in presets (all within the engine's handle limits) and how a preset is recognised as the active one. */
object CurvePresets {
    private fun c(x1: Double, y1: Double, x2: Double, y2: Double) = KeyCurve(x1, y1, x2, y2).clamped()

    val all: List<CurvePreset> = listOf(
        CurvePreset("none", "Ninguna", KeyEase.Hold, null),
        CurvePreset("linear", "Lineal", KeyEase.Linear, KeyCurve.of(KeyEase.Linear)),
        CurvePreset("smooth", "Suavizado", null, c(0.25, 0.1, 0.25, 1.0)),
        CurvePreset("ease_in", "Entrada suave", KeyEase.EaseIn, KeyCurve.of(KeyEase.EaseIn)),
        CurvePreset("ease_out", "Salida suave", KeyEase.EaseOut, KeyCurve.of(KeyEase.EaseOut)),
        CurvePreset("ease_in_out", "Entrada y salida suave", KeyEase.Bezier, KeyCurve.of(KeyEase.Bezier)),
        CurvePreset("sine_in", "Entrada senoidal", null, c(0.12, 0.0, 0.39, 0.0)),
        CurvePreset("sine_out", "Salida senoidal", null, c(0.61, 1.0, 0.88, 1.0)),
        CurvePreset("quad_in", "Entrada cuadrática", null, c(0.11, 0.0, 0.5, 0.0)),
        CurvePreset("quad_out", "Salida cuadrática", null, c(0.5, 1.0, 0.89, 1.0)),
        CurvePreset("cubic_in", "Entrada cúbica", null, c(0.32, 0.0, 0.67, 0.0)),
        CurvePreset("cubic_out", "Salida cúbica", null, c(0.33, 1.0, 0.68, 1.0)),
        CurvePreset("circ_in", "Entrada circular", null, c(0.55, 0.0, 0.99, 0.45)),
        CurvePreset("fast", "Rápida", null, c(0.7, 0.0, 0.3, 1.0)),
        CurvePreset("back_in", "Retroceso", null, c(0.36, 0.0, 0.66, -0.56)),
        CurvePreset("back_out", "Rebote final", null, c(0.34, 1.56, 0.64, 1.0)),
        CurvePreset("auto_bezier", "Auto Bezier", KeyEase.AutoBezier, KeyCurve.of(KeyEase.AutoBezier)),
        CurvePreset("continuous_bezier", "Bezier continuo", KeyEase.ContinuousBezier, KeyCurve.of(KeyEase.ContinuousBezier)),
    )

    /** The name shown on a card: short enough for one line. */
    fun shortName(id: String): String = when (id) {
        "none" -> "Ninguna"
        "linear" -> "Lineal"
        "smooth" -> "Suave"
        "ease_in" -> "Entrada"
        "ease_out" -> "Salida"
        "ease_in_out" -> "Ent./Sal."
        "sine_in" -> "Seno ent."
        "sine_out" -> "Seno sal."
        "quad_in" -> "Cuad. ent."
        "quad_out" -> "Cuad. sal."
        "cubic_in" -> "Cúb. ent."
        "cubic_out" -> "Cúb. sal."
        "circ_in" -> "Circular"
        "fast" -> "Rápida"
        "back_in" -> "Retroceso"
        "back_out" -> "Rebote"
        "auto_bezier" -> "Auto"
        "continuous_bezier" -> "Continua"
        else -> id
    }

    /**
     * Whether [preset] is what the keyframe has now: a standard type is active while the keyframe has that type and
     * its handles were not edited; a handle preset while the keyframe's handles equal its curve.
     */
    fun isActive(preset: CurvePreset, current: String, custom: Boolean, now: KeyCurve): Boolean {
        val kind = preset.kind
        if (kind != null && preset.curve == null) return current == kind.id && !custom
        if (kind != null) return current == kind.id && !custom
        return custom && preset.curve != null && preset.curve.sameAs(now.clamped())
    }
}

/** What saving a curve under a name did. */
enum class SaveResult { Added, Replaced, Full }

/** [CurveStore.addNamed]: the new list and what happened. */
data class SaveOutcome(val list: List<SavedCurve>, val result: SaveResult, val name: String)

/**
 * [list] with [curve] saved under [rawName] (cleaned; a blank name becomes "Curve N"). A name that is already
 * saved gets the new curve (saving again under the same name updates it); a full list is returned unchanged.
 */
fun CurveStore.addNamed(list: List<SavedCurve>, rawName: String, curve: KeyCurve): SaveOutcome {
    val c = curve.clamped()
    val name = cleanName(rawName).ifEmpty { nextName(list) }
    val at = list.indexOfFirst { it.name.equals(name, ignoreCase = true) }
    if (at >= 0) {
        val kept = list[at].name
        return SaveOutcome(list.toMutableList().also { it[at] = SavedCurve(kept, c) }, SaveResult.Replaced, kept)
    }
    if (list.size >= CurveStore.MAX_CURVES) return SaveOutcome(list, SaveResult.Full, name)
    return SaveOutcome(list + SavedCurve(name, c), SaveResult.Added, name)
}

/** The curve of the stretch a [KeyInterpInfo] describes, points included. */
fun io.github.artcraftandroid.filmcraft.core.KeyInterpInfo.toCurve(): KeyCurve = KeyCurve(x1, y1, x2, y2, KeyCurve.pointsFromFlat(mid))
