package io.github.artcraftandroid.filmcraft.ui.editor

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * The shape of a sound's fade-in and fade-out over a clip, in pure maths so the timeline draws exactly what
 * the engine mixes. The engine's fade is a constant-power ramp (`crates/render/src/transitions.rs`,
 * `audio_gains`): in from silence along sin(p·π/2), out to silence along cos(p·π/2), p = progress through
 * the fade. Playback and export mix that same ramp, so this curve is the real gain, not an animation.
 */
object FadeCurve {
    /** The gain (0.0 silent to 1.0 full) [t] ticks into a clip of [duration] ticks. */
    fun gain(t: Long, duration: Long, fadeIn: Long, fadeOut: Long): Double {
        var g = 1.0
        if (fadeIn > 0 && t < fadeIn) {
            g *= sin(PI / 2 * (t.coerceAtLeast(0L).toDouble() / fadeIn))
        }
        val outStart = duration - fadeOut
        if (fadeOut > 0 && t > outStart) {
            g *= cos(PI / 2 * ((t - outStart).coerceAtMost(fadeOut).toDouble() / fadeOut))
        }
        return g.coerceIn(0.0, 1.0)
    }
}
