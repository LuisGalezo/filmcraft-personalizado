package io.github.artcraftandroid.filmcraft.engine

import android.media.Image
import android.media.MediaCodec
import android.media.MediaCodecInfo.CodecCapabilities
import android.media.MediaCodecInfo.CodecProfileLevel
import android.media.MediaCodecInfo.EncoderCapabilities
import android.media.MediaCodecList
import android.media.MediaFormat
import android.util.Log
import io.github.artcraftandroid.filmcraft.core.HardwareH264
import io.github.artcraftandroid.filmcraft.core.HwException
import io.github.artcraftandroid.filmcraft.core.HwOpen
import io.github.artcraftandroid.filmcraft.core.HwOutput
import java.io.File
import java.nio.ByteBuffer
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong

/**
 * The phone's hardware H.264 encoder (`MediaCodec`) for the exporter. The engine decides when it is used: only when
 * [supports] says it can do exactly the requested size, frame rate and bitrate; if it cannot, refuses to open, or fails
 * during an export, the engine's software encoder does the job (nothing here lowers quality to go faster).
 *
 * Required (the encoder is not used if the phone lacks any, so quality is never lowered quietly): High profile, VBR rate
 * control, flexible YUV 4:2:0 input, the exact size and frame rate, and the requested bitrate inside the codec's range.
 * Optional (tried first, dropped one tier at a time if the codec refuses them; none of them changes quality): operating
 * rate and priority (speed hints), colour metadata (the MP4 carries it too), `KEY_MAX_B_FRAMES` (if ignored and the encoder
 * does reorder, the engine detects it and the export is done again in software), float frame rate / key frame interval.
 *
 * Choices that keep the output right:
 * - Input is `COLOR_FormatYUV420Flexible` through `getInputImage`: the planes are written with the stride and pixel
 *   stride the codec reports, whatever its internal layout (NV12, I420, padded rows), so colours cannot be swapped.
 * - BT.709 limited range is stated in the format, like the engine's own conversion.
 * - No B-frames (`KEY_MAX_B_FRAMES = 0`): presentation order equals decoding order, so the MP4 needs no composition offsets.
 * - A size the codec cannot do is refused, never cropped or scaled; a bitrate outside its range is refused, never clamped.
 */
class MediaCodecH264(private val reportFile: File? = null) : HardwareH264 {
    private class Candidate(val name: String, val caps: CodecCapabilities)

    private class Session(val codec: MediaCodec, val w: Int, val h: Int) {
        val info = MediaCodec.BufferInfo()
        var configSeen = false
        var ended = false
    }

    private val sessions = ConcurrentHashMap<Long, Session>()
    private val ids = AtomicLong(1)

    /** Hardware H.264 encoders of this phone that take flexible YUV 4:2:0 and encode High profile with VBR rate control. */
    private val candidates: List<Candidate> by lazy { detect() }

    /** What was found and what was chosen, for the log and for [reportFile]. */
    @Volatile
    var report: String = "hardware H.264 encoders: not looked for yet"
        private set

    /** Looks for the phone's hardware encoders now (once) and returns what was found and chosen: for the diagnostics screen. */
    fun detectionReport(): String {
        candidates
        return report
    }

    /** Whether a hardware encoder that can do High profile with VBR exists on this phone (looks for it on first use). */
    val hasUsableEncoder: Boolean get() = candidates.isNotEmpty()

    private fun detect(): List<Candidate> {
        val text = StringBuilder("hardware H.264 encoders (MediaCodec)\n")
        val found = mutableListOf<Candidate>()
        try {
            for (info in MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos) {
                if (!info.isEncoder || info.supportedTypes.none { it.equals(MIME, ignoreCase = true) }) continue
                val hardware = info.isHardwareAccelerated && !info.isSoftwareOnly
                val caps = runCatching { info.getCapabilitiesForType(MIME) }.getOrNull()
                if (caps == null) {
                    text.append(" ${info.name}: capabilities unavailable\n")
                    continue
                }
                // Some codec implementations do not expose video capabilities.
                // Treat those codecs as unsupported instead of dereferencing null.
                val vc = caps.videoCapabilities
                if (vc == null) {
                    text.append(" ${info.name}: video capabilities unavailable\\n")
                    continue
                }
                // EncoderCapabilities may be absent on some vendor codecs; without it,
                // VBR support cannot be verified, so safely skip this hardware candidate.
                val enc = caps.encoderCapabilities
                if (enc == null) {
                    text.append(" ${info.name}: encoder capabilities unavailable\n")
                    continue
                }
                val profiles = caps.profileLevels.map { it.profile }.toSet()
                val high = CodecProfileLevel.AVCProfileHigh in profiles
                val main = CodecProfileLevel.AVCProfileMain in profiles
                val flexible = CodecCapabilities.COLOR_FormatYUV420Flexible in caps.colorFormats
                val vbr = enc.isBitrateModeSupported(EncoderCapabilities.BITRATE_MODE_VBR)
                val cbr = enc.isBitrateModeSupported(EncoderCapabilities.BITRATE_MODE_CBR)
                text.append(
                    " ${info.name}: hardware=$hardware profiles(high=$high main=$main) flexibleYUV=$flexible vbr=$vbr cbr=$cbr " +
                        "width=${vc.supportedWidths} height=${vc.supportedHeights} align=${vc.widthAlignment}x${vc.heightAlignment} " +
                        "bitrate=${vc.bitrateRange} maxInstances=${caps.maxSupportedInstances}\n",
                )
                if (hardware && high && flexible && vbr) found += Candidate(info.name, caps)
            }
        } catch (e: Exception) {
            text.append(" detection failed: ${e.message}\n")
        }
        // the phone maker's own encoders first
        found.sortBy { if (it.name.startsWith("c2.android.") || it.name.startsWith("OMX.google.")) 1 else 0 }
        text.append(if (found.isEmpty()) "usable hardware encoder (High profile + VBR + flexible YUV): none, the software encoder is used" else "usable: ${found.joinToString { it.name }}")
        report = text.toString()
        Log.i(TAG, report)
        runCatching { reportFile?.writeText(report) }
        return found
    }

    /** The first hardware encoder that does exactly this, or null. */
    private fun pick(width: Int, height: Int, fps: Double, bitrateKbps: Long): Candidate? =
        candidates.firstOrNull { c ->
            val vc = c.caps.videoCapabilities ?: return@firstOrNull false
            width % vc.widthAlignment == 0 && height % vc.heightAlignment == 0 &&
                vc.isSizeSupported(width, height) && vc.areSizeAndRateSupported(width, height, fps) &&
                bitrateKbps * 1000 in vc.bitrateRange.lower.toLong()..vc.bitrateRange.upper.toLong()
        }

    override fun supports(width: UInt, height: UInt, fpsNum: UInt, fpsDen: UInt, bitrateKbps: UInt): Boolean = try {
        if (fpsNum == 0u || fpsDen == 0u) false
        else pick(width.toInt(), height.toInt(), fpsNum.toDouble() / fpsDen.toDouble(), bitrateKbps.toLong()) != null
    } catch (e: Exception) {
        Log.w(TAG, "supports() failed", e)
        false
    }

    /** The format for one tier: 0 = everything, 1 = without the speed hints, 2 = also without colour metadata, B-frame hint and float values. */
    private fun format(cfg: HwOpen, tier: Int): MediaFormat {
        val fps = cfg.fpsNum.toDouble() / cfg.fpsDen.toDouble()
        val gopSeconds = (cfg.keyint.toDouble() / fps).coerceAtLeast(0.5)
        return MediaFormat.createVideoFormat(MIME, cfg.width.toInt(), cfg.height.toInt()).apply {
            // required: these never change from tier to tier
            setInteger(MediaFormat.KEY_COLOR_FORMAT, CodecCapabilities.COLOR_FormatYUV420Flexible)
            setInteger(MediaFormat.KEY_BIT_RATE, (cfg.bitrateKbps.toLong() * 1000).coerceAtMost(Int.MAX_VALUE.toLong()).toInt())
            setInteger(MediaFormat.KEY_BITRATE_MODE, EncoderCapabilities.BITRATE_MODE_VBR)
            setInteger(MediaFormat.KEY_PROFILE, CodecProfileLevel.AVCProfileHigh)
            if (tier < 2) {
                if (cfg.fpsDen == 1u) setInteger(MediaFormat.KEY_FRAME_RATE, cfg.fpsNum.toInt()) else setFloat(MediaFormat.KEY_FRAME_RATE, fps.toFloat())
                setFloat(MediaFormat.KEY_I_FRAME_INTERVAL, gopSeconds.toFloat())
                // presentation order = decoding order: the MP4 then needs no composition offsets
                setInteger(MediaFormat.KEY_MAX_B_FRAMES, 0)
                // the engine's conversion is BT.709, limited range, SDR
                setInteger(MediaFormat.KEY_COLOR_STANDARD, MediaFormat.COLOR_STANDARD_BT709)
                setInteger(MediaFormat.KEY_COLOR_RANGE, MediaFormat.COLOR_RANGE_LIMITED)
                setInteger(MediaFormat.KEY_COLOR_TRANSFER, MediaFormat.COLOR_TRANSFER_SDR_VIDEO)
            } else {
                // whole numbers for codecs that reject floats; the exact rate still comes from the timestamps
                setInteger(MediaFormat.KEY_FRAME_RATE, fps.toInt().coerceAtLeast(1).let { if (fps - it > 0.5) it + 1 else it })
                setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, Math.ceil(gopSeconds).toInt().coerceAtLeast(1))
            }
            if (tier == 0) {
                // an export is not real time: let the encoder run as fast as it can
                setInteger(MediaFormat.KEY_PRIORITY, 1)
                setInteger(MediaFormat.KEY_OPERATING_RATE, Short.MAX_VALUE.toInt())
            }
        }
    }

    override fun open(cfg: HwOpen): ULong {
        val w = cfg.width.toInt()
        val h = cfg.height.toInt()
        val fps = cfg.fpsNum.toDouble() / cfg.fpsDen.toDouble()
        val c = pick(w, h, fps, cfg.bitrateKbps.toLong()) ?: throw HwException.Failed("no hardware encoder supports ${w}x$h at $fps fps and ${cfg.bitrateKbps} kbit/s with High profile and VBR")
        var last: Exception? = null
        for (tier in 0..2) {
            var codec: MediaCodec? = null
            try {
                codec = MediaCodec.createByCodecName(c.name)
                codec.configure(format(cfg, tier), null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
                codec.start()
                val id = ids.getAndIncrement()
                sessions[id] = Session(codec, w, h)
                val accepted = runCatching { codec.inputFormat.toString() }.getOrDefault("?")
                Log.i(TAG, "opened ${c.name} (tier $tier): ${w}x$h $fps fps ${cfg.bitrateKbps} kbit/s; the codec accepted: $accepted")
                return id.toULong()
            } catch (e: Exception) {
                // a failed configure leaves the codec unusable: release it and try the next, plainer, format
                last = e
                Log.w(TAG, "${c.name} refused format tier $tier: ${e.message}")
                runCatching { codec?.release() }
            }
        }
        throw HwException.Failed("${c.name} could not be started: ${last?.message}")
    }

    override fun encode(session: ULong, yuv420: ByteArray, ptsUs: Long): List<HwOutput> {
        val s = sessions[session.toLong()] ?: throw HwException.Failed("encoder session is closed")
        try {
            val cw = (s.w + 1) / 2
            val ch = (s.h + 1) / 2
            if (yuv420.size != s.w * s.h + 2 * cw * ch) throw HwException.Failed("picture has ${yuv420.size} bytes, expected ${s.w * s.h + 2 * cw * ch}")
            val out = mutableListOf<HwOutput>()
            val deadline = System.nanoTime() + FEED_TIMEOUT_NS
            var fed = false
            while (!fed) {
                val index = s.codec.dequeueInputBuffer(5_000)
                if (index >= 0) {
                    val image = s.codec.getInputImage(index) ?: throw HwException.Failed("the encoder gave no input image")
                    // The Image belongs to the codec's buffer: it is filled, then CLOSED, and only then is the buffer handed back.
                    // If filling fails the exception ends this session (the caller closes it, which releases every buffer).
                    try {
                        fillImage(image, yuv420, s.w, s.h)
                    } finally {
                        image.close()
                    }
                    s.codec.queueInputBuffer(index, 0, yuv420.size, ptsUs, 0)
                    fed = true
                }
                drain(s, out, 0)
                if (!fed && System.nanoTime() > deadline) throw HwException.Failed("the encoder did not take a picture in time")
            }
            // the first picture does not return before the parameter sets (SPS/PPS) are known: the file's header needs them
            val configDeadline = System.nanoTime() + CONFIG_TIMEOUT_NS
            while (!s.configSeen) {
                drain(s, out, 20_000)
                if (!s.configSeen && System.nanoTime() > configDeadline) throw HwException.Failed("the encoder gave no parameter sets")
            }
            return out
        } catch (e: HwException) {
            throw e
        } catch (e: Exception) {
            throw HwException.Failed("encode failed: ${e.message}")
        }
    }

    override fun finish(session: ULong): List<HwOutput> {
        val s = sessions[session.toLong()] ?: throw HwException.Failed("encoder session is closed")
        try {
            val out = mutableListOf<HwOutput>()
            val deadline = System.nanoTime() + FINISH_TIMEOUT_NS
            var sent = false
            while (!sent) {
                val index = s.codec.dequeueInputBuffer(5_000)
                if (index >= 0) {
                    s.codec.queueInputBuffer(index, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                    sent = true
                }
                drain(s, out, 0)
                if (!sent && System.nanoTime() > deadline) throw HwException.Failed("the encoder did not accept the end of the stream")
            }
            while (!s.ended) {
                drain(s, out, 20_000)
                if (!s.ended && System.nanoTime() > deadline) throw HwException.Failed("the encoder did not finish in time")
            }
            return out
        } catch (e: HwException) {
            throw e
        } catch (e: Exception) {
            throw HwException.Failed("finish failed: ${e.message}")
        }
    }

    override fun close(session: ULong) {
        val s = sessions.remove(session.toLong()) ?: return
        runCatching { s.codec.stop() }
        runCatching { s.codec.release() }
    }

    /** Collects what the encoder has ready. Waits up to [timeoutUs] for the first buffer, then takes what is already there. */
    private fun drain(s: Session, out: MutableList<HwOutput>, timeoutUs: Long) {
        var wait = timeoutUs
        while (true) {
            val i = s.codec.dequeueOutputBuffer(s.info, wait)
            wait = 0
            when {
                i == MediaCodec.INFO_TRY_AGAIN_LATER -> return
                i == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                    // the parameter sets also come in the output format (csd-0 = SPS, csd-1 = PPS, Annex B)
                    val f = s.codec.outputFormat
                    val sets = listOf("csd-0", "csd-1").mapNotNull { key -> f.getByteBuffer(key)?.let { b -> ByteArray(b.remaining()).also { b.duplicate().get(it) } } }
                    if (sets.isNotEmpty()) {
                        out += HwOutput(sets.reduce { a, b -> a + b }, 0L, false, true)
                        s.configSeen = true
                    }
                }
                i >= 0 -> {
                    val info = s.info
                    val buffer = s.codec.getOutputBuffer(i)
                    if (info.flags and MediaCodec.BUFFER_FLAG_PARTIAL_FRAME != 0) {
                        s.codec.releaseOutputBuffer(i, false)
                        throw HwException.Failed("the encoder returned a partial frame")
                    }
                    if (buffer != null && info.size > 0) {
                        buffer.position(info.offset)
                        buffer.limit(info.offset + info.size)
                        val bytes = ByteArray(info.size)
                        buffer.get(bytes)
                        val config = info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0
                        if (config) s.configSeen = true
                        out += HwOutput(bytes, info.presentationTimeUs, info.flags and MediaCodec.BUFFER_FLAG_KEY_FRAME != 0, config)
                    }
                    val last = info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0
                    s.codec.releaseOutputBuffer(i, false)
                    if (last) {
                        s.ended = true
                        return
                    }
                }
                // INFO_OUTPUT_BUFFERS_CHANGED and anything unknown: look again
            }
        }
    }

    private fun fillImage(image: Image, yuv: ByteArray, w: Int, h: Int) {
        val cw = (w + 1) / 2
        val ch = (h + 1) / 2
        val planes = image.planes
        if (planes.size < 3) throw HwException.Failed("the encoder's input image has ${planes.size} planes")
        try {
            copyPlane(yuv, 0, w, h, planes[0].buffer, planes[0].rowStride, planes[0].pixelStride)
            copyPlane(yuv, w * h, cw, ch, planes[1].buffer, planes[1].rowStride, planes[1].pixelStride)
            copyPlane(yuv, w * h + cw * ch, cw, ch, planes[2].buffer, planes[2].rowStride, planes[2].pixelStride)
        } catch (e: IllegalStateException) {
            // never accept a picture that is only partly written: the export falls back to the software encoder
            throw HwException.Failed("input image rejected: ${e.message}")
        }
    }

    companion object {
        private const val TAG = "SevenCutHW"
        private const val MIME = "video/avc"
        private const val FEED_TIMEOUT_NS = 10_000_000_000L
        private const val CONFIG_TIMEOUT_NS = 5_000_000_000L
        private const val FINISH_TIMEOUT_NS = 30_000_000_000L
    }
}

/**
 * Writes one plane of a planar picture (`width` x `height` samples at `src[srcOffset]`) into a codec's plane buffer,
 * honouring its row stride and pixel stride. With a pixel stride above 1 the planes are interleaved (NV12): the bytes
 * between this plane's samples belong to the other chroma plane, so each row is read, changed at its own samples
 * only, and written back.
 *
 * The WHOLE plane must fit: if the destination cannot hold every row, or the source is too short, this throws
 * [IllegalStateException] before a single byte is written, so a damaged picture is never queued.
 */
internal fun copyPlane(src: ByteArray, srcOffset: Int, width: Int, height: Int, dst: ByteBuffer, rowStride: Int, pixelStride: Int) {
    check(width > 0 && height > 0 && pixelStride > 0 && rowStride > 0) { "bad plane geometry ${width}x$height stride $rowStride/$pixelStride" }
    val rowBytes = (width - 1).toLong() * pixelStride + 1
    check(rowStride >= rowBytes) { "row stride $rowStride is smaller than a row of $rowBytes bytes" }
    check(srcOffset >= 0 && srcOffset.toLong() + width.toLong() * height <= src.size) { "the picture is too short for a ${width}x$height plane" }
    // the last row only needs its own samples, not the padding after them
    val needed = (height - 1).toLong() * rowStride + rowBytes
    check(needed <= dst.limit()) { "plane buffer holds ${dst.limit()} bytes, ${needed} are needed" }
    val d = dst.duplicate()
    val tmp = if (pixelStride == 1) null else ByteArray(rowBytes.toInt())
    for (row in 0 until height) {
        val start = row * rowStride
        if (tmp == null) {
            d.position(start)
            d.put(src, srcOffset + row * width, width)
        } else {
            d.position(start)
            d.get(tmp, 0, tmp.size)
            for (x in 0 until width) tmp[x * pixelStride] = src[srcOffset + row * width + x]
            d.position(start)
            d.put(tmp, 0, tmp.size)
        }
    }
}
