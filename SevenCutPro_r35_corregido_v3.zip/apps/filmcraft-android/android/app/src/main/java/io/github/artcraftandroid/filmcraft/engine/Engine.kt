package io.github.artcraftandroid.filmcraft.engine

import android.graphics.Bitmap
import io.github.artcraftandroid.filmcraft.core.Frame
import io.github.artcraftandroid.filmcraft.core.MobileException
import io.github.artcraftandroid.filmcraft.core.MobileSession
import java.nio.ByteBuffer
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.withContext

/**
 * The FilmCraft engine (Rust: `apps/filmcraft-android`) as the app uses it: one [MobileSession]
 * and the threads its calls run on. Never call the session from the main thread.
 */
class Engine(val session: MobileSession) {
    /** Edits run one at a time, in the order the UI issued them. */
    val commands: CoroutineDispatcher = Dispatchers.IO.limitedParallelism(1)

    /**
     * The preview: one picture at a time, the newest wins. Its own thread at a higher priority, so the
     * picture under the finger is not queued behind filmstrip decoding on the shared default pool.
     */
    val preview: CoroutineDispatcher = pool("fc-preview", 1, Thread.NORM_PRIORITY + 3)

    /** Timeline filmstrips, waveforms and picker thumbnails: low priority, they must never slow the preview or playback. */
    val thumbnails: CoroutineDispatcher = pool("fc-thumbs", 2, Thread.MIN_PRIORITY + 1)

    /** Run [block] on the session after the edits issued before it. */
    suspend fun <T> command(block: MobileSession.() -> T): T = withContext(commands) { session.block() }
}

/** A small daemon thread pool at [priority] whose idle threads exit after 30 s (nothing is left behind). */
private fun pool(name: String, threads: Int, priority: Int): CoroutineDispatcher {
    val n = java.util.concurrent.atomic.AtomicInteger()
    val executor = java.util.concurrent.ThreadPoolExecutor(
        threads, threads, 30L, java.util.concurrent.TimeUnit.SECONDS, java.util.concurrent.LinkedBlockingQueue(),
    ) { r -> Thread(r, "$name-${n.incrementAndGet()}").apply { isDaemon = true; this.priority = priority } }
    executor.allowCoreThreadTimeOut(true)
    return executor.asCoroutineDispatcher()
}

/** A message for the user from anything the engine (or the system) threw. */
val Throwable.userMessage: String
    get() = when (this) {
        is MobileException -> message?.takeIf { it.isNotBlank() } ?: "Something went wrong."
        else -> message?.takeIf { it.isNotBlank() && !it.contains("Exception") } ?: "Something went wrong."
    }

/** A frame's pixels as a new bitmap. */
fun Frame.toBitmap(): Bitmap? {
    val size = validatedFrameSize(width.toLong(), height.toLong(), rgba.size) ?: return null
    val (w, h, byteCount) = size
    val bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    copyPremultipliedPixels(bitmap, rgba, byteCount)
    return bitmap
}

/** A frame's pixels into [into] when it is safe to reuse, else a new bitmap. */
fun Frame.intoBitmap(into: Bitmap?): Bitmap? {
    val size = validatedFrameSize(width.toLong(), height.toLong(), rgba.size) ?: return null
    val (w, h, byteCount) = size
    val reusable = into != null &&
        !into.isRecycled &&
        into.isMutable &&
        into.config == Bitmap.Config.ARGB_8888 &&
        into.width == w &&
        into.height == h
    val bitmap = if (reusable) into!! else Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    copyPremultipliedPixels(bitmap, rgba, byteCount)
    return bitmap
}

/** Reject invalid or unreasonably large dimensions before any Int arithmetic/allocation. */
private fun validatedFrameSize(width: Long, height: Long, rgbaSize: Int): Triple<Int, Int, Int>? {
    if (width <= 0L || height <= 0L || width > MAX_FRAME_DIMENSION || height > MAX_FRAME_DIMENSION) return null
    val byteCount = width * height * BYTES_PER_PIXEL
    if (byteCount <= 0L || byteCount > Int.MAX_VALUE || byteCount > rgbaSize.toLong()) return null
    return Triple(width.toInt(), height.toInt(), byteCount.toInt())
}

/**
 * Premultiply straight-alpha RGBA and copy it into [bitmap] through a reusable per-thread direct
 * buffer (no full-frame ByteArray per frame). The conversion runs in small chunks and moves each
 * chunk into the direct buffer with one bulk put: a per-byte `put` on a direct buffer was measured
 * slower than the original copy (see FILMCRAFT_ENGINE_REVIEW.txt).
 *
 * Not suspending, so the thread-local buffer cannot change threads mid-call. Call it from the
 * preview/thumbnail dispatchers, never from the main thread.
 */
private fun copyPremultipliedPixels(bitmap: Bitmap, rgba: ByteArray, byteCount: Int) {
    val buffer = reusablePixelBuffer.get().get(byteCount)
    buffer.clear()
    buffer.limit(byteCount)

    val chunk = chunkScratch.get()
    var pos = 0
    while (pos < byteCount) {
        val len = minOf(chunk.size, byteCount - pos)
        var j = 0
        while (j < len) {
            val src = pos + j
            val alpha = rgba[src + 3].toInt() and 0xff
            if (alpha == 255) {
                chunk[j] = rgba[src]
                chunk[j + 1] = rgba[src + 1]
                chunk[j + 2] = rgba[src + 2]
            } else if (alpha == 0) {
                chunk[j] = 0
                chunk[j + 1] = 0
                chunk[j + 2] = 0
            } else {
                chunk[j] = (((rgba[src].toInt() and 0xff) * alpha + 127) / 255).toByte()
                chunk[j + 1] = (((rgba[src + 1].toInt() and 0xff) * alpha + 127) / 255).toByte()
                chunk[j + 2] = (((rgba[src + 2].toInt() and 0xff) * alpha + 127) / 255).toByte()
            }
            chunk[j + 3] = alpha.toByte()
            j += 4
        }
        buffer.put(chunk, 0, len)
        pos += len
    }

    buffer.flip()
    bitmap.copyPixelsFromBuffer(buffer)
}

private class ReusablePixelBuffer {
    private var buffer: ByteBuffer? = null

    fun get(requiredBytes: Int): ByteBuffer {
        // Very large frames are not worth keeping alive in native memory for the thread's lifetime.
        if (requiredBytes > MAX_RETAINED_BUFFER) return ByteBuffer.allocateDirect(requiredBytes)
        var current = buffer
        if (current == null || current.capacity() < requiredBytes) {
            current = ByteBuffer.allocateDirect(requiredBytes)
            buffer = current
        }
        return current
    }
}

private val reusablePixelBuffer = object : ThreadLocal<ReusablePixelBuffer>() {
    override fun initialValue(): ReusablePixelBuffer = ReusablePixelBuffer()
}

private val chunkScratch = object : ThreadLocal<ByteArray>() {
    override fun initialValue(): ByteArray = ByteArray(CHUNK_BYTES)
}

private const val BYTES_PER_PIXEL = 4L
private const val MAX_FRAME_DIMENSION = 8_192L
private const val CHUNK_BYTES = 16_384 // a multiple of 4
private const val MAX_RETAINED_BUFFER = 16 * 1024 * 1024 // 1920x1920 RGBA is 14.7 MB
