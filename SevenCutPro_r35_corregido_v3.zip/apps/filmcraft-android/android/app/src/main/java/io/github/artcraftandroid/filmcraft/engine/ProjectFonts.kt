package io.github.artcraftandroid.filmcraft.engine

import java.io.File

/** A font file that was copied into a project, and the families it gives. */
data class CarriedFont(val file: File, val families: List<String>)

/**
 * Keeps a project's custom fonts WITH the project (its `fonts/` folder), so a project never depends on
 * another project having been opened first.
 *
 * A text clip refers to a font by family name; the name is looked up in a database that lives as long as the
 * app's process and is filled from the font files of whichever project was opened. A project that
 * got text from another project (a composition added from the project menu) therefore showed that font only
 * while the other project's files were registered in the same process, and lost it after the app was closed.
 * The fix is to give every project its own copy of every custom font it uses: when a composition is added, and
 * (for projects made before this) when a project is opened.
 */
object ProjectFonts {
    private val EXTENSIONS = setOf("ttf", "otf")

    /** Most font files read while looking for a missing family (a bound on what opening a project can cost). */
    const val MAX_CANDIDATES = 300

    private const val MAX_FONT_BYTES = 32L * 1024 * 1024

    fun fontFiles(dir: File): List<File> =
        dir.listFiles()?.filter { it.isFile && !it.name.startsWith(".") && it.extension.lowercase() in EXTENSIONS }?.sortedBy { it.name }.orEmpty()

    /**
     * Copy [source] into [to] unless a file with the very same bytes is already there (whatever its name).
     * A different font that has the same file name keeps its own name ("Name (1).ttf"): nothing is overwritten.
     * Returns the new file, or null when the project already had it (or the file can't be read or written).
     */
    fun copyInto(source: File, to: File): File? {
        if (!source.isFile || source.length() == 0L || source.length() > MAX_FONT_BYTES) return null
        return runCatching {
            to.mkdirs()
            val bytes = source.readBytes()
            val same = fontFiles(to).any { it.length() == source.length() && it.readBytes().contentEquals(bytes) }
            if (same) return null
            val target = Projects.uniqueFile(to, source.name)
            val temp = File(to, ".${target.name}.tmp")
            try {
                temp.writeBytes(bytes)
                check(temp.renameTo(target)) { "could not save ${target.name}" }
            } finally {
                temp.delete()
            }
            target
        }.getOrNull()
    }

    /** Copy every font of [from] the project [to] does not have yet. Returns the new files. */
    fun copyAll(from: File, to: File): List<File> = fontFiles(from).mapNotNull { copyInto(it, to) }

    /**
     * Find the families in [wanted] among [candidates] (font files of other projects, or the app's old global
     * folder) and copy the files that give them into [to]. [familiesOf] reads the family names inside a file
     * without registering it. The search stops as soon as everything wanted is found, or after
     * [MAX_CANDIDATES] files. A family nobody has (a system font, a font that was never saved) is simply not found.
     */
    suspend fun carry(wanted: Collection<String>, candidates: List<File>, to: File, familiesOf: suspend (ByteArray) -> List<String>): List<CarriedFont> {
        val remaining = wanted.toMutableList()
        val carried = mutableListOf<CarriedFont>()
        for (file in candidates.take(MAX_CANDIDATES)) {
            if (remaining.isEmpty()) break
            if (!file.isFile || file.length() == 0L || file.length() > MAX_FONT_BYTES) continue
            val families = runCatching { familiesOf(file.readBytes()) }.getOrDefault(emptyList())
            if (families.none { f -> remaining.any { it.equals(f, ignoreCase = true) } }) continue
            // the file is in the project already (same bytes): nothing to copy, but the family is covered
            val copy = copyInto(file, to)
            remaining.removeAll { r -> families.any { it.equals(r, ignoreCase = true) } }
            if (copy != null) carried += CarriedFont(copy, families)
        }
        return carried
    }
}
