package io.github.artcraftandroid.filmcraft.ui

import android.app.Application
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.FileProvider
import io.github.artcraftandroid.filmcraft.BuildConfig
import io.github.artcraftandroid.filmcraft.FilmcraftApplication
import io.github.artcraftandroid.filmcraft.core.GpuDiagnosis
import io.github.artcraftandroid.filmcraft.core.RenderSystemStatus
import io.github.artcraftandroid.filmcraft.core.gpuDiagnose
import io.github.artcraftandroid.filmcraft.core.gpuProbeReset
import io.github.artcraftandroid.filmcraft.core.renderSystemStatus
import io.github.artcraftandroid.filmcraft.core.setGpuAcceleration
import io.github.artcraftandroid.filmcraft.core.setMediacodecEnabled
import io.github.artcraftandroid.filmcraft.engine.HardwareInfo
import io.github.artcraftandroid.filmcraft.engine.HardwareInfoCollector
import io.github.artcraftandroid.filmcraft.engine.buildReportText
import java.io.File
import java.util.Date
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * State and actions of "Diagnóstico y aceleración de hardware". GPU (composition, not implemented yet) and MediaCodec (the video
 * encoder) are two separate things here, each with its own switch:
 * - GPU acceleration is OFF by default and can only be switched on once a diagnosis on this phone found a usable GPU; it is
 *   applied at the next start only for the same app build that validated it. Until the engine has a GPU compositor, switching it on
 *   changes nothing but what the status says: every frame is still composited on the CPU.
 * - MediaCodec is ON by default (as since the first MediaCodec export), with the software encoder as the automatic fallback.
 */
class HardwareModel(private val app: Application, private val scope: CoroutineScope) {
    private val prefs = app.getSharedPreferences("hardware", Context.MODE_PRIVATE)
    private val buildId = "${BuildConfig.VERSION_NAME}+${BuildConfig.VERSION_CODE}"

    var diagnosis by mutableStateOf<GpuDiagnosis?>(null)
        private set
    var running by mutableStateOf(false)
        private set
    var info by mutableStateOf<HardwareInfo?>(null)
        private set
    var status by mutableStateOf<RenderSystemStatus?>(null)
        private set
    var encoderReport by mutableStateOf("")
        private set
    var gpuRequested by mutableStateOf(false)
        private set
    var mediaCodecEnabled by mutableStateOf(true)
        private set
    var message by mutableStateOf<String?>(null)
        private set

    private val gpuStateDir get() = File(app.filesDir, "gpu")

    /** The GPU switch may be turned on: a diagnosis in this session found a GPU the engine could use. */
    val canEnableGpu: Boolean get() = diagnosis?.usable == true

    /** Restore the two switches into the engine at start. GPU only if this very build validated it before. */
    fun applyAtStartup() {
        mediaCodecEnabled = prefs.getBoolean(KEY_MEDIACODEC, true)
        val validatedHere = prefs.getString(KEY_GPU_VALIDATED, null) == buildId
        gpuRequested = prefs.getBoolean(KEY_GPU_REQUESTED, false) && validatedHere
        runCatching {
            setMediacodecEnabled(mediaCodecEnabled)
            setGpuAcceleration(gpuRequested)
        }
    }

    /** Read the phone's information and the engine's counters again (cheap; the screen calls it when it opens). */
    fun refresh() {
        scope.launch(Dispatchers.Default) {
            runCatching {
                info = HardwareInfoCollector.collect(app)
                status = renderSystemStatus()
                encoderReport = (app as FilmcraftApplication).hardwareEncoder.detectionReport()
            }.onFailure { message = "No se pudo leer el estado del hardware: ${it.message}" }
        }
    }

    /** Run the GPU diagnosis (a few seconds, off the UI thread). Only asks the GPU questions and allocates test textures: nothing is rendered. */
    fun runDiagnosis() {
        if (running) return
        running = true
        scope.launch(Dispatchers.Default) {
            try {
                val memory = android.app.ActivityManager.MemoryInfo()
                (app.getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager).getMemoryInfo(memory)
                val result = gpuDiagnose(gpuStateDir.absolutePath, buildId, (memory.totalMem / (1024 * 1024)).toULong(), 20_000u)
                diagnosis = result
                if (result.usable) {
                    prefs.edit().putString(KEY_GPU_VALIDATED, buildId).apply()
                } else {
                    // a GPU that is not usable cannot stay switched on
                    setGpuRequested(false)
                }
            } catch (e: Exception) {
                message = "El diagnóstico GPU falló: ${e.message}"
            } finally {
                running = false
                runCatching { status = renderSystemStatus() }
            }
        }
    }

    /** Forget a recorded crash of the GPU probe, to try again. */
    fun resetBlock() {
        runCatching { gpuProbeReset(gpuStateDir.absolutePath) }
        message = "Se borró el bloqueo del diagnóstico GPU. Ejecútalo de nuevo."
    }

    fun setGpuRequested(on: Boolean) {
        val allowed = on && canEnableGpu
        gpuRequested = allowed
        prefs.edit().putBoolean(KEY_GPU_REQUESTED, allowed).apply()
        runCatching { setGpuAcceleration(allowed) }
        scope.launch(Dispatchers.Default) { runCatching { status = renderSystemStatus() } }
    }

    fun setMediaCodec(on: Boolean) {
        mediaCodecEnabled = on
        prefs.edit().putBoolean(KEY_MEDIACODEC, on).apply()
        runCatching { setMediacodecEnabled(on) }
        scope.launch(Dispatchers.Default) { runCatching { status = renderSystemStatus() } }
    }

    /** The whole report as text: the phone, what works, MediaCodec and the GPU diagnosis. */
    fun reportText(): String =
        buildReportText(
            appBuild = buildId,
            now = Date(),
            info = info,
            working = status?.rows?.map { Triple(it.stage, it.system, it.detail) }.orEmpty(),
            encoderReport = encoderReport,
            gpuSummary = diagnosis?.summary,
        )

    /** Share the report through the system share sheet, as a text file (no need to open Android/data). */
    fun share(context: Context) {
        runCatching {
            val dir = File(app.cacheDir, "share").apply { mkdirs() }
            val file = File(dir, "informe-hardware-seven-cut-pro.txt")
            file.writeText(reportText())
            val uri = FileProvider.getUriForFile(app, "${app.packageName}.files", file)
            val send = Intent(Intent.ACTION_SEND)
                .setType("text/plain")
                .putExtra(Intent.EXTRA_STREAM, uri)
                .putExtra(Intent.EXTRA_SUBJECT, "Seven Cut Pro: diagnóstico de hardware")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            send.clipData = ClipData.newRawUri("", uri)
            context.startActivity(Intent.createChooser(send, "Compartir informe").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }.onFailure { message = "No se pudo compartir el informe: ${it.message}" }
    }

    /** Copy the report to the clipboard. */
    fun copy() {
        runCatching {
            (app.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("Informe de hardware", reportText()))
            message = "Informe copiado."
        }.onFailure { message = "No se pudo copiar el informe: ${it.message}" }
    }

    fun clearMessage() {
        message = null
    }

    private companion object {
        const val KEY_GPU_REQUESTED = "gpu_requested"
        const val KEY_GPU_VALIDATED = "gpu_validated_build"
        const val KEY_MEDIACODEC = "mediacodec_enabled"
    }
}
