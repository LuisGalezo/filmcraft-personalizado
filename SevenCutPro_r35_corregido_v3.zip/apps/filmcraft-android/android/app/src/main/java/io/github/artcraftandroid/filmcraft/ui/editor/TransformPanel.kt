package io.github.artcraftandroid.filmcraft.ui.editor

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle as UiTextStyle
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import io.github.artcraftandroid.filmcraft.ui.Fc
import io.github.artcraftandroid.filmcraft.ui.FcSize
import io.github.artcraftandroid.filmcraft.ui.FcType
import io.github.artcraftandroid.filmcraft.ui.GlyphIcon
import io.github.artcraftandroid.filmcraft.ui.Inter
import io.github.artcraftandroid.filmcraft.ui.LucideIcons
import io.github.artcraftandroid.filmcraft.ui.ToolPanel
import io.github.artcraftandroid.filmcraft.ui.glyph
import kotlin.math.abs
import kotlin.math.roundToLong

private enum class TransformTab(val label: String, val steps: List<Double>, val unit: String) {
    Position("Position", listOf(1.0, 10.0, 100.0), "%"),
    Zoom("Zoom", listOf(1.0, 10.0, 50.0), "%"),
    Rotate("Rotate", listOf(1.0, 15.0, 90.0), "°"),
}

/**
 * Transform: position, zoom and rotation of the selected (or chosen) clips, typed as exact numbers.
 * Each section has its own Reset. Nothing here is a finger-drag control (the preview still has
 * its own pinch / drag gestures).
 *
 * Position is the clip's centre from the frame's centre in % of the frame (X across, Y down; 0 =
 * centred, 100 = one whole frame away), so a value above 100 or below -100 puts it wholly outside
 * the frame, to start an entrance from there. Zoom is the size in % of the placed size; Rotate is
 * degrees, clockwise.
 */
@Composable
fun TransformPanel(ed: EditorController, close: () -> Unit, modifier: Modifier = Modifier) {
    var tab by remember { mutableStateOf(TransformTab.Position) }
    val ids = ed.transformTargets.map { it.id }
    val revision = ed.timeline?.revision
    val places by produceState(emptyList<io.github.artcraftandroid.filmcraft.core.Placement>(), ids, revision) {
        value = ed.placementsOf(ids)
    }
    val frameW = (ed.timeline?.width?.toDouble() ?: 1.0).coerceAtLeast(1.0)
    val frameH = (ed.timeline?.height?.toDouble() ?: 1.0).coerceAtLeast(1.0)
    val xs = places.map { (it.x - frameW / 2) / frameW * 100.0 }
    val ys = places.map { (it.y - frameH / 2) / frameH * 100.0 }
    val zooms = places.map { it.scale * 100.0 }
    val turns = places.map { it.rotation }
    ToolPanel("Transform", close, modifier.imePadding(), tag = "transform_panel") {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp)) {
            for (t in TransformTab.entries) {
                Column(
                    Modifier
                        .weight(1f)
                        .clickable(role = Role.Tab) { tab = t }
                        .testTag("transform_tab_${t.name.lowercase()}")
                        .semantics { selected = tab == t },
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Text(t.label, style = FcType.Label, color = if (tab == t) Fc.Title else Fc.Detail, modifier = Modifier.padding(top = 6.dp, bottom = 10.dp))
                    Box(Modifier.width(48.dp).height(3.dp).clip(CircleShape).background(if (tab == t) Fc.Title else Color.Transparent))
                }
            }
        }
        HorizontalDivider(color = Fc.Divider, thickness = 1.dp)
        // the same height on every tab
        Column(Modifier.fillMaxWidth().height(224.dp).padding(horizontal = FcSize.PanelPadding, vertical = 12.dp)) {
            val enabled = places.isNotEmpty()
            when (tab) {
                TransformTab.Position -> SectionBody(
                    tab = tab,
                    reset = { ed.transform("reset_position", null, null, false) },
                ) { step ->
                    ValueRow("X", tab.unit, xs, enabled, "transform_x", step,
                        onSet = { ed.transform("position", it, null, false) },
                        onStep = { ed.transform("position", it, null, true) })
                    Spacer(Modifier.height(10.dp))
                    ValueRow("Y", tab.unit, ys, enabled, "transform_y", step,
                        onSet = { ed.transform("position", null, it, false) },
                        onStep = { ed.transform("position", null, it, true) })
                }
                TransformTab.Zoom -> SectionBody(
                    tab = tab,
                    reset = { ed.transform("reset_zoom", null, null, false) },
                ) { step ->
                    ValueRow("Zoom", tab.unit, zooms, enabled, "transform_zoom", step,
                        onSet = { ed.transform("zoom", it, null, false) },
                        onStep = { ed.transform("zoom", it, null, true) })
                }
                TransformTab.Rotate -> SectionBody(
                    tab = tab,
                    reset = { ed.transform("reset_rotate", null, null, false) },
                ) { step ->
                    ValueRow("Angle", tab.unit, turns, enabled, "transform_rotate", step,
                        onSet = { ed.transform("rotate", it, null, false) },
                        onStep = { ed.transform("rotate", it, null, true) })
                }
            }
        }
    }
}

/** One section: its step choice and its own Reset on top, then [content] with the chosen step. */
@Composable
private fun SectionBody(tab: TransformTab, reset: () -> Unit, content: @Composable (step: Double) -> Unit) {
    var stepIndex by remember(tab) { mutableIntStateOf(0) }
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text("Step", style = FcType.Caption, color = Fc.Detail)
        Spacer(Modifier.width(8.dp))
        tab.steps.forEachIndexed { i, s ->
            Box(
                Modifier
                    .padding(end = 6.dp)
                    .height(32.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(if (i == stepIndex) Fc.Title else Fc.Chip)
                    .clickable(role = Role.Button) { stepIndex = i }
                    .padding(horizontal = 12.dp)
                    .testTag("transform_step_${tab.name.lowercase()}_$i")
                    .semantics { selected = i == stepIndex },
                contentAlignment = Alignment.Center,
            ) {
                Text(fmt(s), style = FcType.Caption, color = if (i == stepIndex) Fc.Panel else Fc.Body)
            }
        }
        Spacer(Modifier.weight(1f))
        Row(
            Modifier
                .height(32.dp)
                .clip(CircleShape)
                .background(Fc.PillButton)
                .clickable(role = Role.Button, onClick = reset)
                .padding(horizontal = 12.dp)
                .testTag("transform_reset_${tab.name.lowercase()}")
                .semantics { contentDescription = "Reset ${tab.label.lowercase()}" },
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            GlyphIcon(LucideIcons.Undo2.glyph(), Fc.Body, size = 18.dp)
            Text("Reset", style = FcType.Caption, color = Fc.Body)
        }
    }
    Spacer(Modifier.height(16.dp))
    content(tab.steps[stepIndex])
}

/**
 * A label, then − [number] + and a sign flip. With several clips the number shows "—" when they
 * differ; typing sets every clip to it, − / + move each one by the step from where it is.
 */
@Composable
private fun ValueRow(
    label: String,
    unit: String,
    values: List<Double>,
    enabled: Boolean,
    tag: String,
    step: Double,
    onSet: (Double) -> Unit,
    onStep: (Double) -> Unit,
) {
    val same = values.isNotEmpty() && values.all { abs(it - values[0]) < 0.005 }
    val shown = if (same) fmt(values[0]) else "—"
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, style = FcType.Label, color = Fc.Secondary, modifier = Modifier.width(56.dp))
        RoundButton("−", "$label minus", enabled, "${tag}_minus") { onStep(-step) }
        Spacer(Modifier.width(8.dp))
        NumberField(shown, enabled, tag, Modifier.weight(1f), onSet)
        Spacer(Modifier.width(2.dp))
        Text(unit, style = FcType.Caption, color = Fc.Detail, modifier = Modifier.width(18.dp), textAlign = TextAlign.Center)
        Spacer(Modifier.width(6.dp))
        RoundButton("+", "$label plus", enabled, "${tag}_plus") { onStep(step) }
        Spacer(Modifier.width(8.dp))
        // flips the sign, so a negative value never depends on the keyboard having a minus key
        RoundButton("±", "$label flip sign", enabled && same, "${tag}_sign") { onSet(-values[0]) }
    }
}

@Composable
private fun RoundButton(text: String, description: String, enabled: Boolean, tag: String, onClick: () -> Unit) {
    Box(
        Modifier
            .size(44.dp)
            .clip(CircleShape)
            .background(if (enabled) Fc.PillButton else Fc.Raised)
            .clickable(enabled = enabled, role = Role.Button, onClick = onClick)
            .testTag(tag)
            .semantics { contentDescription = description },
        contentAlignment = Alignment.Center,
    ) {
        Text(text, style = FcType.Header, color = if (enabled) Fc.Title else Fc.Disabled)
    }
}

/** An exact number: typed in, applied with the keyboard's Done (or when the field loses focus). */
@Composable
private fun NumberField(value: String, enabled: Boolean, tag: String, modifier: Modifier, onCommit: (Double) -> Unit) {
    var text by remember(value) { mutableStateOf(value) }
    var focused by remember { mutableStateOf(false) }
    val focus = LocalFocusManager.current
    fun commit() {
        val v = text.trim().replace(',', '.').toDoubleOrNull()
        if (v != null && v.isFinite()) {
            if (fmt(v) != value) onCommit(v)
        } else {
            text = value
        }
    }
    BasicTextField(
        value = text,
        onValueChange = { s -> text = s.filter { it.isDigit() || it == '.' || it == ',' || it == '-' }.take(12) },
        enabled = enabled,
        singleLine = true,
        textStyle = UiTextStyle(fontFamily = Inter, fontSize = 17.sp, color = Fc.Title, textAlign = TextAlign.Center),
        cursorBrush = SolidColor(Fc.Title),
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal, imeAction = ImeAction.Done),
        keyboardActions = KeyboardActions(onDone = { commit(); focus.clearFocus() }),
        modifier = modifier
            .height(44.dp)
            .border(1.dp, Fc.Divider, RoundedCornerShape(12.dp))
            .onFocusChanged {
                if (focused && !it.isFocused) commit()
                focused = it.isFocused
            }
            .testTag(tag),
        decorationBox = { inner ->
            Box(Modifier.fillMaxSize().padding(horizontal = 8.dp), contentAlignment = Alignment.Center) { inner() }
        },
    )
}

/** A number as short as it can be: whole numbers without decimals, else two decimals trimmed. */
private fun fmt(v: Double): String {
    if (abs(v - v.roundToLong()) < 0.005) return v.roundToLong().toString()
    return String.format(java.util.Locale.US, "%.2f", v).trimEnd('0').trimEnd('.')
}
