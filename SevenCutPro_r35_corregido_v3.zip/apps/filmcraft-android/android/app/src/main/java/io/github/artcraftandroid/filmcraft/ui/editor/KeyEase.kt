package io.github.artcraftandroid.filmcraft.ui.editor

/** One way a keyframe can be interpolated (Premiere's keyframe types); [id] is what the engine takes. */
enum class KeyEase(val id: String, val label: String) {
    Linear("linear", "Linear"),
    Bezier("bezier", "Bezier"),
    AutoBezier("auto_bezier", "Auto Bezier"),
    ContinuousBezier("continuous_bezier", "Cont. Bezier"),
    Hold("hold", "Hold"),
    EaseIn("ease_in", "Ease In"),
    EaseOut("ease_out", "Ease Out"),
    ;

    /**
     * The change from one key to the next (0 → 1) at [u] (0..1) when only this key carries the type:
     * what the tile's little curve draws. The shapes follow the engine's own easing (a cubic
     * Bezier with one third of the stretch as handle length, flat where a handle is eased).
     */
    fun at(u: Double): Double {
        val x = u.coerceIn(0.0, 1.0)
        return when (this) {
            Linear -> x
            Hold -> if (x < 1.0) 0.0 else 1.0
            Bezier, AutoBezier, ContinuousBezier -> bezierY(1.0 / 3.0, 0.0, 2.0 / 3.0, 1.0, x)
            EaseIn -> bezierY(1.0 / 3.0, 1.0 / 3.0, 2.0 / 3.0, 1.0, x)
            EaseOut -> bezierY(1.0 / 3.0, 0.0, 2.0 / 3.0, 2.0 / 3.0, x)
        }
    }

    companion object {
        fun of(id: String): KeyEase? = entries.firstOrNull { it.id == id }

        /** The y of the CSS-style cubic Bezier (0,0)-(x1,y1)-(x2,y2)-(1,1) at [x] (bisection). */
        fun bezierY(x1: Double, y1: Double, x2: Double, y2: Double, x: Double): Double {
            fun bx(s: Double) = 3 * (1 - s) * (1 - s) * s * x1 + 3 * (1 - s) * s * s * x2 + s * s * s
            fun by(s: Double) = 3 * (1 - s) * (1 - s) * s * y1 + 3 * (1 - s) * s * s * y2 + s * s * s
            var lo = 0.0
            var hi = 1.0
            repeat(50) {
                val mid = (lo + hi) / 2
                if (bx(mid) < x) lo = mid else hi = mid
            }
            return by((lo + hi) / 2)
        }
    }
}

/**
 * The stretch to play so the user sees what a type does: "Ease In" shapes the way into the key, so
 * the stretch before it; every other type shapes the way out, so the stretch after it. Returns
 * (from, to) in timeline ticks, or null when there is nothing to play. [key], [prev] (-1: none) and
 * [next] come from the engine.
 */
fun keyPreviewSpan(kind: KeyEase, key: Long, prev: Long, next: Long, minTicks: Long): Pair<Long, Long>? {
    val span = if (kind == KeyEase.EaseIn && prev >= 0) prev to key else key to next
    return if (span.second - span.first >= minTicks) span else null
}
