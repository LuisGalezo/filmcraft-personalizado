package io.github.artcraftandroid.filmcraft.ui.editor

import android.graphics.BitmapFactory
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import io.github.artcraftandroid.filmcraft.engine.ProjectEntry
import io.github.artcraftandroid.filmcraft.ui.Fc
import io.github.artcraftandroid.filmcraft.ui.FcDialog
import io.github.artcraftandroid.filmcraft.ui.FcType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Files ▸ Projects: the person's saved projects (and only those) as cards with their picture and
 * name. Choosing one and pressing Add puts an independent copy of it on the timeline as a composition.
 */
@Composable
fun ProjectPickerDialog(ed: EditorController) {
    var chosen by remember { mutableStateOf<ProjectEntry?>(null) }
    val choices = ed.projectChoices
    FcDialog(
        title = "Add a composition",
        confirm = "Add",
        onConfirm = { chosen?.let { ed.addProjectAsComposition(it) } },
        onDismiss = { ed.closeProjectPicker() },
        confirmEnabled = chosen != null,
    ) {
        Text("Pick one of your projects. It is added as a copy: changing it here never changes the original.", style = FcType.Caption, color = Fc.Detail)
        Spacer(Modifier.height(12.dp))
        when {
            choices == null -> Box(Modifier.fillMaxWidth().height(120.dp), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = Fc.Accent)
            }
            choices.isEmpty() -> Box(Modifier.fillMaxWidth().height(120.dp).testTag("project_picker_empty"), contentAlignment = Alignment.Center) {
                Text("You have no other saved projects yet.", style = FcType.Body, color = Fc.Detail, textAlign = TextAlign.Center)
            }
            else -> LazyVerticalGrid(
                columns = GridCells.Adaptive(96.dp),
                modifier = Modifier.fillMaxWidth().heightIn(max = 320.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                items(choices, key = { it.id }) { p ->
                    ProjectChoice(p, selected = chosen?.id == p.id) { chosen = p }
                }
            }
        }
    }
}

@Composable
private fun ProjectChoice(p: ProjectEntry, selected: Boolean, onClick: () -> Unit) {
    val poster by produceState<ImageBitmap?>(null, p.id, p.opened) {
        value = withContext(Dispatchers.IO) { runCatching { BitmapFactory.decodeFile(p.poster.absolutePath)?.asImageBitmap() }.getOrNull() }
    }
    val shape = RoundedCornerShape(12.dp)
    Column(Modifier.testTag("project_picker_${p.id}")) {
        Box(
            Modifier
                .size(96.dp)
                .clip(shape)
                .background(Fc.Raised)
                .border(if (selected) 2.dp else 1.dp, if (selected) Fc.Accent else Fc.Hairline, shape)
                .clickable(role = Role.Button, onClick = onClick)
                .semantics { contentDescription = p.name },
        ) {
            poster?.let { Image(it, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
        }
        Spacer(Modifier.height(5.dp))
        Text(p.name, style = FcType.Caption, color = if (selected) Fc.Title else Fc.Detail, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}
