package io.github.artcraftandroid.filmcraft.ui.editor

/**
 * The two families of keyframes a layer can have. Each one is stored on its own parameters in the
 * engine, so adding, removing, moving or restyling a key of one never touches the other; they are
 * only shown on the same layer.
 */
object KeyGroup {
    const val TRANSFORM = "transform"
    const val AUDIO = "audio"

    /** Audio while the user works on sound (an audio clip, or the Volume / Fade tools); else Transform. */
    fun of(clipIsAudio: Boolean, soundToolOpen: Boolean): String = if (clipIsAudio || soundToolOpen) AUDIO else TRANSFORM

    /** The key times of [group] out of the two lists a clip reports. */
    fun keys(group: String, transform: List<Long>, audio: List<Long>): List<Long> = if (group == AUDIO) audio else transform

    /** The family that is not [group] (drawn dimmed, not editable from here). */
    fun other(group: String): String = if (group == AUDIO) TRANSFORM else AUDIO
}
