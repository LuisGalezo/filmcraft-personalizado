package io.github.artcraftandroid.filmcraft.ui.editor

/**
 * Where the view goes when another layer is chosen. The timeline is centred on the playhead, so
 * "the view" is the playhead's place: a layer that starts after it is brought in from the left
 * (to its start), one that ended before it from the right (to its last frame), and a layer the
 * playhead is already inside leaves it exactly where it is. A tap never moves it any other way.
 */
object LayerGlide {
    /** The tick to glide to, or null when the playhead is already inside the layer. */
    fun target(playhead: Long, clipStart: Long, clipDuration: Long, frameTicks: Long): Long? {
        val end = clipStart + clipDuration
        val last = (end - frameTicks).coerceAtLeast(clipStart)
        return when {
            playhead < clipStart -> clipStart
            playhead >= end -> last
            else -> null
        }
    }

    /** Moderately quick whatever the distance: 160 ms up to 320 ms. */
    fun millis(distancePx: Float): Long = (150f + distancePx * 0.2f).coerceIn(160f, 320f).toLong()

    /** Fast at first, soft at the end (u in 0..1). */
    fun ease(u: Float): Float {
        val c = u.coerceIn(0f, 1f)
        val r = 1f - c
        return 1f - r * r * r
    }
}
