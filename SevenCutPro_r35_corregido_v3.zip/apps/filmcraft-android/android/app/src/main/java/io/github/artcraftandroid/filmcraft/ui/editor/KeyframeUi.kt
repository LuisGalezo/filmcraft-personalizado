package io.github.artcraftandroid.filmcraft.ui.editor

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.runtime.DisposableEffect
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.sp
import io.github.artcraftandroid.filmcraft.core.KeyInterpInfo
import io.github.artcraftandroid.filmcraft.ui.GlyphIcon
import io.github.artcraftandroid.filmcraft.ui.LucideIcons
import io.github.artcraftandroid.filmcraft.ui.ToolPanel
import io.github.artcraftandroid.filmcraft.ui.glyph
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import io.github.artcraftandroid.filmcraft.core.ClipInfo
import io.github.artcraftandroid.filmcraft.core.ClipKind
import io.github.artcraftandroid.filmcraft.ui.Fc
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import io.github.artcraftandroid.filmcraft.ui.FcIconButton
import io.github.artcraftandroid.filmcraft.ui.FcType
import kotlinx.coroutines.delay

/**
 * Add or remove a keyframe at the playhead on the selected layer. An empty diamond adds one (the
 * clip's position, scale, rotation, opacity and its sound's volume keep the values they have right
 * there, and from then on edits at other times make their own keys); a filled one says there is a
 * key at the playhead and removes it. Shown only while a layer is selected, beside Undo and Redo.
 */
@Composable
fun KeyframeButton(ed: EditorController, size: Dp, modifier: Modifier = Modifier) {
    val clip = ed.selectedClip ?: return
    if (clip.kind == ClipKind.MISSING) return
    val here = ed.keysOf(clip).any { Math.abs(it - ed.playhead) <= ed.frameTicks / 2 }
    val label = if (here) "Remove keyframe" else "Add keyframe"
    Box(
        modifier
            .size(size)
            .clickable(role = Role.Button, onClickLabel = label) { ed.toggleKeyframe() }
            .testTag(if (here) "editor_keyframe_remove_button" else "editor_keyframe_add_button")
            .semantics { contentDescription = label },
        contentAlignment = Alignment.Center,
    ) {
        Canvas(Modifier.size(size * 0.5f)) {
            val c = Offset(this.size.width / 2, this.size.height / 2)
            val d = this.size.width / 2 - 1.dp.toPx()
            val diamond = Path().apply {
                moveTo(c.x, c.y - d)
                lineTo(c.x + d, c.y)
                lineTo(c.x, c.y + d)
                lineTo(c.x - d, c.y)
                close()
            }
            if (here) {
                drawPath(diamond, Color(0xFFFFD54A))
            }
            drawPath(diamond, if (here) Color(0xFF3A2E00) else Fc.Icon, style = Stroke(2.dp.toPx()))
        }
    }
}

/** Opens the interpolation panel (Linear, Bezier, Hold, Ease In/Out...) for the keys of the selected layer. */
@Composable
fun KeyframeEaseButton(ed: EditorController, size: Dp, modifier: Modifier = Modifier) {
    val clip = ed.selectedClip ?: return
    if (clip.kind == ClipKind.MISSING || ed.keysOf(clip).isEmpty()) return
    Box(
        modifier
            .size(size)
            .clickable(role = Role.Button, onClickLabel = "Keyframe interpolation") { ed.panel = Panel.KeyInterp }
            .testTag("editor_keyframe_ease_button")
            .semantics { contentDescription = "Keyframe interpolation" },
        contentAlignment = Alignment.Center,
    ) {
        GlyphIcon(LucideIcons.ChartSpline.glyph(), Fc.Icon, size = size * 0.5f)
    }
}

/** What the advanced editor opens with: the preset's name and the keyframe's curve as it is now. */
private data class EditTarget(val name: String, val curve: KeyCurve, val kindId: String, val custom: Boolean)

/**
 * The interpolation curves window (the first of two levels): a row of presets, each with its name and a little drawing of
 * its curve: Ninguna, Lineal, Suavizado, Entrada suave, Salida suave, Entrada y salida suave and other shapes, then the
 * curves the user saved. Tapping one applies it at once to the stretch that leaves the key at the playhead (and plays the
 * stretch) and shows "Toca de nuevo para ajustar"; tapping the curve that is active opens the advanced editor
 * ([CurveEditorScreen]). A saved preset has a small x: tap it once (it turns red), tap again to delete it.
 * This is only about how a property goes from one keyframe to the next.
 */
@Composable
fun KeyInterpPanel(ed: EditorController, clip: ClipInfo, close: () -> Unit, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("seven_cut_curves", android.content.Context.MODE_PRIVATE) }
    var saved by remember { mutableStateOf(runCatching { CurveStore.decode(prefs.getString("curves", null)) }.getOrDefault(emptyList())) }
    fun keep(list: List<SavedCurve>) {
        saved = list
        runCatching { prefs.edit().putString("curves", CurveStore.encode(list)).apply() }
    }
    val info by produceState<KeyInterpInfo?>(null, clip.id, ed.timeline?.revision, ed.playhead) {
        value = runCatching { ed.keyInterpInfo(clip.id) }.getOrNull()
    }
    val i = info
    val canShape = i != null && i.hasKeys && i.hasNext
    val now = i?.toCurve() ?: KeyCurve.LINEAR
    var hint by remember { mutableStateOf<String?>(null) }
    var editing by remember { mutableStateOf<EditTarget?>(null) }
    LaunchedEffect(hint) {
        if (hint != null) {
            delay(2600)
            hint = null
        }
    }
    fun tapped(label: String, kind: KeyEase?, curve: KeyCurve?, active: Boolean) {
        val inf = i ?: return
        if (active) {
            when {
                curve == null -> hint = "\"$label\" no tiene curva que ajustar"
                !canShape -> hint = "Necesitas otro keyframe después de este"
                else -> editing = EditTarget(label, now.clamped(), inf.current, inf.custom)
            }
            return
        }
        if (kind != null) {
            ed.applyKeyInterp(kind)
        } else if (curve != null) {
            if (!canShape) {
                hint = "Necesitas otro keyframe después de este"
                return
            }
            ed.applyKeyCurve(curve)
        }
        hint = if (curve == null) "Sin interpolación: el valor salta" else "Toca de nuevo para ajustar"
    }
    ToolPanel("Curvas de interpolación", close, modifier, tag = "editor_keyframe_interp_panel") {
        if (i != null && !i.hasKeys) {
            Text("Añade primero un keyframe", color = Fc.Secondary, fontSize = 14.sp, modifier = Modifier.padding(16.dp))
        } else {
            Column(Modifier.fillMaxWidth().height(150.dp)) {
                // always there, so the panel does not change height when the hint appears
                Text(
                    hint ?: "", color = Fc.AccentLight, fontSize = 12.sp, maxLines = 1,
                    modifier = Modifier.fillMaxWidth().height(22.dp).padding(horizontal = 16.dp).testTag("editor_key_curve_hint"),
                )
                Row(
                    Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 14.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    for (p in CurvePresets.all) {
                        val on = i != null && CurvePresets.isActive(p, i.current, i.custom, now)
                        PresetCard(
                            p.short, p.label, on, p.adjustable, p.curve == null, { p.at(it) },
                            Modifier.testTag("editor_key_preset_" + p.id), onTap = { tapped(p.label, p.kind, p.curve, on) },
                            badge = when (p.id) {
                                "auto_bezier" -> 1
                                "continuous_bezier" -> 2
                                else -> 0
                            },
                        )
                    }
                    for (sc in saved) {
                        val on = i != null && i.custom && sc.curve.sameAs(now.clamped())
                        PresetCard(
                            sc.name, sc.name, on, true, false, { sc.curve.at(it) }, Modifier.testTag("editor_key_curve_saved"),
                            onTap = { tapped(sc.name, null, sc.curve, on) },
                            onDelete = { keep(saved - sc) },
                        )
                    }
                }
            }
        }
    }
    val target = editing
    if (target != null && i != null) {
        CurveEditorScreen(ed, i, target, saved, ::keep, onApplied = { hint = it }) { editing = null }
    }
}

/** How a [SmallPill] looks. */
private enum class PillStyle { Outline, Filled, White, Text }

/**
 * A compact button: the pill is 30 dp tall but the touch area is 44 dp, so it is comfortable to press without looking big.
 * [check] puts a tick before the label.
 */
@Composable
private fun SmallPill(
    label: String,
    style: PillStyle,
    tag: String,
    description: String = label,
    check: Boolean = false,
    onClick: () -> Unit,
) {
    val shape = RoundedCornerShape(15.dp)
    Box(
        Modifier
            .heightIn(min = 44.dp)
            .clickable(role = Role.Button, onClickLabel = description, onClick = onClick)
            .padding(horizontal = 2.dp)
            .testTag(tag),
        contentAlignment = Alignment.Center,
    ) {
        Row(
            Modifier
                .height(30.dp)
                .clip(shape)
                .then(
                    when (style) {
                        PillStyle.Filled -> Modifier.background(Fc.Accent)
                        PillStyle.White -> Modifier.background(Color.White)
                        PillStyle.Outline -> Modifier.border(1.dp, Fc.Secondary, shape)
                        PillStyle.Text -> Modifier
                    },
                )
                .padding(horizontal = 11.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            if (check) {
                GlyphIcon(LucideIcons.Check.glyph(), Color.White, size = 14.dp)
                Spacer(Modifier.width(4.dp))
            }
            Text(
                label,
                color = when (style) {
                    PillStyle.Filled -> Color.White
                    PillStyle.White -> Color.Black
                    PillStyle.Outline, PillStyle.Text -> Fc.Body
                },
                fontSize = 12.sp, maxLines = 1,
            )
        }
    }
}

/**
 * The advanced editor (the second level): a screen of its own with only the video and the graph, half and half. Top: the
 * video, which plays just the stretch between the key and the next key. Bottom: the curve, enlarged. Tap the curve to add a
 * point there, tap a point to select it, drag a point (or the handles of the selected point, or the two end handles) to
 * reshape it; "Eliminar punto" removes the selected point. Top right: APLICAR sets the curve on the stretch, GUARDAR keeps it
 * under a name as a preset. Bottom: RESTABLECER goes back to how the curve was when the editor opened; in the middle, the name
 * of the preset being edited.
 * What is edited is a DRAFT: the preview (picture and sound) plays the draft from a copy of the project, so nothing is changed
 * and nothing goes into the undo history until APLICAR, which is one undo step each time. Leaving without APLICAR drops the draft.
 */
@Composable
private fun CurveEditorScreen(
    ed: EditorController,
    info: KeyInterpInfo,
    target: EditTarget,
    saved: List<SavedCurve>,
    keep: (List<SavedCurve>) -> Unit,
    onApplied: (String) -> Unit,
    onClose: () -> Unit,
) {
    val key = info.key
    val next = info.next
    var draft by remember { mutableStateOf(target.curve) }
    // what the keyframe really has: how it was when the editor opened, then what APLICAR last set
    var base by remember { mutableStateOf(target.curve) }
    var selected by remember { mutableStateOf(-1) }
    // the handles of the selected point show only while this is on (the two end handles also stay for a curve with no points)
    var showHandles by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    var naming by remember { mutableStateOf(false) }
    LaunchedEffect(message) {
        if (message != null) {
            delay(2200)
            message = null
        }
    }
    val span = next - key
    // where the playhead is inside this stretch (no line when it is outside it)
    val progress = if (span > 0 && ed.playhead in key..next) ((ed.playhead - key).toDouble() / span).coerceIn(0.0, 1.0) else null
    // opening the editor moves nothing: the video stays where it is; a tap on it plays and pauses
    LaunchedEffect(Unit) { message = "Toca el video para reproducir" }
    DisposableEffect(Unit) {
        onDispose {
            ed.stop()
            ed.setDraftCurve(null)
        }
    }

    /** The preview follows the draft (or the keyframe itself when the draft is back to what it has). */
    fun settle() = ed.setDraftCurve(if (draft.sameAs(base)) null else draft)

    fun leave() {
        ed.setDraftCurve(null)
        onClose()
    }
    fun togglePreview() = ed.togglePreview(key, next, if (draft.sameAs(base)) null else draft)
    fun apply() {
        if (draft.sameAs(base)) {
            onApplied("Sin cambios que aplicar")
        } else {
            ed.applyKeyCurve(draft, play = false)
            onApplied("Curva aplicada")
        }
        // the editor closes and the settings window shows the curve; the video stays where it was
        ed.setDraftCurve(null)
        onClose()
    }
    fun addOrDelete() {
        if (selected in draft.mid.indices) {
            draft = CurveMath.removePoint(draft, selected)
            selected = -1
            settle()
            return
        }
        val at = progress?.takeIf { it in 0.03..0.97 } ?: 0.5
        val added = CurveMath.addPoint(draft, at) ?: listOf(0.5, 0.25, 0.75, 0.4, 0.6).firstNotNullOfOrNull { CurveMath.addPoint(draft, it) }
        if (added == null) {
            message = "No cabe otro punto (máximo ${CurveMath.MAX_POINTS})"
        } else {
            draft = added.first
            selected = added.second
            settle()
        }
    }

    Dialog(onDismissRequest = { leave() }, properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)) {
        BoxWithConstraints(
            Modifier
                .fillMaxSize()
                .background(Fc.Black)
                .statusBarsPadding()
                .navigationBarsPadding()
                .testTag("editor_key_curve_screen"),
        ) {
            val barH = 48.dp
            val stripH = 48.dp
            // The video keeps its own shape (Fit, never stretched) and gets the height that shape needs, at most half the
            // screen; the graph gets the rest of the middle, but never less than 25% nor more than 38% of the screen, so it is
            // neither squashed nor the whole screen.
            val aspect = ((ed.timeline?.width?.toInt() ?: 16).toFloat() / (ed.timeline?.height?.toInt() ?: 9).toFloat()).coerceIn(0.3f, 3.5f)
            val room = maxHeight - barH - stripH
            val videoWanted = minOf(maxWidth / aspect, maxHeight * 0.5f)
            val graphH = (room - videoWanted).coerceIn(maxHeight * 0.25f, maxHeight * 0.38f).coerceAtMost(room - 120.dp)
            Column(Modifier.fillMaxSize()) {
                // top: the video of this stretch; a tap plays and pauses it; the close button and messages float over it
                Box(
                    Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .background(Fc.Black)
                        .pointerInput(Unit) { detectTapGestures(onTap = { togglePreview() }) }
                        .semantics { contentDescription = if (ed.playing) "Pausar vista previa" else "Reproducir vista previa" }
                        .testTag("editor_key_curve_preview"),
                    contentAlignment = Alignment.Center,
                ) {
                    ed.picture?.let { Image(it, contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Fit) }
                    FcIconButton(
                        LucideIcons.X.glyph(), "Cerrar", { leave() }, size = 40.dp,
                        modifier = Modifier.align(Alignment.TopStart).padding(6.dp).testTag("editor_key_curve_close"),
                    )
                    message?.let {
                        Box(
                            Modifier.align(Alignment.TopCenter).padding(top = 12.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xCC000000)).padding(horizontal = 10.dp, vertical = 4.dp),
                        ) {
                            Text(it, color = Fc.Title, fontSize = 12.sp, maxLines = 1, modifier = Modifier.testTag("editor_key_curve_message"))
                        }
                    }
                }
                // the control strip: GUARDAR, Manejadores (on/off) and add / remove a point
                Row(
                    Modifier.fillMaxWidth().height(stripH).background(Fc.Panel).padding(horizontal = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    SmallPill("GUARDAR", PillStyle.Outline, "editor_key_curve_save") { naming = true }
                    Spacer(Modifier.weight(1f))
                    val canHandles = selected in draft.mid.indices
                    SmallPill(
                        "Manejadores", if (showHandles) PillStyle.Filled else PillStyle.Outline, "editor_key_curve_handles",
                        description = if (showHandles) "Ocultar manejadores" else "Mostrar manejadores",
                    ) {
                        if (!showHandles && !canHandles && draft.mid.isNotEmpty()) message = "Selecciona un punto para ver sus manejadores"
                        showHandles = !showHandles
                    }
                    val removing = selected in draft.mid.indices
                    SmallPill(
                        if (removing) "− Eliminar punto" else "+ Agregar punto", PillStyle.White,
                        if (removing) "editor_key_curve_delete_point" else "editor_key_curve_add_point",
                    ) { addOrDelete() }
                }
                // the middle: the graph
                Box(Modifier.fillMaxWidth().height(graphH).background(Fc.Panel)) {
                    CurveEditor(
                        curve = draft,
                        enabled = true,
                        progress = progress,
                        onChange = { draft = it },
                        onDone = { settle() },
                        big = true,
                        selected = selected,
                        onSelect = { selected = it },
                        showHandles = showHandles,
                        modifier = Modifier.fillMaxSize().padding(horizontal = 10.dp, vertical = 4.dp).testTag("editor_key_curve_editor_big"),
                    )
                    Text(
                        "Puntos: ${draft.mid.size}", color = Fc.Secondary, fontSize = 11.sp,
                        modifier = Modifier.align(Alignment.TopStart).padding(start = 20.dp, top = 10.dp).testTag("editor_key_curve_points_count"),
                    )
                }
                // the bottom: RESTABLECER, the name of the preset, APLICAR
                Row(
                    Modifier.fillMaxWidth().height(barH).background(Fc.Panel).padding(horizontal = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    SmallPill("RESTABLECER", PillStyle.Text, "editor_key_curve_reset") {
                        draft = target.curve
                        selected = -1
                        settle()
                        message = if (base.sameAs(target.curve)) "Curva restablecida" else "Restablecida: pulsa APLICAR para confirmar"
                    }
                    Text(
                        target.name + if (!draft.sameAs(target.curve)) " (editada)" else "",
                        color = Fc.Title, fontSize = 15.sp, maxLines = 1, textAlign = TextAlign.Center,
                        modifier = Modifier.weight(1f).testTag("editor_key_curve_name"),
                    )
                    SmallPill("APLICAR", PillStyle.Filled, "editor_key_curve_apply", check = true) { apply() }
                }
            }
        }
    }
    if (naming) {
        CurveNameDialog(
            start = CurveStore.nextName(saved),
            onCancel = { naming = false },
            onSave = { name ->
                val out = CurveStore.addNamed(saved, name, draft)
                if (out.result != SaveResult.Full) keep(out.list)
                message = when (out.result) {
                    SaveResult.Added -> "Guardada: ${out.name}"
                    SaveResult.Replaced -> "Actualizada: ${out.name}"
                    SaveResult.Full -> "La lista está llena"
                }
                naming = false
            },
        )
    }
}

/** The small window that asks for the name of a curve to keep as a preset. */
@Composable
private fun CurveNameDialog(start: String, onCancel: () -> Unit, onSave: (String) -> Unit) {
    var name by remember { mutableStateOf(start) }
    Dialog(onDismissRequest = onCancel, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(
            Modifier
                .fillMaxWidth(0.86f)
                .clip(RoundedCornerShape(24.dp))
                .background(Fc.Panel)
                .padding(20.dp)
                .testTag("editor_key_curve_name_dialog"),
        ) {
            Text("Nombre de la curva", style = FcType.Header, color = Fc.Title)
            Spacer(Modifier.height(12.dp))
            BasicTextField(
                value = name,
                onValueChange = { name = it.take(CurveStore.MAX_NAME) },
                singleLine = true,
                textStyle = TextStyle(color = Color.White, fontSize = 16.sp),
                cursorBrush = SolidColor(Fc.Accent),
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(Fc.Raised)
                    .padding(horizontal = 14.dp, vertical = 12.dp)
                    .testTag("editor_key_curve_name_field"),
            )
            Spacer(Modifier.height(16.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                DialogButton("Cancelar", filled = false, tag = "editor_key_curve_name_cancel", modifier = Modifier.weight(1f)) { onCancel() }
                DialogButton("Guardar", filled = true, tag = "editor_key_curve_name_save", modifier = Modifier.weight(1f)) { onSave(name) }
            }
        }
    }
}

@Composable
private fun DialogButton(label: String, filled: Boolean, tag: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(22.dp)
    Box(
        modifier
            .height(44.dp)
            .clip(shape)
            .then(if (filled) Modifier.background(Fc.Accent) else Modifier.border(1.dp, Fc.Secondary, shape))
            .clickable(role = Role.Button, onClickLabel = label, onClick = onClick)
            .testTag(tag),
        contentAlignment = Alignment.Center,
    ) {
        Text(label, style = FcType.Button, color = if (filled) Color.White else Fc.Body, maxLines = 1)
    }
}

/**
 * One preset card: a rounded square with a simple drawing of the curve (dashed guides at the start and end values) and a short
 * name under it. The active card has a white border; when it can be adjusted it says "Ajustar" over its drawing, so a second
 * tap opens the advanced editor. "Ninguna" shows a crossed circle instead of a curve. A saved preset ([onDelete] set) shows a
 * small x: the first tap arms it (it turns red for 3 seconds), the second deletes the preset, so a stray touch deletes nothing.
 */
@Composable
private fun PresetCard(
    short: String,
    description: String,
    on: Boolean,
    adjustable: Boolean,
    isNone: Boolean,
    at: (Double) -> Double,
    modifier: Modifier,
    onTap: () -> Unit,
    onDelete: (() -> Unit)? = null,
    badge: Int = 0,
) {
    var armed by remember { mutableStateOf(false) }
    LaunchedEffect(armed) {
        if (armed) {
            delay(3000)
            armed = false
        }
    }
    val shape = RoundedCornerShape(14.dp)
    Box(modifier.width(86.dp)) {
        Column(
            Modifier
                .fillMaxWidth()
                .pointerInput(Unit) { detectTapGestures(onTap = { onTap() }) }
                .semantics { contentDescription = description + if (on) ", activa" else "" },
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Box(
                Modifier
                    .size(86.dp)
                    .clip(shape)
                    .background(Fc.Raised)
                    .border(if (on) 2.dp else 0.dp, if (on) Color.White else Color.Transparent, shape),
                contentAlignment = Alignment.Center,
            ) {
                Canvas(Modifier.fillMaxSize()) {
                    val w = size.width
                    val h = size.height
                    val pad = 12.dp.toPx()
                    val top = pad
                    val bottom = h - pad
                    val dash = PathEffect.dashPathEffect(floatArrayOf(6.dp.toPx(), 5.dp.toPx()))
                    val guide = Color(0x55FFFFFF)
                    // the dashed guides sit at the start value (bottom) and the end value (top), a solid one between
                    drawLine(guide, Offset(0f, top), Offset(w, top), 1.dp.toPx(), pathEffect = dash)
                    drawLine(guide, Offset(0f, bottom), Offset(w, bottom), 1.dp.toPx(), pathEffect = dash)
                    drawLine(guide, Offset(0f, (top + bottom) / 2), Offset(w, (top + bottom) / 2), 1.dp.toPx())
                    if (isNone) {
                        val c = Offset(w / 2, h / 2)
                        val r = 15.dp.toPx()
                        val ink = if (on) Color.White else Fc.Icon
                        drawCircle(ink, r, c, style = Stroke(2.5.dp.toPx()))
                        drawLine(ink, Offset(c.x - r * 0.7f, c.y + r * 0.7f), Offset(c.x + r * 0.7f, c.y - r * 0.7f), 2.5.dp.toPx(), StrokeCap.Round)
                    } else {
                        // A faint straight line shows what "no shaping" would be, so how far a curve bends away from it is
                        // easy to see; under the curve a light fill makes the slow and the fast parts stand out.
                        val p0 = 12.dp.toPx()
                        val t0 = p0
                        val b0 = h - p0
                        drawLine(Color(0x44FFFFFF), Offset(p0, b0), Offset(w - p0, t0), 1.dp.toPx())
                        val path = Path()
                        val n = 56
                        for (k in 0..n) {
                            val u = k / n.toFloat()
                            val x = p0 + u * (w - 2 * p0)
                            val v = at(u.toDouble()).toFloat().coerceIn(-0.25f, 1.25f)
                            val y = b0 - v * (b0 - t0)
                            if (k == 0) path.moveTo(x, y) else path.lineTo(x, y)
                        }
                        val ink = if (on) Color.White else Fc.Icon
                        val fill = Path().apply {
                            addPath(path)
                            lineTo(w - p0, b0)
                            lineTo(p0, b0)
                            close()
                        }
                        drawPath(fill, ink.copy(alpha = 0.12f))
                        drawPath(path, ink, style = Stroke(3.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
                        drawCircle(ink, 3.dp.toPx(), Offset(p0, b0))
                        drawCircle(ink, 3.dp.toPx(), Offset(w - p0, t0))
                        // Auto Bezier / continuous Bezier have the same shape as Bezier between two keys; what sets them apart is
                        // the key in the middle: automatic handles (a ring), or a handle that goes straight through it (a ring and its tangent)
                        if (badge != 0) {
                            val mu = 0.5f
                            val mv = at(0.5).toFloat().coerceIn(-0.25f, 1.25f)
                            val mc = Offset(p0 + mu * (w - 2 * p0), b0 - mv * (b0 - t0))
                            if (badge == 2) {
                                val dv = (at(0.56) - at(0.44)).toFloat() / 0.12f
                                val dir = Offset(1f, -dv * (b0 - t0) / (w - 2 * p0)).let { d -> d / d.getDistance() }
                                drawLine(Color(0xFFFFB020), mc - dir * 14.dp.toPx(), mc + dir * 14.dp.toPx(), 2.dp.toPx(), StrokeCap.Round)
                            }
                            drawCircle(Color.Black, 4.5.dp.toPx(), mc)
                            drawCircle(Color(0xFFFFB020), 4.5.dp.toPx(), mc, style = Stroke(2.dp.toPx()))
                        }
                    }
                    if (on && adjustable) drawRect(Color(0x99000000))
                }
                if (on && adjustable) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Canvas(Modifier.size(26.dp, 20.dp)) {
                            val w = size.width
                            val h = size.height
                            val t = 2.dp.toPx()
                            drawLine(Color.White, Offset(0f, h * 0.25f), Offset(w, h * 0.25f), t, StrokeCap.Round)
                            drawLine(Color.White, Offset(0f, h * 0.75f), Offset(w, h * 0.75f), t, StrokeCap.Round)
                            drawCircle(Fc.Raised, 4.dp.toPx(), Offset(w * 0.62f, h * 0.25f))
                            drawCircle(Color.White, 4.dp.toPx(), Offset(w * 0.62f, h * 0.25f), style = Stroke(t))
                            drawCircle(Fc.Raised, 4.dp.toPx(), Offset(w * 0.34f, h * 0.75f))
                            drawCircle(Color.White, 4.dp.toPx(), Offset(w * 0.34f, h * 0.75f), style = Stroke(t))
                        }
                        Text("Ajustar", color = Color.White, fontSize = 13.sp, maxLines = 1)
                    }
                }
            }
            Text(
                short, color = if (on) Fc.Title else Fc.Secondary, fontSize = 13.sp, textAlign = TextAlign.Center,
                maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                modifier = Modifier.padding(top = 6.dp).fillMaxWidth(),
            )
        }
        if (onDelete != null) {
            val action = if (armed) "Confirm: delete preset $description" else "Delete preset $description"
            Box(
                Modifier
                    .align(Alignment.TopEnd)
                    .offset(x = 4.dp, y = (-4).dp)
                    .size(32.dp)
                    .clip(CircleShape)
                    .clickable(role = Role.Button, onClickLabel = action) { if (armed) onDelete() else armed = true }
                    .testTag("editor_key_curve_delete")
                    .semantics { contentDescription = action },
                contentAlignment = Alignment.Center,
            ) {
                Box(Modifier.size(22.dp).clip(CircleShape).background(if (armed) Color(0xFFD64545) else Color(0xE6000000)), contentAlignment = Alignment.Center) {
                    GlyphIcon(if (armed) LucideIcons.Trash2.glyph() else LucideIcons.X.glyph(), if (armed) Color.White else Fc.Body, size = 13.dp)
                }
            }
        }
    }
}

/** What a touch on the graph found: [kind] is one of the HIT_ values, [index] the point, [u] the time on the curve for HIT_CURVE. */
private data class Hit(val kind: Int, val index: Int = -1, val u: Double = 0.0)

/** The margin inside the graph, so that a point on the border can still be grabbed. */
private val GRAPH_PAD = 20.dp

private const val HIT_NONE = 0
private const val HIT_END1 = 1
private const val HIT_END2 = 2
private const val HIT_POINT = 3
private const val HIT_IN = 4
private const val HIT_OUT = 5
private const val HIT_CURVE = 6

/**
 * What is under [at] on a graph [w] × [h] px with [pad] px of margin. The nearest control within [reach] wins, and a point wins
 * over a handle that is about as near, so a handle never keeps a point from being picked. Handles count only when they are
 * shown: the selected point's two handles while [showHandles] is on, the two end handles while it is on or the curve has no
 * points. Then the curve itself (within 0.8 of [reach]); else nothing.
 */
private fun hitGraph(at: Offset, c: KeyCurve, sel: Int, showHandles: Boolean, w: Float, h: Float, pad: Float, reach: Float): Hit {
    fun px(x: Double) = pad + x.toFloat() * (w - 2 * pad)
    fun py(y: Double) = pad + ((1.5 - y) / 2.0).toFloat() * (h - 2 * pad)
    val m = c.mid
    var best = Hit(HIT_NONE)
    var bestScore = Float.MAX_VALUE
    fun consider(d: Float, hit: Hit, bonus: Float) {
        if (d <= reach && d - bonus < bestScore) {
            bestScore = d - bonus
            best = hit
        }
    }
    for (k in m.indices) consider((Offset(px(m[k].x), py(m[k].y)) - at).getDistance(), Hit(HIT_POINT, k), reach * 0.3f)
    if (showHandles && sel in m.indices) {
        consider((Offset(px(m[sel].inX), py(m[sel].inY)) - at).getDistance(), Hit(HIT_IN, sel), 0f)
        consider((Offset(px(m[sel].outX), py(m[sel].outY)) - at).getDistance(), Hit(HIT_OUT, sel), 0f)
    }
    if (showHandles || m.isEmpty()) {
        consider((Offset(px(c.x1), py(c.y1)) - at).getDistance(), Hit(HIT_END1), 0f)
        consider((Offset(px(c.x2), py(c.y2)) - at).getDistance(), Hit(HIT_END2), 0f)
    }
    if (best.kind != HIT_NONE) return best
    var nearest = Float.MAX_VALUE
    var nearestU = 0.0
    for (k in 0..80) {
        val u = k / 80.0
        val d = (Offset(px(u), py(c.at(u).coerceIn(-0.5, 1.5))) - at).getDistance()
        if (d < nearest) {
            nearest = d
            nearestU = u
        }
    }
    return if (nearest <= reach * 0.8f) Hit(HIT_CURVE, u = nearestU) else Hit(HIT_NONE)
}

/**
 * The graph editor: the curve from the first key (bottom left) to the next (top right). The two end handles are always
 * there; the points inside the curve are circles (the [selected] one filled, with its own two handles). Tap the curve to add a
 * point there (the curve keeps its shape), tap a point to select it, tap elsewhere to select none; drag a point or a handle
 * to move it. [onChange] follows the finger, [onDone] runs when a change is finished (the finger lifts, or a point is added).
 * The vertical line and the dot run along the curve as the stretch plays ([progress]). The value range shown is -0.5..1.5, so
 * a curve can overshoot. [big] is the large window: bigger handles and reach, thicker line, finer grid.
 */
@Composable
private fun CurveEditor(
    curve: KeyCurve,
    enabled: Boolean,
    progress: Double?,
    onChange: (KeyCurve) -> Unit,
    onDone: () -> Unit,
    modifier: Modifier = Modifier,
    big: Boolean = false,
    selected: Int = -1,
    onSelect: (Int) -> Unit = {},
    showHandles: Boolean = true,
) {
    val handlesOn by rememberUpdatedState(showHandles)
    val latest by rememberUpdatedState(curve)
    val changeNow by rememberUpdatedState(onChange)
    val done by rememberUpdatedState(onDone)
    val picked by rememberUpdatedState(selected)
    val select by rememberUpdatedState(onSelect)
    Canvas(
        modifier
            .clip(RoundedCornerShape(14.dp))
            .background(Color(0xFF111111))
            .pointerInput(enabled, big) {
                if (!enabled) return@pointerInput
                val pad = GRAPH_PAD.toPx()
                val reach = (if (big) 32.dp else 24.dp).toPx()
                detectTapGestures(onTap = { at ->
                    val h = hitGraph(at, latest, picked, handlesOn, size.width.toFloat(), size.height.toFloat(), pad, reach)
                    when (h.kind) {
                        HIT_POINT -> select(h.index)
                        HIT_CURVE -> {
                            val added = CurveMath.addPoint(latest, h.u)
                            if (added != null) {
                                changeNow(added.first)
                                select(added.second)
                                done()
                            }
                        }
                        else -> select(-1)
                    }
                })
            }
            .pointerInput(enabled, big) {
                if (!enabled) return@pointerInput
                val pad = GRAPH_PAD.toPx()
                val reach = (if (big) 32.dp else 24.dp).toPx()
                fun ux(p: Float) = ((p - pad) / (size.width - 2 * pad)).toDouble()
                fun uy(p: Float) = 1.5 - ((p - pad) / (size.height - 2 * pad)).toDouble() * 2.0
                var dragging = Hit(HIT_NONE)
                detectDragGestures(
                    onDragStart = { at ->
                        dragging = hitGraph(at, latest, picked, handlesOn, size.width.toFloat(), size.height.toFloat(), pad, reach)
                        if (dragging.kind == HIT_POINT) select(dragging.index)
                    },
                    onDragEnd = {
                        if (dragging.kind != HIT_NONE && dragging.kind != HIT_CURVE) done()
                        dragging = Hit(HIT_NONE)
                    },
                    onDragCancel = { dragging = Hit(HIT_NONE) },
                ) { change, _ ->
                    val h = dragging
                    if (h.kind == HIT_NONE || h.kind == HIT_CURVE) return@detectDragGestures
                    change.consume()
                    val x = ux(change.position.x)
                    val y = uy(change.position.y).coerceIn(-0.5, 1.5)
                    when (h.kind) {
                        HIT_END1 -> changeNow(latest.withFirst(x, y))
                        HIT_END2 -> changeNow(latest.withSecond(x, y))
                        HIT_POINT -> changeNow(CurveMath.movePoint(latest, h.index, x, y))
                        HIT_IN -> changeNow(CurveMath.movePointHandle(latest, h.index, true, x, y))
                        HIT_OUT -> changeNow(CurveMath.movePointHandle(latest, h.index, false, x, y))
                    }
                }
            }
            .semantics { contentDescription = "Curve editor" },
    ) {
        val pad = GRAPH_PAD.toPx()
        fun px(x: Double) = pad + x.toFloat() * (size.width - 2 * pad)
        fun py(y: Double) = pad + ((1.5 - y) / 2.0).toFloat() * (size.height - 2 * pad)
        val line = Color(0xFF3A3A3A)
        val dash = PathEffect.dashPathEffect(floatArrayOf(10.dp.toPx(), 8.dp.toPx()))
        // a thin frame, faint thirds in time, a solid line at the middle value, and dashed lines at the start value (0)
        // and the end value (1): the two values the stretch goes between
        drawRect(line, Offset(px(0.0), py(1.5)), androidx.compose.ui.geometry.Size(px(1.0) - px(0.0), py(-0.5) - py(1.5)), style = Stroke(1.dp.toPx()))
        for (t in listOf(0.25, 0.5, 0.75)) drawLine(line.copy(alpha = 0.55f), Offset(px(t), py(1.5)), Offset(px(t), py(-0.5)), 1.dp.toPx())
        drawLine(line, Offset(px(0.0), py(0.5)), Offset(px(1.0), py(0.5)), 1.dp.toPx())
        for (v in listOf(0.0, 1.0)) drawLine(Color(0xFF7A7A7A), Offset(px(0.0), py(v)), Offset(px(1.0), py(v)), 1.dp.toPx(), pathEffect = dash)
        // the playback position inside the stretch
        if (progress != null) drawLine(Color.White, Offset(px(progress), py(1.5)), Offset(px(progress), py(-0.5)), 2.dp.toPx())
        val path = Path()
        val n = if (big) 160 else 48
        for (k in 0..n) {
            val u = k / n.toDouble()
            val x = px(u)
            val y = py(curve.at(u).coerceIn(-0.5, 1.5))
            if (k == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        val ink = if (enabled) Fc.AccentLight else Fc.Secondary
        drawPath(path, ink, style = Stroke((if (big) 4 else 2).dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
        if (enabled) {
            val handle = (if (big) 7 else 5).dp.toPx()
            // the two end handles: shown for a curve with no points, or while "Manejadores" is on
            if (showHandles || curve.mid.isEmpty()) {
                val a = Offset(px(curve.x1), py(curve.y1))
                val b = Offset(px(curve.x2), py(curve.y2))
                drawLine(ink.copy(alpha = 0.7f), Offset(px(0.0), py(0.0)), a, 1.5.dp.toPx())
                drawLine(ink.copy(alpha = 0.7f), Offset(px(1.0), py(1.0)), b, 1.5.dp.toPx())
                drawCircle(Fc.Accent, handle, a)
                drawCircle(Color.White, handle, a, style = Stroke(1.5.dp.toPx()))
                drawCircle(Fc.Accent, handle, b)
                drawCircle(Color.White, handle, b, style = Stroke(1.5.dp.toPx()))
            }
            // ONLY the selected point's two handles, and only while "Manejadores" is on: hiding them changes nothing in the curve
            if (showHandles) {
                curve.mid.getOrNull(selected)?.let { p ->
                    val i = Offset(px(p.inX), py(p.inY))
                    val o = Offset(px(p.outX), py(p.outY))
                    drawLine(Color.White.copy(alpha = 0.6f), Offset(px(p.x), py(p.y)), i, 1.5.dp.toPx())
                    drawLine(Color.White.copy(alpha = 0.6f), Offset(px(p.x), py(p.y)), o, 1.5.dp.toPx())
                    drawCircle(Color.White, handle * 0.85f, i)
                    drawCircle(Color.White, handle * 0.85f, o)
                }
            }
            // the points: small circles, the selected one filled white
            curve.mid.forEachIndexed { k, p ->
                val c = Offset(px(p.x), py(p.y))
                val r = 8.dp.toPx()
                if (k == selected) {
                    drawCircle(Color.White, r, c)
                } else {
                    drawCircle(Color.Black, r, c)
                    drawCircle(Color.White, r, c, style = Stroke(2.dp.toPx()))
                }
            }
        }
        if (progress != null) {
            drawCircle(Color.White, (if (big) 6 else 4).dp.toPx(), Offset(px(progress), py(curve.at(progress).coerceIn(-0.5, 1.5))))
        }
    }
}
