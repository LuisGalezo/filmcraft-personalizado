package io.github.artcraftandroid.filmcraft.engine

import android.app.ActivityManager
import android.content.Context
import android.media.MediaCodecList
import android.os.Build
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** What the phone says about itself: its graphics APIs, its memory, and the video encoders MediaCodec offers. */
data class HardwareInfo(
    /** Label and value, in the order the screen shows them. */
    val device: List<Pair<String, String>>,
    /** One line per H.264/HEVC encoder MediaCodec lists, hardware or software. */
    val encoders: List<String>,
)

/** A Vulkan version as Android declares it (`VK_MAKE_VERSION`): 0x401000 is 1.1.0. */
internal fun formatVulkanVersion(v: Int): String = "${v ushr 22}.${(v ushr 12) and 0x3FF}.${v and 0xFFF}"

/** An OpenGL ES version as `ConfigurationInfo.reqGlEsVersion` has it: 0x30002 is 3.2. */
internal fun formatGlesVersion(v: Int): String = "${v ushr 16}.${v and 0xFFFF}"

internal fun wholeMegabytes(bytes: Long): Long = bytes / (1024 * 1024)

object HardwareInfoCollector {
    fun collect(context: Context): HardwareInfo {
        val pm = context.packageManager
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memory = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
        val features = runCatching { pm.systemAvailableFeatures.orEmpty().toList() }.getOrDefault(emptyList())
        fun feature(name: String) = features.firstOrNull { it.name == name }

        val rows = mutableListOf<Pair<String, String>>()
        rows += "Dispositivo" to "${Build.MANUFACTURER} ${Build.MODEL}"
        rows += "Android" to "${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})"
        if (Build.VERSION.SDK_INT >= 31) rows += "Procesador (SoC)" to "${Build.SOC_MANUFACTURER} ${Build.SOC_MODEL}"
        rows += "Arquitecturas" to Build.SUPPORTED_ABIS.joinToString()
        rows += "Memoria RAM" to "${wholeMegabytes(memory.totalMem)} MB (libres ahora: ${wholeMegabytes(memory.availMem)} MB)"
        rows += "Vulkan: versión" to (feature("android.hardware.vulkan.version")?.let { formatVulkanVersion(it.version) } ?: "no declarada")
        rows += "Vulkan: nivel" to (feature("android.hardware.vulkan.level")?.version?.toString() ?: "no declarado")
        rows += "Vulkan: cómputo" to (if (feature("android.hardware.vulkan.compute") != null) "sí" else "no declarado")
        rows += "OpenGL ES" to runCatching { formatGlesVersion(am.deviceConfigurationInfo.reqGlEsVersion) }.getOrDefault("desconocido")
        return HardwareInfo(rows, encoders())
    }

    private fun encoders(): List<String> {
        val lines = mutableListOf<String>()
        runCatching {
            for (info in MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos) {
                if (!info.isEncoder) continue
                for (mime in info.supportedTypes) {
                    if (!mime.equals("video/avc", ignoreCase = true) && !mime.equals("video/hevc", ignoreCase = true)) continue
                    val caps = runCatching { info.getCapabilitiesForType(mime) }.getOrNull() ?: continue
                    val vc = caps.videoCapabilities ?: run {
                        lines += "${info.name}: ${mime.removePrefix("video/").uppercase(Locale.ROOT)}, capacidades de vídeo no disponibles"
                        continue
                    }
                    val hardware = info.isHardwareAccelerated && !info.isSoftwareOnly
                    lines += "${info.name}: ${mime.removePrefix("video/").uppercase(Locale.ROOT)}, ${if (hardware) "hardware" else "software"}, " +
                        "hasta ${vc.supportedWidths.upper}x${vc.supportedHeights.upper}, ${vc.bitrateRange.upper / 1_000_000} Mbit/s"
                }
            }
        }
        return lines
    }
}

/**
 * The shareable report, as plain text: the phone, what is working, MediaCodec, and the GPU diagnosis. [working] is
 * (step, system, detail). Pure, so it is tested without a phone.
 */
internal fun buildReportText(
    appBuild: String,
    now: Date,
    info: HardwareInfo?,
    working: List<Triple<String, String, String>>,
    encoderReport: String,
    gpuSummary: String?,
): String = buildString {
    appendLine("SEVEN CUT PRO — Diagnóstico y aceleración de hardware")
    appendLine("Versión de la app: $appBuild")
    appendLine("Generado: ${SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.ROOT).format(now)}")
    appendLine()
    appendLine("== Dispositivo ==")
    if (info == null) appendLine("(sin datos todavía)") else info.device.forEach { appendLine("${it.first}: ${it.second}") }
    appendLine()
    appendLine("== Sistema en uso (CPU, GPU o MediaCodec) ==")
    if (working.isEmpty()) appendLine("(sin datos todavía)") else working.forEach { appendLine("- ${it.first}: ${it.second}. ${it.third}") }
    appendLine()
    appendLine("== Codificadores de vídeo que ofrece el teléfono (MediaCodec) ==")
    if (info == null || info.encoders.isEmpty()) appendLine("(ninguno listado)") else info.encoders.forEach { appendLine(it) }
    appendLine()
    appendLine("== Detección de MediaCodec para exportar ==")
    appendLine(encoderReport.ifBlank { "(sin datos todavía)" })
    appendLine()
    appendLine("== Diagnóstico GPU (wgpu) ==")
    appendLine(gpuSummary?.trimEnd() ?: "Aún no se ha ejecutado el diagnóstico GPU.")
}
