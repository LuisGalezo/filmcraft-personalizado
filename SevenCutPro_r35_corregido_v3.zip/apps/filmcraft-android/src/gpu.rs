//! GPU diagnostics for the app (stage 1 of the GPU work): ask the device's GPU what it can do and write it down. Nothing here
//! renders anything, and nothing in the export or the CPU renderer calls it.

use std::path::Path;
use std::time::Duration;

/// The probe's answer, for the app to write to a file and the log.
#[derive(Debug, Clone, uniffi::Record)]
pub struct GpuProbeResult {
    /// The whole report as JSON (schema in `filmcraft_gpu::report`).
    pub json: String,
    /// The same, as readable text.
    pub summary: String,
    /// Whether wgpu is built into this binary (`gpu-probe` feature); false = nothing was probed.
    pub wgpu_compiled: bool,
    /// "ran", "skipped" or "timed_out", with the reason after a colon when there is one.
    pub status: String,
    /// The adapter the compositor would use ("name on backend"), or empty when there is none.
    pub selected: String,
}

/// Probe the GPU. Safe from any thread; gives up after `timeout_ms`; a build that crashed in an earlier probe is not probed
/// again (`state_dir` holds the marker, `build_id` names the build). Never panics.
#[uniffi::export]
pub fn gpu_probe(state_dir: String, build_id: String, system_ram_mb: u64, timeout_ms: u32) -> GpuProbeResult {
    let opts = filmcraft_gpu::ProbeOptions {
        system_ram_mb: (system_ram_mb > 0).then_some(system_ram_mb),
        timeout: Duration::from_millis(u64::from(timeout_ms.max(1000))),
        state_dir: Some(Path::new(&state_dir).to_path_buf()),
        build_id,
        allocation_tests: true,
    };
    let report = filmcraft_gpu::run_probe(&opts);
    let status = match &report.status {
        filmcraft_gpu::report::Status::Ran => "ran".to_string(),
        filmcraft_gpu::report::Status::Skipped(why) => format!("skipped: {why}"),
        filmcraft_gpu::report::Status::TimedOut(why) => format!("timed_out: {why}"),
    };
    GpuProbeResult {
        json: report.to_json(),
        summary: report.summary(),
        wgpu_compiled: report.wgpu_compiled,
        status,
        selected: report.selected.as_ref().map(|s| format!("{} on {}", s.name, s.backend)).unwrap_or_default(),
    }
}

/// Forget a recorded probe crash (after a driver update, or to try again on purpose).
#[uniffi::export]
pub fn gpu_probe_reset(state_dir: String) {
    filmcraft_gpu::guard::reset(Path::new(&state_dir));
}

// ---- the diagnosis, as the app's screen shows it ------------------------------------------------------------------------

use filmcraft_gpu::report::{AdapterReport, GpuReport, Level, Status};
use filmcraft_gpu::stages;

#[derive(Debug, Clone, PartialEq, Eq, uniffi::Record)]
pub struct KeyValue {
    pub key: String,
    pub value: String,
}

#[derive(Debug, Clone, PartialEq, Eq, uniffi::Record)]
pub struct GpuFormatView {
    pub name: String,
    pub role: String,
    pub required: bool,
    pub sampled: bool,
    pub render: bool,
    pub blendable: bool,
    pub filterable: bool,
    pub copy_src: bool,
}

#[derive(Debug, Clone, PartialEq, Eq, uniffi::Record)]
pub struct GpuAdapterView {
    /// "Vulkan" or "OpenGL ES".
    pub backend: String,
    pub name: String,
    pub device_type: String,
    pub driver: String,
    pub device_ok: bool,
    /// Why no device could be made, or empty.
    pub error: String,
    pub limits: Vec<KeyValue>,
    pub formats: Vec<GpuFormatView>,
    /// What the reservation tests found: test, then result and detail.
    pub allocations: Vec<KeyValue>,
    pub features: Vec<String>,
    /// "supported", "limited" or "unsupported".
    pub overall: String,
    /// The adapter a GPU compositor would use.
    pub selected: bool,
}

#[derive(Debug, Clone, PartialEq, Eq, uniffi::Record)]
pub struct GpuBackendView {
    /// "Vulkan" or "OpenGL ES".
    pub name: String,
    pub error: String,
    pub adapters: Vec<GpuAdapterView>,
}

/// One acceleratable function and what this phone says about it.
#[derive(Debug, Clone, PartialEq, Eq, uniffi::Record)]
pub struct GpuFeatureView {
    pub id: String,
    pub title: String,
    /// "supported", "limited" or "unsupported".
    pub level: String,
    pub reason: String,
}

/// One step of the progressive GPU integration.
#[derive(Debug, Clone, PartialEq, Eq, uniffi::Record)]
pub struct GpuStageView {
    pub id: String,
    pub title: String,
    pub device_level: String,
    pub implemented: bool,
    pub note: String,
}

#[derive(Debug, Clone, PartialEq, Eq, uniffi::Record)]
pub struct GpuBudgetView {
    pub budget_mb: u64,
    pub max_frame_side: u32,
    pub max_compositors: u32,
    pub compositor_1080p_f16_mb: u64,
    pub software_renderer: bool,
}

#[derive(Debug, Clone, PartialEq, uniffi::Record)]
pub struct GpuDiagnosis {
    /// "ran", or "skipped: why" / "timed_out: why".
    pub status: String,
    pub wgpu_compiled: bool,
    /// "name on backend", or empty.
    pub selected: String,
    /// A usable adapter exists (the GPU switch may be offered).
    pub usable: bool,
    pub system_ram_mb: u64,
    pub elapsed_ms: u64,
    pub backends: Vec<GpuBackendView>,
    pub features: Vec<GpuFeatureView>,
    pub stages: Vec<GpuStageView>,
    pub budget: Option<GpuBudgetView>,
    pub issues: Vec<String>,
    pub summary: String,
    pub json: String,
}

fn level_name(l: Level) -> String {
    match l {
        Level::Supported => "supported",
        Level::Limited => "limited",
        Level::Unsupported => "unsupported",
    }
    .into()
}

fn backend_title(b: &str) -> String {
    match b {
        "vulkan" => "Vulkan".into(),
        "gl" => "OpenGL ES".into(),
        other => other.to_string(),
    }
}

fn mb(bytes: u64) -> String {
    format!("{} MB", bytes / (1 << 20))
}

fn adapter_view(a: &AdapterReport, selected: bool) -> GpuAdapterView {
    GpuAdapterView {
        backend: backend_title(&a.backend),
        name: a.name.clone(),
        device_type: a.device_type.clone(),
        driver: format!("{} {}", a.driver, a.driver_info).trim().to_string(),
        device_ok: a.device.ok,
        error: a.device.error.clone().unwrap_or_default(),
        limits: vec![
            KeyValue { key: "Textura 2D máxima".into(), value: format!("{} px", a.limits.max_texture_dimension_2d) },
            KeyValue { key: "Buffer máximo".into(), value: mb(a.limits.max_buffer_size) },
            KeyValue { key: "Grupos de enlace".into(), value: a.limits.max_bind_groups.to_string() },
            KeyValue { key: "Texturas por etapa de shader".into(), value: a.limits.max_sampled_textures_per_shader_stage.to_string() },
            KeyValue { key: "Destinos de color".into(), value: a.limits.max_color_attachments.to_string() },
            KeyValue { key: "Capas de textura".into(), value: a.limits.max_texture_array_layers.to_string() },
        ],
        formats: a
            .formats
            .iter()
            .map(|f| GpuFormatView {
                name: f.name.clone(),
                role: f.role.clone(),
                required: f.required,
                sampled: f.support.sampled,
                render: f.support.render_attachment,
                blendable: f.support.blendable,
                filterable: f.support.filterable,
                copy_src: f.support.copy_src,
            })
            .collect(),
        allocations: a
            .allocations
            .iter()
            .map(|t| KeyValue { key: t.what.clone(), value: format!("{}{}", t.result, t.detail.as_ref().map_or(String::new(), |d| format!(" ({d})"))) })
            .collect(),
        features: a.features.clone(),
        overall: a.verdict.as_ref().map_or("unsupported".to_string(), |v| level_name(v.overall)),
        selected,
    }
}

/// The screen's view of a report. Pure: tested without a phone.
pub fn diagnosis(report: &GpuReport) -> GpuDiagnosis {
    let status = match &report.status {
        Status::Ran => "ran".to_string(),
        Status::Skipped(why) => format!("skipped: {why}"),
        Status::TimedOut(why) => format!("timed_out: {why}"),
    };
    let sel = report.selected.as_ref();
    let backends = report
        .backends
        .iter()
        .map(|b| GpuBackendView {
            name: backend_title(&b.backend),
            error: b.error.clone().unwrap_or_default(),
            adapters: b.adapters.iter().map(|a| adapter_view(a, sel.is_some_and(|s| s.backend == b.backend && s.name == a.name))).collect(),
        })
        .collect();
    // the functions and steps are the selected adapter's; with none selected, the best-looking adapter explains why not
    let basis = report.selected_adapter().or_else(|| report.backends.iter().flat_map(|b| &b.adapters).find(|a| a.verdict.is_some()));
    let verdict = basis.and_then(|a| a.verdict.as_ref());
    GpuDiagnosis {
        status,
        wgpu_compiled: report.wgpu_compiled,
        selected: sel.map(|s| format!("{} ({})", s.name, backend_title(&s.backend))).unwrap_or_default(),
        usable: sel.is_some(),
        system_ram_mb: report.system_ram_mb.unwrap_or(0),
        elapsed_ms: report.elapsed_ms,
        backends,
        features: verdict
            .map(|v| v.features.iter().map(|f| GpuFeatureView { id: f.feature.clone(), title: stages::feature_title(&f.feature).into(), level: level_name(f.level), reason: f.reason.clone() }).collect())
            .unwrap_or_default(),
        stages: verdict
            .map(|v| stages::plan(v).into_iter().map(|p| GpuStageView { id: p.id, title: p.title, device_level: level_name(p.device_level), implemented: p.implemented, note: p.note }).collect())
            .unwrap_or_default(),
        budget: basis.and_then(|a| a.budget.as_ref()).map(|b| GpuBudgetView {
            budget_mb: b.budget_bytes / (1 << 20),
            max_frame_side: b.max_frame_side,
            max_compositors: b.max_compositors,
            compositor_1080p_f16_mb: b.compositor_1080p_f16_bytes / (1 << 20),
            software_renderer: b.software_renderer,
        }),
        issues: report.issues.iter().map(|i| format!("{} [{}]: {}", i.severity, i.stage, i.message)).collect(),
        summary: report.summary(),
        json: report.to_json(),
    }
}

/// Run the GPU diagnosis for the "Diagnóstico y aceleración de hardware" screen. Safe from any thread (it takes a few seconds): the
/// probe runs on its own thread with a time limit, and a build that crashed in an earlier probe is not probed again until
/// [`gpu_probe_reset`]. It only asks the GPU questions and allocates a few test textures; nothing is rendered and the export and the CPU
/// renderer are untouched.
#[uniffi::export]
pub fn gpu_diagnose(state_dir: String, build_id: String, system_ram_mb: u64, timeout_ms: u32) -> GpuDiagnosis {
    let opts = filmcraft_gpu::ProbeOptions {
        system_ram_mb: (system_ram_mb > 0).then_some(system_ram_mb),
        timeout: Duration::from_millis(u64::from(timeout_ms.max(1000))),
        state_dir: Some(Path::new(&state_dir).to_path_buf()),
        build_id,
        allocation_tests: true,
    };
    diagnosis(&filmcraft_gpu::run_probe(&opts))
}

#[cfg(test)]
mod tests {
    use super::*;
    use filmcraft_gpu::report::{BackendReport, DeviceReport, FormatReport, FormatSupport, LimitsReport, Selected};

    fn format(name: &str, render: bool) -> FormatReport {
        FormatReport { name: name.into(), role: "rol".into(), required: true, support: FormatSupport { sampled: true, render_attachment: render, copy_src: true, copy_dst: true, storage: false, filterable: true, blendable: render } }
    }

    fn adapter(name: &str, device_ok: bool) -> AdapterReport {
        AdapterReport {
            backend: "vulkan".into(),
            name: name.into(),
            vendor_id: 1,
            device_id: 2,
            device_type: "integrated_gpu".into(),
            driver: "Qualcomm".into(),
            driver_info: "512.7".into(),
            features: vec!["FLOAT32_FILTERABLE".into()],
            limits: LimitsReport { max_texture_dimension_2d: 16384, max_buffer_size: 1 << 30, max_bind_groups: 4, max_sampled_textures_per_shader_stage: 16, max_color_attachments: 8, max_texture_array_layers: 2048, ..Default::default() },
            formats: vec![format("R8Unorm", true), format("Rgba8Unorm", true), format("Rgba16Float", true), format("Rgba32Float", true), format("R16Uint", true)],
            device: DeviceReport { attempted: true, ok: device_ok, error: if device_ok { None } else { Some("sin dispositivo".into()) }, ..Default::default() },
            allocations: vec![],
            verdict: None,
            budget: None,
        }
    }

    fn report(adapters: Vec<AdapterReport>) -> GpuReport {
        let mut r = GpuReport::new(true, Some(8192));
        r.backends = vec![BackendReport { backend: "vulkan".into(), adapters, error: None, elapsed_ms: 5 }, BackendReport { backend: "gl".into(), adapters: vec![], error: Some("sin EGL".into()), elapsed_ms: 1 }];
        filmcraft_gpu::finalize(&mut r);
        r
    }

    #[test]
    fn a_capable_phone_shows_its_adapter_formats_functions_steps_and_budget() {
        let d = diagnosis(&report(vec![adapter("Adreno 740", true)]));
        assert_eq!(d.status, "ran");
        assert!(d.usable && d.selected == "Adreno 740 (Vulkan)");
        assert_eq!(d.system_ram_mb, 8192);
        assert_eq!(d.backends.len(), 2);
        assert_eq!((d.backends[0].name.as_str(), d.backends[1].name.as_str()), ("Vulkan", "OpenGL ES"));
        assert_eq!(d.backends[1].error, "sin EGL");
        let a = &d.backends[0].adapters[0];
        assert!(a.selected && a.device_ok && a.overall == "supported");
        assert_eq!(a.driver, "Qualcomm 512.7");
        assert_eq!(a.formats.len(), 5);
        assert!(a.limits.iter().any(|l| l.key == "Textura 2D máxima" && l.value == "16384 px"));
        assert!(d.features.iter().any(|f| f.id == "blend_modes" && f.level == "supported" && f.title == "Los 27 modos de fusión"));
        assert_eq!(d.stages.len(), 7);
        assert!(d.stages.iter().all(|s| !s.implemented && s.device_level == "supported"), "nothing is implemented in the engine yet");
        let b = d.budget.unwrap();
        assert_eq!(b.budget_mb, 768);
        assert!(!b.software_renderer);
        assert!(d.summary.contains("Adreno 740") && d.json.contains("\"schema\""));
    }

    #[test]
    fn a_phone_with_no_usable_gpu_says_why_and_offers_nothing() {
        let d = diagnosis(&report(vec![adapter("Broken", false)]));
        assert!(!d.usable && d.selected.is_empty());
        assert!(d.backends[0].adapters[0].error.contains("sin dispositivo"));
        assert!(d.features.iter().all(|f| f.level == "unsupported"), "the best-looking adapter explains why not");
        assert!(d.stages.iter().all(|s| s.device_level == "unsupported"));
        assert!(d.issues.iter().any(|i| i.contains("[select]")));
    }

    #[test]
    fn a_build_without_wgpu_or_a_blocked_probe_shows_its_reason() {
        let mut r = GpuReport::new(false, None);
        r.status = Status::Skipped("este APK no incluye wgpu".into());
        let d = diagnosis(&r);
        assert_eq!(d.status, "skipped: este APK no incluye wgpu");
        assert!(!d.wgpu_compiled && !d.usable);
        assert!(d.backends.is_empty() && d.features.is_empty() && d.stages.is_empty() && d.budget.is_none());
        assert_eq!(d.system_ram_mb, 0);
    }
}
