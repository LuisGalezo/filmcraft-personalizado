//! Which system does what: the user's two hardware switches, and a plain-language status of every step of an export (decoding,
//! preview, compositing, encoding) saying whether the CPU, the GPU or MediaCodec did it. GPU and MediaCodec are different things:
//! the GPU composites pictures (not implemented yet: everything is composited on the CPU), MediaCodec is the phone's video
//! *encoder* (the hardware H.264 encoder, with the software encoder as the automatic fallback).

use std::sync::atomic::{AtomicBool, Ordering};

/// The GPU compositor is not written yet (stage 3 of the GPU work), so even when the switch is on every frame is composited on the CPU.
/// This flips to `true` in the same change that registers the GPU frame renderer.
pub const GPU_COMPOSITOR_AVAILABLE: bool = false;

/// GPU acceleration: off until it has been validated on the phone. Never on by itself.
static GPU_REQUESTED: AtomicBool = AtomicBool::new(false);
/// MediaCodec for H.264 exports: on (with the software encoder as fallback), as since r32.
static MEDIACODEC_ENABLED: AtomicBool = AtomicBool::new(true);

/// Whether the user asked for GPU acceleration (default false). The export request carries it as `gpuRendering`.
#[uniffi::export]
pub fn gpu_acceleration_requested() -> bool {
    GPU_REQUESTED.load(Ordering::Relaxed)
}

#[uniffi::export]
pub fn set_gpu_acceleration(requested: bool) {
    GPU_REQUESTED.store(requested, Ordering::Relaxed);
}

/// Whether exports may use MediaCodec (default true). Off = the software encoder always. The export request carries it as `hardwareEncoding`.
#[uniffi::export]
pub fn mediacodec_enabled() -> bool {
    MEDIACODEC_ENABLED.load(Ordering::Relaxed)
}

#[uniffi::export]
pub fn set_mediacodec_enabled(enabled: bool) {
    MEDIACODEC_ENABLED.store(enabled, Ordering::Relaxed);
}

/// One row of "what is working": a step, the system doing it ("CPU", "GPU", "GPU + CPU", "MediaCodec", "Software") and why.
#[derive(Debug, Clone, PartialEq, Eq, uniffi::Record)]
pub struct SystemInUse {
    pub stage: String,
    pub system: String,
    pub detail: String,
}

#[derive(Debug, Clone, PartialEq, Eq, uniffi::Record)]
pub struct RenderSystemStatus {
    pub rows: Vec<SystemInUse>,
    pub gpu_requested: bool,
    pub mediacodec_enabled: bool,
    pub gpu_frames: u64,
    pub gpu_fallbacks: u64,
    pub encoder_frames: u64,
    pub encoder_sessions: u64,
    pub encoder_declined: u64,
    pub encoder_status: String,
}

/// What the status is worked out from.
#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct StatusInputs {
    pub gpu_requested: bool,
    pub gpu_compositor_available: bool,
    pub mediacodec_enabled: bool,
    pub gpu_frames: u64,
    pub gpu_fallbacks: u64,
    pub encoder_frames: u64,
    pub encoder_sessions: u64,
    pub encoder_declined: u64,
    /// The engine's note on the last H.264 export's encoder ("hardware: ..." / "software: ..."), empty before any.
    pub encoder_status: String,
}

fn row(stage: &str, system: &str, detail: impl Into<String>) -> SystemInUse {
    SystemInUse { stage: stage.into(), system: system.into(), detail: detail.into() }
}

/// The rows of "Sistema en uso". Pure, so it is tested without a phone.
pub fn rows(i: &StatusInputs) -> Vec<SystemInUse> {
    let mut v = vec![
        row("Decodificación de vídeo", "CPU", "Códecs del propio motor. La decodificación por hardware no se usa."),
        row("Vista previa del editor", "CPU", "Siempre en CPU por ahora: la GPU no interviene en la vista previa."),
    ];

    let (system, detail) = if i.gpu_frames > 0 {
        if i.gpu_fallbacks > 0 {
            ("GPU + CPU".to_string(), format!("{} fotogramas compuestos en GPU, {} con respaldo en CPU (desde que se abrió la app).", i.gpu_frames, i.gpu_fallbacks))
        } else {
            ("GPU".to_string(), format!("{} fotogramas compuestos en GPU (desde que se abrió la app).", i.gpu_frames))
        }
    } else if !i.gpu_requested {
        ("CPU".to_string(), "La aceleración GPU está desactivada (valor por defecto).".to_string())
    } else if !i.gpu_compositor_available {
        ("CPU".to_string(), "GPU solicitada, pero el compositor GPU aún no está implementado: todo se compone en CPU.".to_string())
    } else if i.gpu_fallbacks > 0 {
        ("CPU".to_string(), format!("GPU solicitada, pero {} fotogramas volvieron a CPU y ninguno se compuso en GPU.", i.gpu_fallbacks))
    } else {
        ("CPU".to_string(), "GPU solicitada, aún sin exportaciones con GPU.".to_string())
    };
    v.push(row("Composición, efectos, filtros y transiciones (exportación)", &system, detail));
    v.push(row("Texto", "CPU", "Los glifos se rasterizan siempre en CPU."));

    let status = i.encoder_status.as_str();
    let counters = format!("Fotogramas por hardware: {}, sesiones: {}, rechazos: {} (desde que se abrió la app).", i.encoder_frames, i.encoder_sessions, i.encoder_declined);
    let (system, detail) = if !i.mediacodec_enabled {
        ("Software".to_string(), format!("MediaCodec está desactivado en este diagnóstico: se usa el codificador por software. {counters}"))
    } else if status.starts_with("hardware:") {
        ("MediaCodec".to_string(), format!("{} {counters}", status.trim_start_matches("hardware:").trim().to_string() + "."))
    } else if status.starts_with("software:") {
        ("Software".to_string(), format!("{} {counters}", status.trim_start_matches("software:").trim().to_string() + "."))
    } else {
        ("Sin exportar aún".to_string(), format!("Al exportar se usará MediaCodec si el teléfono lo admite y, si no, el codificador por software. {counters}"))
    };
    v.push(row("Codificación de vídeo H.264 (exportación)", &system, detail));
    v
}

/// What is working now, from the engine's own counters.
#[uniffi::export]
pub fn render_system_status() -> RenderSystemStatus {
    let gpu = filmcraft_export::gpu_render_stats();
    let hw = filmcraft_export::hw_encode_stats();
    let inputs = StatusInputs {
        gpu_requested: gpu_acceleration_requested(),
        gpu_compositor_available: GPU_COMPOSITOR_AVAILABLE,
        mediacodec_enabled: mediacodec_enabled(),
        gpu_frames: gpu.frames,
        gpu_fallbacks: gpu.fallbacks,
        encoder_frames: hw.frames,
        encoder_sessions: hw.sessions,
        encoder_declined: hw.declined,
        encoder_status: filmcraft_export::hardware_status(),
    };
    RenderSystemStatus {
        rows: rows(&inputs),
        gpu_requested: inputs.gpu_requested,
        mediacodec_enabled: inputs.mediacodec_enabled,
        gpu_frames: inputs.gpu_frames,
        gpu_fallbacks: inputs.gpu_fallbacks,
        encoder_frames: inputs.encoder_frames,
        encoder_sessions: inputs.encoder_sessions,
        encoder_declined: inputs.encoder_declined,
        encoder_status: inputs.encoder_status,
    }
}

/// The two switches as the export request needs them: `(gpuRendering, hardwareEncoding)`.
pub(crate) fn export_switches() -> (&'static str, &'static str) {
    (if gpu_acceleration_requested() { "auto" } else { "off" }, if mediacodec_enabled() { "auto" } else { "off" })
}

#[cfg(test)]
mod tests {
    use super::*;

    fn system_of<'a>(v: &'a [SystemInUse], stage_start: &str) -> &'a SystemInUse {
        v.iter().find(|r| r.stage.starts_with(stage_start)).unwrap_or_else(|| panic!("no row {stage_start}"))
    }

    fn inputs() -> StatusInputs {
        StatusInputs { mediacodec_enabled: true, ..Default::default() }
    }

    #[test]
    fn the_defaults_are_gpu_off_and_mediacodec_on() {
        // statics other tests of the crate may flip: restore the defaults before reading them
        set_gpu_acceleration(false);
        set_mediacodec_enabled(true);
        assert!(!gpu_acceleration_requested());
        assert!(mediacodec_enabled());
        assert_eq!(export_switches(), ("off", "auto"));
        set_gpu_acceleration(true);
        set_mediacodec_enabled(false);
        assert_eq!(export_switches(), ("auto", "off"));
        set_gpu_acceleration(false);
        set_mediacodec_enabled(true);
    }

    #[test]
    fn decoding_preview_and_text_are_always_cpu() {
        let v = rows(&inputs());
        for stage in ["Decodificación", "Vista previa", "Texto"] {
            assert_eq!(system_of(&v, stage).system, "CPU", "{stage}");
        }
    }

    #[test]
    fn compositing_is_cpu_and_says_why() {
        let off = rows(&inputs());
        let c = system_of(&off, "Composición");
        assert_eq!(c.system, "CPU");
        assert!(c.detail.contains("desactivada"));

        let asked = rows(&StatusInputs { gpu_requested: true, ..inputs() });
        let c = system_of(&asked, "Composición");
        assert_eq!(c.system, "CPU");
        assert!(c.detail.contains("aún no está implementado"));

        let ready = rows(&StatusInputs { gpu_requested: true, gpu_compositor_available: true, ..inputs() });
        assert!(system_of(&ready, "Composición").detail.contains("aún sin exportaciones con GPU"));
    }

    #[test]
    fn compositing_is_gpu_only_when_the_counters_say_frames_were_composited_there() {
        let gpu = rows(&StatusInputs { gpu_requested: true, gpu_compositor_available: true, gpu_frames: 240, ..inputs() });
        assert_eq!(system_of(&gpu, "Composición").system, "GPU");
        let mixed = rows(&StatusInputs { gpu_requested: true, gpu_compositor_available: true, gpu_frames: 200, gpu_fallbacks: 40, ..inputs() });
        let c = system_of(&mixed, "Composición");
        assert_eq!(c.system, "GPU + CPU");
        assert!(c.detail.contains("200") && c.detail.contains("40"));
        // every frame fell back: that is the CPU working, and it is said
        let failed = rows(&StatusInputs { gpu_requested: true, gpu_compositor_available: true, gpu_fallbacks: 12, ..inputs() });
        let c = system_of(&failed, "Composición");
        assert_eq!(c.system, "CPU");
        assert!(c.detail.contains("12"));
    }

    #[test]
    fn the_encoder_is_named_from_the_engines_own_note() {
        let none = rows(&inputs());
        assert_eq!(system_of(&none, "Codificación").system, "Sin exportar aún");

        let hw = rows(&StatusInputs { encoder_status: "hardware: 1080x1920 at 30.000 fps, 18662 kbit/s".into(), encoder_frames: 300, encoder_sessions: 1, ..inputs() });
        let e = system_of(&hw, "Codificación");
        assert_eq!(e.system, "MediaCodec");
        assert!(e.detail.contains("1080x1920") && e.detail.contains("300"));

        let sw = rows(&StatusInputs { encoder_status: "software: the phone's hardware encoder does not support 4000x3000".into(), encoder_declined: 1, ..inputs() });
        let e = system_of(&sw, "Codificación");
        assert_eq!(e.system, "Software");
        assert!(e.detail.contains("does not support 4000x3000") && e.detail.contains("rechazos: 1"));
    }

    #[test]
    fn turning_mediacodec_off_always_shows_software() {
        let v = rows(&StatusInputs { mediacodec_enabled: false, encoder_status: "hardware: 1920x1080".into(), ..inputs() });
        let e = system_of(&v, "Codificación");
        assert_eq!(e.system, "Software");
        assert!(e.detail.contains("desactivado"));
    }
}
