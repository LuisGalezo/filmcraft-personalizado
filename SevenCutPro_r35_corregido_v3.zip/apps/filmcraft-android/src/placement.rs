//! Where a picture, video or text sits on the frame, and moving, scaling and turning it with a
//! finger on the preview (one undo step per gesture).

use filmcraft_engine::{EngineError, Session};
use filmcraft_project::{ClipId, ItemKind, ParamValue, TrackKind};
use serde_json::json;

use crate::text::{self, Placement};
use crate::{MobileError, edits, model};

/// How small and large an item may get, as a fraction / multiple of the frame's width.
const MIN_WIDTH: f64 = 0.01;
const MAX_WIDTH: f64 = 20.0;
const MAX_TEXT_WIDTH: f64 = 6.0;
/// How far from the frame's centre the Transform panel may put an item (% of the frame's width /
/// height): ten frames away, far past any edge so an item can fly in from (or out of) the frame.
const MAX_OFFSET: f64 = 1_000.0;
/// The largest turn the Transform panel accepts, in degrees either way.
const MAX_TURN: f64 = 3_600.0;

fn is_text(s: &Session, id: u64) -> bool {
    model::sequence(s)
        .ok()
        .and_then(|(_, q)| model::find(q, ClipId(id)))
        .and_then(|f| s.project.item(f.clip.item))
        .is_some_and(|p| matches!(p.kind, ItemKind::Graphic { .. }))
}

/// Where clip `id` sits on the frame.
pub(crate) fn placement(s: &mut Session, id: u64) -> Result<Placement, MobileError> {
    if is_text(s, id) {
        return text::placement(s, id);
    }
    let (_, seq) = model::sequence(s)?;
    let (fw, fh) = (f64::from(seq.settings.width), f64::from(seq.settings.height));
    let f = model::find(seq, ClipId(id)).filter(|f| f.kind == TrackKind::Video).ok_or_else(|| MobileError::Command("That clip has no picture.".into()))?;
    let c = f.clip;
    let (sw, sh) = s.project.source_size(c.item).map(|(w, h)| (f64::from(w.max(1)), f64::from(h.max(1)))).unwrap_or((fw, fh));
    // where the clip is right now (its keys, when it has them, are read at the playhead)
    let mt = c.effect_time_at(s.playhead().max(c.start).min(c.end() - filmcraft_time::Tick(1)));
    let (mut x, mut y, mut scale, mut rotation) = (fw / 2.0, fh / 2.0, 1.0, 0.0);
    if let Some(m) = c.effects.iter().find(|e| e.effect == "motion" && e.enabled) {
        let p = m.vec2_at("position", mt);
        if !p.x.is_nan() && !p.y.is_nan() {
            (x, y) = (p.x, p.y);
        }
        scale = m.f64_at("scale", mt) / 100.0;
        rotation = m.f64_at("rotation", mt);
    }
    let fit = if c.scale_to_frame { (fw / sw).min(fh / sh) } else { 1.0 };
    Ok(Placement { x, y, width: sw * fit, height: sh * fit, scale, rotation })
}

/// The upright rectangle (left, top, right, bottom; frame pixels, clamped to the frame) a picture
/// clip covers, ignoring rotation: what the look pickers crop their previews to.
pub(crate) fn clip_rect(project: &filmcraft_project::Project, seq: &filmcraft_project::Sequence, id: u64) -> Option<(f64, f64, f64, f64)> {
    let (fw, fh) = (f64::from(seq.settings.width), f64::from(seq.settings.height));
    let f = model::find(seq, ClipId(id)).filter(|f| f.kind == TrackKind::Video)?;
    let c = f.clip;
    let (sw, sh) = project.source_size(c.item).map(|(w, h)| (f64::from(w.max(1)), f64::from(h.max(1))))?;
    let mt = c.source_in;
    let (mut x, mut y, mut scale) = (fw / 2.0, fh / 2.0, 1.0);
    if let Some(m) = c.effects.iter().find(|e| e.effect == "motion" && e.enabled) {
        let p = m.vec2_at("position", mt);
        if !p.x.is_nan() && !p.y.is_nan() {
            (x, y) = (p.x, p.y);
        }
        scale = m.f64_at("scale", mt) / 100.0;
    }
    let fit = if c.scale_to_frame { (fw / sw).min(fh / sh) } else { 1.0 };
    let (w, h) = (sw * fit * scale, sh * fit * scale);
    let r = ((x - w / 2.0).max(0.0), (y - h / 2.0).max(0.0), (x + w / 2.0).min(fw), (y + h / 2.0).min(fh));
    (r.2 - r.0 >= 1.0 && r.3 - r.1 >= 1.0).then_some(r)
}

/// Move, scale and turn clip `id`: centre at (`x`, `y`) frame pixels, `scale` × its placed size,
/// `rotation` degrees. A gesture is one undo step: its first call passes `merge = false` (a new
/// step), every later call of the same gesture `merge = true` (folded into that step, so the step
/// ends at the position where the finger was lifted).
pub(crate) fn set_placement(s: &mut Session, id: u64, x: f64, y: f64, scale: f64, rotation: f64, merge: bool) -> Result<(), MobileError> {
    if ![x, y, scale, rotation].iter().all(|v| v.is_finite()) {
        return Err(MobileError::Command("The placement must be numbers.".into()));
    }
    if !merge {
        // never fold a new gesture into the previous one
        s.history.merge_key = None;
    }
    apply_placement(s, id, x, y, scale, rotation, true)
}

/// Put clip `id` at the placement given (see [`set_placement`]); `merge` folds the edit into the
/// undo step of the previous edit of the same clip's placement.
fn apply_placement(s: &mut Session, id: u64, x: f64, y: f64, scale: f64, rotation: f64, merge: bool) -> Result<(), MobileError> {
    let now = placement(s, id)?;
    let (_, seq) = model::sequence(s)?;
    let fw = f64::from(seq.settings.width.max(1));
    let text = is_text(s, id);
    let max = if text { MAX_TEXT_WIDTH } else { MAX_WIDTH };
    let base = now.width.max(1.0);
    let scale = scale.clamp(MIN_WIDTH * fw / base, max * fw / base);
    let key = format!("place:{id}");
    if text {
        // a text layer is placed by its anchor: move that by however far the centre moves
        let v = edits::ex(s, "graphics.list", json!({"clip": id}))?;
        let l = v["layers"].as_array().and_then(|a| a.first()).ok_or_else(|| MobileError::Command("That clip has no text.".into()))?;
        let px = l["position"][0].as_f64().unwrap_or(now.x);
        let py = l["position"][1].as_f64().unwrap_or(now.y);
        let props = json!({"position": [px + x - now.x, py + y - now.y], "scale": scale * 100.0, "rotation": rotation});
        let mut q = json!({"clip": id, "layer": 0, "props": props});
        if merge {
            // `graphics.set` wants a boolean here (a text key was ignored, so every step of a
            // drag became an undo step of its own)
            q["merge"] = json!(true);
        }
        edits::ex(s, "graphics.set", q)?;
        return Ok(());
    }
    let ph = s.playhead();
    s.edit_sequence_as("Transform", merge.then_some(key.as_str()), |q, _, _| {
        let c = q.find_item_mut(ClipId(id)).map(|x| x.1).ok_or_else(|| EngineError::Other("clip gone".into()))?;
        let mt = c.effect_time_at(ph.max(c.start).min(c.end() - filmcraft_time::Tick(1)));
        let m = c.effects.iter_mut().find(|e| e.effect == "motion").ok_or_else(|| EngineError::Other("no motion".into()))?;
        // a property with keyframes gets a key at the playhead (its other keys stay); one without is set
        let mut put = |p: &str, v: ParamValue| {
            if let Some(param) = m.param_mut(p) {
                if param.is_animated() {
                    param.set_at(mt, v);
                } else {
                    param.value = v;
                }
            }
        };
        put("position", ParamValue::Vec2(filmcraft_geom::Vec2::new(x, y)));
        put("scale", ParamValue::Float(scale * 100.0));
        put("rotation", ParamValue::Float(rotation));
        m.enabled = true;
        Ok(())
    })?;
    edits::settle(s);
    Ok(())
}

/// The Transform panel: change one `part` of every chosen clip (the ones with a picture, and text),
/// all as one undo step.
///
/// * `"position"`: `x` / `y` are the centre's distance from the frame's centre, in % of the
///   frame's width / height (0 = centred, 100 = one whole frame to the right / down, negative =
///   left / up, no upper limit short of [`MAX_OFFSET`]). A `None` axis is left as it is.
/// * `"zoom"`: `x` is the size in % of the clip's placed size (100 = as placed).
/// * `"rotate"`: `x` is the turn in degrees, clockwise.
/// * `"reset_position"`, `"reset_zoom"`, `"reset_rotate"`: put that part back (centred, 100 %, 0°).
///
/// With `relative` the values are added to what each clip has (so several clips keep their
/// arrangement); without it every clip gets the value itself.
pub(crate) fn transform_clips(s: &mut Session, ids: &[u64], part: &str, x: Option<f64>, y: Option<f64>, relative: bool) -> Result<(), MobileError> {
    if [x, y].iter().flatten().any(|v| !v.is_finite()) {
        return Err(MobileError::Command("The values must be numbers.".into()));
    }
    if !matches!(part, "position" | "zoom" | "rotate" | "reset_position" | "reset_zoom" | "reset_rotate") {
        return Err(MobileError::Command(format!("Unknown transform: {part}.")));
    }
    let (fw, fh, targets) = {
        let (_, seq) = model::sequence(s)?;
        let mut out: Vec<u64> = Vec::new();
        for &id in ids {
            let cid = model::shown_clip(seq, ClipId(id));
            if !out.contains(&cid.0) && model::find(seq, cid).is_some_and(|f| f.kind == TrackKind::Video) {
                out.push(cid.0);
            }
        }
        (f64::from(seq.settings.width.max(1)), f64::from(seq.settings.height.max(1)), out)
    };
    if targets.is_empty() {
        return Err(MobileError::Command("None of the chosen clips has a picture.".into()));
    }
    let to_engine = |e: MobileError| EngineError::Other(e.to_string());
    s.edit_group("Transform", |s| {
        for &id in &targets {
            let now = placement(s, id).map_err(to_engine)?;
            let (mut nx, mut ny, mut ns, mut nr) = (now.x, now.y, now.scale, now.rotation);
            match part {
                "position" => {
                    if let Some(v) = x {
                        let cur = (nx - fw / 2.0) / fw * 100.0;
                        nx = fw / 2.0 + (if relative { cur + v } else { v }).clamp(-MAX_OFFSET, MAX_OFFSET) / 100.0 * fw;
                    }
                    if let Some(v) = y {
                        let cur = (ny - fh / 2.0) / fh * 100.0;
                        ny = fh / 2.0 + (if relative { cur + v } else { v }).clamp(-MAX_OFFSET, MAX_OFFSET) / 100.0 * fh;
                    }
                }
                "zoom" => {
                    if let Some(v) = x {
                        // 100 % is "as placed"; the size limits are applied in `apply_placement`
                        ns = (if relative { ns * 100.0 + v } else { v }).max(0.0) / 100.0;
                    }
                }
                "rotate" => {
                    if let Some(v) = x {
                        nr = (if relative { nr + v } else { v }).clamp(-MAX_TURN, MAX_TURN);
                    }
                }
                "reset_position" => (nx, ny) = (fw / 2.0, fh / 2.0),
                "reset_zoom" => ns = 1.0,
                _ => nr = 0.0,
            }
            apply_placement(s, id, nx, ny, ns, nr, false).map_err(to_engine)?;
        }
        Ok(())
    })?;
    Ok(())
}
