//! The phone's hardware H.264 encoder (Android `MediaCodec`), implemented in Kotlin and used by the engine's exporter.
//!
//! `MediaCodec` is reached from Kotlin, not from Rust through the NDK, for three reasons: the NDK has no way to ask
//! what an encoder supports (sizes, frame rates, bitrates, profiles: `MediaCodecList` is Java only); this keeps the
//! app free of `unsafe` code and of a new native dependency; and it uses the bridge the app already has (UniFFI).
//! The engine side (what is asked for, how the output becomes MP4 samples, the software fallback) is in
//! `filmcraft_export::hw_h264` and does not know about Android.

use filmcraft_export::{H264Backend, H264Session, HwConfig, HwPacket};
use std::sync::Arc;

/// What the hardware encoder is asked to do (see `HwConfig` in the exporter).
#[derive(Debug, Clone, uniffi::Record)]
pub struct HwOpen {
    pub width: u32,
    pub height: u32,
    pub fps_num: u32,
    pub fps_den: u32,
    pub bitrate_kbps: u32,
    pub max_bitrate_kbps: u32,
    pub keyint: u32,
}

/// One buffer out of the encoder: an Annex B access unit, or the parameter sets (`config`).
#[derive(Debug, Clone, uniffi::Record)]
pub struct HwOutput {
    pub data: Vec<u8>,
    pub pts_us: i64,
    pub key: bool,
    pub config: bool,
}

#[derive(Debug, thiserror::Error, uniffi::Error)]
#[uniffi(flat_error)]
pub enum HwError {
    #[error("{0}")]
    Failed(String),
}

impl From<uniffi::UnexpectedUniFFICallbackError> for HwError {
    fn from(e: uniffi::UnexpectedUniFFICallbackError) -> Self {
        HwError::Failed(e.reason)
    }
}

/// Implemented by the app in Kotlin on top of `MediaCodec`. Several encodes never run at once; a session is a number.
#[uniffi::export(with_foreign)]
pub trait HardwareH264: Send + Sync {
    /// Whether a hardware encoder does exactly this: the size, the frame rate and at least this bitrate, High or Main profile.
    fn supports(&self, width: u32, height: u32, fps_num: u32, fps_den: u32, bitrate_kbps: u32) -> bool;
    fn open(&self, cfg: HwOpen) -> Result<u64, HwError>;
    /// One picture, planar 8-bit 4:2:0 (Y, then U, then V). The first call returns once the parameter sets are known.
    fn encode(&self, session: u64, yuv420: Vec<u8>, pts_us: i64) -> Result<Vec<HwOutput>, HwError>;
    /// End of stream: whatever is still inside the encoder.
    fn finish(&self, session: u64) -> Result<Vec<HwOutput>, HwError>;
    fn close(&self, session: u64);
}

fn packets(v: Vec<HwOutput>) -> Vec<HwPacket> {
    v.into_iter().map(|o| HwPacket { data: o.data, pts_us: o.pts_us, key: o.key, config: o.config }).collect()
}

struct Backend(Arc<dyn HardwareH264>);

impl H264Backend for Backend {
    fn supports(&self, c: &HwConfig) -> bool {
        // a panic or an error in the Kotlin side means "no": the software encoder takes over
        let ok = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| self.0.supports(c.width, c.height, c.fps_num, c.fps_den, c.bitrate_kbps))).unwrap_or(false);
        log::info!("hardware H.264 {}x{} {}/{} fps {} kbit/s: {}", c.width, c.height, c.fps_num, c.fps_den, c.bitrate_kbps, if ok { "supported" } else { "not supported, software encoder" });
        ok
    }

    fn open(&self, c: &HwConfig) -> Result<Box<dyn H264Session>, String> {
        let cfg = HwOpen {
            width: c.width,
            height: c.height,
            fps_num: c.fps_num,
            fps_den: c.fps_den,
            bitrate_kbps: c.bitrate_kbps,
            max_bitrate_kbps: c.max_bitrate_kbps,
            keyint: c.keyint,
        };
        let id = self.0.open(cfg).map_err(|e| {
            log::warn!("hardware H.264 could not be opened, software encoder: {e}");
            e.to_string()
        })?;
        log::info!("hardware H.264 export started (session {id})");
        Ok(Box::new(Session { backend: self.0.clone(), id, closed: false }))
    }
}

struct Session {
    backend: Arc<dyn HardwareH264>,
    id: u64,
    closed: bool,
}

impl H264Session for Session {
    fn encode(&mut self, yuv420: &[u8], pts_us: i64) -> Result<Vec<HwPacket>, String> {
        self.backend.encode(self.id, yuv420.to_vec(), pts_us).map(packets).map_err(|e| {
            log::warn!("hardware H.264 failed while encoding: {e}");
            e.to_string()
        })
    }

    fn finish(&mut self) -> Result<Vec<HwPacket>, String> {
        let r = self.backend.finish(self.id).map(packets).map_err(|e| {
            log::warn!("hardware H.264 failed at the end of the stream: {e}");
            e.to_string()
        });
        if r.is_ok() {
            log::info!("hardware H.264 export finished (session {})", self.id);
        }
        self.closed = true;
        self.backend.close(self.id);
        r
    }
}

impl Drop for Session {
    fn drop(&mut self) {
        // an export that failed or was cancelled never reaches `finish`: the codec is released here
        if !self.closed {
            self.backend.close(self.id);
        }
    }
}

/// Plug the phone's hardware H.264 encoder into the exporter (`None` takes it out). Called once, at startup. Exports
/// that the hardware cannot do, or that fail in it, are done by the software encoder.
#[uniffi::export]
pub fn set_hardware_h264(provider: Option<Arc<dyn HardwareH264>>) {
    filmcraft_export::set_h264_backend(provider.map(|p| Arc::new(Backend(p)) as Arc<dyn H264Backend>));
}

/// Why the last H.264 export used hardware or software ("hardware: 1080x1920 at 30.000 fps, 18662 kbit/s" /
/// "software: <reason>").
#[uniffi::export]
pub fn hardware_encoder_status() -> String {
    filmcraft_export::hardware_status()
}
