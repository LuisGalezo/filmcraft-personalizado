//! Keyframes (a clip's properties changing over time) and speed ramps, for the phone's editor.
//!
//! Both are the engine's own keyframed parameters, so undo, redo, copy, split and move treat them
//! like any other edit:
//! * a keyframe is a key on a clip's Motion (position, scale, rotation), Opacity or text-layer
//!   parameter, or on a sound's Volume level, at the playhead's media time;
//! * a speed ramp is a set of keys on the Time Remapping speed (see `filmcraft_project::speed_ramp`),
//!   on the picture and on its linked sound alike so the two stay in step.
use filmcraft_engine::{EngineError, Session};
use filmcraft_project::graphic;
use filmcraft_project::{ClipId, Interpolation, Keyframe, MAX_RAMP_PERCENT, MIN_RAMP_PERCENT, Param, ParamValue, TrackItem, TrackKind};
use filmcraft_time::{TICKS_PER_SECOND, Tick};

use crate::{MobileError, edits, model};

fn cmd(m: &str) -> MobileError {
    MobileError::Command(m.into())
}

fn other(m: &str) -> EngineError {
    EngineError::Other(m.into())
}

/// Keys closer than this (a 240th of a second) are the same key.
const TOL: i64 = TICKS_PER_SECOND / 240;

/// A property a keyframe can animate: the clip it is on, the effect on that clip, the parameter.
struct Prop {
    clip: ClipId,
    effect: usize,
    param: &'static str,
}

/// The animatable properties of one clip as (effect index, parameter id): a sound's volume, a
/// text's position, scale, rotation and opacity, a picture's motion and opacity.
fn own_props(c: &TrackItem, audio: bool) -> Vec<(usize, &'static str)> {
    let mut v = Vec::new();
    if audio {
        if let Some(i) = c.effects.iter().position(|e| e.effect == "volume") {
            v.push((i, "level"));
        }
        return v;
    }
    if let Some(i) = c.effects.iter().position(graphic::is_layer) {
        for id in ["position", "scale", "rotation", "opacity"] {
            v.push((i, id));
        }
        return v;
    }
    if let Some(i) = c.effects.iter().position(|e| e.effect == "motion") {
        for id in ["position", "scale", "rotation"] {
            v.push((i, id));
        }
    }
    if let Some(i) = c.effects.iter().position(|e| e.effect == "opacity") {
        v.push((i, "opacity"));
    }
    v
}

/// Which family of properties a keyframe operation works on. Each family keeps its keys on its own
/// parameters (Transform: Motion position/scale/rotation and Opacity, or a text layer's; Audio: the
/// sound's Volume level), so an operation on one family never reads, moves, removes or restyles a
/// key of the other, even though both are shown on the same layer.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) enum KeyGroup {
    Transform,
    Audio,
}

impl KeyGroup {
    /// `transform` or `audio` (what the app sends).
    pub(crate) fn parse(id: &str) -> Result<Self, MobileError> {
        match id {
            "transform" => Ok(Self::Transform),
            "audio" => Ok(Self::Audio),
            _ => Err(cmd("Unknown keyframe group.")),
        }
    }
}

/// What a keyframe of `group` on clip `id` animates: for Transform the picture's (or text's) own
/// properties, for Audio the volume of the clip's sound (the linked sound of a picture, or the
/// sound clip itself).
fn props(s: &Session, id: u64, group: KeyGroup) -> Result<Vec<Prop>, MobileError> {
    let (_, seq) = model::sequence(s)?;
    let cid = model::shown_clip(seq, ClipId(id));
    let f = model::find(seq, cid).ok_or_else(|| cmd("That clip is no longer on the timeline."))?;
    let audio = f.kind == TrackKind::Audio;
    let mut out: Vec<Prop> = Vec::new();
    match group {
        KeyGroup::Transform => {
            if !audio {
                out.extend(own_props(f.clip, false).into_iter().map(|(effect, param)| Prop { clip: f.clip.id, effect, param }));
            }
        }
        KeyGroup::Audio => {
            if audio {
                out.extend(own_props(f.clip, true).into_iter().map(|(effect, param)| Prop { clip: f.clip.id, effect, param }));
            } else if let Some(a) = model::sound_of(seq, &f) {
                out.extend(own_props(a.clip, true).into_iter().map(|(effect, param)| Prop { clip: a.clip.id, effect, param }));
            }
        }
    }
    Ok(out)
}

/// The time keys of clip `c` are read and written at when the playhead is at `ph`.
fn key_time(c: &TrackItem, ph: Tick) -> Tick {
    c.effect_time_at(ph.max(c.start).min(c.end() - Tick(1)))
}

/// Add a keyframe at the playhead to every property of `group` of clip `id`, or remove the ones
/// there when there are some. Only that group is touched: removing a Transform key leaves the
/// volume keys where they are and the other way round. Returns whether keys were added. Nothing
/// changes how the clip looks or sounds: a new key holds the value the property has right there.
pub(crate) fn toggle_keyframe(s: &mut Session, id: u64, group: KeyGroup) -> Result<bool, MobileError> {
    let list = props(s, id, group)?;
    if list.is_empty() {
        return Err(cmd(match group {
            KeyGroup::Transform => "Nothing on this clip can be animated here.",
            KeyGroup::Audio => "This clip has no sound to animate.",
        }));
    }
    let ph = s.playhead();
    let (fw, fh) = {
        let (_, seq) = model::sequence(s)?;
        (f64::from(seq.settings.width.max(1)), f64::from(seq.settings.height.max(1)))
    };
    let here = {
        let (_, seq) = model::sequence(s)?;
        list.iter().any(|p| {
            model::find(seq, p.clip).is_some_and(|f| {
                let t = key_time(f.clip, ph);
                f.clip.effects.get(p.effect).and_then(|e| e.param(p.param)).is_some_and(|param| param.keyframes.iter().any(|k| (k.time.0 - t.0).abs() <= TOL))
            })
        })
    };
    s.edit_sequence_as(match (group, here) { (KeyGroup::Transform, true) => "Remove Keyframe", (KeyGroup::Transform, false) => "Add Keyframe", (KeyGroup::Audio, true) => "Remove Audio Keyframe", (KeyGroup::Audio, false) => "Add Audio Keyframe" }, None, |q, _, _| {
        for p in &list {
            let c = q.find_item_mut(p.clip).map(|x| x.1).ok_or_else(|| other("clip gone"))?;
            let t = key_time(c, ph);
            let Some(param) = c.effects.get_mut(p.effect).and_then(|e| e.param_mut(p.param)) else { continue };
            let value = match param.value_at(t) {
                // a position that was never set is the frame's centre
                ParamValue::Vec2(v) => ParamValue::Vec2(filmcraft_geom::Vec2::new(if v.x.is_nan() { fw / 2.0 } else { v.x }, if v.y.is_nan() { fh / 2.0 } else { v.y })),
                v => v,
            };
            if here {
                param.keyframes.retain(|k| (k.time.0 - t.0).abs() > TOL);
                if param.keyframes.is_empty() {
                    // the last key goes: the property stays as it looked there
                    param.value = value;
                }
            } else if !param.keyframes.iter().any(|k| (k.time.0 - t.0).abs() <= TOL) {
                let i = param.keyframes.partition_point(|k| k.time < t);
                param.keyframes.insert(i, Keyframe::new(t, value));
            }
        }
        Ok(())
    })?;
    edits::settle(s);
    Ok(!here)
}

/// Where clip `c`'s own keys are on the timeline, in ticks (what the timeline draws as diamonds).
pub(crate) fn key_ticks(c: &TrackItem, audio: bool) -> Vec<i64> {
    let mut out: Vec<i64> = Vec::new();
    for (i, id) in own_props(c, audio) {
        let Some(param) = c.effects.get(i).and_then(|e| e.param(id)) else { continue };
        for k in &param.keyframes {
            let t = c.timeline_time_of(k.time);
            // a key on the clip's last frame can land a rounding step past its end: it is still its key
            if t.0 >= c.start.0 - TOL * 8 && t.0 <= c.end().0 + TOL * 8 {
                out.push(t.0.clamp(c.start.0, c.end().0));
            }
        }
    }
    out.sort_unstable();
    out.dedup_by(|a, b| (*a - *b).abs() <= TOL);
    out
}

// ---------- keyframe interpolation ("rampas" of a keyframe) ----------

/// The interpolation of the keyframe the user is on, and where the stretches around it run.
#[derive(Debug, Clone, uniffi::Record)]
pub struct KeyInterpInfo {
    /// Whether the clip has any keyframe.
    pub has_keys: bool,
    /// The keyframe the choice applies to, in timeline ticks: the one at the playhead or, between
    /// keys, the last one before it (the first one when the playhead is before them all).
    pub key: i64,
    /// The keyframe before it (timeline ticks), or -1 when it is the first.
    pub prev: i64,
    /// The keyframe after it, or the clip's end when it is the last (timeline ticks).
    pub next: i64,
    /// How that keyframe is interpolated: `linear`, `bezier`, `auto_bezier`, `continuous_bezier`,
    /// `hold`, `ease_in` or `ease_out` (empty when there is no keyframe).
    pub current: String,
    /// The curve of the stretch that leaves the key, as the control points of a cubic Bezier in
    /// (time, value) space, both 0..1 on the time axis (`y` may overshoot 0..1): what a handle editor draws.
    pub x1: f64,
    pub y1: f64,
    pub x2: f64,
    pub y2: f64,
    /// Whether the curve's handles were edited by hand (not one of the seven standard shapes).
    pub custom: bool,
    /// Whether a keyframe follows this one (a stretch to shape).
    pub has_next: bool,
    /// The points inside that curve, six numbers each in the stretch's normalized space: `x, y, in_x, in_y, out_x,
    /// out_y` (empty for the usual curve of two handles). See `filmcraft_project::keyframe::CurvePoint`.
    pub mid: Vec<f64>,
}

fn interp_id(i: Interpolation) -> &'static str {
    match i {
        Interpolation::Linear => "linear",
        Interpolation::Bezier => "bezier",
        Interpolation::AutoBezier => "auto_bezier",
        Interpolation::ContinuousBezier => "continuous_bezier",
        Interpolation::Hold => "hold",
        Interpolation::EaseIn => "ease_in",
        Interpolation::EaseOut => "ease_out",
    }
}

fn parse_interp(id: &str) -> Option<Interpolation> {
    Interpolation::ALL.into_iter().find(|i| interp_id(*i) == id)
}

/// Timeline ticks of every key of `group` of clip `id`, sorted and de-duplicated, with the clip's
/// start and end.
fn key_map(s: &Session, id: u64, group: KeyGroup) -> Result<(Vec<i64>, i64, i64), MobileError> {
    let list = props(s, id, group)?;
    let (_, seq) = model::sequence(s)?;
    let shown = model::find(seq, model::shown_clip(seq, ClipId(id))).ok_or_else(|| cmd("That clip is no longer on the timeline."))?;
    let (start, end) = (shown.clip.start.0, shown.clip.end().0);
    let mut ticks = Vec::new();
    for p in &list {
        let Some(f) = model::find(seq, p.clip) else { continue };
        let Some(param) = f.clip.effects.get(p.effect).and_then(|e| e.param(p.param)) else { continue };
        for k in &param.keyframes {
            let t = f.clip.timeline_time_of(k.time);
            if t >= f.clip.start && t <= f.clip.end() {
                ticks.push(t.0);
            }
        }
    }
    ticks.sort_unstable();
    ticks.dedup_by(|a, b| (*a - *b).abs() <= TOL);
    Ok((ticks, start, end))
}

/// How the first property of `group` with a key at timeline tick `key` interpolates there.
fn interp_at(s: &Session, id: u64, group: KeyGroup, key: i64) -> Option<Interpolation> {
    let list = props(s, id, group).ok()?;
    let (_, seq) = model::sequence(s).ok()?;
    for p in &list {
        let Some(f) = model::find(seq, p.clip) else { continue };
        let Some(param) = f.clip.effects.get(p.effect).and_then(|e| e.param(p.param)) else { continue };
        if let Some(k) = param.keyframes.iter().find(|k| (f.clip.timeline_time_of(k.time).0 - key).abs() <= TOL) {
            return Some(k.interp);
        }
    }
    None
}

/// The keyframe of `group` the playhead is on (or the last one before it) and the stretches around it.
pub(crate) fn key_interp_info(s: &Session, id: u64, group: KeyGroup) -> KeyInterpInfo {
    let none = KeyInterpInfo { has_keys: false, key: 0, prev: -1, next: 0, current: String::new(), x1: 1.0 / 3.0, y1: 1.0 / 3.0, x2: 2.0 / 3.0, y2: 2.0 / 3.0, custom: false, has_next: false, mid: Vec::new() };
    let Ok((ticks, _, end)) = key_map(s, id, group) else { return none };
    let Some(first) = ticks.first().copied() else { return none };
    let ph = s.playhead().0;
    let key = ticks.iter().rev().find(|t| **t <= ph + TOL).copied().unwrap_or(first);
    let prev = ticks.iter().rev().find(|t| **t < key - TOL).copied().unwrap_or(-1);
    let next = ticks.iter().find(|t| **t > key + TOL).copied().unwrap_or(end);
    let current = interp_at(s, id, group, key).map(|i| interp_id(i).to_string()).unwrap_or_default();
    let (x1, y1, x2, y2, custom, mid) = curve_at(s, id, group, key, next).unwrap_or((1.0 / 3.0, 1.0 / 3.0, 2.0 / 3.0, 2.0 / 3.0, false, Vec::new()));
    let has_next = ticks.iter().any(|t| *t > key + TOL);
    KeyInterpInfo { has_keys: true, key, prev, next, current, x1, y1, x2, y2, custom, has_next, mid }
}

/// Handle values of the outgoing stretch of the key at timeline tick `key` (to the key at `next`) on the
/// first property of `group` that has both keys, and whether they were edited by hand.
fn curve_at(s: &Session, id: u64, group: KeyGroup, key: i64, next: i64) -> Option<(f64, f64, f64, f64, bool, Vec<f64>)> {
    let list = props(s, id, group).ok()?;
    let (_, seq) = model::sequence(s).ok()?;
    for p in &list {
        let Some(f) = model::find(seq, p.clip) else { continue };
        let Some(param) = f.clip.effects.get(p.effect).and_then(|e| e.param(p.param)) else { continue };
        let Some(i) = param.keyframes.iter().position(|k| (f.clip.timeline_time_of(k.time).0 - key).abs() <= TOL) else { continue };
        let Some(b) = param.keyframes.get(i + 1) else { continue };
        if (f.clip.timeline_time_of(b.time).0 - next).abs() > TOL {
            continue;
        }
        let a = &param.keyframes[i];
        let (x1, y1, x2, y2) = filmcraft_project::keyframe::segment_curve(a, b);
        let third = 1.0 / 3.0;
        let custom = matches!(a.interp, Interpolation::Bezier)
            && (!a.mid.is_empty() || (a.out_influence - third).abs() > 1e-6 || a.out_y != 0.0 || (b.in_influence - third).abs() > 1e-6 || b.in_y != 1.0);
        return Some((x1, y1, x2, y2, custom, points_to_flat(&a.mid)));
    }
    None
}

/// Give the keyframe the playhead is on (see [`key_interp_info`]) the interpolation `interp`, on
/// every property of `group` that has a key there, as one undo step. The other group is untouched. Like Premiere's
/// per-keyframe types: `ease_out` slows the way out of the key, `ease_in` the way into it, the
/// Bezier kinds both, `hold` keeps the value until the next key, `linear` is a steady change.
pub(crate) fn set_key_interp(s: &mut Session, id: u64, group: KeyGroup, interp: &str) -> Result<KeyInterpInfo, MobileError> {
    let interp = parse_interp(interp).ok_or_else(|| cmd("Unknown keyframe interpolation."))?;
    let info = key_interp_info(s, id, group);
    if !info.has_keys {
        return Err(cmd("Add a keyframe first."));
    }
    let list = props(s, id, group)?;
    let key = info.key;
    s.edit_sequence_as("Keyframe Interpolation", None, |q, _, _| {
        for p in &list {
            let c = q.find_item_mut(p.clip).map(|x| x.1).ok_or_else(|| other("clip gone"))?;
            let hits: Vec<usize> = match c.effects.get(p.effect).and_then(|e| e.param(p.param)) {
                Some(par) => par.keyframes.iter().enumerate().filter(|(_, k)| (c.timeline_time_of(k.time).0 - key).abs() <= TOL).map(|(i, _)| i).collect(),
                None => continue,
            };
            if let Some(par) = c.effects.get_mut(p.effect).and_then(|e| e.param_mut(p.param)) {
                for i in hits {
                    par.keyframes[i].interp = interp;
                    // a standard shape has the standard handles: a curve edited by hand is replaced
                    par.keyframes[i].out_influence = 1.0 / 3.0;
                    par.keyframes[i].out_y = 0.0;
                    par.keyframes[i].mid.clear();
                    if let Some(b) = par.keyframes.get_mut(i + 1) {
                        b.in_influence = 1.0 / 3.0;
                        b.in_y = 1.0;
                    }
                }
            }
        }
        Ok(())
    })?;
    edits::settle(s);
    Ok(key_interp_info(s, id, group))
}

/// A curve to put on a stretch: its two end handles (time 0..1, value free) and the points inside it.
pub(crate) struct Shape {
    x1: f64,
    y1: f64,
    x2: f64,
    y2: f64,
    mid: Vec<filmcraft_project::keyframe::CurvePoint>,
}

/// Six numbers per point (`x, y, in_x, in_y, out_x, out_y`) as the points they stand for, sanitized.
fn flat_to_points(v: &[f64]) -> Result<Vec<filmcraft_project::keyframe::CurvePoint>, MobileError> {
    if v.len() % 6 != 0 || v.len() > 6 * filmcraft_project::keyframe::MAX_CURVE_POINTS * 2 {
        return Err(cmd("That curve is not valid."));
    }
    let raw: Vec<filmcraft_project::keyframe::CurvePoint> = v
        .chunks_exact(6)
        .map(|c| filmcraft_project::keyframe::CurvePoint { x: c[0], y: c[1], in_x: c[2], in_y: c[3], out_x: c[4], out_y: c[5] })
        .collect();
    Ok(filmcraft_project::keyframe::CurvePoint::sanitize(&raw))
}

fn points_to_flat(p: &[filmcraft_project::keyframe::CurvePoint]) -> Vec<f64> {
    p.iter().flat_map(|c| [c.x, c.y, c.in_x, c.in_y, c.out_x, c.out_y]).collect()
}

/// The curve the app asked for, checked and kept within the engine's limits.
pub(crate) fn shape_of(x1: f64, y1: f64, x2: f64, y2: f64, mid: &[f64]) -> Result<Shape, MobileError> {
    if ![x1, y1, x2, y2].iter().chain(mid.iter()).all(|v| v.is_finite()) {
        return Err(cmd("That curve is not valid."));
    }
    Ok(Shape { x1: x1.clamp(0.01, 1.0), y1: y1.clamp(-1.0, 2.0), x2: x2.clamp(0.0, 0.99), y2: y2.clamp(-1.0, 2.0), mid: flat_to_points(mid)? })
}

/// Put `shape` on the stretch of `p` that leaves the key at timeline tick `key` and ends at `next`, on clip `c`. The
/// key becomes a `bezier` key. False when `c` has no such stretch on that property.
fn put_shape(c: &mut TrackItem, p: &Prop, key: i64, next: i64, shape: &Shape) -> bool {
    let at = |c: &TrackItem, k: &Keyframe, t: i64| (c.timeline_time_of(k.time).0 - t).abs() <= TOL;
    let found = match c.effects.get(p.effect).and_then(|e| e.param(p.param)) {
        Some(par) => par.keyframes.iter().position(|k| at(c, k, key)).filter(|i| par.keyframes.get(i + 1).is_some_and(|b| at(c, b, next))),
        None => None,
    };
    let Some(i) = found else { return false };
    let Some(par) = c.effects.get_mut(p.effect).and_then(|e| e.param_mut(p.param)) else { return false };
    par.keyframes[i].interp = Interpolation::Bezier;
    par.keyframes[i].out_influence = shape.x1;
    par.keyframes[i].out_y = shape.y1;
    par.keyframes[i].mid = shape.mid.clone();
    par.keyframes[i + 1].in_influence = 1.0 - shape.x2;
    par.keyframes[i + 1].in_y = shape.y2;
    true
}

/// Shape the stretch that leaves the key the playhead is on (see [`key_interp_info`]) with a cubic
/// Bezier whose control points are `(x1, y1)` and `(x2, y2)` (time 0..1, value free so a curve may
/// overshoot), on every property of `group` that has that key and the next one, as one undo step.
/// The key becomes a `bezier` key. The other group is untouched.
pub(crate) fn set_key_curve(s: &mut Session, id: u64, group: KeyGroup, x1: f64, y1: f64, x2: f64, y2: f64) -> Result<KeyInterpInfo, MobileError> {
    set_key_curve_points(s, id, group, x1, y1, x2, y2, &[])
}

/// [`set_key_curve`] with points inside the curve: `mid` is six numbers per point (`x, y, in_x, in_y, out_x, out_y`,
/// see `filmcraft_project::keyframe::CurvePoint`), at most 16 points. The stretch becomes several cubic Bezier
/// pieces, one between each two neighbouring points. With no points it is the usual curve of two handles. One undo step.
#[allow(clippy::too_many_arguments)]
pub(crate) fn set_key_curve_points(s: &mut Session, id: u64, group: KeyGroup, x1: f64, y1: f64, x2: f64, y2: f64, mid: &[f64]) -> Result<KeyInterpInfo, MobileError> {
    let shape = shape_of(x1, y1, x2, y2, mid)?;
    let info = key_interp_info(s, id, group);
    if !info.has_keys {
        return Err(cmd("Add a keyframe first."));
    }
    let (ticks, _, _) = key_map(s, id, group)?;
    if !ticks.iter().any(|t| (*t - info.next).abs() <= TOL) {
        return Err(cmd("Add a keyframe after this one to shape the curve."));
    }
    let list = props(s, id, group)?;
    let (key, next) = (info.key, info.next);
    let mut done = 0usize;
    s.edit_sequence_as("Keyframe Curve", None, |q, _, _| {
        for p in &list {
            let c = q.find_item_mut(p.clip).map(|x| x.1).ok_or_else(|| other("clip gone"))?;
            if put_shape(c, p, key, next, &shape) {
                done += 1;
            }
        }
        Ok(())
    })?;
    if done == 0 {
        return Err(cmd("Add a keyframe after this one to shape the curve."));
    }
    edits::settle(s);
    Ok(key_interp_info(s, id, group))
}

/// A copy of the project in which the stretch that leaves the selected key has `shape`, for previewing a draft curve.
/// The session is not touched: no edit, no undo step. What is drawn and mixed from the copy is what APPLY would give.
pub(crate) fn draft_project(s: &Session, id: u64, group: KeyGroup, shape: &Shape) -> Result<filmcraft_project::Project, MobileError> {
    let info = key_interp_info(s, id, group);
    if !info.has_keys || !info.has_next {
        return Err(cmd("Add a keyframe after this one to shape the curve."));
    }
    let list = props(s, id, group)?;
    let seq = s.state.active_sequence.ok_or(MobileError::NoSequence)?;
    let mut project = (*s.project).clone();
    let q = project.sequence_mut(seq).ok_or(MobileError::NoSequence)?;
    let mut done = 0usize;
    for p in &list {
        if let Some((_, c)) = q.find_item_mut(p.clip) {
            if put_shape(c, p, info.key, info.next, shape) {
                done += 1;
            }
        }
    }
    if done == 0 {
        return Err(cmd("Add a keyframe after this one to shape the curve."));
    }
    Ok(project)
}

/// Move the keyframe of `group` at timeline tick `from` of clip `id` (on every property of that
/// group that has a key there) to tick `to`, as one undo step. The other group's keys stay. The new place must be inside the clip and not
/// on another keyframe. Returns where the key now is.
pub(crate) fn move_key(s: &mut Session, id: u64, group: KeyGroup, from: i64, to: i64) -> Result<i64, MobileError> {
    let (ticks, start, end) = key_map(s, id, group)?;
    if !ticks.iter().any(|t| (*t - from).abs() <= TOL) {
        return Err(cmd("That keyframe is no longer there."));
    }
    let to = to.clamp(start + 1, end - 1);
    if (to - from).abs() <= TOL {
        return Ok(from);
    }
    if ticks.iter().any(|t| (*t - from).abs() > TOL && (*t - to).abs() <= TOL ) {
        return Err(cmd("There is already a keyframe there."));
    }
    let list = props(s, id, group)?;
    s.edit_sequence_as("Move Keyframe", None, |q, _, _| {
        for p in &list {
            let c = q.find_item_mut(p.clip).map(|x| x.1).ok_or_else(|| other("clip gone"))?;
            let target = c.effect_time_at(Tick(to));
            let hits: Vec<usize> = match c.effects.get(p.effect).and_then(|e| e.param(p.param)) {
                Some(par) => par.keyframes.iter().enumerate().filter(|(_, k)| (c.timeline_time_of(k.time).0 - from).abs() <= TOL).map(|(i, _)| i).collect(),
                None => continue,
            };
            if let Some(par) = c.effects.get_mut(p.effect).and_then(|e| e.param_mut(p.param)) {
                for i in hits {
                    par.keyframes[i].time = target;
                }
                par.keyframes.sort_by_key(|k| k.time.0);
            }
        }
        Ok(())
    })?;
    edits::settle(s);
    Ok(to)
}

// ---------- speed ramp ----------

/// A point of a speed ramp.
#[derive(Debug, Clone, uniffi::Record)]
pub struct RampPoint {
    /// Its place among the keys (what `ramp_edit` takes as `index`).
    pub index: u32,
    /// Where it is on the clip, 0 (start) to 1 (end), in timeline time.
    pub at: f64,
    /// The speed from there on, in % of the clip's own speed.
    pub percent: f64,
}

/// A clip's speed ramp as the speed panel draws it.
#[derive(Debug, Clone, uniffi::Record)]
pub struct RampInfo {
    /// Whether the clip can have a ramp (a video longer than two frames).
    pub eligible: bool,
    pub points: Vec<RampPoint>,
    /// The speed (%) at 48 evenly spaced moments of the clip's timeline length.
    pub curve: Vec<f64>,
    /// Footage the clip plays, and footage it has from its in point to the end of the media (ticks).
    pub played: i64,
    pub available: i64,
    /// Index of the point at the playhead, or -1.
    pub point_at_playhead: i32,
    /// The speed (%) at the playhead.
    pub percent_at_playhead: f64,
}

struct RampTarget {
    clip: TrackItem,
    sound: Option<ClipId>,
    /// Footage from the clip's in point to the end of its media (ticks); 0 when unknown.
    available: i64,
}

/// The clip a ramp applies to: a movie's picture longer than two frames.
fn ramp_target(s: &Session, id: u64) -> Result<RampTarget, MobileError> {
    let (_, seq) = model::sequence(s)?;
    let cid = model::shown_clip(seq, ClipId(id));
    let f = model::find(seq, cid).filter(|f| f.kind == TrackKind::Video).ok_or_else(|| cmd("A speed ramp needs a video clip."))?;
    let c = f.clip;
    let frame = s.sequence_rate().frame_duration();
    if c.duration <= Tick(frame.0 * 2) {
        return Err(cmd("The clip is too short for a speed ramp."));
    }
    let available = match s.project.item(c.item).map(|p| &p.kind) {
        Some(filmcraft_project::ItemKind::Media(m)) if m.info.kind == filmcraft_media::MediaKind::Movie && m.info.video.is_some() => (m.info.duration.0 - c.source_in.0).max(0),
        _ => return Err(cmd("A speed ramp needs a video clip.")),
    };
    Ok(RampTarget { clip: c.clone(), sound: model::sound_of(seq, &f).filter(|a| a.kind == TrackKind::Audio).map(|a| a.clip.id), available })
}

/// The speed ramp of clip `id`; `eligible` says whether it can have one at all.
pub(crate) fn ramp_info(s: &Session, id: u64) -> RampInfo {
    let empty = RampInfo { eligible: false, points: Vec::new(), curve: Vec::new(), played: 0, available: 0, point_at_playhead: -1, percent_at_playhead: 100.0 };
    let Ok(t) = ramp_target(s, id) else { return empty };
    let c = &t.clip;
    let dur = c.duration.0.max(1) as f64;
    let ramp = c.speed_ramp();
    let percent_at = |m: f64| ramp.map_or(100.0, |p| p.f64_at(Tick(m.round() as i64)));
    let curve = (0..48)
        .map(|j| {
            let rel = dur * (f64::from(j) + 0.5) / 48.0;
            percent_at(c.source_in.0 as f64 + ramp.map_or(0.0, |p| c.ramp_media_after(p, rel)))
        })
        .collect();
    let mut points = Vec::new();
    if let Some(p) = ramp {
        for (i, k) in p.keyframes.iter().enumerate() {
            let at = (c.timeline_time_of(k.time) - c.start).0 as f64 / dur;
            if (-0.001..=1.001).contains(&at) {
                points.push(RampPoint { index: i as u32, at: at.clamp(0.0, 1.0), percent: k.value.as_f64().unwrap_or(100.0) });
            }
        }
    }
    let here = key_time(c, s.playhead());
    let point_at_playhead = ramp.and_then(|p| p.keyframes.iter().position(|k| (k.time.0 - here.0).abs() <= TOL)).map_or(-1, |i| i as i32);
    RampInfo { eligible: true, points, curve, played: c.media_played().0, available: t.available, point_at_playhead, percent_at_playhead: percent_at(here.0 as f64) }
}

/// The shapes of the named speed ramps: (position on the clip 0..1, relative speed). The speeds are
/// scaled so that the ramp plays exactly as much footage as the clip does at normal speed.
fn preset_shape(name: &str) -> Option<&'static [(f64, f64)]> {
    let shape: &'static [(f64, f64)] = match name {
        // slow, fast in the middle, slow again
        "mountain" => &[(0.0, 0.3), (0.5, 2.0), (1.0, 0.3)],
        // starts slow and picks up
        "ease_in" => &[(0.0, 0.25), (0.35, 1.0), (1.0, 1.0)],
        // normal, then slows down to the end
        "ease_out" => &[(0.0, 1.0), (0.65, 1.0), (1.0, 0.25)],
        // slow at both ends
        "ease_in_out" => &[(0.0, 0.25), (0.3, 1.0), (0.7, 1.0), (1.0, 0.25)],
        // calm, one quick flash, calm
        "flash" => &[(0.0, 0.5), (0.3, 0.5), (0.45, 3.0), (0.6, 0.5), (1.0, 0.5)],
        // slow, a sudden jump of speed, slow
        "jump" => &[(0.0, 0.6), (0.42, 0.6), (0.5, 3.2), (0.58, 0.6), (1.0, 0.6)],
        // fast, nearly frozen in the middle, fast again
        "bullet" => &[(0.0, 3.0), (0.28, 3.0), (0.45, 0.2), (0.55, 0.2), (0.72, 3.0), (1.0, 3.0)],
        _ => return None,
    };
    Some(shape)
}

/// The keys (media tick, %) that make a ramp of `shape` over a clip that plays `nominal` ticks of
/// footage from `src_in` at normal speed: each key sits where the footage has got to by then.
fn preset_keys(shape: &[(f64, f64)], src_in: i64, nominal: i64) -> Vec<(i64, f64)> {
    let area: f64 = shape.windows(2).map(|w| (w[1].0 - w[0].0) * (w[0].1 + w[1].1) / 2.0).sum();
    let k = if area > 0.0 { 1.0 / area } else { 1.0 };
    let mut media = 0.0;
    let mut out = Vec::with_capacity(shape.len());
    for (i, &(u, w)) in shape.iter().enumerate() {
        if i > 0 {
            let (pu, pw) = shape[i - 1];
            media += (u - pu) * (pw + w) / 2.0 * k;
        }
        out.push((src_in + (nominal as f64 * media).round() as i64, (w * k * 100.0).clamp(MIN_RAMP_PERCENT, MAX_RAMP_PERCENT)));
    }
    out
}

/// Put a key of `percent` % at media time `t` (the existing one there when there is one).
fn set_key(p: &mut Param, t: Tick, percent: f64) {
    let v = ParamValue::Float(percent.clamp(MIN_RAMP_PERCENT, MAX_RAMP_PERCENT));
    if let Some(k) = p.keyframes.iter_mut().find(|k| (k.time.0 - t.0).abs() <= TOL) {
        k.value = v;
        return;
    }
    let mut k = Keyframe::new(t, v);
    // smooth: the speed eases from one key to the next
    k.interp = Interpolation::AutoBezier;
    let i = p.keyframes.partition_point(|k| k.time < t);
    p.keyframes.insert(i, k);
}

fn with_speed(c: &mut TrackItem, idx: usize, f: impl FnOnce(&mut Param)) {
    if let Some(p) = c.effects.get_mut(idx).and_then(|e| e.param_mut("speed")) {
        f(p);
    }
}

/// The index of clip `c`'s Time Remapping effect, adding it when the clip (a sound) has none.
fn remap_index(c: &mut TrackItem) -> Result<usize, EngineError> {
    if let Some(i) = c.effects.iter().position(|e| e.effect == "time_remap") {
        return Ok(i);
    }
    let e = filmcraft_project::effect::find_effect("time_remap").map(|d| d.instance()).ok_or_else(|| other("no time remapping"))?;
    c.effects.push(e);
    Ok(c.effects.len() - 1)
}

/// Change clip `id`'s speed ramp, as one undo step on the picture and its sound together.
///
/// `op`: `add` (a point at the playhead of `percent` %, or of the speed there when `percent` is not
/// above 0), `speed` (point `index` gets `percent`), `remove` (point `index`; the last two go
/// together: no ramp), `ease_in` (the clip starts at `percent` % and eases up to normal speed),
/// `ease_out` (it eases down to `percent` % by its last frame), `clear` (no ramp).
///
/// The ramp may not make the clip play more footage than it has: that edit is refused.
pub(crate) fn ramp_edit(s: &mut Session, id: u64, op: &str, index: i32, percent: f64) -> Result<(), MobileError> {
    if !matches!(op, "add" | "speed" | "remove" | "ease_in" | "ease_out" | "clear") && !op.starts_with("preset:") {
        return Err(cmd("Unknown speed ramp edit."));
    }
    if !percent.is_finite() {
        return Err(cmd("The speed must be a number."));
    }
    let t = ramp_target(s, id)?;
    let (clip_id, sound, available) = (t.clip.id, t.sound, t.available);
    let ph = s.playhead();
    let op = op.to_string();
    s.edit_sequence_as("Speed Ramp", None, |q, _, _| {
        let c = q.find_item_mut(clip_id).map(|x| x.1).ok_or_else(|| other("clip gone"))?;
        let idx = remap_index(c)?;
        let (src_in, nominal) = (c.source_in, (c.duration.0 as f64 * c.speed.abs()).round() as i64);
        let here = key_time(c, ph);
        match op.as_str() {
            "add" => with_speed(c, idx, |p| {
                let current = if p.is_animated() { p.f64_at(here) } else { 100.0 };
                if !p.is_animated() {
                    // the first point: the clip has been at its own speed up to here
                    set_key(p, src_in, 100.0);
                }
                set_key(p, here, if percent > 0.0 { percent } else { current });
            }),
            "speed" => with_speed(c, idx, |p| {
                if let Some(k) = usize::try_from(index).ok().and_then(|i| p.keyframes.get_mut(i)) {
                    k.value = ParamValue::Float(percent.clamp(MIN_RAMP_PERCENT, MAX_RAMP_PERCENT));
                }
            }),
            "remove" => with_speed(c, idx, |p| {
                if let Ok(i) = usize::try_from(index) {
                    if i < p.keyframes.len() {
                        p.keyframes.remove(i);
                    }
                }
                if p.keyframes.len() <= 1 {
                    p.keyframes.clear();
                    p.value = ParamValue::Float(100.0);
                }
            }),
            "clear" => with_speed(c, idx, |p| {
                p.keyframes.clear();
                p.value = ParamValue::Float(100.0);
            }),
            "ease_in" => with_speed(c, idx, |p| {
                let t1 = Tick(src_in.0 + (nominal as f64 * 0.3).round() as i64);
                set_key(p, src_in, percent);
                if !p.keyframes.iter().any(|k| k.time.0 > src_in.0 + TOL && k.time.0 <= t1.0 + TOL) {
                    set_key(p, t1, 100.0);
                }
            }),
            p if p.starts_with("preset:") => {
                let shape = preset_shape(&p["preset:".len()..]).ok_or_else(|| other("Unknown speed ramp."))?;
                let keys = preset_keys(shape, src_in.0, nominal);
                with_speed(c, idx, |par| {
                    par.keyframes.clear();
                    par.value = ParamValue::Float(100.0);
                    for (t, pc) in &keys {
                        set_key(par, Tick(*t), *pc);
                    }
                });
                // the clip keeps its length, so the ramp may not play more footage than there is: slow it
                // down evenly until it fits
                for _ in 0..4 {
                    let played = c.media_played().0;
                    if available <= 0 || played <= available {
                        break;
                    }
                    let f = (available as f64 / played as f64) * 0.995;
                    with_speed(c, idx, |par| {
                        for k in &mut par.keyframes {
                            if let Some(v) = k.value.as_f64() {
                                k.value = ParamValue::Float((v * f).clamp(MIN_RAMP_PERCENT, MAX_RAMP_PERCENT));
                            }
                        }
                    });
                }
            }
            _ => {
                // ease_out: normal speed until 70 % of the footage, then down to `percent` % at the
                // clip's last frame. The last key sits where the clip really ends, which moves as the
                // speed falls, so it is placed again a few times.
                let t_mid = Tick(src_in.0 + (c.media_played().0 as f64 * 0.7).round() as i64);
                with_speed(c, idx, |p| {
                    if !p.is_animated() {
                        set_key(p, t_mid, 100.0);
                    }
                });
                let mut end = Tick(src_in.0 + c.media_played().0 - 1);
                for _ in 0..5 {
                    with_speed(c, idx, |p| set_key(p, end, percent));
                    let next = Tick(src_in.0 + c.media_played().0 - 1);
                    if (next.0 - end.0).abs() <= TOL {
                        break;
                    }
                    with_speed(c, idx, |p| p.keyframes.retain(|k| k.time != end));
                    end = next;
                }
                with_speed(c, idx, |p| set_key(p, end, percent));
            }
        }
        // the footage the clip plays must exist
        if available > 0 && c.media_played().0 > available {
            return Err(other("That speed would play more footage than the clip has. Make the ramp slower or shorter."));
        }
        let ramp = c.effects.get(idx).and_then(|e| e.param("speed")).cloned();
        // the linked sound follows the same curve, so picture and sound stay in step
        if let (Some(sound), Some(ramp)) = (sound, ramp) {
            let a = q.find_item_mut(sound).map(|x| x.1).ok_or_else(|| other("sound gone"))?;
            let ai = remap_index(a)?;
            if let Some(p) = a.effects.get_mut(ai).and_then(|e| e.param_mut("speed")) {
                *p = ramp;
            }
        }
        Ok(())
    })?;
    edits::settle(s);
    Ok(())
}
