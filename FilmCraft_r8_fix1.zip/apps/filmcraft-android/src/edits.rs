//! The phone editor's edits, each one undo step, built from the engine's commands.
//!
//! Main-track edits keep V1 free of gaps (inserts push later clips, deletes and trims pull them
//! back); overlays and audio lanes move freely, and items on them after a main-track insert move
//! along with it, whole.

use filmcraft_engine::{EngineError, Session};
use filmcraft_project::{ClipId, EffectInstance, ItemId, ParamValue, TrackItem, TrackKind, Transition, TransitionId};
use filmcraft_time::{FrameRate, Tick};
use serde_json::{Value, json};

use crate::model;
use crate::{MobileError, presets};

/// The Volume level that means silence (the engine's floor).
pub(crate) const SILENT_DB: f64 = -287.5;
/// Voice-over recordings are named "Voiceover 1", "Voiceover 2"…
pub(crate) const VOICEOVER_PREFIX: &str = "Voiceover";
/// Pictures, text and blanks last this long when added (seconds).
pub(crate) const STILL_SECONDS: f64 = 4.0;
/// Speed range (1.0 = normal).
pub(crate) const MIN_SPEED: f64 = 0.1;
pub(crate) const MAX_SPEED: f64 = 10.0;
/// Transition length range (seconds) and the length a new one starts at.
pub(crate) const MIN_TRANSITION: f64 = 0.1;
pub(crate) const MAX_TRANSITION: f64 = 5.0;
pub(crate) const DEFAULT_TRANSITION: f64 = 0.4;
/// A clip can't be split closer to either end than this many frames.
const SPLIT_MARGIN_FRAMES: i64 = 2;
/// Motion Scale's upper bound (the parameter's range, in %).
const MAX_SCALE: f64 = 10_000.0;

/// Run engine command `id` with `params`.
pub(crate) fn ex(s: &mut Session, id: &str, params: Value) -> Result<Value, MobileError> {
    Ok(s.execute(id, params)?)
}

fn other(msg: impl Into<String>) -> EngineError {
    EngineError::Other(msg.into())
}

/// After an edit made without `execute`: what `execute` does after every command, so playback and
/// auto-save see it.
pub(crate) fn settle(s: &mut Session) {
    s.sync_persistence();
    s.previews.live.publish_project(s.project.clone());
}

fn ticks(t: i64) -> Tick {
    Tick(t.max(0))
}

/// The clip `id` (a hidden audio partner counts as its video clip): its track kind and index.
fn locate(s: &Session, id: u64) -> Result<(TrackKind, usize, TrackItem), MobileError> {
    let (_, seq) = model::sequence(s)?;
    let cid = model::shown_clip(seq, ClipId(id));
    let f = model::find(seq, cid).ok_or_else(|| MobileError::Command("That clip is no longer on the timeline.".into()))?;
    Ok((f.kind, f.track, f.clip.clone()))
}

fn is_main(kind: TrackKind, track: usize) -> bool {
    kind == TrackKind::Video && track == 0
}

/// The clip that carries a clip's sound (a video clip's linked audio, or the audio clip).
fn sound_clip(s: &Session, id: u64) -> Result<TrackItem, MobileError> {
    let (_, seq) = model::sequence(s)?;
    let cid = model::shown_clip(seq, ClipId(id));
    let f = model::find(seq, cid).ok_or_else(|| MobileError::Command("That clip is no longer on the timeline.".into()))?;
    model::sound_of(seq, &f).map(|a| a.clip.clone()).ok_or_else(|| MobileError::Command("This clip has no sound.".into()))
}

/// Where new media goes on the main track: after the clip under the playhead, before a clip
/// starting exactly at it, else after the last clip.
pub(crate) fn insert_point(s: &Session) -> Result<Tick, MobileError> {
    let (_, seq) = model::sequence(s)?;
    let ph = s.playhead();
    let clips = model::main_clips(seq);
    for &(start, end, _) in &clips {
        if ph == start {
            return Ok(start);
        }
        if ph > start && ph < end {
            return Ok(end);
        }
    }
    Ok(clips.last().map(|c| c.1).unwrap_or(Tick::ZERO))
}

/// Whether `[start, end)` is free on a track (ignoring `except`).
fn free(items: &[TrackItem], start: Tick, end: Tick, except: Option<ClipId>) -> bool {
    items.iter().all(|c| Some(c.id) == except || c.end() <= start || c.start >= end)
}

/// A lane of `kind` (index ≥ `first`, 0-based) free over `[start, end)`, preferring `want`;
/// adds a track when none is. Returns the engine's 1-based track name ("V2", "A3").
fn free_lane(
    s: &mut Session,
    kind: TrackKind,
    first: usize,
    want: Option<usize>,
    start: Tick,
    end: Tick,
    except: Option<ClipId>,
) -> Result<String, MobileError> {
    let letter = if kind == TrackKind::Video { "V" } else { "A" };
    Ok(format!("{letter}{}", free_lane_index(s, kind, first, want, start, end, except)? + 1))
}

/// [`free_lane`] as a 0-based track index.
pub(crate) fn free_lane_index(
    s: &mut Session,
    kind: TrackKind,
    first: usize,
    want: Option<usize>,
    start: Tick,
    end: Tick,
    except: Option<ClipId>,
) -> Result<usize, MobileError> {
    let track_count = {
        let (_, seq) = model::sequence(s)?;
        if kind == TrackKind::Video { seq.video_tracks.len() } else { seq.audio_tracks.len() }
    };

    // A deliberate drop on V4/V5 must not silently land on an empty V2/V3.
    // Materialize every missing lane up to the requested index first.
    if let Some(w) = want.filter(|&w| w >= first) {
        if w >= track_count {
            let missing = w + 1 - track_count;
            let p = if kind == TrackKind::Video {
                json!({"video": missing, "audio": 0})
            } else {
                json!({"video": 0, "audio": missing})
            };
            ex(s, "sequence.addTracks", p)?;
            return Ok(w);
        }
        let (_, seq) = model::sequence(s)?;
        let tracks = if kind == TrackKind::Video { &seq.video_tracks } else { &seq.audio_tracks };
        if tracks.get(w).is_some_and(|t| free(&t.items, start, end, except)) {
            return Ok(w);
        }
    }

    let (_, seq) = model::sequence(s)?;
    let tracks = if kind == TrackKind::Video { &seq.video_tracks } else { &seq.audio_tracks };
    if let Some(i) = tracks.iter().enumerate().skip(first)
        .find(|(_, t)| free(&t.items, start, end, except)).map(|(i, _)| i)
    {
        return Ok(i);
    }

    let missing = first.saturating_sub(tracks.len()) + 1;
    let n = tracks.len();
    let p = if kind == TrackKind::Video { json!({"video": missing, "audio": 0}) } else { json!({"video": 0, "audio": missing}) };
    ex(s, "sequence.addTracks", p)?;
    Ok(n.max(first))
}

/// Resolve a user-selected lane without silently falling back to another lane.
/// Missing requested lanes are created; occupied requested lanes return a clear error.
fn free_lane_exact(
    s: &mut Session,
    kind: TrackKind,
    first: usize,
    want: usize,
    start: Tick,
    end: Tick,
    except: Option<ClipId>,
) -> Result<String, MobileError> {
    let (_, seq) = model::sequence(s)?;
    let tracks = if kind == TrackKind::Video { &seq.video_tracks } else { &seq.audio_tracks };
    if let Some(track) = tracks.get(want) {
        if !free(&track.items, start, end, except) {
            let label = if kind == TrackKind::Video { "V" } else { "A" };
            return Err(MobileError::Command(format!(
                "Track {label}{} is occupied at that time. Move the other clip or choose another track.",
                want + 1
            )));
        }
    }
    free_lane(s, kind, first, Some(want), start, end, except)
}

fn clips_of(v: &Value, key: &str) -> Vec<u64> {
    v[key].as_array().map(|a| a.iter().filter_map(Value::as_u64).collect()).unwrap_or_default()
}

fn select_one(s: &mut Session, id: Option<u64>) -> Result<(), MobileError> {
    match id {
        Some(c) => ex(s, "timeline.select", json!({"clips": [c]}))?,
        // an empty clip selection also clears a transition's
        None => ex(s, "timeline.select", json!({"clips": []}))?,
    };
    Ok(())
}

/// Import files into the project; their item ids, or the first error.
pub(crate) fn import(s: &mut Session, paths: &[String]) -> Result<Vec<u64>, MobileError> {
    let r = s.execute("file.import", json!({ "paths": paths })).map_err(|e| MobileError::Import(e.to_string()))?;
    let items: Vec<u64> = r["items"].as_array().map(|a| a.iter().filter_map(Value::as_u64).collect()).unwrap_or_default();
    if items.is_empty() {
        let msg = r["errors"].as_array().and_then(|e| e.first()).and_then(Value::as_str).unwrap_or("The file holds no media.").to_string();
        return Err(MobileError::Import(msg));
    }
    Ok(items)
}

fn item_kind(s: &Session, item: u64) -> Option<filmcraft_media::MediaKind> {
    match &s.project.item(ItemId(item))?.kind {
        filmcraft_project::ItemKind::Media(m) => Some(m.info.kind),
        _ => None,
    }
}

/// Add pictures, videos and sounds: pictures and videos onto the main track at the insert point,
/// back to back; sounds onto audio lanes at the playhead. Returns the new clips (the first is
/// selected).
pub(crate) fn add_media(s: &mut Session, paths: &[String]) -> Result<Vec<u64>, MobileError> {
    let items = import(s, paths)?;
    let r = s.edit_group("Add Media", |s| {
        let mut out = Vec::new();
        let mut at = insert_point(s).map_err(|e| other(e.to_string()))?;
        for &item in &items {
            if item_kind(s, item) == Some(filmcraft_media::MediaKind::AudioOnly) {
                let ph = s.playhead();
                let len = item_duration(s, item);
                let lane = free_lane(s, TrackKind::Audio, 1, None, ph, ph + len, None).map_err(|e| other(e.to_string()))?;
                let r = s.execute("timeline.place", json!({"item": item, "time": ph.0, "track": lane}))?;
                out.extend(clips_of(&r, "clips"));
                continue;
            }
            let r =
                ripple_main(s, at, |s| s.execute("timeline.place", json!({"item": item, "time": at.0, "track": "V1", "audioTrack": "A1", "insert": true})))?;
            let placed = clips_of(&r, "clips");
            // the video clip (not its audio) is the one the phone shows
            let (_, seq) = model::sequence(s).map_err(|e| other(e.to_string()))?;
            if let Some(v) = placed.iter().filter_map(|&c| model::find(seq, ClipId(c))).find(|f| f.kind == TrackKind::Video) {
                at = v.clip.end();
                out.push(v.clip.id.0);
            }
        }
        Ok(out)
    })?;
    select_one(s, r.first().copied())?;
    Ok(r)
}

/// Add visual media directly to a requested overlay lane at the playhead. Video audio remains
/// linked on a separate available audio lane, rather than colliding with V1 audio; audio-only files still go to audio lanes.
pub(crate) fn add_media_to_overlay(
    s: &mut Session,
    paths: &[String],
    index: usize,
) -> Result<Vec<u64>, MobileError> {
    if index == 0 {
        return Err(MobileError::Command("Choose an overlay lane (V2 or higher).".into()));
    }
    // Import and placement must be one undoable transaction. If the requested
    // lane is occupied (or placement otherwise fails), edit_group restores the
    // project snapshot so imported media cannot be left orphaned in the bin.
    let r = s.edit_group("Add Media to Overlay", |s| {
        let items = import(s, paths).map_err(|e| other(e.to_string()))?;
        let mut out = Vec::new();
        let mut at = s.playhead();
        for &item in &items {
            let len = item_duration(s, item);
            if item_kind(s, item) == Some(filmcraft_media::MediaKind::AudioOnly) {
                let lane = free_lane(s, TrackKind::Audio, 1, None, at, at + len, None)
                    .map_err(|e| other(e.to_string()))?;
                let placed = s.execute("timeline.place", json!({"item": item, "time": at.0, "track": lane, "video": false}))?;
                out.extend(clips_of(&placed, "clips"));
                continue;
            }
            let lane = free_lane_exact(s, TrackKind::Video, 1, index, at, at + len, None)
                .map_err(|e| other(e.to_string()))?;
            // Keep the video's sound attached, but place it on an independent audio lane
            // instead of colliding with the main V1/A1 sound.
            let audio_lane = free_lane(s, TrackKind::Audio, 1, None, at, at + len, None)
                .map_err(|e| other(e.to_string()))?;
            let placed = s.execute("timeline.place", json!({
                "item": item,
                "time": at.0,
                "track": lane,
                "audioTrack": audio_lane,
                "insert": false
            }))?;
            let ids = clips_of(&placed, "clips");
            let (_, seq) = model::sequence(s).map_err(|e| other(e.to_string()))?;
            if let Some(video) = ids.iter().filter_map(|&id| model::find(seq, ClipId(id)))
                .find(|found| found.kind == TrackKind::Video)
            {
                at = video.clip.end();
                out.push(video.clip.id.0);
            }
        }
        Ok(out)
    })?;
    select_one(s, r.first().copied())?;
    Ok(r)
}

fn item_duration(s: &Session, item: u64) -> Tick {
    match s.project.item(ItemId(item)).map(|p| &p.kind) {
        Some(filmcraft_project::ItemKind::Media(m)) if m.info.duration > Tick::ZERO => m.info.duration,
        _ => Tick::from_seconds_f64(STILL_SECONDS),
    }
}

/// Add sound files (Files ▸ Audio): on a free audio lane at the playhead.
pub(crate) fn add_audio(s: &mut Session, paths: &[String]) -> Result<Vec<u64>, MobileError> {
    let items = import(s, paths)?;
    let r = s.edit_group("Add Audio", |s| {
        let mut out = Vec::new();
        let mut at = s.playhead();
        for &item in &items {
            let len = item_duration(s, item);
            let lane = free_lane(s, TrackKind::Audio, 1, None, at, at + len, None).map_err(|e| other(e.to_string()))?;
            let r = s.execute("timeline.place", json!({"item": item, "time": at.0, "track": lane, "video": false}))?;
            let placed = clips_of(&r, "clips");
            let (_, seq) = model::sequence(s).map_err(|e| other(e.to_string()))?;
            if let Some(f) = placed.iter().filter_map(|&c| model::find(seq, ClipId(c))).find(|f| f.kind == TrackKind::Audio) {
                at = f.clip.end();
                out.push(f.clip.id.0);
            }
        }
        Ok(out)
    })?;
    select_one(s, r.first().copied())?;
    Ok(r)
}

/// Add a blank (black) clip to the main track at the insert point.
pub(crate) fn add_blank(s: &mut Session) -> Result<u64, MobileError> {
    let r = s.edit_group("Add Blank", |s| {
        let item = s.execute("file.newBlackVideo", json!({"seconds": STILL_SECONDS}))?["item"].as_u64().ok_or_else(|| other("no blank was made"))?;
        let at = insert_point(s).map_err(|e| other(e.to_string()))?;
        let r = ripple_main(s, at, |s| s.execute("timeline.place", json!({"item": item, "time": at.0, "track": "V1", "insert": true, "audio": false})))?;
        clips_of(&r, "clips").first().copied().ok_or_else(|| other("the blank could not be placed"))
    })?;
    select_one(s, Some(r))?;
    s.set_playhead(locate(s, r)?.2.start);
    Ok(r)
}

/// Split the clip at the playhead; the part after the cut is selected.
pub(crate) fn split(s: &mut Session, id: u64) -> Result<u64, MobileError> {
    let (kind, track, c) = locate(s, id)?;
    let rate = s.sequence_rate();
    let ph = rate.snap(s.playhead());
    let margin = Tick(rate.frame_duration().0.saturating_mul(SPLIT_MARGIN_FRAMES));
    if ph < c.start + margin || ph > c.end() - margin {
        return Err(MobileError::Command("Move the playhead into the clip to split it.".into()));
    }
    ex(s, "timeline.razor", json!({"time": ph.0, "clip": c.id.0}))?;
    let (_, seq) = model::sequence(s)?;
    let tracks = if kind == TrackKind::Video { &seq.video_tracks } else { &seq.audio_tracks };
    let right = tracks.get(track).and_then(|t| t.items.iter().find(|i| i.start == ph)).map(|i| i.id.0).unwrap_or(id);
    select_one(s, Some(right))?;
    Ok(right)
}

/// Delete a clip: the main track closes the gap (and later items on other lanes move up with it);
/// on another lane the gap stays.
pub(crate) fn delete(s: &mut Session, id: u64) -> Result<(), MobileError> {
    let (kind, track, c) = locate(s, id)?;
    if !is_main(kind, track) {
        ex(s, "edit.clear", json!({"clips": [c.id.0]}))?;
        return Ok(());
    }
    s.edit_group("Delete", |s| ripple_main(s, c.end(), |s| s.execute("edit.rippleDelete", json!({"clips": [c.id.0]}))))?;
    Ok(())
}

/// Switch sync lock off on every track but V1 and A1; returns the tracks it changed.
fn unlock_others(s: &mut Session) -> filmcraft_engine::Result<Vec<String>> {
    let Some(seq) = s.active_sequence() else { return Err(EngineError::NoSequence) };
    let mut names = Vec::new();
    for (i, t) in seq.video_tracks.iter().enumerate().skip(1) {
        if t.sync_lock {
            names.push(format!("V{}", i + 1));
        }
    }
    for (i, t) in seq.audio_tracks.iter().enumerate().skip(1) {
        if t.sync_lock {
            names.push(format!("A{}", i + 1));
        }
    }
    for n in &names {
        s.execute("timeline.setTrack", json!({"track": n, "syncLock": false}))?;
    }
    Ok(names)
}

fn relock(s: &mut Session, names: &[String]) -> filmcraft_engine::Result<()> {
    for n in names {
        s.execute("timeline.setTrack", json!({"track": n, "syncLock": true}))?;
    }
    Ok(())
}

fn main_end(s: &Session) -> filmcraft_engine::Result<Tick> {
    let seq = s.active_sequence().ok_or(EngineError::NoSequence)?;
    Ok(seq.video_tracks.first().map(|t| t.end()).unwrap_or(Tick::ZERO))
}

/// A main-track edit (`f`) that moves what comes after `at` (an insert, delete, trim or speed
/// change), made the phone's way. The engine ripples every sync-locked lane, cutting whatever lies
/// across the edit point or refusing the edit; on the phone, items on the other lanes move whole.
/// So the other lanes and the captions sit the edit out; then whatever on the lanes starts at or
/// after `at` moves by as much as the main track grew or shrank, never back over the item before it
/// on its lane. The captions follow their footage afterwards (`speech::follow_main`). Several undo
/// steps: call it in an edit group.
fn ripple_main<R>(s: &mut Session, at: Tick, f: impl FnOnce(&mut Session) -> filmcraft_engine::Result<R>) -> filmcraft_engine::Result<R> {
    let before = main_end(s)?;
    let (lanes, captions) = s.edit_sequence("Ripple", |q, _, _| {
        let mut lanes = Vec::new();
        for t in q.video_tracks.iter_mut().skip(1).chain(q.audio_tracks.iter_mut().skip(1)).filter(|t| t.sync_lock) {
            t.sync_lock = false;
            lanes.push(t.id);
        }
        let mut captions = Vec::new();
        for t in q.caption_tracks.iter_mut().filter(|t| t.sync_lock) {
            t.sync_lock = false;
            captions.push(t.id);
        }
        Ok((lanes, captions))
    })?;
    let r = f(s)?;
    let delta = main_end(s)? - before;
    s.edit_sequence("Ripple", |q, _, _| {
        for t in q.video_tracks.iter_mut().chain(q.audio_tracks.iter_mut()).filter(|t| lanes.contains(&t.id)) {
            t.sync_lock = true;
            if delta != Tick::ZERO {
                shift_lane(t, at, delta);
            }
        }
        for t in q.caption_tracks.iter_mut().filter(|t| captions.contains(&t.id)) {
            t.sync_lock = true;
        }
        Ok(())
    })?;
    Ok(r)
}

/// Move every item on a lane that starts at or after `at` by `delta`, keeping each one after the
/// end of the item before it (and the start of the timeline).
fn shift_lane(t: &mut filmcraft_project::Track, at: Tick, delta: Tick) {
    t.sort();
    let mut prev_end = Tick::ZERO;
    let mut moved = Vec::new();
    for it in &mut t.items {
        if it.start >= at {
            let to = (it.start + delta).max(prev_end);
            moved.push((it.id, to - it.start));
            it.start = to;
        }
        prev_end = prev_end.max(it.end());
    }
    // a transition moves with the item it belongs to
    for tr in &mut t.transitions {
        let by = moved.iter().find(|(id, _)| tr.from == Some(*id) || tr.to == Some(*id)).map(|m| m.1);
        if let Some(by) = by {
            tr.start += by;
        }
    }
    t.sort();
}

/// Duplicate a clip right after itself (the main track makes room; other lanes find a free lane).
pub(crate) fn duplicate(s: &mut Session, id: u64) -> Result<u64, MobileError> {
    let (kind, track, c) = locate(s, id)?;
    let copy = s.edit_group("Duplicate", |s| {
        let (lane, insert) = if is_main(kind, track) {
            ("V1".to_string(), true)
        } else {
            (free_lane(s, kind, 1, Some(track), c.end(), c.end() + c.duration, None).map_err(|e| other(e.to_string()))?, false)
        };
        let moves = json!({"moves": [{"clip": c.id.0, "track": lane, "time": c.end().0}], "copy": true, "insert": insert});
        let r = if insert { ripple_main(s, c.end(), |s| s.execute("timeline.move", moves))? } else { s.execute("timeline.move", moves)? };
        let (_, seq) = s.active_sequence().map(|q| ((), q)).ok_or(EngineError::NoSequence)?;
        let copies = clips_of(&r, "copied");
        copies.iter().copied().find(|&x| model::find(seq, ClipId(x)).is_some_and(|f| f.kind == kind)).ok_or_else(|| other("the copy could not be placed"))
    })?;
    select_one(s, Some(copy))?;
    Ok(copy)
}

/// Replace a clip's media, keeping its place, length and settings. A video shorter than the clip
/// is refused.
pub(crate) fn replace(s: &mut Session, id: u64, path: &str) -> Result<(), MobileError> {
    let (_, _, c) = locate(s, id)?;
    let old = shown_size(s, c.item);
    let short = std::cell::Cell::new(false);
    // one undo step; a refused replace leaves nothing behind
    let r = s.edit_group("Replace", |s| {
        let items = import(s, &[path.to_string()]).map_err(|e| other(e.to_string()))?;
        let item = items.first().copied().ok_or_else(|| other("The file holds no media."))?;
        let r = s.execute("clip.replaceFromBin", json!({"clips": [c.id.0], "item": item}))?;
        if r["short"].as_array().is_some_and(|a| !a.is_empty()) {
            short.set(true);
            return Err(other("short"));
        }
        refit(s, c.id, old)?;
        add_missing_sound(s, c.id, ItemId(item))
    });
    match r {
        Err(_) if short.get() => Err(MobileError::Command("The new video is shorter than the clip. Choose a longer video or trim the clip first.".into())),
        r => Ok(r?),
    }
}

/// A picture that became a video has no sound of its own yet: give it the sound of its new media,
/// linked to the picture (so it shows inside the clip, never as a lane of its own), under it and
/// as long as it, on a free audio lane. A clip that already has its sound is left alone.
fn add_missing_sound(s: &mut Session, clip: ClipId, item: ItemId) -> filmcraft_engine::Result<()> {
    if !s.project.source_streams(item).1 {
        return Ok(());
    }
    let (start, dur, source_in, speed, main) = {
        let (_, seq) = model::sequence(s).map_err(|e| other(e.to_string()))?;
        let Some(f) = model::find(seq, clip) else { return Ok(()) };
        if f.kind != TrackKind::Video || f.clip.item != item || model::partner(seq, f.clip, TrackKind::Audio).is_some() {
            return Ok(());
        }
        (f.clip.start, f.clip.duration, f.clip.source_in, f.clip.speed, is_main(f.kind, f.track))
    };
    let lane = free_lane(s, TrackKind::Audio, if main { 0 } else { 1 }, None, start, start + dur, None).map_err(|e| other(e.to_string()))?;
    let placed = s.execute(
        "timeline.place",
        json!({"item": item.0, "track": lane, "video": false, "time": start.0, "sourceIn": source_in.0, "duration": dur.0}),
    )?;
    let sound = clips_of(&placed, "clips").first().copied().ok_or_else(|| other("the sound could not be added"))?;
    s.edit_sequence("Replace", |q, ctx, _| {
        let link = match q.find_item(clip).and_then(|(_, c)| c.link) {
            Some(l) => l,
            None => alloc(ctx),
        };
        if let Some((_, v)) = q.find_item_mut(clip) {
            v.link = Some(link);
        }
        let a = q.find_item_mut(ClipId(sound)).map(|x| x.1).ok_or_else(|| other("sound gone"))?;
        a.link = Some(link);
        a.speed = speed;
        a.duration = dur;
        Ok(())
    })
}

/// The size a picture shows at, in the sequence's pixels (its display aspect), if it has one.
fn shown_size(s: &Session, item: ItemId) -> Option<(f64, f64)> {
    let seq = s.active_sequence()?;
    let size = s.project.source_size(item).filter(|&(w, h)| w > 0 && h > 0)?;
    let par = s.project.source_par(item).unwrap_or(seq.settings.par);
    Some(filmcraft_project::conformed_size(size, par, seq.settings.par))
}

/// After a replace, the new picture fits the frame the way the old one did (the clip's scale
/// mode): its anchor moves to the same point of the new picture, and its scale changes by as
/// much as the fit does. Without both sizes the clip stays as it is.
fn refit(s: &mut Session, clip: ClipId, old: Option<(f64, f64)>) -> filmcraft_engine::Result<()> {
    let Some((w0, h0)) = old else { return Ok(()) };
    let seq = s.active_sequence().ok_or(EngineError::NoSequence)?;
    let (fw, fh) = (f64::from(seq.settings.width.max(1)), f64::from(seq.settings.height.max(1)));
    let Some(item) = seq.find_item(clip).map(|(_, c)| c.item) else { return Ok(()) };
    let Some((w1, h1)) = shown_size(s, item) else { return Ok(()) };
    let fit = |w: f64, h: f64| (fw / w).min(fh / h);
    let k = fit(w1, h1) / fit(w0, h0);
    if !k.is_finite() || k <= 0.0 {
        return Ok(());
    }
    s.edit_sequence("Replace", |q, _, _| {
        let Some((_, it)) = q.find_item_mut(clip) else { return Ok(()) };
        // Scale to Frame Size refits on its own
        let refits = it.scale_to_frame;
        let Some(m) = it.effect_mut("motion") else { return Ok(()) };
        if let Some(p) = m.param_mut("anchor") {
            p.map_values(|v| match v {
                // an automatic (NaN) anchor stays automatic
                ParamValue::Vec2(mut v) => {
                    v.x = v.x / w0 * w1;
                    v.y = v.y / h0 * h1;
                    ParamValue::Vec2(v)
                }
                other => other,
            });
        }
        if !refits {
            for id in ["scale", "scale_width"] {
                if let Some(p) = m.param_mut(id) {
                    p.map_values(|v| match v {
                        ParamValue::Float(x) => ParamValue::Float((x * k).clamp(0.0, MAX_SCALE)),
                        other => other,
                    });
                }
            }
        }
        Ok(())
    })
}

/// Change a clip's speed (0.1× to 10×), keeping the pitch of its sound. The main track makes room
/// or closes up.
pub(crate) fn set_speed(s: &mut Session, id: u64, speed: f64) -> Result<(), MobileError> {
    let (kind, track, c) = locate(s, id)?;
    if !speed.is_finite() {
        return Err(MobileError::Command("Speed must be a number.".into()));
    }
    let speed = speed.clamp(MIN_SPEED, MAX_SPEED);
    let params = json!({"clips": [c.id.0], "speed": speed * 100.0, "ripple": is_main(kind, track), "maintainPitch": true});
    if is_main(kind, track) {
        s.edit_group("Speed", |s| ripple_main(s, c.end(), |s| s.execute("clip.speedDuration", params)))?;
    } else {
        ex(s, "clip.speedDuration", params)?;
    }
    Ok(())
}

/// Insert a 4-second still of the frame at the playhead into the clip.
pub(crate) fn freeze(s: &mut Session, id: u64) -> Result<u64, MobileError> {
    let (kind, track, c) = locate(s, id)?;
    let rate = s.sequence_rate();
    let ph = rate.snap(s.playhead());
    if ph < c.start || ph >= c.end() - rate.frame_duration() {
        return Err(MobileError::Command("Move the playhead into the clip to freeze a frame.".into()));
    }
    let r = s.edit_group("Freeze Frame", |s| {
        ripple_main(s, ph, |s| s.execute("clip.insertFrameHoldSegment", json!({"clip": c.id.0, "time": ph.0, "seconds": STILL_SECONDS})))
    })?;
    let held = r["clip"].as_u64();
    let _ = (kind, track);
    if let Some(h) = held {
        select_one(s, Some(h))?;
    }
    Ok(held.unwrap_or(id))
}

fn db_of(volume: f64) -> f64 {
    if !volume.is_finite() || volume <= 0.001 { SILENT_DB } else { 20.0 * volume.min(2.0).log10() }
}

/// Set a clip's volume (0.0 to 2.0). `merge` folds a slider drag into one undo step.
pub(crate) fn set_volume(s: &mut Session, id: u64, volume: f64, merge: bool) -> Result<(), MobileError> {
    let a = sound_clip(s, id)?;
    let db = db_of(volume);
    let key = format!("volume:{}", a.id.0);
    s.edit_sequence_as("Volume", merge.then_some(key.as_str()), |q, _, _| {
        let c = q.find_item_mut(a.id).map(|x| x.1).ok_or_else(|| other("clip gone"))?;
        let e = c.effects.iter_mut().find(|e| e.effect == "volume").ok_or_else(|| other("no volume"))?;
        if let Some(p) = e.param_mut("level") {
            p.value = filmcraft_project::ParamValue::Float(db);
            p.keyframes.clear();
        }
        Ok(())
    })?;
    settle(s);
    Ok(())
}

/// Mute or unmute a clip's sound.
pub(crate) fn set_muted(s: &mut Session, id: u64, muted: bool) -> Result<(), MobileError> {
    let a = sound_clip(s, id)?;
    s.edit_sequence(if muted { "Mute" } else { "Unmute" }, |q, _, _| {
        q.find_item_mut(a.id).map(|x| x.1).ok_or_else(|| other("clip gone"))?.enabled = !muted;
        Ok(())
    })?;
    settle(s);
    Ok(())
}

/// Set a clip's sound fades (ticks; 0 = none). Each is kept within the clip.
pub(crate) fn set_fades(s: &mut Session, id: u64, fade_in: i64, fade_out: i64) -> Result<(), MobileError> {
    let a = sound_clip(s, id)?;
    let rate = s.sequence_rate();
    let clamp = |t: i64| rate.snap(Tick(t.clamp(0, a.duration.0)));
    let (fi, fo) = (clamp(fade_in), clamp(fade_out));
    let (fi, fo) = if fi + fo > a.duration { (Tick(a.duration.0 / 2), Tick(a.duration.0 - a.duration.0 / 2)) } else { (fi, fo) };
    s.edit_sequence("Fade", |q, ctx, _| {
        let track = q.audio_tracks.iter().find(|t| t.items.iter().any(|c| c.id == a.id)).map(|t| t.id).ok_or_else(|| other("clip gone"))?;
        if let Some(t) = q.track_mut(track) {
            t.transitions.retain(|tr| !(tr.from.is_none() && tr.to == Some(a.id)) && !(tr.from == Some(a.id) && tr.to.is_none()));
        }
        let fade = |id: u64, start: Tick, dur: Tick, from, to| -> filmcraft_engine::Result<Transition> {
            let effect = filmcraft_project::find_effect("constant_power").ok_or_else(|| other("no fade"))?.instance();
            Ok(Transition { id: TransitionId(id), effect, start, duration: dur, from, to, align: Default::default(), reverse: false })
        };
        if fi > Tick::ZERO {
            let id = alloc(ctx);
            filmcraft_edit::add_transition(q, track, fade(id, a.start, fi, None, Some(a.id))?, ctx)?;
        }
        if fo > Tick::ZERO {
            let id = alloc(ctx);
            filmcraft_edit::add_transition(q, track, fade(id, a.end() - fo, fo, Some(a.id), None)?, ctx)?;
        }
        Ok(())
    })?;
    settle(s);
    Ok(())
}

fn alloc(ctx: &mut filmcraft_edit::EditCtx) -> u64 {
    let id = *ctx.next_id;
    *ctx.next_id += 1;
    id
}

/// Copy a video clip's sound to an audio lane of its own, under the clip. Returns the new clip.
pub(crate) fn extract_audio(s: &mut Session, id: u64) -> Result<u64, MobileError> {
    let (kind, _, c) = locate(s, id)?;
    if kind != TrackKind::Video {
        return Err(MobileError::Command("Only a video's sound can be extracted.".into()));
    }
    let a = sound_clip(s, id)?;
    let name = s.project.item(c.item).map(|p| p.name.clone()).unwrap_or_default();
    let copy = s.edit_group("Extract Audio", |s| {
        let lane = free_lane(s, TrackKind::Audio, 1, None, a.start, a.end(), None).map_err(|e| other(e.to_string()))?;
        let r = s.execute("timeline.move", json!({"moves": [{"clip": a.id.0, "track": lane, "time": a.start.0}], "copy": true, "linked": false}))?;
        let copy = clips_of(&r, "copied").first().copied().ok_or_else(|| other("the sound could not be copied"))?;
        s.edit_sequence("Extract Audio", |q, _, _| {
            let c = q.find_item_mut(ClipId(copy)).map(|x| x.1).ok_or_else(|| other("copy gone"))?;
            c.link = None;
            c.name = format!("Extracted {name}");
            Ok(())
        })?;
        Ok(copy)
    })?;
    settle(s);
    select_one(s, Some(copy))?;
    Ok(copy)
}

/// Where standard effects go in a clip's list: before the intrinsic Motion/Opacity.
fn effect_pos(c: &TrackItem) -> usize {
    c.effects.iter().position(|e| e.def().is_some_and(|d| d.intrinsic)).unwrap_or(c.effects.len())
}

fn resolve(inst: &mut [EffectInstance], w: u32, h: u32) {
    for e in inst {
        filmcraft_project::resolve_auto_points(e, (w, h), (w, h));
    }
}

/// Replace a clip's preset instances (`slots`) with `new`.
fn swap_instances(c: &mut TrackItem, slots: &[usize], new: Vec<EffectInstance>) {
    let at = slots.first().copied();
    for &i in slots.iter().rev() {
        if i < c.effects.len() {
            c.effects.remove(i);
        }
    }
    let pos = at.filter(|&i| i <= c.effects.len()).unwrap_or_else(|| effect_pos(c));
    for (k, e) in new.into_iter().enumerate() {
        c.effects.insert(pos + k, e);
    }
}

fn picture_clips(s: &Session, id: u64, all: bool) -> Result<Vec<ClipId>, MobileError> {
    if !all {
        let (kind, _, c) = locate(s, id)?;
        if kind != TrackKind::Video {
            return Err(MobileError::Command("Only pictures and videos take this.".into()));
        }
        return Ok(vec![c.id]);
    }
    let (_, seq) = model::sequence(s)?;
    let mut v = Vec::new();
    for t in &seq.video_tracks {
        for c in &t.items {
            let text = s.project.item(c.item).is_some_and(|p| matches!(p.kind, filmcraft_project::ItemKind::Graphic { .. }));
            if !text {
                v.push(c.id);
            }
        }
    }
    Ok(v)
}

/// Set a clip's filter (empty = none) at `amount` (0–200); `all` applies it to every picture.
pub(crate) fn set_filter(s: &mut Session, id: u64, filter: &str, amount: f64, merge: bool, all: bool) -> Result<(), MobileError> {
    let clips = picture_clips(s, id, all)?;
    filter_clips(s, &clips, format!("filter:{id}"), filter, amount, merge && !all)
}

/// [`set_filter`] for exactly `clips`, as one edit (one undo step; `key` merges a slider drag).
fn filter_clips(s: &mut Session, clips: &[ClipId], key: String, filter: &str, amount: f64, merge: bool) -> Result<(), MobileError> {
    let (_, seq) = model::sequence(s)?;
    let (w, h) = (seq.settings.width, seq.settings.height);
    let new = if filter.is_empty() {
        Vec::new()
    } else {
        presets::filter_instances(filter, amount).ok_or_else(|| MobileError::Command(format!("Unknown filter {filter}.")))?
    };
    s.edit_sequence_as("Filter", merge.then_some(key.as_str()), |q, _, _| {
        for cid in clips {
            let c = q.find_item_mut(*cid).map(|x| x.1).ok_or_else(|| other("clip gone"))?;
            let slots = presets::filter_slots(c);
            let mut inst = new.clone();
            resolve(&mut inst, w, h);
            swap_instances(c, &slots, inst);
        }
        Ok(())
    })?;
    settle(s);
    Ok(())
}

/// Set a clip's effect (empty = none) at `amount` (0–100); `all` applies it to every picture.
pub(crate) fn set_effect(s: &mut Session, id: u64, effect: &str, amount: f64, merge: bool, all: bool) -> Result<(), MobileError> {
    let clips = picture_clips(s, id, all)?;
    effect_clips(s, &clips, format!("effect:{id}"), effect, amount, merge && !all)
}

/// [`set_effect`] for exactly `clips`, as one edit.
fn effect_clips(s: &mut Session, clips: &[ClipId], key: String, effect: &str, amount: f64, merge: bool) -> Result<(), MobileError> {
    let (_, seq) = model::sequence(s)?;
    let (w, h) = (seq.settings.width, seq.settings.height);
    let new = if effect.is_empty() {
        Vec::new()
    } else {
        presets::effect_instances(effect, amount).ok_or_else(|| MobileError::Command(format!("Unknown effect {effect}.")))?
    };
    s.edit_sequence_as("Effect", merge.then_some(key.as_str()), |q, _, _| {
        for cid in clips {
            let c = q.find_item_mut(*cid).map(|x| x.1).ok_or_else(|| other("clip gone"))?;
            let slots = presets::effect_slots(c);
            let mut inst = new.clone();
            resolve(&mut inst, w, h);
            swap_instances(c, &slots, inst);
        }
        Ok(())
    })?;
    settle(s);
    Ok(())
}

/// Set a clip's opacity (0.0 to 1.0); `all` sets every picture's.
pub(crate) fn set_opacity(s: &mut Session, id: u64, opacity: f64, merge: bool, all: bool) -> Result<(), MobileError> {
    let clips = picture_clips(s, id, all)?;
    opacity_clips(s, &clips, format!("opacity:{id}"), opacity, merge && !all)
}

/// [`set_opacity`] for exactly `clips`, as one edit.
fn opacity_clips(s: &mut Session, clips: &[ClipId], key: String, opacity: f64, merge: bool) -> Result<(), MobileError> {
    let v = if opacity.is_finite() { opacity.clamp(0.0, 1.0) * 100.0 } else { 100.0 };
    s.edit_sequence_as("Opacity", merge.then_some(key.as_str()), |q, _, _| {
        for cid in clips {
            let c = q.find_item_mut(*cid).map(|x| x.1).ok_or_else(|| other("clip gone"))?;
            if let Some(p) = c.effects.iter_mut().find(|e| e.effect == "opacity").and_then(|e| e.param_mut("opacity")) {
                p.value = filmcraft_project::ParamValue::Float(v);
                p.keyframes.clear();
            }
        }
        Ok(())
    })?;
    settle(s);
    Ok(())
}

/// Flip a clip's picture left-right (`horizontal`) or upside down.
pub(crate) fn set_flip(s: &mut Session, id: u64, horizontal: bool, on: bool) -> Result<(), MobileError> {
    let clips = picture_clips(s, id, false)?;
    flip_clips(s, &clips, horizontal, on)
}

/// [`set_flip`] for exactly `clips`, as one edit.
fn flip_clips(s: &mut Session, clips: &[ClipId], horizontal: bool, on: bool) -> Result<(), MobileError> {
    let fx = if horizontal { "horizontal_flip" } else { "vertical_flip" };
    let inst = filmcraft_project::find_effect(fx).ok_or_else(|| MobileError::Command("flip is missing".into()))?.instance();
    s.edit_sequence(if horizontal { "Mirror" } else { "Flip" }, |q, _, _| {
        for cid in clips {
            let c = q.find_item_mut(*cid).map(|x| x.1).ok_or_else(|| other("clip gone"))?;
            c.effects.retain(|e| e.effect != fx);
            if on {
                let pos = effect_pos(c);
                c.effects.insert(pos, inst.clone());
            }
        }
        Ok(())
    })?;
    settle(s);
    Ok(())
}

/// A tool applied to several chosen clips at once, as one undo step. `ids` are the chosen clips (a
/// sound stands for its picture); each tool takes the ones it applies to and leaves the rest alone
/// (a filter skips text and sound, speed skips text, volume skips what has no sound). `op` is one of
/// delete, duplicate, split, speed, filter, effect, opacity, mirror, flip, volume, mute; `text`,
/// `amount` and `on` are its settings (filter/effect name and strength, opacity 0–1, speed, volume
/// 0–2, mirror/flip/mute on or off); `merge` folds a slider drag into one undo step.
pub(crate) fn edit_many(s: &mut Session, ids: &[u64], op: &str, text: &str, amount: f64, on: bool, merge: bool) -> Result<(), MobileError> {
    struct Chosen {
        id: ClipId,
        kind: TrackKind,
        graphic: bool,
        sound: bool,
    }
    let mut chosen: Vec<(Tick, Chosen)> = Vec::new();
    {
        let (_, seq) = model::sequence(s)?;
        for &id in ids {
            let cid = model::shown_clip(seq, ClipId(id));
            if chosen.iter().any(|c| c.1.id == cid) {
                continue;
            }
            let Some(f) = model::find(seq, cid) else { continue };
            let graphic = s.project.item(f.clip.item).is_some_and(|p| matches!(p.kind, filmcraft_project::ItemKind::Graphic { .. }));
            let sound = model::sound_of(seq, &f).is_some();
            chosen.push((f.clip.start, Chosen { id: cid, kind: f.kind, graphic, sound }));
        }
    }
    chosen.sort_by_key(|c| c.0);
    if chosen.is_empty() {
        return Err(MobileError::Command("The chosen clips are no longer on the timeline.".into()));
    }
    let key = format!("{op}:many:{}", chosen[0].1.id.0);
    let picture: Vec<ClipId> = chosen.iter().filter(|c| c.1.kind == TrackKind::Video && !c.1.graphic).map(|c| c.1.id).collect();
    let none = |what: &str| MobileError::Command(format!("None of the chosen clips takes {what}."));
    let run = |r: Result<(), MobileError>| r.map_err(|e| other(e.to_string()));
    let all: Vec<ClipId> = chosen.iter().map(|c| c.1.id).collect();
    match op {
        "delete" => {
            s.edit_group("Delete", |s| {
                for id in &all {
                    if locate(s, id.0).is_ok() {
                        run(delete(s, id.0))?;
                    }
                }
                Ok(())
            })?;
        }
        "duplicate" => {
            s.edit_group("Duplicate", |s| {
                for id in &all {
                    if locate(s, id.0).is_ok() {
                        run(duplicate(s, id.0).map(|_| ()))?;
                    }
                }
                Ok(())
            })?;
        }
        "split" => {
            let rate = s.sequence_rate();
            let ph = rate.snap(s.playhead());
            let margin = Tick(rate.frame_duration().0.saturating_mul(SPLIT_MARGIN_FRAMES));
            let here: Vec<ClipId> = {
                let (_, seq) = model::sequence(s)?;
                all.iter().copied().filter(|c| model::find(seq, *c).is_some_and(|f| ph >= f.clip.start + margin && ph <= f.clip.end() - margin)).collect()
            };
            if here.is_empty() {
                return Err(MobileError::Command("Move the playhead into the chosen clips to split them.".into()));
            }
            s.edit_group("Split", |s| {
                for id in &here {
                    run(split(s, id.0).map(|_| ()))?;
                }
                Ok(())
            })?;
        }
        "speed" => {
            let targets: Vec<ClipId> = chosen.iter().filter(|c| !c.1.graphic && c.1.kind == TrackKind::Video).map(|c| c.1.id).collect();
            if targets.is_empty() {
                return Err(none("a speed change"));
            }
            s.edit_group("Speed", |s| {
                for id in &targets {
                    run(set_speed(s, id.0, amount))?;
                }
                Ok(())
            })?;
        }
        "filter" | "effect" | "opacity" | "mirror" | "flip" if picture.is_empty() => return Err(none("this")),
        "filter" => filter_clips(s, &picture, key, text, amount, merge)?,
        "effect" => effect_clips(s, &picture, key, text, amount, merge)?,
        "opacity" => opacity_clips(s, &picture, key, amount, merge)?,
        "mirror" => flip_clips(s, &picture, true, on)?,
        "flip" => flip_clips(s, &picture, false, on)?,
        "volume" | "mute" => {
            let mut sounds: Vec<ClipId> = Vec::new();
            {
                let (_, seq) = model::sequence(s)?;
                for c in chosen.iter().filter(|c| c.1.sound) {
                    if let Some(f) = model::find(seq, c.1.id) {
                        if let Some(a) = model::sound_of(seq, &f) {
                            sounds.push(a.clip.id);
                        }
                    }
                }
            }
            if sounds.is_empty() {
                return Err(none("a volume change"));
            }
            if op == "volume" {
                let db = db_of(amount);
                s.edit_sequence_as("Volume", merge.then_some(key.as_str()), |q, _, _| {
                    for a in &sounds {
                        let c = q.find_item_mut(*a).map(|x| x.1).ok_or_else(|| other("clip gone"))?;
                        if let Some(p) = c.effects.iter_mut().find(|e| e.effect == "volume").and_then(|e| e.param_mut("level")) {
                            p.value = filmcraft_project::ParamValue::Float(db);
                            p.keyframes.clear();
                        }
                    }
                    Ok(())
                })?;
            } else {
                s.edit_sequence(if on { "Mute" } else { "Unmute" }, |q, _, _| {
                    for a in &sounds {
                        q.find_item_mut(*a).map(|x| x.1).ok_or_else(|| other("clip gone"))?.enabled = !on;
                    }
                    Ok(())
                })?;
            }
            settle(s);
        }
        other_op => return Err(MobileError::Command(format!("Unknown tool {other_op}."))),
    }
    Ok(())
}

/// A transition's slot on the main track: between `from` and `to`, or at the start (`from`
/// empty) or end (`to` empty).
fn transition_at(s: &Session, from: Option<u64>, to: Option<u64>) -> Option<TransitionId> {
    let (_, seq) = model::sequence(s).ok()?;
    seq.video_tracks.first()?.transitions.iter().find(|t| t.from.map(|c| c.0) == from && t.to.map(|c| c.0) == to).map(|t| t.id)
}

/// Footage a clip can still show past one of its edges, in timeline time: before its in point
/// (`head`) or after its out point. Pictures, blanks and text never run out.
fn spare(s: &Session, c: &TrackItem, head: bool) -> Tick {
    let endless = Tick(i64::MAX / 4);
    let media = match s.project.item(c.item).map(|p| &p.kind) {
        Some(filmcraft_project::ItemKind::Media(m))
            if matches!(m.media, filmcraft_project::MediaRef::File { .. }) && m.info.kind != filmcraft_media::MediaKind::Still =>
        {
            m.info.duration
        }
        _ => return endless,
    };
    let speed = if c.speed.is_finite() && c.speed.abs() > 1e-6 { c.speed.abs() } else { 1.0 };
    let used = Tick::from_seconds_f64(c.duration.seconds() * speed);
    let left = if head { c.source_in } else { media - (c.source_in + used) };
    Tick::from_seconds_f64(left.max(Tick::ZERO).seconds() / speed)
}

/// The longest transition a slot takes (seconds). Each side of a cut gives up to a third of its
/// clip plus the footage it has to spare (at most half the clip), less what a transition at its
/// other end already uses; the cut takes twice the smaller side. A start or end takes half the clip.
pub(crate) fn max_transition(s: &Session, from: Option<u64>, to: Option<u64>) -> f64 {
    let Ok((_, seq)) = model::sequence(s) else { return 0.0 };
    let clip = |c: Option<u64>| c.and_then(|c| seq.find_item(ClipId(c))).map(|(_, c)| c.clone());
    let transitions = seq.video_tracks.first().map(|t| t.transitions.clone()).unwrap_or_default();
    // what the transition at a clip's far end takes from it
    let far = |c: &TrackItem, head: bool| -> f64 {
        transitions
            .iter()
            .find(|t| if head { t.from == Some(c.id) && t.to.is_some() } else { t.to == Some(c.id) && t.from.is_some() })
            .map_or(0.0, |t| t.duration.seconds() / 2.0)
    };
    let side = |c: &TrackItem, head: bool| {
        let len = c.duration.seconds();
        ((len + spare(s, c, head).seconds().min(len / 2.0)) / 3.0 - far(c, head)).max(0.0)
    };
    let max = match (clip(from), clip(to)) {
        (Some(a), Some(b)) => 2.0 * side(&a, false).min(side(&b, true)),
        (Some(a), None) | (None, Some(a)) => a.duration.seconds() / 2.0,
        (None, None) => 0.0,
    };
    max.min(MAX_TRANSITION)
}

/// Make the footage a transition of `frames` on the cut between `from` and `to` needs: each side
/// lends half from its spare footage, and what it lacks is trimmed off the clip itself (the main
/// track closes up, so the video gets shorter). Starts and ends need nothing.
fn make_room(s: &mut Session, rate: FrameRate, from: Option<u64>, to: Option<u64>, frames: i64) -> Result<(), MobileError> {
    let (Some(a), Some(b)) = (from, to) else { return Ok(()) };
    let out_half = rate.tick_of(frames / 2);
    let in_half = rate.tick_of(frames - frames / 2);
    let (_, _, ca) = locate(s, a)?;
    let short = out_half - spare(s, &ca, false);
    if short > Tick::ZERO {
        trim(s, a, false, -short.0)?;
    }
    let (_, _, cb) = locate(s, b)?;
    let short = in_half - spare(s, &cb, true);
    if short > Tick::ZERO {
        trim(s, b, true, short.0)?;
    }
    Ok(())
}

/// Put transition `preset` (empty = none) of `seconds` in a main-track slot. Returns its id.
pub(crate) fn set_transition(s: &mut Session, from: Option<u64>, to: Option<u64>, preset: &str, seconds: f64, all: bool) -> Result<Option<u64>, MobileError> {
    if all {
        return set_transition_everywhere(s, preset, seconds);
    }
    let rate = s.sequence_rate();
    let r = s.edit_group(if preset.is_empty() { "Remove Transition" } else { "Transition" }, |s| place_transition(s, rate, from, to, preset, seconds))?;
    if let Some(t) = r {
        ex(s, "timeline.select", json!({"clips": [], "transitions": [t]}))?;
    }
    Ok(r)
}

fn place_transition(s: &mut Session, rate: FrameRate, from: Option<u64>, to: Option<u64>, preset: &str, seconds: f64) -> filmcraft_engine::Result<Option<u64>> {
    if let Some(old) = transition_at(s, from, to) {
        s.execute("sequence.removeTransition", json!({"transitions": [old.0]}))?;
    }
    if preset.is_empty() {
        return Ok(None);
    }
    let (effect, params) = presets::transition_params(preset).ok_or_else(|| other(format!("unknown transition {preset}")))?;
    let max = max_transition(s, from, to);
    if max < MIN_TRANSITION {
        return Err(other("The clips are too short for a transition."));
    }
    let secs = if seconds.is_finite() { seconds.clamp(MIN_TRANSITION, max) } else { DEFAULT_TRANSITION.min(max) };
    let frames = (secs * rate.as_f64()).round().max(1.0) as i64;
    make_room(s, rate, from, to, frames).map_err(|e| other(e.to_string()))?;
    let (clip, edge) = match (from, to) {
        (Some(f), _) => (f, "out"),
        (None, Some(t)) => (t, "in"),
        (None, None) => return Err(other("no slot")),
    };
    let r = s.execute("sequence.applyVideoTransition", json!({"clip": clip, "edge": edge, "effect": effect, "frames": frames, "params": params}))?;
    Ok(r["transition"].as_u64())
}

fn set_transition_everywhere(s: &mut Session, preset: &str, seconds: f64) -> Result<Option<u64>, MobileError> {
    let rate = s.sequence_rate();
    let (_, seq) = model::sequence(s)?;
    let clips = model::main_clips(seq);
    let cuts: Vec<(u64, u64)> = clips.windows(2).filter_map(|w| Some((w.first()?.2.0, w.get(1)?.2.0))).collect();
    s.edit_group("Apply To All", |s| {
        for (a, b) in cuts {
            // a cut too short for a transition is skipped
            let _ = place_transition(s, rate, Some(a), Some(b), preset, seconds);
        }
        Ok(())
    })?;
    Ok(None)
}

/// Change a transition's length (seconds).
pub(crate) fn set_transition_duration(s: &mut Session, id: u64, seconds: f64) -> Result<(), MobileError> {
    let (_, seq) = model::sequence(s)?;
    let tr = seq
        .video_tracks
        .first()
        .and_then(|t| t.transitions.iter().find(|t| t.id.0 == id))
        .cloned()
        .ok_or_else(|| MobileError::Command("That transition is gone.".into()))?;
    let max = max_transition(s, tr.from.map(|c| c.0), tr.to.map(|c| c.0));
    let secs = if seconds.is_finite() { seconds.clamp(MIN_TRANSITION, max.max(MIN_TRANSITION)) } else { DEFAULT_TRANSITION };
    let rate = s.sequence_rate();
    let frames = (secs * rate.as_f64()).round().max(1.0) as i64;
    let (from, to) = (tr.from.map(|c| c.0), tr.to.map(|c| c.0));
    s.edit_group("Transition Duration", |s| {
        make_room(s, rate, from, to, frames).map_err(|e| other(e.to_string()))?;
        s.execute("sequence.setTransition", json!({"transition": id, "frames": frames}))
    })?;
    Ok(())
}

/// Trim a clip's head (`head`) or tail by `delta` ticks (positive moves the edge right). The main
/// track ripples. Returns the change actually made.
pub(crate) fn trim(s: &mut Session, id: u64, head: bool, delta: i64) -> Result<i64, MobileError> {
    let (kind, track, c) = locate(s, id)?;
    let main = is_main(kind, track);
    // an overlay edge stops at its neighbours
    let delta = if main {
        delta
    } else {
        let (_, seq) = model::sequence(s)?;
        let tracks = if kind == TrackKind::Video { &seq.video_tracks } else { &seq.audio_tracks };
        let items = tracks.get(track).map(|t| t.items.as_slice()).unwrap_or(&[]);
        if head {
            let prev_end = items.iter().filter(|i| i.end() <= c.start && i.id != c.id).map(|i| i.end()).max().unwrap_or(Tick::ZERO);
            delta.max((prev_end - c.start).0)
        } else {
            let next_start = items.iter().filter(|i| i.start >= c.end() && i.id != c.id).map(|i| i.start).min();
            next_start.map(|n| delta.min((n - c.end()).0)).unwrap_or(delta)
        }
    };
    let rate = s.sequence_rate();
    // no edge moves further than the whole timeline plus the clip
    let limit = seq_end(s).0.saturating_add(c.duration.0).max(1);
    let delta = delta.clamp(-limit, limit);
    let delta = rate.snap_nearest(Tick(delta.abs())).0 * delta.signum();
    if delta == 0 {
        return Ok(0);
    }
    let params = json!({"clip": c.id.0, "edge": if head { "in" } else { "out" }, "mode": if main { "ripple" } else { "regular" }, "delta": delta});
    // trimming a head moves the clip's own footage too, and what lies over it
    let at = if head { c.start } else { c.end() };
    let r = if main { s.edit_group("Trim", |s| ripple_main(s, at, |s| s.execute("timeline.trim", params)))? } else { ex(s, "timeline.trim", params)? };
    Ok(r["delta"].as_i64().unwrap_or(0))
}

/// Move a main-track clip to position `index` among the main track's clips.
pub(crate) fn reorder(s: &mut Session, id: u64, index: u32) -> Result<(), MobileError> {
    let (kind, track, c) = locate(s, id)?;
    if !is_main(kind, track) {
        return Err(MobileError::Command("Only main-track clips are reordered.".into()));
    }
    let (_, seq) = model::sequence(s)?;
    let order: Vec<ClipId> = model::main_clips(seq).iter().map(|x| x.2).collect();
    let from = order.iter().position(|&x| x == c.id).ok_or_else(|| MobileError::Command("clip gone".into()))?;
    let to = (index as usize).min(order.len().saturating_sub(1));
    if from == to {
        return Ok(());
    }
    s.edit_group("Reorder", |s| {
        let locked = unlock_others(s)?;
        let r = (|| {
            // park the clip past the end, close the gap it left, then insert it at its new place
            let park = seq_end(s) + Tick::from_seconds_f64(1.0);
            s.execute("timeline.move", json!({"moves": [{"clip": c.id.0, "track": "V1", "time": park.0}], "insert": false}))?;
            s.execute("sequence.closeGap", json!({"track": "V1", "time": c.start.0}))?;
            let seq = s.active_sequence().ok_or(EngineError::NoSequence)?;
            let rest: Vec<(Tick, Tick)> = model::main_clips(seq).iter().filter(|x| x.2 != c.id).map(|x| (x.0, x.1)).collect();
            let at = rest.get(to).map(|x| x.0).or_else(|| rest.last().map(|x| x.1)).unwrap_or(Tick::ZERO);
            s.execute("timeline.move", json!({"moves": [{"clip": c.id.0, "track": "V1", "time": at.0}], "insert": true}))?;
            Ok(())
        })();
        relock(s, &locked)?;
        r
    })?;
    Ok(())
}

fn seq_end(s: &Session) -> Tick {
    s.active_sequence().map(|q| q.duration()).unwrap_or(Tick::ZERO)
}

/// Move an overlay or audio clip to `start` on lane `index` (1, 2… overlays; -1, -2… audio).
/// Explicitly selected lanes must be free; they never silently redirect to another lane.
pub(crate) fn move_clip(s: &mut Session, id: u64, index: i32, start: i64) -> Result<(), MobileError> {
    let (kind, track, c) = locate(s, id)?;
    let start = s.sequence_rate().snap_nearest(ticks(start));
    let want = usize::try_from(index.unsigned_abs()).ok().filter(|&w| w >= 1);

    // V1 is gapless and therefore uses insert semantics when an overlay clip is
    // dropped onto it. The engine moves linked video audio together with its clip.
    if index == 0 && kind == TrackKind::Video && !is_main(kind, track) {
        return move_into_main(s, &c, start);
    }
    if is_main(kind, track) && index == 0 {
        return Err(MobileError::Command("Main-track clips are reordered instead.".into()));
    }
    // A main-track clip leaving V1 for an overlay lane: V1 stays gapless, so what follows it closes up.
    if is_main(kind, track) && index > 0 {
        if let Some(requested) = want {
            return move_out_of_main(s, &c, requested, start);
        }
    }
    let first = if kind == TrackKind::Video { 1 } else { 0 };
    let lane = if let Some(requested) = want {
        free_lane_exact(s, kind, first, requested, start, start + c.duration, Some(c.id))?
    } else {
        free_lane(s, kind, first, None, start, start + c.duration, Some(c.id))?
    };
    ex(s, "timeline.move", json!({"moves": [{"clip": c.id.0, "track": lane, "time": start.0}], "insert": false}))?;
    Ok(())
}

/// Group the chosen clips into one composition (a nested sequence), as one undo step. The engine
/// builds the sequence from the clips, keeping their distances in time, their durations, their
/// lanes relative to each other, their linked sound, effects and settings, and puts one clip that
/// plays it where the group started. The clip keeps the sound of the group linked to it (and so
/// hidden inside it), as every video clip does. Returns the clip that plays the composition.
pub(crate) fn create_composition(s: &mut Session, ids: &[u64], name: &str) -> Result<u64, MobileError> {
    use std::collections::HashSet;
    let mut want: Vec<ClipId> = Vec::new();
    let mut sound: Vec<ClipId> = Vec::new();
    // the stretch of V1 the chosen main-track clips took up (they are next to each other)
    let mut main_region: Option<(Tick, Tick)> = None;
    {
        let (_, seq) = model::sequence(s)?;
        let mut main: Vec<(Tick, Tick, ClipId)> = Vec::new();
        for &id in ids {
            let cid = model::shown_clip(seq, ClipId(id));
            if want.contains(&cid) {
                continue;
            }
            let f = model::find(seq, cid).ok_or_else(|| MobileError::Command("That clip is no longer on the timeline.".into()))?;
            want.push(cid);
            if is_main(f.kind, f.track) {
                main.push((f.clip.start, f.clip.end(), cid));
            }
            // sound the user chose on its own: if the engine leaves it behind (and copies it into the
            // composition), it must not stay in this sequence as well, or it would play twice
            if f.kind == TrackKind::Audio {
                sound.push(cid);
            }
            if f.kind == TrackKind::Video {
                if let Some(a) = model::partner(seq, f.clip, TrackKind::Audio) {
                    sound.push(a.clip.id);
                }
            }
        }
        if want.len() < 2 {
            return Err(MobileError::Command("Select at least two clips to make a composition.".into()));
        }
        main_region = main.iter().map(|m| m.0).min().zip(main.iter().map(|m| m.1).max());
        // V1 has no gaps: the chosen V1 clips must be next to each other, or the clips between would be left out
        if let (Some(lo), Some(hi)) = (main.iter().map(|m| m.0).min(), main.iter().map(|m| m.1).max()) {
            let chosen: HashSet<ClipId> = main.iter().map(|m| m.2).collect();
            if seq.video_tracks.first().is_some_and(|t| t.items.iter().any(|x| !chosen.contains(&x.id) && x.start < hi && x.end() > lo)) {
                return Err(MobileError::Command("Select consecutive clips on V1 to make a composition.".into()));
            }
        }
    }
    let ids: Vec<u64> = want.iter().map(|c| c.0).collect();
    let name = if name.trim().is_empty() { "Composition" } else { name.trim() };
    Ok(s.edit_group("Make Composition", |s| {
        s.execute("timeline.select", json!({"clips": ids, "linked": false}))?;
        let made = s.execute("clip.nest", json!({"name": name}))?;
        let item = made["sequence"].as_u64().ok_or_else(|| other("the composition could not be made"))?;
        let clips = clips_of(&made, "clips");
        let nest = *clips.first().ok_or_else(|| other("the composition could not be made"))?;
        // With the sound of the group on several lanes the engine nests the picture alone, leaves
        // the sound in this sequence (now unlinked, and so visible) and copies it into the
        // composition. The composition plays its own sound, so what was left is removed and the
        // composition's sound is linked to its clip, hidden like every clip's sound.
        // (A composition of pictures alone gets its sound clip too: sound added inside it later
        // must play, and it is drawn with its waveform like any clip's.)
        if clips.len() < 2 {
            s.edit_sequence("Make Composition", |q, _, _| {
                for t in &mut q.audio_tracks {
                    t.items.retain(|i| !sound.contains(&i.id));
                    t.transitions.retain(|tr| !tr.from.is_some_and(|c| sound.contains(&c)) && !tr.to.is_some_and(|c| sound.contains(&c)));
                }
                Ok(())
            })?;
            add_missing_sound(s, ClipId(nest), ItemId(item))?;
        }
        // The composition goes where the engine puts it (by the first chosen clip's lane). When that
        // is not V1, the stretch of V1 the chosen clips left is empty: close up exactly that, so
        // the next V1 clips (and their sound) move left by it and V1 keeps no gap it did not have.
        if let Some((lo, hi)) = main_region {
            let on_main = {
                let seq = s.active_sequence().ok_or(EngineError::NoSequence)?;
                model::find(seq, ClipId(nest)).is_some_and(|f| is_main(f.kind, f.track))
            };
            if !on_main {
                s.edit_sequence("Close Gap", |q, _, _| {
                    close_main_after(q, hi, hi - lo);
                    Ok(())
                })?;
            }
        }
        s.execute("timeline.select", json!({"clips": [nest], "linked": false}))?;
        Ok(nest)
    })?)
}

/// Every composition clip of the open sequence plays the sound of the sequence it holds: one made
/// before sound was linked to compositions (or whose sound was lost) gets it back, linked to its
/// clip and hidden inside it. A clip that already has its sound is left alone. One undo step, and
/// nothing at all when there is nothing to restore.
pub(crate) fn ensure_composition_sound(s: &mut Session) -> Result<usize, MobileError> {
    let missing: Vec<(ClipId, ItemId)> = {
        let (_, seq) = model::sequence(s)?;
        let mut v = Vec::new();
        for t in &seq.video_tracks {
            for c in &t.items {
                let comp = s.project.item(c.item).is_some_and(|p| matches!(p.kind, filmcraft_project::ItemKind::Sequence(_)));
                if comp && model::partner(seq, c, TrackKind::Audio).is_none() {
                    v.push((c.id, c.item));
                }
            }
        }
        v
    };
    if missing.is_empty() {
        return Ok(0);
    }
    s.edit_group("Restore Sound", |s| {
        for (clip, item) in &missing {
            add_missing_sound(s, *clip, *item)?;
        }
        Ok(())
    })?;
    Ok(missing.len())
}

/// Every clip on a video track of any sequence that plays sequence item `item`: a composition and
/// each copy (duplicate) or piece (cut) of it. They all show the same sequence, so editing one
/// changes the others.
fn composition_players(p: &filmcraft_project::Project, item: ItemId) -> Vec<ClipId> {
    use filmcraft_project::ItemKind;
    let mut players = Vec::new();
    for pi in p.items.values() {
        if let ItemKind::Sequence(q) = &pi.kind {
            for t in &q.video_tracks {
                players.extend(t.items.iter().filter(|c| c.item == item).map(|c| c.id));
            }
        }
    }
    players
}

/// How many OTHER clips play the composition `item` that is being edited (0 when it is on its own).
pub(crate) fn composition_links(s: &Session, item: u64) -> usize {
    composition_players(&s.project, ItemId(item)).len().saturating_sub(1)
}

/// Keep the changes just made to composition `item` for the one clip `clip` (and its linked sound):
/// that clip gets a sequence of its own, an independent copy of the edited one, and every other clip
/// that played `item` gets it back as it was before the edit (`original`). One undo step. From then
/// on the clip shares nothing with the others, so nothing about it needs asking again.
pub(crate) fn keep_composition_alone(s: &mut Session, item: u64, clip: u64, original: filmcraft_project::Sequence) -> Result<(), MobileError> {
    use filmcraft_project::{ItemKind, TrackId};
    let (item, clip) = (ItemId(item), ClipId(clip));
    Ok(s.edit("Keep Composition Apart", |pr, _| {
        let edited = pr.sequence(item).ok_or_else(|| other("That composition is no longer in the project."))?.clone();
        let name = pr.item(item).map(|i| i.name.clone()).unwrap_or_else(|| "Composition".to_string());
        // the clip being edited and the link that ties its sound to it
        let mut found = false;
        let mut link: Option<u64> = None;
        for pi in pr.items.values() {
            if let ItemKind::Sequence(q) = &pi.kind {
                for c in q.video_tracks.iter().chain(q.audio_tracks.iter()).flat_map(|t| t.items.iter()) {
                    if c.id == clip && c.item == item {
                        found = true;
                        link = c.link;
                    }
                }
            }
        }
        if !found {
            return Err(other("The composition's clip is no longer on the timeline."));
        }
        // an independent copy of what was edited: clips, tracks, links and transitions get ids of their own
        let mut copy = edited;
        let mut links: std::collections::HashMap<u64, u64> = std::collections::HashMap::new();
        for t in copy.video_tracks.iter_mut().chain(copy.audio_tracks.iter_mut()) {
            t.id = TrackId(pr.alloc_id());
            let mut ids: std::collections::HashMap<ClipId, ClipId> = std::collections::HashMap::new();
            for it in &mut t.items {
                let fresh = ClipId(pr.alloc_id());
                ids.insert(it.id, fresh);
                it.id = fresh;
                if let Some(l) = it.link {
                    it.link = Some(*links.entry(l).or_insert_with(|| pr.alloc_id()));
                }
            }
            for tr in &mut t.transitions {
                tr.id = TransitionId(pr.alloc_id());
                tr.from = tr.from.and_then(|c| ids.get(&c).copied());
                tr.to = tr.to.and_then(|c| ids.get(&c).copied());
            }
        }
        let alone = pr.new_sequence(&format!("{name} (separate)"), copy.settings.clone(), 0, 0, None);
        *pr.sequence_mut(alone).ok_or_else(|| other("The separate composition could not be made."))? = copy;
        // the others show what the composition was before this edit
        *pr.sequence_mut(item).ok_or_else(|| other("That composition is no longer in the project."))? = original;
        // this clip, and the sound linked to it, now play their own sequence
        for pi in pr.items.values_mut() {
            if let ItemKind::Sequence(q) = &mut pi.kind {
                // Sequences are shared through Arc; detach this sequence before mutating its clips.
                let q = std::sync::Arc::make_mut(q);
                for c in q.video_tracks.iter_mut().chain(q.audio_tracks.iter_mut()).flat_map(|t| t.items.iter_mut()) {
                    if c.item == item && (c.id == clip || (link.is_some() && c.link == link)) {
                        c.item = alone;
                    }
                }
            }
        }
        Ok(())
    })?)
}

/// The project's main sequence: the one no other sequence plays (the lowest id when several).
pub(crate) fn root_sequence(s: &Session) -> Option<ItemId> {
    use filmcraft_project::ItemKind;
    let played: std::collections::HashSet<ItemId> = s
        .project
        .items
        .values()
        .filter_map(|i| match &i.kind {
            ItemKind::Sequence(q) => Some(q),
            _ => None,
        })
        .flat_map(|q| q.video_tracks.iter().chain(q.audio_tracks.iter()))
        .flat_map(|t| t.items.iter().map(|c| c.item))
        .collect();
    s.project.items.values().filter(|i| matches!(i.kind, ItemKind::Sequence(_)) && !played.contains(&i.id)).map(|i| i.id).min_by_key(|i| i.0)
}

/// An overlay clip dropped on V1: the main track's magnetic insertion. The drop time snaps to the
/// nearest clip boundary of V1 (never into the middle of a clip, so nothing is cut), every V1 clip
/// from there on moves right by the clip's length (with its linked sound), and the clip goes into
/// the room that opens up: nothing is overwritten, V1 gets no new gap, and the clip keeps its
/// length and content. Its own sound goes to the main track's sound lane, still linked and hidden.
/// Other lanes stay where they are. One undo step.
fn move_into_main(s: &mut Session, c: &TrackItem, drop: Tick) -> Result<(), MobileError> {
    let dur = c.duration;
    let (at, sound) = {
        let (_, seq) = model::sequence(s)?;
        let mut bounds = vec![Tick::ZERO];
        if let Some(v1) = seq.video_tracks.first() {
            for it in &v1.items {
                bounds.push(it.start);
                bounds.push(it.end());
            }
        }
        let at = bounds.into_iter().min_by_key(|b| (b.0 - drop.0).abs()).unwrap_or(Tick::ZERO);
        let sound = model::partner(seq, c, TrackKind::Audio).map(|f| (f.clip.id, f.clip.start - c.start));
        (at, sound)
    };
    s.edit_group("Move", |s| {
        s.edit_sequence("Make Room", |q, _, _| {
            open_main_gap(q, at, dur);
            Ok(())
        })?;
        let mut moves = vec![json!({"clip": c.id.0, "track": "V1", "time": at.0})];
        if let Some((audio, offset)) = sound {
            let a_start = at + offset;
            let lane = free_lane(s, TrackKind::Audio, 0, None, a_start, a_start + dur, Some(audio)).map_err(|e| other(e.to_string()))?;
            moves.push(json!({"clip": audio.0, "track": lane, "time": a_start.0}));
        }
        s.execute("timeline.move", json!({"moves": moves, "insert": false, "linked": false}))?;
        Ok(())
    })?;
    Ok(())
}

/// Make room for `dur` at `at` on V1: every V1 clip that starts at or after `at` moves right by
/// `dur`, with the transitions among them and each one's linked sound. A transition between a clip
/// before `at` and one after it is dropped (they are no longer next to each other).
fn open_main_gap(q: &mut filmcraft_project::Sequence, at: Tick, dur: Tick) {
    let Some(v1) = q.video_tracks.first_mut() else { return };
    let mut moved: Vec<(ClipId, Option<u64>)> = Vec::new();
    for it in &mut v1.items {
        if it.start >= at {
            moved.push((it.id, it.link));
            it.start += dur;
        }
    }
    let is_moved = |c: Option<ClipId>| c.is_some_and(|c| moved.iter().any(|m| m.0 == c));
    v1.transitions.retain(|tr| !(tr.from.is_some() && tr.to.is_some() && is_moved(tr.to) && !is_moved(tr.from)));
    for tr in &mut v1.transitions {
        if is_moved(tr.from) || is_moved(tr.to) {
            tr.start += dur;
        }
    }
    v1.sort();
    for t in &mut q.audio_tracks {
        let mut sound: Vec<ClipId> = Vec::new();
        for it in &mut t.items {
            if it.link.is_some_and(|l| moved.iter().any(|m| m.1 == Some(l))) {
                it.start += dur;
                sound.push(it.id);
            }
        }
        if sound.is_empty() {
            continue;
        }
        for tr in &mut t.transitions {
            if tr.from.is_some_and(|c| sound.contains(&c)) || tr.to.is_some_and(|c| sound.contains(&c)) {
                tr.start += dur;
            }
        }
        t.sort();
    }
}

/// Move several overlay clips (V2 and above) together, as one undo step: every clip moves
/// `time_delta` ticks (never before 0) and `lane_delta` lanes, so their distances in time, their
/// lengths and their lanes relative to each other stay as they were. Clips that are not in `ids`
/// never move. When the target lanes are taken by clips outside the group, the whole group goes up
/// to the next lanes where it fits (new lanes are made when needed). Each clip's linked sound goes
/// with it, on an audio lane that is free there, and stays hidden inside the clip.
pub(crate) fn move_group(s: &mut Session, ids: &[u64], lane_delta: i32, time_delta: i64) -> Result<(), MobileError> {
    use std::collections::HashSet;
    struct Member {
        id: ClipId,
        track: usize,
        start: Tick,
        end: Tick,
        /// The linked sound: clip, its lane, start and end.
        sound: Option<(ClipId, usize, Tick, Tick)>,
    }
    let frame = s.sequence_rate().frame_duration().0.max(1);
    let mut members: Vec<Member> = Vec::new();
    {
        let (_, seq) = model::sequence(s)?;
        for &id in ids {
            let cid = model::shown_clip(seq, ClipId(id));
            if members.iter().any(|m| m.id == cid) {
                continue;
            }
            let f = model::find(seq, cid).ok_or_else(|| MobileError::Command("That clip is no longer on the timeline.".into()))?;
            if f.kind != TrackKind::Video || f.track == 0 {
                return Err(MobileError::Command("Only clips on V2 and above can be moved together.".into()));
            }
            let sound = model::partner(seq, f.clip, TrackKind::Audio).map(|a| (a.clip.id, a.track, a.clip.start, a.clip.end()));
            members.push(Member { id: cid, track: f.track, start: f.clip.start, end: f.clip.end(), sound });
        }
    }
    if members.is_empty() {
        return Ok(());
    }
    // the time shift, on the frame grid, never taking any clip (or its sound) before zero
    let earliest = members.iter().flat_map(|m| std::iter::once(m.start.0).chain(m.sound.map(|x| x.2.0))).min().unwrap_or(0);
    let d = ((time_delta as f64 / frame as f64).round() as i64 * frame).max(-earliest);
    let min_track = members.iter().map(|m| m.track).min().unwrap_or(1);
    let first_lane_shift = (lane_delta as i64).max(1 - min_track as i64);
    if first_lane_shift == 0 && d == 0 {
        return Ok(());
    }

    // plan: the lane shift and where each sound goes, from the timeline as it is now
    let (shift, audio_lanes) = {
        let (_, seq) = model::sequence(s)?;
        let group: HashSet<ClipId> = members.iter().map(|m| m.id).collect();
        let fits = |k: i64| {
            members.iter().all(|m| match seq.video_tracks.get((m.track as i64 + k) as usize) {
                None => true,
                Some(t) => t.items.iter().filter(|x| !group.contains(&x.id)).all(|x| x.end() <= m.start + Tick(d) || x.start >= m.end + Tick(d)),
            })
        };
        let mut k = first_lane_shift;
        while !fits(k) {
            k += 1;
            if k > first_lane_shift + 98 {
                return Err(MobileError::Command("There is no free track for these clips.".into()));
            }
        }
        let sounds: HashSet<ClipId> = members.iter().filter_map(|m| m.sound.map(|x| x.0)).collect();
        let mut planned: Vec<(usize, Tick, Tick)> = Vec::new();
        let mut lanes: Vec<Option<usize>> = Vec::new();
        for m in &members {
            let Some((_, lane, a_start, a_end)) = m.sound else {
                lanes.push(None);
                continue;
            };
            let (ns, ne) = (a_start + Tick(d), a_end + Tick(d));
            let ok = |i: usize| {
                seq.audio_tracks.get(i).is_none_or(|t| t.items.iter().filter(|x| !sounds.contains(&x.id)).all(|x| x.end() <= ns || x.start >= ne))
                    && planned.iter().all(|&(pi, ps, pe)| pi != i || pe <= ns || ps >= ne)
            };
            let pick = if lane >= 1 && ok(lane) { Some(lane) } else { (1..=seq.audio_tracks.len() + members.len()).find(|&i| ok(i)) };
            let pick = pick.ok_or_else(|| MobileError::Command("There is no free audio lane for these clips.".into()))?;
            planned.push((pick, ns, ne));
            lanes.push(Some(pick));
        }
        (k, lanes)
    };

    s.edit_group("Move Clips", |s| {
        // lanes that don't exist yet are made first
        let (have_v, have_a) = {
            let (_, seq) = model::sequence(s).map_err(|e| other(e.to_string()))?;
            (seq.video_tracks.len(), seq.audio_tracks.len())
        };
        let need_v = members.iter().map(|m| (m.track as i64 + shift) as usize + 1).max().unwrap_or(0);
        let need_a = audio_lanes.iter().flatten().map(|&i| i + 1).max().unwrap_or(0);
        if need_v > have_v || need_a > have_a {
            s.execute("sequence.addTracks", json!({"video": need_v.saturating_sub(have_v), "audio": need_a.saturating_sub(have_a)}))?;
        }
        let mut moves = Vec::new();
        for (m, lane) in members.iter().zip(&audio_lanes) {
            let track = (m.track as i64 + shift) as usize;
            moves.push(json!({"clip": m.id.0, "track": format!("V{}", track + 1), "time": m.start.0 + d}));
            if let (Some((aid, _, a_start, _)), Some(lane)) = (m.sound, lane) {
                moves.push(json!({"clip": aid.0, "track": format!("A{}", lane + 1), "time": a_start.0 + d}));
            }
        }
        s.execute("timeline.move", json!({"moves": moves, "insert": false, "linked": false}))?;
        Ok(())
    })?;
    Ok(())
}

/// Take main-track clip `c` out of V1 and put it on overlay lane `requested` at `start`, then close
/// up exactly the space it left: only V1 clips that started at or after the end of `c` (and their
/// linked sound) move left by its length, never back over the clip before them, so gaps that were
/// already there stay. The clip's own sound travels with it, kept linked (so it is still drawn
/// inside the clip) but on a free audio lane, never on top of A1's sound for the main track. Every
/// other lane, and the media itself, stays where it is. One undo step.
fn move_out_of_main(s: &mut Session, c: &TrackItem, requested: usize, start: Tick) -> Result<(), MobileError> {
    let (at, dur) = (c.end(), c.duration);
    let sound = {
        let (_, seq) = model::sequence(s)?;
        model::partner(seq, c, TrackKind::Audio).map(|f| (f.clip.id, f.clip.start - c.start))
    };
    let refused: std::cell::RefCell<Option<MobileError>> = std::cell::RefCell::new(None);
    let r = s.edit_group("Move", |s| {
        let lane = match free_lane_exact(s, TrackKind::Video, 1, requested, start, start + dur, Some(c.id)) {
            Ok(l) => l,
            Err(e) => {
                let msg = e.to_string();
                *refused.borrow_mut() = Some(e);
                return Err(other(msg));
            }
        };
        let mut moves = vec![json!({"clip": c.id.0, "track": lane, "time": start.0})];
        if let Some((audio, offset)) = sound {
            let a_start = start + offset;
            let a_lane = free_lane(s, TrackKind::Audio, 1, None, a_start, a_start + dur, None).map_err(|e| other(e.to_string()))?;
            moves.push(json!({"clip": audio.0, "track": a_lane, "time": a_start.0}));
        }
        s.execute("timeline.move", json!({"moves": moves, "insert": false, "linked": false}))?;
        s.edit_sequence("Close Gap", |q, _, _| {
            close_main_after(q, at, dur);
            Ok(())
        })?;
        Ok(())
    });
    let held = refused.borrow_mut().take();
    match (r, held) {
        (Err(_), Some(e)) => Err(e),
        (r, _) => Ok(r?),
    }
}

/// After a clip of length `dur` that ended at `at` left V1: move every V1 clip that starts at or
/// after `at` left by `dur` (never back over the clip before it), with the transitions on V1 and
/// each clip's linked sound, wherever it sits. Nothing else moves.
fn close_main_after(q: &mut filmcraft_project::Sequence, at: Tick, dur: Tick) {
    let Some(v1) = q.video_tracks.first_mut() else { return };
    v1.sort();
    let mut prev_end = Tick::ZERO;
    // (clip, its link, how far it moved: ≤ 0)
    let mut moved: Vec<(ClipId, Option<u64>, Tick)> = Vec::new();
    for it in &mut v1.items {
        if it.start >= at {
            let to = (it.start - dur).max(prev_end);
            moved.push((it.id, it.link, to - it.start));
            it.start = to;
        }
        prev_end = prev_end.max(it.end());
    }
    for tr in &mut v1.transitions {
        if let Some(by) = moved.iter().find(|m| tr.from == Some(m.0) || tr.to == Some(m.0)).map(|m| m.2) {
            tr.start += by;
        }
    }
    v1.sort();
    // the sound that belongs to a moved picture follows it by the same amount
    for t in &mut q.audio_tracks {
        let mut sound: Vec<(ClipId, Tick)> = Vec::new();
        for it in &mut t.items {
            let by = it.link.and_then(|l| moved.iter().find(|m| m.1 == Some(l)).map(|m| m.2));
            if let Some(by) = by {
                it.start += by;
                sound.push((it.id, by));
            }
        }
        if sound.is_empty() {
            continue;
        }
        for tr in &mut t.transitions {
            if let Some(by) = sound.iter().find(|m| tr.from == Some(m.0) || tr.to == Some(m.0)).map(|m| m.1) {
                tr.start += by;
            }
        }
        t.sort();
    }
}

/// Give a project that holds nothing yet the exact size of the first media added to it. A
/// project with any clip (or caption) keeps its size: only the manual aspect tool changes that.
/// When the project has no history either (it was just made) the change is not an undo step.
pub(crate) fn fit_empty_frame(s: &mut Session, width: u32, height: u32) -> Result<bool, MobileError> {
    let even = |x: u32| (x.clamp(2, 7680) & !1).max(2);
    let (w, h) = (even(width), even(height));
    let (_, seq) = model::sequence(s)?;
    let empty = seq.video_tracks.iter().chain(seq.audio_tracks.iter()).all(|t| t.items.is_empty()) && seq.caption_tracks.iter().all(|t| t.captions.is_empty());
    if !empty || (seq.settings.width, seq.settings.height) == (w, h) {
        return Ok(false);
    }
    let fresh = s.history.undo.is_empty() && s.history.redo.is_empty();
    s.execute("sequence.settings", json!({"width": w, "height": h}))?;
    if fresh {
        s.history.undo.clear();
        s.history.redo.clear();
    }
    Ok(true)
}

/// Change the frame's aspect: the new size keeps 1080 pixels on the short side.
/// Change the frame's shape. Every picture is sized to fit the frame when it's added (and a finger
/// scales it from there), so each one scales by how much its own fit changes, about the frame's
/// centre: a picture of the new shape fills the frame, and going to another shape and back gives
/// the same pictures.
pub(crate) fn set_aspect(s: &mut Session, num: u32, den: u32) -> Result<(), MobileError> {
    let (w, h) = frame_size(num, den);
    let (_, seq) = model::sequence(s)?;
    let (w0, h0) = (seq.settings.width, seq.settings.height);
    if (w0, h0) == (w, h) {
        return Ok(());
    }
    let (fw0, fh0, fw1, fh1) = (f64::from(w0.max(1)), f64::from(h0.max(1)), f64::from(w), f64::from(h));
    // a picture's fit in a frame, from its size at its display aspect
    let fit = |sw: f64, sh: f64, fw: f64, fh: f64| (fw / sw).min(fh / sh);
    let mut factors = std::collections::HashMap::new();
    for t in &seq.video_tracks {
        for it in &t.items {
            let k = match shown_size(s, it.item) {
                Some((sw, sh)) => fit(sw, sh, fw1, fh1) / fit(sw, sh, fw0, fh0),
                None => fit(fw0, fh0, fw1, fh1),
            };
            if k.is_finite() && k > 0.0 {
                factors.insert(it.id, k);
            }
        }
    }
    s.edit_group("Aspect Ratio", |s| {
        s.execute("sequence.settings", json!({"width": w, "height": h}))?;
        s.edit_sequence("Aspect Ratio", |q, _, _| {
            let (c0, c1) = ((fw0 / 2.0, fh0 / 2.0), (fw1 / 2.0, fh1 / 2.0));
            for it in q.video_tracks.iter_mut().flat_map(|t| t.items.iter_mut()) {
                let Some(&k) = factors.get(&it.id) else { continue };
                // Scale to Frame Size refits on its own
                let refits = it.scale_to_frame;
                let Some(m) = it.effect_mut("motion") else { continue };
                if let Some(p) = m.param_mut("position") {
                    p.map_values(|v| match v {
                        // an automatic (NaN) position follows the centre by itself
                        ParamValue::Vec2(mut v) => {
                            v.x = c1.0 + k * (v.x - c0.0);
                            v.y = c1.1 + k * (v.y - c0.1);
                            ParamValue::Vec2(v)
                        }
                        other => other,
                    });
                }
                if !refits {
                    for id in ["scale", "scale_width"] {
                        if let Some(p) = m.param_mut(id) {
                            p.map_values(|v| match v {
                                ParamValue::Float(x) => ParamValue::Float((x * k).clamp(0.0, MAX_SCALE)),
                                other => other,
                            });
                        }
                    }
                }
            }
            Ok(())
        })
    })?;
    Ok(())
}

/// The frame size for an aspect ratio: 1080 on the short side, even numbers.
pub(crate) fn frame_size(num: u32, den: u32) -> (u32, u32) {
    let (n, d) = (num.max(1) as f64, den.max(1) as f64);
    let even = |x: f64| ((x / 2.0).round() * 2.0).clamp(2.0, 7680.0) as u32;
    if n >= d { (even(1080.0 * n / d), 1080) } else { (1080, even(1080.0 * d / n)) }
}
