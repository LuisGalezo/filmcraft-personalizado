package io.github.artcraftandroid.filmcraft.ui.editor

import android.graphics.Bitmap
import android.net.Uri
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import io.github.artcraftandroid.filmcraft.core.CaptionInfo
import io.github.artcraftandroid.filmcraft.core.CaptionLook
import io.github.artcraftandroid.filmcraft.core.CaptionStatus
import io.github.artcraftandroid.filmcraft.core.ClipInfo
import io.github.artcraftandroid.filmcraft.core.ClipKind
import io.github.artcraftandroid.filmcraft.core.LaneKind
import io.github.artcraftandroid.filmcraft.core.MobileSession
import io.github.artcraftandroid.filmcraft.core.Renderer
import io.github.artcraftandroid.filmcraft.core.SessionStatus
import io.github.artcraftandroid.filmcraft.core.SpeechAudio
import io.github.artcraftandroid.filmcraft.core.SpeechSettings
import io.github.artcraftandroid.filmcraft.core.TextStyle
import io.github.artcraftandroid.filmcraft.core.TimelineInfo
import io.github.artcraftandroid.filmcraft.core.TransitionInfo
import io.github.artcraftandroid.filmcraft.engine.Engine
import io.github.artcraftandroid.filmcraft.engine.ProjectEntry
import io.github.artcraftandroid.filmcraft.engine.Projects
import io.github.artcraftandroid.filmcraft.engine.intoBitmap
import io.github.artcraftandroid.filmcraft.engine.userMessage
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.filterNotNull
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** A tool's panel. */
sealed interface Panel {
    data object Speed : Panel
    data object Volume : Panel
    data object Fade : Panel
    data object Opacity : Panel
    data object Filters : Panel
    data object Effects : Panel
    /** The transition between [from] and [to] (either empty at the ends). */
    data class Transitions(val from: ULong?, val to: ULong?) : Panel
    /** Typing text: a new clip ([clip] empty), editing one, or a caption's words ([caption]). */
    data class TextInput(val clip: ULong?, val caption: ULong? = null) : Panel
    data object TextStyle : Panel
    data object AspectRatio : Panel
    data object Voiceover : Panel
    /** Captions: make them, and their look. */
    data object Captions : Panel
    /** Text to speech: new speech ([clip] empty) or saying a speech clip again. */
    data class Speech(val clip: ULong?) : Panel
}

/** The tool bar's submenus. */
enum class Submenu { None, Retime, ClipAudio, AddAudio, Files }

/** What the editor needs from the rest of the app. */
interface EditorHost {
    fun tell(message: String)
    /** Ask the user for media: [kind] picks the picker; [onPicked] gets what they chose. */
    fun pick(kind: PickKind, onPicked: (List<Uri>) -> Unit)
    fun close()
    fun export()
    /** Ask for the microphone; [onGranted] runs once it may be used. */
    fun requestMicrophone(onGranted: () -> Unit)
}

enum class PickKind { PhotosAndVideos, FilesVisual, FilesAudio, ReplaceVisual, ExtractAudioVideo, FilmcraftPackage }

/**
 * The open project in the editor: the timeline as the engine last reported it, the playhead,
 * the picture at it, playback, the selection and the open tool. Every edit goes through [edit],
 * which runs it on the engine's command thread, re-reads the timeline and saves the project.
 */
@Stable
class EditorController(
    val engine: Engine,
    project: ProjectEntry,
    private val projects: Projects,
    private val scope: CoroutineScope,
    private val host: EditorHost,
) {
    private val session: MobileSession get() = engine.session

    var project by mutableStateOf(project)
        private set
    var timeline by mutableStateOf<TimelineInfo?>(null)
        private set
    var status by mutableStateOf<SessionStatus?>(null)
        private set
    var picture by mutableStateOf<ImageBitmap?>(null)
        private set
    var playhead by mutableLongStateOf(0L)
        private set
    var playing by mutableStateOf(false)
        private set
    var panel by mutableStateOf<Panel?>(null)
    var submenu by mutableStateOf(Submenu.None)
    /** Timeline zoom; 0 until the timeline knows its width. */
    var pxPerSecond by mutableFloatStateOf(0f)
    /** The player's height (px) when the user has resized it, else 0 (55 % of the room). */
    var playerHeight by mutableFloatStateOf(0f)
    /** The player's height (px) last laid out without a panel: kept while one is open. */
    var basePlayerPx = 0f
    /** The side-by-side layout's player width fraction. */
    var sideFraction by mutableFloatStateOf(0f)
    /** Busy with something the user waits for (importing media). */
    var busy by mutableStateOf<String?>(null)
        private set
    /** Text being typed for a new text clip (shown on the preview until it is added). */
    var typing by mutableStateOf("")
    /** A clip is being dragged or trimmed: tools wait. */
    var gesture by mutableStateOf(false)
    /** When enabled, tapping timeline clips adds/removes them from the engine selection. */
    var multiSelectMode by mutableStateOf(false)
    var multiSelectedClipIds by mutableStateOf<Set<ULong>>(emptySet())
    /** Parent sequence IDs for nested-composition navigation. */
    private val sequenceParents = ArrayDeque<ULong>()
    /** The composition (sequence item) and the clip that plays it, for each composition being edited. */
    private val nestedEdits = ArrayDeque<Pair<ULong, ULong?>>()
    /** Asked when "Accept" would change compositions that other clips (copies, cut pieces) also play. */
    var syncPrompt by mutableStateOf<SyncPrompt?>(null)
        private set

    class SyncPrompt(val item: ULong, val clip: ULong, val others: Int)
    var canReturnToParent by mutableStateOf(false)
        private set
    /** Prevent overlapping open/accept requests from corrupting the nested-sequence stack. */
    var nestedNavigationBusy by mutableStateOf(false)
        private set
    /**
     * Composition ("Nido") operations are switched off for now: grouping clips, opening a composition
     * and accepting its changes could break the editor. Their UI stays visible but inactive.
     */
    val nestOperationsEnabled: Boolean = false

    /**
     * Compositions are on: grouping the chosen clips into one, opening it with a double tap to edit
     * its clips, and "Accept changes" to save it and return. (What the project notes call "Nido".)
     * Switching this off puts the editor back as it was without them.
     */
    val compositionsEnabled: Boolean = true

    /**
     * Choosing several clips on V2 and above and moving them together is on. It is independent of
     * the composition switch above, which stays off.
     */
    val multiSelectEnabled: Boolean = true

    val media = MediaCache(engine, scope)
    private var renderer: Renderer? = null
    /** Sequence identity used to invalidate the preview renderer when nesting changes. */
    private var rendererSequenceId: ULong? = null
    private val player = Player()
    private var playJob: Job? = null
    private var saveJob: Job? = null
    private var lastSaved = -1L
    /** The revision cache is scoped to a sequence: nested sequences may share revision numbers. */
    private var lastSavedSequenceId: ULong? = null
    /** Stable identity of the project's root sequence; nested edits must not replace its metadata. */
    private var mainSequenceId: ULong? = null

    /** The preview's longest side in pixels (set by the preview from its size). */
    var previewSide = 1080
        set(v) {
            // Keep the preview sharp on high-density phones while bounding memory use.
            // Export rendering remains independent and uses the sequence output resolution.
            field = v.coerceIn(160, 1920)
        }

    private data class FrameRequest(val time: Long, val draft: Boolean, val seq: Long)
    private val frameRequests = MutableStateFlow<FrameRequest?>(null)
    private var requestSeq = 0L
    /** Bumped whenever in-flight preview frames must be discarded (sequence switch). */
    private var previewEpoch = 0L
    private val bitmaps = arrayOfNulls<Bitmap>(2)
    private var nextBitmap = 0

    init {
        scope.launch { renderFrames() }
    }

    // ---- reading ----

    val rateNum: Long get() = timeline?.rateNum ?: 30L
    val rateDen: Long get() = timeline?.rateDen ?: 1L
    val duration: Long get() = timeline?.duration ?: 0L
    val frameTicks: Long get() = TimelineMath.tickOfFrame(1, rateNum, rateDen)

    val selectedClip: ClipInfo?
        get() {
            val id = timeline?.selected ?: return null
            return timeline?.lanes?.firstNotNullOfOrNull { l -> l.clips.firstOrNull { it.id == id } }
        }

    /** Several clips are chosen (multi-select): the clip tools then apply to every one of them. */
    val multiTools: Boolean get() = multiSelectMode && multiSelectedClipIds.size >= 2

    /** The chosen clips, in timeline order. */
    val chosenClips: List<ClipInfo>
        get() = timeline?.lanes?.flatMap { it.clips }?.filter { it.id in multiSelectedClipIds }.orEmpty().sortedBy { it.start }

    /** The clip a tool panel reads its current value from: the selected clip, or the first chosen one. */
    val toolClip: ClipInfo? get() = if (multiTools) chosenClips.firstOrNull() else selectedClip

    /** The selected caption (picked here, not in the engine: captions aren't clips). */
    var selectedCaption by mutableStateOf<ULong?>(null)

    val selectedCaptionInfo: CaptionInfo?
        get() {
            val id = selectedCaption ?: return null
            return timeline?.captions?.firstOrNull { it.id == id }
        }

    val selectedTransition: TransitionInfo?
        get() {
            val id = timeline?.selectedTransition ?: return null
            return timeline?.transitions?.firstOrNull { it.id == id }
        }

    fun laneOf(clip: ULong): io.github.artcraftandroid.filmcraft.core.LaneInfo? = timeline?.lanes?.firstOrNull { l -> l.clips.any { it.id == clip } }

    fun isMain(clip: ULong): Boolean = laneOf(clip)?.kind == LaneKind.MAIN

    val mainClips: List<ClipInfo> get() = timeline?.lanes?.firstOrNull { it.kind == LaneKind.MAIN }?.clips.orEmpty()

    // ---- loading and saving ----

    /** Open the project: load or create its engine project, then show it. */
    suspend fun load(fresh: Boolean) {
        // Register project-local fonts before opening the project so text clips can
        // resolve their families immediately. Global fonts are still registered at app start.
        project.fontsDir.listFiles()?.filter { it.isFile && it.extension.lowercase() in setOf("ttf", "otf") }?.forEach { font ->
            runCatching { engine.command { addCustomFontData(font.readBytes()) } }
        }
        val t = engine.command {
            if (fresh || !project.projectFile.isFile) newProject(project.name, project.width.toUInt(), project.height.toUInt(), 30u)
            else openProject(project.projectFile.absolutePath)
        }
        timeline = t
        mainSequenceId = engine.command { sequenceInfo().id.toULong() }
        sequenceParents.clear()
        nestedEdits.clear()
        syncPrompt = null
        canReturnToParent = false
        lastSaved = -1L
        lastSavedSequenceId = null
        playhead = t.playhead
        refreshStatus()
        newRenderer()
        // A fresh project is considered saved only if the engine and project listing
        // were both written successfully. Do not pre-mark its revision here: save()
        // owns the cache update after the complete save path succeeds.
        if (fresh) save() else {
            lastSaved = t.revision.toLong()
            lastSavedSequenceId = mainSequenceId
        }
        requestFrame(playhead, draft = false)
    }

    private suspend fun refreshStatus() {
        status = engine.command { poll() }
    }

    private suspend fun newRenderer() {
        // Read the active sequence identity alongside renderer creation. A nested sequence
        // can have the same edit revision as its parent, so revision alone is not a valid key.
        val created = runCatching {
            engine.command {
                val sequenceId = sequenceInfo().id.toULong()
                sequenceId to renderer()
            }
        }.getOrNull() ?: return
        renderer = created.second
        rendererSequenceId = created.first
        media.renderer = created.second
    }

    /** Re-read the timeline and sequence identity as one serialized engine operation. */
    suspend fun refresh() {
        // The engine's Renderer is a snapshot of the project taken when it was created (it knows
        // its revision). After an import or any edit it still shows the OLD project, which drew an
        // empty (black) picture and played nothing until the project was reopened. So renew it
        // whenever the sequence OR the edit revision no longer matches.
        val previous = renderer
        val snapshot = runCatching {
            engine.command {
                val currentTimeline = timeline()
                val sequenceId = sequenceInfo().id.toULong()
                val stale = previous == null ||
                    sequenceId != rendererSequenceId ||
                    previous.revision() != currentTimeline.revision
                val replacementRenderer = if (stale) renderer() else null
                Triple(currentTimeline, sequenceId, replacementRenderer)
            }
        }.getOrNull() ?: return
        val (t, activeSequenceId, replacementRenderer) = snapshot
        val changed = t.revision != timeline?.revision
        val sequenceChanged = activeSequenceId != rendererSequenceId
        if (sequenceChanged) invalidatePendingPreview()
        timeline = t
        // an edit that shortens the video past the playhead brings it back to the end
        playhead = if (t.playhead > t.duration) engine.command { setPlayhead(t.duration) } else t.playhead
        if (replacementRenderer != null) {
            renderer = replacementRenderer
            rendererSequenceId = activeSequenceId
            media.renderer = replacementRenderer
        }
        refreshStatus()
        if (changed) scheduleSave()
        requestFrame(playhead, draft = false)
    }

    private fun scheduleSave() {
        saveJob?.cancel()
        saveJob = scope.launch {
            delay(400)
            save()
        }
    }

    /** Save the project file and its listing now. The timeline snapshot, active sequence
     * identity and save operation are captured together on the serialized engine dispatcher. */
    suspend fun save(): Boolean {
        if (timeline == null) return false
        val path = project.projectFile.absolutePath
        data class SavedState(val sequenceId: ULong, val snapshot: TimelineInfo, val wasAlreadySaved: Boolean)
        val saved = runCatching {
            engine.command {
                val snapshot = timeline()
                val sequenceId = sequenceInfo().id.toULong()
                val alreadySaved = snapshot.revision.toLong() == lastSaved && sequenceId == lastSavedSequenceId
                if (!alreadySaved) saveProject(path)
                SavedState(sequenceId, snapshot, alreadySaved)
            }
        }.onFailure { host.tell(it.userMessage) }.getOrElse { return false }

        if (saved.wasAlreadySaved) return true
        return runCatching {
            // Nested sequences are part of the editable project, but must not replace the
            // root project's Home-card metadata or poster.
            if (saved.sequenceId == mainSequenceId) {
                val t = saved.snapshot
                val p = project.copy(duration = t.duration, width = t.width.toInt(), height = t.height.toInt(), opened = System.currentTimeMillis())
                withContext(Dispatchers.IO) { projects.write(p) }
                project = p
                val now = System.currentTimeMillis()
                if (now - lastPoster > 20_000 || !p.poster.isFile) {
                    lastPoster = now
                    savePoster()
                }
            }
            // Update the deduplication cache only after the full save path succeeds. If
            // writing project metadata fails, the next save must retry instead of treating
            // this revision as already saved. Sequence identity remains part of the key.
            lastSaved = saved.snapshot.revision.toLong()
            lastSavedSequenceId = saved.sequenceId
            true
        }.getOrElse {
            host.tell(it.userMessage)
            false
        }
    }

    /** Export the current editable project as a portable .filmcraft package. */
    fun exportProjectPackage(output: java.io.OutputStream) {
        scope.launch {
            runCatching {
                check(save()) { "Could not save the project before exporting." }
                withContext(Dispatchers.IO) { projects.exportPackage(project, output) }
            }.onSuccess { host.tell("FilmCraft project exported successfully.") }
                .onFailure { host.tell(it.userMessage) }
        }
    }

    /** Import a package as a separate project; it can be opened from the Home screen. */
    fun importProjectPackage(input: java.io.InputStream) {
        scope.launch {
            runCatching { withContext(Dispatchers.IO) { projects.importPackage(input) } }
                .onSuccess { host.tell("Project imported. Open it from the Projects screen.") }
                .onFailure { host.tell(it.userMessage) }
        }
    }

    private var lastPoster = 0L

    /** The first frame, small, for the project's card on Home. Never render a nested
     * sequence as the project's poster, even if close/save happens while a composition is open. */
    private suspend fun savePoster() {
        val rootId = mainSequenceId ?: return
        val rootRenderer = runCatching {
            engine.command {
                val activeId = sequenceInfo().id.toULong()
                if (activeId == rootId && rendererSequenceId == activeId) renderer else null
            }
        }.getOrNull() ?: return
        val bmp = withContext(engine.thumbnails) {
            runCatching { rootRenderer.frame(0, 360u, false, null).intoBitmap(null) }.getOrNull()
        } ?: return
        withContext(Dispatchers.IO) { projects.savePoster(project, bmp) }
    }

    /** Save and make the poster for Home (the first frame). */
    suspend fun close() {
        stop()
        captionJob?.let { job -> runCatching { engine.command { cancelCaptions(job) } } }
        saveJob?.cancel()
        save()
        savePoster()
        media.release()
        // the natural voices' model and export buffers aren't needed on Home
        withContext(Dispatchers.IO) { runCatching { io.github.artcraftandroid.filmcraft.core.trimMemory() } }
    }

    // ---- editing ----

    /**
     * Run an edit on the engine's command thread; then show the result. Playback stops first.
     * Errors become a message.
     */
    fun edit(block: MobileSession.() -> Unit) {
        stop()
        scope.launch {
            try {
                engine.command { block() }
            } catch (e: Exception) {
                host.tell(e.userMessage)
            }
            refresh()
        }
    }

    /** An edit that runs in the background without stopping playback or saving (slider drags). */
    fun quickEdit(block: MobileSession.() -> Unit) {
        scope.launch {
            try {
                engine.command { block() }
            } catch (e: Exception) {
                host.tell(e.userMessage)
            }
            refresh()
        }
    }

    fun undo() = edit { undo() }
    fun redo() = edit { redo() }

    /** Toggle multi-selection mode for choosing several timeline clips. Keep the UI and
     * engine selections in sync so a previous single selection cannot leak into a nest. */
    fun toggleMultiSelectMode() {
        if (!multiSelectEnabled) return
        multiSelectMode = !multiSelectMode
        multiSelectedClipIds = emptySet()
        selectedCaption = null
        submenu = Submenu.None
        if (panel !is Panel.TextInput) panel = null
        edit {
            execute("timeline.select", """{"clips": []}""")
        }
        if (multiSelectMode) {
            host.tell("Multi-select on. Tap clips: hold one on V2 or above to move them together, or use the file menu to create a composition.")
        }
    }

    /** Add or remove one clip from the engine's multi-selection. */
    fun toggleClipSelection(clip: ULong) {
        submenu = Submenu.None
        selectedCaption = null
        if (panel !is Panel.TextInput) panel = null
        multiSelectedClipIds = if (clip in multiSelectedClipIds) multiSelectedClipIds - clip else multiSelectedClipIds + clip
        edit {
            execute("timeline.select", """{"clips":[${clip}],"toggle":true,"linked":false}""")
        }
    }

    /**
     * Move the chosen overlay clips together by [laneDelta] lanes and [timeDelta] ticks. The engine
     * keeps their distances, moves them up to free lanes when the target is taken, and treats the
     * whole move as one undo step.
     */
    fun moveGroup(ids: Collection<ULong>, laneDelta: Int, timeDelta: Long) {
        if (ids.isEmpty() || (laneDelta == 0 && timeDelta == 0L)) return
        // moving V1 clips (or sounds) together is not available yet: only clips on V2 and above
        val overlay = timeline?.lanes?.filter { it.kind == LaneKind.OVERLAY }?.flatMap { l -> l.clips.map { it.id } }?.toSet().orEmpty()
        if (!overlay.containsAll(ids)) {
            host.tell("Clips can be moved together on V2 and above for now.")
            return
        }
        edit { moveClips(ids.toList(), laneDelta, timeDelta) }
    }

    /** Group exactly the clips highlighted by multi-select into one editable composition. */
    fun createComposition() {
        if (!compositionsEnabled) {
            host.tell("Compositions are temporarily disabled.")
            return
        }
        if (nestedNavigationBusy) return
        val selected = multiSelectedClipIds.toList()
        if (!multiSelectMode || selected.size < 2) {
            host.tell("Select at least two clips before creating a composition.")
            return
        }
        stop()
        scope.launch {
            try {
                // the exact set the interface shows is what is grouped; the engine does all of it as one undo step
                engine.command { createComposition(selected, "Composition") }
                multiSelectMode = false
                multiSelectedClipIds = emptySet()
                refresh()
                host.tell("Composition created. Double-tap its clip to edit the contents.")
            } catch (e: Exception) {
                // a failed grouping changes nothing and the chosen clips stay chosen
                host.tell(e.userMessage)
                refresh()
            }
        }
    }

    /** Invalidate in-flight frames before a sequence switch can publish an old preview. */
    private fun invalidatePendingPreview() {
        previewEpoch++
        requestSeq++
        frameRequests.value = null
    }

    /** Open a nested sequence played by a timeline clip. */
    fun openNestedComposition(item: ULong, clip: ULong? = null) {
        if (!compositionsEnabled) return
        if (nestedNavigationBusy) return
        nestedNavigationBusy = true
        stop()
        // Do not let a delayed save from the parent race with the sequence switch.
        saveJob?.cancel()
        scope.launch {
            try {
                val parent = engine.command { sequenceInfo().id.toULong() }
                engine.command {
                    execute("sequence.open", """{"item":$item}""")
                    // how it looks now, so a change meant for this clip alone can leave the others as they were
                    beginCompositionEdit(item)
                }
                invalidatePendingPreview()
                sequenceParents.addLast(parent)
                nestedEdits.addLast(item to clip)
                canReturnToParent = sequenceParents.isNotEmpty()
                refresh()
                host.tell("Composition opened. Edit its clips, then return to the parent sequence.")
            } catch (e: Exception) {
                host.tell("This clip is not an editable nested composition: ${e.userMessage}")
            } finally {
                nestedNavigationBusy = false
            }
        }
    }

    /**
     * Accept the composition's changes. When other clips play the same composition (a duplicate, a
     * piece of a cut) the person is asked first whether the change goes to all of them or only to
     * this one; a composition that is alone is accepted without asking.
     */
    fun acceptNestedChanges() {
        if (!compositionsEnabled) return
        if (nestedNavigationBusy || syncPrompt != null) return
        if (sequenceParents.isEmpty()) return
        val (item, clip) = nestedEdits.lastOrNull() ?: return completeAccept()
        if (clip == null) return completeAccept()
        nestedNavigationBusy = true
        scope.launch {
            val others = runCatching { engine.command { compositionLinks(item) } }.getOrDefault(0u)
            nestedNavigationBusy = false
            if (others > 0u) {
                syncPrompt = SyncPrompt(item, clip, others.toInt())
            } else {
                // alone: nothing to ask; the engine only forgets how it looked before
                runCatching { engine.command { endCompositionEdit(item, clip, true) } }
                completeAccept()
            }
        }
    }

    /** The answer to the question above: [applyToAll] linked compositions, or only this one (kept apart for good). */
    fun resolveSyncPrompt(applyToAll: Boolean) {
        val p = syncPrompt ?: return
        syncPrompt = null
        nestedNavigationBusy = true
        scope.launch {
            try {
                engine.command { endCompositionEdit(p.item, p.clip, applyToAll) }
            } catch (e: Exception) {
                host.tell(e.userMessage)
                nestedNavigationBusy = false
                return@launch
            }
            nestedNavigationBusy = false
            completeAccept()
        }
    }

    /** Close the question and go on editing the composition. */
    fun cancelSyncPrompt() {
        syncPrompt = null
    }

    /** Save the active nested sequence and return to its parent. */
    private fun completeAccept() {
        if (nestedNavigationBusy) return
        val parent = sequenceParents.lastOrNull() ?: return
        nestedNavigationBusy = true
        stop()
        // The explicit save below owns this transition; discard any pending debounce.
        saveJob?.cancel()
        scope.launch {
            try {
                check(save()) { "Could not save this composition. Your changes have not been discarded." }
                // back in the parent, its compositions play the sound of what was just edited
                engine.command {
                    execute("sequence.open", """{"item":$parent}""")
                    restoreCompositionSound()
                }
                invalidatePendingPreview()
                sequenceParents.removeLast()
                nestedEdits.removeLastOrNull()
                canReturnToParent = sequenceParents.isNotEmpty()
                refresh()
                host.tell("Changes saved. Returned to the parent composition.")
            } catch (e: Exception) {
                host.tell(e.userMessage)
            } finally {
                nestedNavigationBusy = false
            }
        }
    }

    fun select(clip: ULong?) {
        submenu = Submenu.None
        if (panel !is Panel.TextInput) panel = null
        selectedCaption = null
        quickEdit { select(clip) }
    }

    fun selectCaption(id: ULong) {
        submenu = Submenu.None
        if (panel !is Panel.TextInput && panel != Panel.Captions) panel = null
        selectedCaption = id
        if (timeline?.selected != null || timeline?.selectedTransition != null) quickEdit { select(null) }
    }

    fun selectTransition(t: TransitionInfo) {
        submenu = Submenu.None
        quickEdit { selectTransition(t.id) }
    }

    // ---- playhead and playback ----

    /** Move the playhead (the timeline scrolls under it); [draft] while the finger moves. */
    fun seek(t: Long, draft: Boolean = true) {
        if (playing) stop()
        val c = t.coerceIn(0L, duration.coerceAtLeast(0L))
        playhead = c
        requestFrame(c, draft)
        scope.launch { engine.command { setPlayhead(c) } }
    }

    /** The finger left the timeline: draw the frame at full quality. */
    fun settle() {
        requestFrame(playhead, draft = false)
    }

    fun step(frames: Int) {
        val f = TimelineMath.frames(playhead, rateNum, rateDen) + frames
        seek(TimelineMath.tickOfFrame(f.coerceAtLeast(0), rateNum, rateDen), draft = false)
    }

    fun togglePlay() = if (playing) stop() else play()

    fun play() {
        val end = duration
        if (end <= 0) return
        if (playhead >= end - frameTicks) playhead = 0
        playRange(playhead, end, back = null)
    }

    /** Play from [from] to [to], then stop there, or go back to [back] if given. */
    private fun playRange(from: Long, to: Long, back: Long?) {
        val r = renderer ?: return
        stop()
        val end = to.coerceIn(0L, duration)
        val start = from.coerceIn(0L, end)
        if (end - start < frameTicks) return
        playhead = start
        playing = true
        player.start(r, start, end)
        // the UI thread's dispatcher brings the display's frame clock (the view model's scope has none)
        playJob = scope.launch(androidx.compose.ui.platform.AndroidUiDispatcher.Main) {
            while (isActive && playing) {
                withFrameNanos { }
                val t = player.position().coerceAtMost(end)
                playhead = t
                requestFrame(t, draft = true)
                if (t >= end) break
            }
            if (playing) {
                playing = false
                player.stop()
                if (back != null) playhead = back.coerceIn(0L, duration)
                engine.command { setPlayhead(playhead) }
                requestFrame(playhead, draft = false)
            }
        }
    }

    /** Play the transition between [from] and [to], start to end; the playhead stays at its end. */
    private fun previewTransition(from: ULong?, to: ULong?) {
        val tr = timeline?.transitions?.firstOrNull { it.from == from && it.to == to } ?: return
        playRange(tr.start, tr.start + tr.duration, back = null)
    }

    fun stop() {
        if (!playing) return
        playing = false
        playJob?.cancel()
        playJob = null
        player.stop()
        val t = playhead
        scope.launch {
            engine.command { setPlayhead(t) }
            requestFrame(t, draft = false)
        }
    }

    private fun requestFrame(t: Long, draft: Boolean) {
        frameRequests.value = FrameRequest(t, draft, ++requestSeq)
    }

    private suspend fun renderFrames() {
        frameRequests.filterNotNull().collect { req ->
            val r = renderer ?: return@collect
            // Frames are dropped only when the preview was invalidated (sequence/renderer switch),
            // not merely because a newer request exists: during playback a request arrives every
            // display frame, so dropping on "newer request" would discard every slow frame.
            val epoch = previewEpoch
            val side = if (req.draft && playing) (previewSide * 3 / 4).coerceAtLeast(160) else previewSide
            val slot = nextBitmap
            val target = bitmaps[slot]
            // Render AND convert off the main thread (this collector runs on the UI dispatcher).
            val bmp = withContext(engine.preview) {
                runCatching { r.frame(req.time, side.toUInt(), req.draft, null).intoBitmap(target) }
                    .onFailure { android.util.Log.w("FilmCraft", "preview frame at ${req.time} failed: ${it.message}") }
                    .getOrNull()
            } ?: return@collect
            // A frame from the previous sequence may finish after the user has opened
            // another composition. Never let that stale frame replace the current preview.
            if (epoch != previewEpoch || r !== renderer) return@collect
            bitmaps[slot] = bmp
            nextBitmap = 1 - slot
            picture = bmp.asImageBitmap()
            // a draft that is still the newest wish is redrawn properly once things settle
            if (req.draft && !playing && frameRequests.value?.seq == req.seq) {
                delay(120)
                if (frameRequests.value?.seq == req.seq && !playing) requestFrame(req.time, draft = false)
            }
        }
    }

    // ---- adding media ----

    /** Add pictures and videos from the phone's gallery, files, or sounds from files. */
    fun addMedia(kind: PickKind) {
        submenu = Submenu.None
        host.pick(kind) { uris -> if (uris.isNotEmpty()) importAndAdd(uris, audio = kind == PickKind.FilesAudio) }
    }

    /** Add picked media; [first] is a new project's starting media, which can't be undone away. */
    fun importAndAdd(uris: List<Uri>, audio: Boolean, first: Boolean = false, overlayIndex: Int? = null) {
        stop()
        scope.launch {
            busy = "Adding media…"
            try {
                val paths = withContext(Dispatchers.IO) {
                    uris.mapNotNull { u -> runCatching { projects.importUri(project, u).absolutePath }.getOrNull() }
                }
                // A project with nothing in it yet takes the exact size of its first picture or video.
                // One that already has clips is never resized here (only the aspect tool does that).
                val frame = if (!audio && paths.isNotEmpty() && timeline?.lanes?.all { it.clips.isEmpty() } != false) {
                    withContext(Dispatchers.IO) { uris.firstNotNullOfOrNull { projects.mediaFrame(it) } }
                } else null
                if (paths.isEmpty()) {
                    host.tell("That file can't be added.")
                } else {
                    try {
                        engine.command {
                            if (frame != null) fitEmptyFrame(frame.first.toUInt(), frame.second.toUInt())
                            if (audio) addAudio(paths)
                            else if (overlayIndex != null) addMediaToOverlay(paths, overlayIndex.toUInt())
                            else addMedia(paths)
                            if (first) forgetHistory()
                        }
                    } catch (e: Exception) {
                        // The files were copied into the project before the engine accepted them.
                        // Roll them back if adding the clips fails, so the media folder stays clean.
                        withContext(Dispatchers.IO) { projects.rollbackImportedFiles(project, paths) }
                        throw e
                    }
                    if (paths.size < uris.size) host.tell("Some files couldn't be added.")
                }
            } catch (e: Exception) {
                host.tell(e.userMessage)
            } finally {
                busy = null
            }
            refresh()
        }
    }

    fun replaceSelected() {
        val c = selectedClip ?: return
        host.pick(PickKind.ReplaceVisual) { uris ->
            val u = uris.firstOrNull() ?: return@pick
            scope.launch {
                busy = "Replacing…"
                try {
                    val path = withContext(Dispatchers.IO) { projects.importUri(project, u).absolutePath }
                    try {
                        engine.command { replace(c.id, path) }
                    } catch (e: Exception) {
                        withContext(Dispatchers.IO) { projects.rollbackImportedFiles(project, listOf(path)) }
                        throw e
                    }
                } catch (e: Exception) {
                    host.tell(e.userMessage)
                } finally {
                    busy = null
                }
                refresh()
            }
        }
    }

    /** Extract the sound of a video the user picks, onto an audio lane at the playhead. */
    fun extractAudioFromFile() {
        submenu = Submenu.None
        host.pick(PickKind.ExtractAudioVideo) { uris -> if (uris.isNotEmpty()) importAndAdd(uris, audio = true) }
    }

    // ---- clip tools ----

    private inline fun withSelected(block: (ClipInfo) -> Unit) {
        toolClip?.let(block)
    }

    /** Run one tool on every chosen clip as a single undo step (engine `edit_clips`). */
    private fun many(op: String, text: String = "", amount: Double = 0.0, on: Boolean = false, merge: Boolean = false, quick: Boolean = false) {
        val ids = multiSelectedClipIds.toList()
        val block: MobileSession.() -> Unit = { editClips(ids, op, text, amount, on, merge) }
        if (quick) quickEdit(block) else edit(block)
    }

    /** Un-choose every clip (the tool bar goes back to what can be added). */
    fun clearMultiSelection() {
        multiSelectedClipIds = emptySet()
        submenu = Submenu.None
        panel = null
        edit { execute("timeline.select", """{"clips": []}""") }
    }

    fun split() { if (multiTools) many("split") else withSelected { c -> edit { split(c.id) } } }
    fun delete() {
        if (multiTools) {
            panel = null
            submenu = Submenu.None
            many("delete")
            multiSelectedClipIds = emptySet()
        } else withSelected { c -> panel = null; submenu = Submenu.None; edit { deleteClip(c.id) } }
    }
    fun duplicate() { if (multiTools) many("duplicate") else withSelected { c -> edit { duplicate(c.id) } } }
    fun freeze() = withSelected { c -> submenu = Submenu.None; edit { freeze(c.id) } }
    fun extractAudio() = withSelected { c -> submenu = Submenu.None; edit { extractAudio(c.id) } }
    fun toggleMirror() {
        if (multiTools) many("mirror", on = !chosenClips.filter { clipKindHasPicture(it) }.all { it.mirrored })
        else withSelected { c -> edit { setFlip(c.id, true, !c.mirrored) } }
    }
    fun toggleFlip() {
        if (multiTools) many("flip", on = !chosenClips.filter { clipKindHasPicture(it) }.all { it.flipped })
        else withSelected { c -> edit { setFlip(c.id, false, !c.flipped) } }
    }
    fun addBlank() = edit { addBlank() }

    fun setSpeed(speed: Double, done: Boolean) {
        if (multiTools) { if (done) many("speed", amount = speed) }
        else withSelected { c -> if (done) edit { setSpeed(c.id, speed) } }
    }

    fun setVolume(v: Double) {
        if (multiTools) many("volume", amount = v, merge = true, quick = true)
        else withSelected { c -> quickEdit { setVolume(c.id, v, true) } }
    }
    fun setMuted(m: Boolean) {
        if (multiTools) many("mute", on = m) else withSelected { c -> edit { setMuted(c.id, m) } }
    }
    fun setFades(fadeIn: Long, fadeOut: Long) = withSelected { c -> edit { setFades(c.id, fadeIn, fadeOut) } }
    fun setOpacity(v: Double, all: Boolean = false) {
        if (multiTools && !all) many("opacity", amount = v, merge = true, quick = true)
        else withSelected { c -> quickEdit { setOpacity(c.id, v, !all, all) } }
    }
    fun setFilter(id: String, amount: Double, merge: Boolean, all: Boolean = false) {
        if (multiTools && !all) many("filter", text = id, amount = amount, merge = merge, quick = true)
        else withSelected { c -> quickEdit { setFilter(c.id, id, amount, merge, all) } }
    }
    fun setEffect(id: String, amount: Double, merge: Boolean, all: Boolean = false) {
        if (multiTools && !all) many("effect", text = id, amount = amount, merge = merge, quick = true)
        else withSelected { c -> quickEdit { setEffect(c.id, id, amount, merge, all) } }
    }

    /** Put a transition on a cut (none for a blank [preset]) and play it. */
    fun setTransition(from: ULong?, to: ULong?, preset: String, seconds: Double, all: Boolean = false) {
        stop()
        scope.launch {
            try {
                engine.command { setTransition(from, to, preset, seconds, all) }
            } catch (e: Exception) {
                host.tell(e.userMessage)
            }
            refresh()
            if (preset.isNotEmpty()) previewTransition(from, to)
        }
    }

    fun setTransitionDuration(id: ULong, seconds: Double) {
        stop()
        scope.launch {
            try {
                engine.command { setTransitionDuration(id, seconds) }
            } catch (e: Exception) {
                host.tell(e.userMessage)
            }
            refresh()
            val tr = timeline?.transitions?.firstOrNull { it.id == id } ?: return@launch
            previewTransition(tr.from, tr.to)
        }
    }

    suspend fun maxTransition(from: ULong?, to: ULong?): Double = runCatching { engine.command { maxTransition(from, to) } }.getOrDefault(5.0)

    fun trim(clip: ULong, head: Boolean, delta: Long) = edit { trim(clip, head, delta) }

    /** Trim the start or end of a caption on the timeline. */
    fun trimCaption(caption: ULong, head: Boolean, delta: Long) {
        stop()
        scope.launch {
            try {
                engine.command {
                    execute("captions.trim", """{"caption":$caption,"edge":"${if (head) "in" else "out"}","delta":$delta}""")
                }
            } catch (e: Exception) {
                host.tell(e.userMessage)
            }
            refresh()
        }
    }
    fun reorder(clip: ULong, index: Int) = edit { reorder(clip, index.toUInt()) }
    fun move(clip: ULong, lane: Int, start: Long) = edit { moveClip(clip, lane, start) }

    fun setAspect(num: Int, den: Int) = edit { setAspect(num.toUInt(), den.toUInt()) }

    // ---- text ----

    fun addText(text: String) = edit { addText(text) }
    fun setText(clip: ULong, text: String) = edit { setText(clip, text) }

    // Editing an existing text: each keystroke shows on the clip at once; accepting sets the final
    // text in one undo step, cancelling puts the original text, style and position back.
    fun beginTextEdit(clip: ULong) = quickEdit { beginTextEdit(clip) }
    fun previewText(clip: ULong, text: String) = quickEdit { previewText(clip, text) }
    fun cancelTextEdit() = quickEdit { cancelTextEdit() }
    fun finishTextEdit(clip: ULong, text: String) = edit { finishTextEdit(clip, text) }

    suspend fun textStyle(clip: ULong): TextStyle? = runCatching { engine.command { textStyle(clip) } }.getOrNull()

    fun setTextStyle(clip: ULong, style: TextStyle, merge: Boolean, all: Boolean = false) = quickEdit { setTextStyle(clip, style, merge, all) }

    // ---- speech ----

    /** Speech of [st] to hear before adding it (null when it can't be made; the user is told). */
    suspend fun previewSpeech(st: SpeechSettings): SpeechAudio? =
        runCatching { engine.command { previewSpeech(st) } }.onFailure { host.tell(it.userMessage) }.getOrNull()

    suspend fun speechSettings(clip: ULong): SpeechSettings? = runCatching { engine.command { speechSettings(clip) } }.getOrNull()

    /** Add speech at the playhead, or say speech clip [clip] again. */
    fun saySpeech(clip: ULong?, st: SpeechSettings) {
        stop()
        scope.launch {
            busy = "Making speech…"
            try {
                val dir = project.mediaDir.apply { mkdirs() }.absolutePath
                engine.command { if (clip == null) addSpeech(st, dir) else editSpeech(clip, st, dir) }
            } catch (e: Exception) {
                host.tell(e.userMessage)
            } finally {
                busy = null
            }
            refresh()
        }
    }

    // ---- captions ----

    /** Captions being made: how far along (null when nothing is running). */
    var captionProgress by mutableStateOf<CaptionStatus?>(null)
        private set
    private var captionJob: ULong? = null

    /** Make captions from what is said, with speech model [model] in [language] ("auto" detects it). */
    fun makeCaptions(model: String, language: String) {
        if (captionProgress != null) return
        stop()
        captionProgress = CaptionStatus(0.0, "Getting ready…", false, null, 0u)
        scope.launch {
            try {
                val job = engine.command { startCaptions(model, language) }
                captionJob = job
                while (true) {
                    val st = engine.command { captionStatus(job) }
                    captionProgress = st
                    if (st.finished) {
                        when {
                            st.error == "cancelled" -> {}
                            st.error != null -> host.tell(st.error ?: "")
                            st.captions == 0u -> host.tell("No speech was heard, so there are no captions.")
                        }
                        break
                    }
                    delay(300)
                }
            } catch (e: Exception) {
                host.tell(e.userMessage)
            } finally {
                captionJob = null
                captionProgress = null
            }
            refresh()
        }
    }

    fun cancelCaptions() {
        val job = captionJob ?: return
        scope.launch { runCatching { engine.command { cancelCaptions(job) } } }
    }

    suspend fun captionLook(): CaptionLook? = runCatching { engine.command { captionLook() } }.getOrNull()

    fun setCaptionLook(look: CaptionLook, merge: Boolean) = quickEdit { setCaptionLook(look, merge) }

    fun setCaptionText(id: ULong, text: String) = edit { setCaptionText(id, text) }

    fun deleteCaption(id: ULong) {
        selectedCaption = null
        edit { deleteCaption(id) }
    }

    fun deleteCaptions() {
        selectedCaption = null
        edit { deleteCaptions() }
    }

    // ---- placement on the frame ----

    suspend fun placementOf(clip: ULong): io.github.artcraftandroid.filmcraft.core.Placement? =
        runCatching { engine.command { placement(clip) } }.getOrNull()

    /** Move/scale/turn a clip while a finger does it: one undo step per gesture. */
    fun setPlacement(clip: ULong, p: io.github.artcraftandroid.filmcraft.core.Placement, merge: Boolean) {
        placementJob = scope.launch {
            runCatching { engine.command { setPlacement(clip, p.x, p.y, p.scale, p.rotation, merge) } }
            refreshSoon()
        }
    }

    private var placementJob: Job? = null
    private var refreshJob: Job? = null

    /** Re-read the timeline once things calm down (a gesture sends many edits). */
    private fun refreshSoon() {
        refreshJob?.cancel()
        refreshJob = scope.launch {
            delay(60)
            refresh()
        }
    }

    // ---- voice-over ----

    private var voiceStart = 0L

    fun requestMicrophone(onGranted: () -> Unit) = host.requestMicrophone(onGranted)

    fun tellUser(message: String) = host.tell(message)

    /** A recorder for a new take at the playhead, writing "Voiceover N.wav" into the project. */
    fun newVoiceRecorder(): VoiceRecorder? {
        stop()
        voiceStart = playhead
        val dir = project.mediaDir.apply { mkdirs() }
        var n = 1
        while (java.io.File(dir, "Voiceover $n.wav").exists()) n++
        return VoiceRecorder(java.io.File(dir, "Voiceover $n.wav"))
    }

    /** Put a finished take on an audio lane where it started. */
    fun finishVoiceover(r: VoiceRecorder, onAdded: (ULong) -> Unit) {
        val path = r.file.absolutePath
        val at = voiceStart
        scope.launch {
            try {
                if (r.frames < r.rate / 10) {
                    java.io.File(path).delete()
                } else {
                    val ids = engine.command {
                        setPlayhead(at)
                        addAudio(listOf(path))
                    }
                    ids.firstOrNull()?.let(onAdded)
                }
            } catch (e: Exception) {
                host.tell(e.userMessage)
            }
            refresh()
        }
    }

    fun discardTakes(ids: List<ULong>) = edit { ids.forEach { runCatching { deleteClip(it) } } }

    fun closeEditor() = host.close()

    // ---- export ----

    fun export() {
        stop()
        // inside a composition the open sequence is only part of the project
        if (canReturnToParent) {
            host.tell("Accept the composition's changes first, then export the project.")
            return
        }
        val d = duration
        if (d < frameTicks * 5) {
            host.tell("Add at least a few frames to the timeline to export.")
            return
        }
        host.export()
    }

    fun clipKindHasPicture(c: ClipInfo) = c.kind != ClipKind.AUDIO && c.kind != ClipKind.TEXT
}
