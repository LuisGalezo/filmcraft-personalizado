# Seven Cut Pro r37 — reducción de asignaciones en MediaCodec

## Cambio aplicado
- `MediaCodecH264.Session` conserva dos buffers temporales para las filas de las dos superficies cromáticas U/V.
- `fillImage` reutiliza esos buffers al copiar planos flexibles YUV 4:2:0 cuando `pixelStride > 1`.
- `copyPlane` acepta un buffer temporal reutilizable opcional y mantiene el comportamiento anterior para llamadas existentes.
- No se cambió la conversión de color, el orden Y/U/V, los strides, los timestamps, el bitrate, el perfil H.264 ni el flujo de fallback.

## Alcance y límites
Este cambio elimina asignaciones temporales repetidas de los planos cromáticos durante la entrada a MediaCodec. Es una optimización de memoria/GC pequeña y segura en alcance; **no está demostrado que reduzca de forma apreciable los más de 60 segundos de exportación**.

Los siguientes costes siguen presentes y requieren una intervención mayor: decodificación CPU, conversión RGBA→YUV CPU, copia del `Vec<u8>` al cruzar UniFFI y copia de los planos al búfer MediaCodec.

## Verificación
- Inspección estática del código y de las llamadas existentes a `copyPlane`.
- No se pudo ejecutar Gradle, Kotlin compiler, Cargo ni Android SDK en este entorno. No se declara compilación ni prueba en dispositivo.
- Antes de integrar en producción: compilar APK, ejecutar pruebas de `copyPlane` para pixelStride 1 y 2/rowStride con padding, y exportar clips de prueba comparando color, duración, FPS y sincronización.
