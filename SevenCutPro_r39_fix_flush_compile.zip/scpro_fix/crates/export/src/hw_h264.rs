//! Hardware H.264 encoding through a backend the host app provides (Android: `MediaCodec`).
//!
//! The engine only knows this small contract ([`H264Backend`] / [`H264Session`]); the app plugs the phone's encoder in with
//! [`set_h264_backend`]. With no backend registered (the desktop, the tests) nothing here is ever used.
//!
//! What this module guarantees, whatever the backend does:
//! - The software encoder (`h264enc`) stays the fallback. The hardware one is used only when the backend says it
//!   supports exactly the requested size, frame rate and bitrate ([`H264Backend::supports`]) and opens
//!   ([`H264Backend::open`]); otherwise the factory declines and the software encoder is built as before. If the hardware
//!   encoder fails in the middle of an export, [`crate::export`] starts that export again with the software encoder.
//! - Nothing is lowered to go faster: the same size and frame rate, and a bitrate at least as high as the quality
//!   asked for needs ([`hardware_bitrate_kbps`]); a size or bitrate the hardware cannot do is not clamped, it is refused.
//! - Samples written to the MP4 are length-prefixed, parameter sets only in the `avcC`; a picture that is lost or out of
//!   order (B-frames are not wanted) is an error, never a damaged file.
//! - Pixels are BT.709 limited-range 4:2:0, the same conversion the software path uses.

use super::encoders::h264_input;
use super::format::{ColorSignal, ExportSettings, Format, H264Pass};
use super::registry::{EncodedPacket, EncoderFrame, PrepareAhead, VideoEncoder};
use super::{BitrateMode, ExportError, FrameRate, HardwareEncoding, Result, SampleEntry, note_hw_encode_declined, note_hw_encode_frame, note_hw_encode_session};
use std::cell::Cell;
use std::sync::{Arc, Mutex, PoisonError, RwLock};

/// What the hardware encoder is asked to do.
#[derive(Clone, Debug, PartialEq)]
pub struct HwConfig {
    pub width: u32,
    pub height: u32,
    pub fps_num: u32,
    pub fps_den: u32,
    /// Average bitrate wanted, in kbit/s.
    pub bitrate_kbps: u32,
    /// Peak bitrate allowed, in kbit/s.
    pub max_bitrate_kbps: u32,
    /// Frames between key frames.
    pub keyint: u32,
}

/// One buffer the hardware encoder produced: an Annex B access unit, or the parameter sets (`config`).
#[derive(Clone, Debug, PartialEq)]
pub struct HwPacket {
    pub data: Vec<u8>,
    pub pts_us: i64,
    pub key: bool,
    pub config: bool,
}

pub trait H264Backend: Send + Sync {
    /// Whether the encoder can do exactly this (size, rate, bitrate, High or Main profile, no B-frames).
    fn supports(&self, cfg: &HwConfig) -> bool;
    fn open(&self, cfg: &HwConfig) -> std::result::Result<Box<dyn H264Session>, String>;
}

pub trait H264Session: Send {
    /// Feed one picture (planar Y, then U, then V; 8 bit; chroma is `ceil(w/2) x ceil(h/2)`); returns what is ready.
    /// The first call does not return before the parameter sets are known.
    fn encode(&mut self, yuv420: &[u8], pts_us: i64) -> std::result::Result<Vec<HwPacket>, String>;
    /// End of stream: everything still inside the encoder.
    fn finish(&mut self) -> std::result::Result<Vec<HwPacket>, String>;
}

static BACKEND: RwLock<Option<Arc<dyn H264Backend>>> = RwLock::new(None);
#[cfg(not(test))]
static STATUS: Mutex<String> = Mutex::new(String::new());

thread_local! {
    /// Set while an export is retried with the software encoder.
    static SOFTWARE_ONLY: Cell<bool> = const { Cell::new(false) };
    /// Tests use their own backend per thread, so tests that run side by side never see each other's.
    #[cfg(test)]
    static TEST_STATUS: std::cell::RefCell<String> = const { std::cell::RefCell::new(String::new()) };
    #[cfg(test)]
    static TEST_BACKEND: std::cell::RefCell<Option<Arc<dyn H264Backend>>> = const { std::cell::RefCell::new(None) };
}

/// Plug the host's hardware H.264 encoder in (`None` takes it out).
pub fn set_h264_backend(b: Option<Arc<dyn H264Backend>>) {
    *BACKEND.write().unwrap_or_else(PoisonError::into_inner) = b;
}

fn backend() -> Option<Arc<dyn H264Backend>> {
    #[cfg(test)]
    {
        TEST_BACKEND.with(|b| b.borrow().clone())
    }
    #[cfg(not(test))]
    {
        BACKEND.read().unwrap_or_else(PoisonError::into_inner).clone()
    }
}

#[cfg(test)]
fn set_test_backend(b: Option<Arc<dyn H264Backend>>) {
    TEST_BACKEND.with(|t| *t.borrow_mut() = b);
}

/// Why the last H.264 export used the encoder it used ("hardware: ...", "software: ...").
pub fn hardware_status() -> String {
    #[cfg(test)]
    {
        TEST_STATUS.with(|s| s.borrow().clone())
    }
    #[cfg(not(test))]
    {
        STATUS.lock().unwrap_or_else(PoisonError::into_inner).clone()
    }
}

fn note(s: impl Into<String>) {
    #[cfg(test)]
    TEST_STATUS.with(|t| *t.borrow_mut() = s.into());
    #[cfg(not(test))]
    {
        *STATUS.lock().unwrap_or_else(PoisonError::into_inner) = s.into();
    }
}

/// Run `f` with the hardware encoder switched off (the software encoder is chosen), on this thread.
pub(crate) fn with_software_only<R>(f: impl FnOnce() -> R) -> R {
    let before = SOFTWARE_ONLY.with(|c| c.replace(true));
    let r = f();
    SOFTWARE_ONLY.with(|c| c.set(before));
    r
}

/// Whether an export error came from the hardware encoder (it is then worth a second try in software).
pub(crate) fn is_hardware_error(e: &ExportError) -> bool {
    matches!(e, ExportError::Encode(m) if m.starts_with(HW_PREFIX))
}

pub(crate) fn note_fallback(why: &str) {
    note(format!("software: the hardware encoder failed ({why}); the export was redone with the software encoder"));
}

const HW_PREFIX: &str = "hardware encoder: ";

fn hw_err(m: impl std::fmt::Display) -> ExportError {
    ExportError::Encode(format!("{HW_PREFIX}{m}"))
}

/// Average bitrate (kbit/s) that gives the quality of x264-style CRF `crf` at this size and rate: 0.30 bits per pixel per
/// frame at CRF 18 ("visually near lossless"), halved for every 6 CRF, which is how the software encoder's own
/// bitrate moves with CRF. Hardware encoders need more bits than the software one for the same look, so this is
/// deliberately above what the old single-pass budgets (0.2 / 0.1 / 0.05) gave. Never below 500.
pub fn hardware_bitrate_kbps(width: u32, height: u32, fps: f64, crf: f64) -> u32 {
    let crf = if crf.is_finite() { crf.clamp(0.0, 51.0) } else { 18.0 };
    let bpp = 0.30 * 2f64.powf((18.0 - crf) / 6.0);
    let kbps = f64::from(width) * f64::from(height) * fps.max(1.0) * bpp / 1000.0;
    kbps.round().clamp(500.0, f64::from(u32::MAX)) as u32
}

/// Annex B byte stream -> NAL units (without start codes).
pub(crate) fn split_annexb(data: &[u8]) -> Vec<&[u8]> {
    let mut starts: Vec<(usize, usize)> = Vec::new();
    let mut i = 0;
    while i + 3 <= data.len() {
        if data[i] == 0 && data[i + 1] == 0 && data[i + 2] == 1 {
            starts.push((i, i + 3));
            i += 3;
        } else {
            i += 1;
        }
    }
    let mut out = Vec::new();
    for (k, &(_, p)) in starts.iter().enumerate() {
        let end = starts.get(k + 1).map_or(data.len(), |&(s, _)| s);
        let mut nal = &data[p..end];
        // zero bytes before the next start code belong to it (the 4-byte form) or are trailing zeros
        while nal.last() == Some(&0) {
            nal = &nal[..nal.len() - 1];
        }
        if !nal.is_empty() {
            out.push(nal);
        }
    }
    out
}

/// The slice data of an access unit as MP4 wants it: 4-byte lengths, no parameter sets, no access unit delimiters.
/// Parameter sets met on the way are handed to `ps` (SPS, PPS).
pub(crate) fn to_length_prefixed(annexb: &[u8], mut ps: impl FnMut(u8, &[u8])) -> Vec<u8> {
    let mut out = Vec::with_capacity(annexb.len() + 16);
    for nal in split_annexb(annexb) {
        match nal[0] & 0x1f {
            t @ (7 | 8) => ps(t, nal),
            9 => {}
            _ => {
                out.extend_from_slice(&(nal.len() as u32).to_be_bytes());
                out.extend_from_slice(nal);
            }
        }
    }
    out
}

/// An `AVCDecoderConfigurationRecord` (ISO 14496-15) for one SPS and one PPS (NAL units with their header byte), 4-byte
/// sample lengths. The High-profile extension (chroma format, bit depths) is added for the profiles that need it: the
/// hardware encoder is only ever asked for 8-bit 4:2:0.
pub(crate) fn build_avcc(sps: &[u8], pps: &[u8]) -> Vec<u8> {
    let mut v = vec![1, sps.get(1).copied().unwrap_or(0), sps.get(2).copied().unwrap_or(0), sps.get(3).copied().unwrap_or(0), 0xFF, 0xE1];
    v.extend_from_slice(&(sps.len() as u16).to_be_bytes());
    v.extend_from_slice(sps);
    v.push(1);
    v.extend_from_slice(&(pps.len() as u16).to_be_bytes());
    v.extend_from_slice(pps);
    if matches!(sps.get(1), Some(100 | 110 | 122 | 144)) {
        v.extend_from_slice(&[0xFC | 1, 0xF8, 0xF8, 0]);
    }
    v
}

struct HwEncoder {
    session: Box<dyn H264Session>,
    w: u32,
    h: u32,
    rate: FrameRate,
    signal: ColorSignal,
    y: Vec<u8>,
    u: Vec<u8>,
    v: Vec<u8>,
    yuv: Vec<u8>,
    /// YUV planes prepared by the render workers while the preceding batch is encoded.
    ready: Arc<Mutex<std::collections::HashMap<u64, (Vec<u8>, Vec<u8>, Vec<u8>)>>>,
    sps: Option<Vec<u8>>,
    pps: Option<Vec<u8>>,
    /// Pictures given to the encoder / access units that came back (in order: B-frames are off).
    fed: u64,
    out: u64,
}

impl HwEncoder {
    fn pts_us(&self, index: u64) -> i64 {
        (i128::from(index) * i128::from(self.rate.den) * 1_000_000 / i128::from(self.rate.num.max(1))) as i64
    }

    fn index_of(&self, pts_us: i64) -> i64 {
        let d = i128::from(self.rate.den.max(1)) * 1_000_000;
        ((i128::from(pts_us) * i128::from(self.rate.num) + d / 2).div_euclid(d)) as i64
    }

    fn convert(&mut self, packets: Vec<HwPacket>) -> Result<Vec<EncodedPacket>> {
        let mut out = Vec::new();
        for p in packets {
            let mut found: Vec<(u8, Vec<u8>)> = Vec::new();
            let data = to_length_prefixed(&p.data, |t, nal| found.push((t, nal.to_vec())));
            for (t, nal) in found {
                let slot = if t == 7 { &mut self.sps } else { &mut self.pps };
                match slot.as_ref() {
                    None => *slot = Some(nal),
                    // the MP4 header holds ONE set: a different one later would make the rest of the file undecodable
                    Some(old) if old != &nal => return Err(hw_err("the encoder changed its parameter sets (SPS/PPS) during the export")),
                    Some(_) => {}
                }
            }
            if p.config || data.is_empty() {
                continue;
            }
            if self.index_of(p.pts_us) != self.out as i64 {
                return Err(hw_err(format!(
                    "picture {} came back as picture {}: the encoder dropped or reordered pictures",
                    self.out,
                    self.index_of(p.pts_us)
                )));
            }
            self.out += 1;
            out.push(EncodedPacket { data, key: p.key, duration: self.rate.den as u32, composition_offset: 0 });
        }
        Ok(out)
    }
}

impl VideoEncoder for HwEncoder {
    fn sample_entry(&self) -> SampleEntry {
        let (sps, pps) = (self.sps.clone().unwrap_or_default(), self.pps.clone().unwrap_or_default());
        // the same route as the software encoder: parse a real avcC record, and only fall back to the plain constructor
        let cfg = filmcraft_isobmff::AvcConfig::parse(&build_avcc(&sps, &pps))
            .unwrap_or_else(|_| filmcraft_isobmff::AvcConfig::new(vec![sps.clone()], vec![pps.clone()], 4));
        let mut e = SampleEntry::avc(cfg, self.w as u16, self.h as u16);
        self.signal.apply_to(&mut e, false);
        e
    }
    fn timescale(&self) -> u32 {
        self.rate.num as u32
    }
    fn encode(&mut self, f: &EncoderFrame) -> Result<Vec<EncodedPacket>> {
        if f.hdr.is_some() || f.width != self.w || f.height != self.h {
            return Err(hw_err("unexpected picture (size or HDR)"));
        }
        if f.index != self.fed {
            return Err(hw_err(format!("picture {} arrived where {} was expected", f.index, self.fed)));
        }
        let prepared = {
            let mut ready = self.ready.lock().unwrap_or_else(PoisonError::into_inner);
            let mine = ready.remove(&f.index);
            // Discard stale entries from batches that were rendered but never encoded.
            ready.retain(|&index, _| index > f.index);
            mine
        };
        if let Some((y, u, v)) = prepared {
            self.y = y;
            self.u = u;
            self.v = v;
        } else {
            // If preparation was unavailable (for example, a direct single-frame call), keep
            // the exact same conversion as the reference software encoder.
            h264_input(f, self.signal, &mut self.y, &mut self.u, &mut self.v);
        }
        self.yuv.clear();
        self.yuv.extend_from_slice(&self.y);
        self.yuv.extend_from_slice(&self.u);
        self.yuv.extend_from_slice(&self.v);
        let pts = self.pts_us(f.index);
        self.fed += 1;
        let packets = self.session.encode(&self.yuv, pts).map_err(hw_err)?;
        note_hw_encode_frame();
        let out = self.convert(packets)?;
        let (Some(sps), Some(_)) = (&self.sps, &self.pps) else {
            return Err(hw_err("the encoder gave no parameter sets (SPS/PPS) with its first picture"));
        };
        // High profile was asked for: an encoder that quietly chose a lower one would give a worse picture for the same bits
        if sps.len() < 4 || sps[1] != 100 {
            return Err(hw_err(format!("the encoder used H.264 profile {} where High (100) was required", sps.get(1).copied().unwrap_or(0))));
        }
        Ok(out)
    }
    fn prepare_ahead(&self) -> Option<PrepareAhead> {
        let (ready, signal) = (self.ready.clone(), self.signal);
        Some(Arc::new(move |f: &EncoderFrame| {
            let (mut y, mut u, mut v) = (Vec::new(), Vec::new(), Vec::new());
            super::stats::timed(super::stats::Stage::Convert, || h264_input(f, signal, &mut y, &mut u, &mut v));
            ready.lock().unwrap_or_else(PoisonError::into_inner).insert(f.index, (y, u, v));
        }))
    }

    fn flush(&mut self) -> Result<Vec<EncodedPacket>> {
        let packets = self.session.finish().map_err(hw_err)?;
        let out = self.convert(packets)?;
        if self.out != self.fed {
            return Err(hw_err(format!("{} pictures went in and {} came out: pictures were lost", self.fed, self.out)));
        }
        Ok(out)
    }
}

/// Registered before the software H.264 factory: hardware when it can do the job exactly, `None` otherwise.
pub(crate) fn hardware_h264_factory(format: Format, w: u32, h: u32, rate: FrameRate, s: &ExportSettings) -> Option<Result<Box<dyn VideoEncoder>>> {
    if format != Format::H264 {
        return None;
    }
    // a request the hardware encoder could not take: counted (`hw_encode_stats().declined`), the software encoder takes it
    let decline = |why: &str| {
        note_hw_encode_declined();
        note(format!("software: {why}"));
        None
    };
    let Some(backend) = backend() else { return None };
    if SOFTWARE_ONLY.with(Cell::get) {
        // the retry after a hardware failure: the status already says why, keep it
        return None;
    }
    if !matches!(s.hardware_encoding, HardwareEncoding::Auto) {
        // the user's choice (Export > Hardware encoding): not a decline, nothing counted
        note("software: hardware encoding is off for this export");
        return None;
    }
    if s.format.is_mxf() || s.signal.is_hdr() || !matches!(s.h264_pass, H264Pass::Single) || s.pixel_aspect.is_some_and(|(n, d)| n != d) {
        return decline("this export needs features only the software encoder has (MXF, HDR, two passes or non-square pixels)");
    }
    if w == 0 || h == 0 || w % 2 != 0 || h % 2 != 0 || rate.num <= 0 || rate.den <= 0 {
        return decline("the picture size or frame rate cannot be encoded in hardware");
    }
    let fps = rate.num as f64 / rate.den as f64;
    let kbps = match s.bitrate_mode {
        BitrateMode::Crf => hardware_bitrate_kbps(w, h, fps, f64::from(s.crf)),
        _ => s.bitrate_kbps.max(100),
    };
    let keyint = s.keyframe_distance.filter(|k| *k > 0).unwrap_or_else(|| (fps * 2.0).round().max(1.0) as u32);
    let cfg = HwConfig {
        width: w,
        height: h,
        fps_num: rate.num as u32,
        fps_den: rate.den as u32,
        bitrate_kbps: kbps,
        max_bitrate_kbps: (u64::from(kbps) * 3 / 2).min(u64::from(u32::MAX)) as u32,
        keyint,
    };
    if !backend.supports(&cfg) {
        return decline(&format!("the phone's hardware encoder does not support {w}x{h} at {fps:.3} fps and {kbps} kbit/s"));
    }
    match backend.open(&cfg) {
        Ok(session) => {
            note_hw_encode_session();
            note(format!("hardware: {w}x{h} at {fps:.3} fps, {kbps} kbit/s"));
            Some(Ok(Box::new(HwEncoder {
                session,
                w,
                h,
                rate,
                signal: s.signal,
                y: Vec::new(),
                u: Vec::new(),
                v: Vec::new(),
                yuv: Vec::new(),
                ready: Arc::new(Mutex::new(std::collections::HashMap::new())),
                sps: None,
                pps: None,
                fed: 0,
                out: 0,
            })))
        }
        Err(e) => decline(&format!("the hardware encoder could not be opened ({e})")),
    }
}

#[cfg(test)]
#[path = "hw_h264_tests.rs"]
mod tests;
