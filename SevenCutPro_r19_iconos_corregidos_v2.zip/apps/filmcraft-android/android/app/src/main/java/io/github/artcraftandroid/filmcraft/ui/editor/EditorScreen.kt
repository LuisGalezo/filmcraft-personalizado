package io.github.artcraftandroid.filmcraft.ui.editor

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.expandVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.offset
import io.github.artcraftandroid.filmcraft.ui.GlyphIcon
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateCentroid
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateRotation
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsBottomHeight
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.displayCutout
import androidx.compose.foundation.layout.union
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import io.github.artcraftandroid.filmcraft.core.ClipKind
import io.github.artcraftandroid.filmcraft.core.Placement
import io.github.artcraftandroid.filmcraft.ui.Fc
import io.github.artcraftandroid.filmcraft.ui.FcDialog
import io.github.artcraftandroid.filmcraft.ui.FcIconButton
import io.github.artcraftandroid.filmcraft.ui.FcSize
import io.github.artcraftandroid.filmcraft.ui.FcType
import io.github.artcraftandroid.filmcraft.ui.Glyphs
import io.github.artcraftandroid.filmcraft.ui.LucideIcons
import io.github.artcraftandroid.filmcraft.ui.glyph
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlinx.coroutines.launch

/** The editor: preview, transport, timeline and tools, stacked or side by side. */
@Composable
fun EditorScreen(ed: EditorController) {
    BackHandler {
        when {
            ed.panel != null -> ed.panel = null
            ed.submenu != Submenu.None -> ed.submenu = Submenu.None
            ed.multiTools -> ed.clearMultiSelection()
            ed.selectedClip != null || ed.selectedTransition != null || ed.selectedCaption != null -> ed.select(null)
            else -> ed.closeEditor()
        }
    }
    BoxWithConstraints(
        Modifier
            .fillMaxSize()
            .background(Fc.Black)
            .windowInsetsPadding(WindowInsets.displayCutout.union(WindowInsets.navigationBars).only(WindowInsetsSides.Horizontal))
            .testTag("screen_editor"),
    ) {
        if (maxWidth >= 600.dp && maxWidth > maxHeight) SideBySide(ed) else Stacked(ed)
        ed.busy?.let { BusyOverlay(it) }
        if (ed.projectPickerOpen) ProjectPickerDialog(ed)
        ed.ungroupPrompt?.let { p ->
            val dontAsk = remember(p) { mutableStateOf(false) }
            FcDialog(
                title = "Some transitions may be lost",
                confirm = "Continue",
                onConfirm = { ed.confirmUngroup(dontAsk.value) },
                onDismiss = { ed.cancelUngroup() },
            ) {
                Text(
                    "Taking this composition apart puts its clips back on separate tracks, so " +
                        "${if (p.transitions > 1) "${p.transitions} of its transitions" else "one of its transitions"} " +
                        "cannot be kept (including any on the composition's own edges). Every clip and the other elements keep their positions.",
                    style = FcType.Body,
                    color = Fc.Body,
                )
                Row(
                    Modifier.fillMaxWidth().clickable { dontAsk.value = !dontAsk.value }.padding(top = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Checkbox(checked = dontAsk.value, onCheckedChange = { dontAsk.value = it })
                    Text("Don't ask again", style = FcType.Body, color = Fc.Body)
                }
            }
        }
        ed.syncPrompt?.let { p ->
            FcDialog(
                title = "Linked compositions",
                confirm = "All linked",
                onConfirm = { ed.resolveSyncPrompt(true) },
                onDismiss = { ed.resolveSyncPrompt(false) },
                dismiss = "Only this one",
                onDismissRequest = { ed.cancelSyncPrompt() },
            ) {
                val many = p.others > 1
                Text(
                    "${p.others} other composition${if (many) "s" else ""} ${if (many) "are" else "is"} linked to this one (a copy or a piece of a cut). " +
                        "Apply your changes to all of them, or only to this one? Only this one becomes independent for good.",
                    style = FcType.Body,
                    color = Fc.Body,
                )
            }
        }
    }
}

@Composable
private fun BusyOverlay(text: String) {
    Box(Modifier.fillMaxSize().background(Fc.Scrim).clickable(enabled = true, onClick = {}), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            CircularProgressIndicator(color = Fc.Accent)
            Spacer(Modifier.height(16.dp))
            Text(text, style = FcType.Body, color = Fc.Title)
        }
    }
}

@Composable
private fun Stacked(ed: EditorController) {
    val density = LocalDensity.current
    val panel = ed.panel
    val textInput = panel as? Panel.TextInput
    val showPanel = panel != null && textInput == null
    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        AnimatedVisibility(panel == null || panel == Panel.KeyInterp, enter = expandVertically(tween(300)) + fadeIn(tween(300)), exit = shrinkVertically(tween(300)) + fadeOut(tween(300))) {
            TopBar(ed, sideBySide = false)
        }
        BoxWithConstraints(Modifier.weight(1f).fillMaxWidth().clipToBounds()) {
            val room = maxHeight
            val minPlayer = 100.dp
            // at least the ruler, both black margins and the whole main track (V1), so V1 is never
            // cut however far the player is enlarged; the panel needs a little more
            val minTimelineFloor = FcSize.Ruler + FcSize.RulerGap + FcSize.TimelineEdge * 2 + FcSize.MainTrack
            // the curves panel is short and keeps the top bar, so the timeline alone gives way for it and the
            // transport row stays where it is
            val minTimeline = if (showPanel && panel != Panel.KeyInterp) max(110.dp.value, minTimelineFloor.value).dp else minTimelineFloor
            // the player keeps its height when a panel opens (the top bar makes way; the timeline
            // gives up the rest)
            val default = (room + FcSize.ToolTile) * 0.55f
            val wanted = when {
                ed.playerHeight > 0f -> with(density) { ed.playerHeight.toDp() }
                showPanel && ed.basePlayerPx > 0f -> with(density) { ed.basePlayerPx.toDp() }
                else -> default
            }
            // On a short screen (landscape, split screen, a panel open) the player gives up height before
            // the transport row or the timeline are squeezed or pushed under the tools: it may go below
            // its usual minimum, down to a thin strip, so the controls and the ruler always keep their place.
            val maxPlayer = room - FcSize.Transport - minTimeline
            val lowPlayer = min(minPlayer.value, max(maxPlayer.value, 48f)).dp
            val player = wanted.coerceIn(lowPlayer, max(lowPlayer.value, maxPlayer.value).dp)
            if (!showPanel) SideEffect { ed.basePlayerPx = with(density) { player.toPx() } }
            Column(Modifier.fillMaxSize()) {
                Preview(ed, Modifier.fillMaxWidth().height(player))
                TransportRow(ed, onResize = { dy ->
                    val now = if (ed.playerHeight > 0f) ed.playerHeight else with(density) { player.toPx() }
                    ed.playerHeight = (now + dy).coerceIn(with(density) { lowPlayer.toPx() }, with(density) { max(lowPlayer.value, maxPlayer.value).dp.toPx() })
                })
                Timeline(ed, Modifier.fillMaxWidth().weight(1f))
            }
        }
        when {
            showPanel -> EditorPanel(ed, panel!!)
            textInput != null -> TextInputStrip(ed, textInput)
            else -> {
                EditorToolbar(ed)
                Spacer(Modifier.fillMaxWidth().windowInsetsBottomHeight(WindowInsets.navigationBars))
            }
        }
    }
}

@Composable
private fun SideBySide(ed: EditorController) {
    val density = LocalDensity.current
    val panel = ed.panel
    val textInput = panel as? Panel.TextInput
    val showPanel = panel != null && textInput == null
    BoxWithConstraints(Modifier.fillMaxSize().statusBarsPadding()) {
        val total = maxWidth
        val room = maxHeight
        val t = ed.timeline
        val aspect = if (t != null && t.height.toInt() > 0) t.width.toFloat() / t.height.toFloat() else 9f / 16f
        val available = total - 60.dp
        val default = min((maxHeight * aspect).value, (available / 2).value).dp
        val minPlayer = 160.dp
        val minTimeline = 340.dp
        val playerW = (if (ed.sideFraction > 0f) available * ed.sideFraction else default).coerceIn(minPlayer, max(minPlayer.value, (available - minTimeline).value).dp)
        Row(Modifier.fillMaxSize()) {
            // transport rail
            Column(Modifier.width(48.dp).fillMaxHeight(), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                FcIconButton(Glyphs.StepBack, "Previous frame", { ed.step(-1) }, size = 40.dp, iconSize = 22.dp, modifier = Modifier.testTag("editor_previous_frame_button"))
                FcIconButton(if (ed.playing) Glyphs.Pause else Glyphs.Play, if (ed.playing) "Pause" else "Play", { ed.togglePlay() }, size = 40.dp, iconSize = 22.dp, modifier = Modifier.testTag("editor_play_button"))
                FcIconButton(Glyphs.StepForward, "Next frame", { ed.step(1) }, size = 40.dp, iconSize = 22.dp, modifier = Modifier.testTag("editor_next_frame_button"))
            }
            Preview(ed, Modifier.width(playerW).fillMaxHeight())
            // the divider between the monitor and the timeline
            Box(
                Modifier
                    .width(12.dp)
                    .fillMaxHeight()
                    .pointerInput(available) {
                        detectHorizontalDragGestures { change, dx ->
                            change.consume()
                            val now = ed.sideFraction.takeIf { it > 0f } ?: (playerW / available)
                            ed.sideFraction = (now + dx / with(density) { available.toPx() }).coerceIn(minPlayer / available, ((available - minTimeline) / available).coerceAtLeast(minPlayer / available))
                        }
                    }
                    .testTag("editor_side_by_side_divider")
                    .semantics { contentDescription = "Resize monitor" },
                contentAlignment = Alignment.Center,
            ) {
                Box(Modifier.size(width = 4.dp, height = 32.dp).clip(CircleShape).background(Fc.Detail))
            }
            Column(Modifier.weight(1f).fillMaxHeight()) {
                AnimatedVisibility(!showPanel) { TopBar(ed, sideBySide = true) }
                Timeline(ed, Modifier.fillMaxWidth().weight(1f))
                when {
                    showPanel -> Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.BottomCenter) {
                        // never more than most of the height: the timeline stays in sight
                        Box(Modifier.width(min((total - playerW - 60.dp).value, 640f).dp).heightIn(max = room * 0.72f)) { EditorPanel(ed, panel!!) }
                    }
                    textInput != null -> TextInputStrip(ed, textInput)
                    else -> {
                        EditorToolbar(ed)
                        Spacer(Modifier.fillMaxWidth().windowInsetsBottomHeight(WindowInsets.navigationBars))
                    }
                }
            }
        }
    }
}

@Composable
private fun TopBar(ed: EditorController, sideBySide: Boolean) {
    val context = LocalContext.current
    var packageMenu by remember { mutableStateOf(false) }
    val exportPackagePicker = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/zip"),
    ) { uri ->
        if (uri != null) {
            val output = runCatching { context.contentResolver.openOutputStream(uri) }.getOrNull()
            if (output != null) ed.exportProjectPackage(output)
        }
    }
    val importPackagePicker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument(),
    ) { uri ->
        if (uri != null) {
            val input = runCatching { context.contentResolver.openInputStream(uri) }.getOrNull()
            if (input != null) ed.importProjectPackage(input)
        }
    }
    Row(Modifier.fillMaxWidth().height(FcSize.TopBar).padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        FcIconButton(LucideIcons.House.glyph(), "Home", { ed.closeEditor() }, modifier = Modifier.testTag("editor_home_button"))
        if (ed.canReturnToParent) {
            androidx.compose.material3.TextButton(
                onClick = { ed.acceptNestedChanges() },
                enabled = ed.compositionsEnabled && !ed.nestedNavigationBusy,
                modifier = Modifier.testTag("accept_nested_changes_button"),
            ) {
                Text("Accept changes")
            }
        }
        Spacer(Modifier.weight(1f))
        if (sideBySide) {
            val st = ed.status
            KeyframeButton(ed, FcSize.TopButton)
            KeyframeEaseButton(ed, FcSize.TopButton)
            FcIconButton(LucideIcons.Undo2.glyph(), "Undo", { ed.undo() }, enabled = st?.canUndo == true, modifier = Modifier.testTag("editor_top_bar_undo_button"))
            FcIconButton(LucideIcons.Redo2.glyph(), "Redo", { ed.redo() }, enabled = st?.canRedo == true, modifier = Modifier.testTag("editor_top_bar_redo_button"))
            Spacer(Modifier.width(8.dp))
        }
        FcIconButton(
            LucideIcons.Layers.glyph(),
            if (ed.multiSelectMode) "Finish multi-selection" else "Select multiple clips",
            { ed.toggleMultiSelectMode() },
            enabled = ed.multiSelectEnabled,
            // blue while on: the "Accept changes" colour (the theme primary, Fc.Accent)
            tint = if (ed.multiSelectMode) Fc.Accent else Fc.Icon,
            modifier = Modifier.testTag("editor_multi_select_button"),
        )
        Box {
            FcIconButton(LucideIcons.File.glyph(), "Project package", { packageMenu = true }, modifier = Modifier.testTag("editor_project_package_button"))
            DropdownMenu(expanded = packageMenu, onDismissRequest = { packageMenu = false }) {
                DropdownMenuItem(
                    text = { Text("Export project (.filmcraft)") },
                    onClick = { packageMenu = false; exportPackagePicker.launch("Seven-Cut-Pro-Project.filmcraft") },
                )
                DropdownMenuItem(
                    text = { Text("Import project (.filmcraft)") },
                    onClick = { packageMenu = false; importPackagePicker.launch(arrayOf("*/*")) },
                )
                DropdownMenuItem(
                    text = { Text("Create composition (${ed.multiSelectedClipIds.size} selected)") },
                    enabled = ed.compositionsEnabled && ed.multiSelectMode && ed.multiSelectedClipIds.size >= 2 && !ed.nestedNavigationBusy,
                    onClick = { packageMenu = false; ed.createComposition() },
                )
            }
        }
        Box(
            Modifier
                .padding(end = 12.dp)
                .clip(RoundedCornerShape(15.dp))
                .background(if ((ed.timeline?.duration ?: 0L) > 0L) Color.White else Color.White.copy(alpha = 0.4f))
                .clickable(role = Role.Button) { ed.export() }
                .padding(horizontal = 14.dp, vertical = 6.dp)
                .testTag("editor_export_button"),
        ) {
            Text("Export", style = FcType.Button, color = Color.Black)
        }
    }
}

@Composable
private fun TransportRow(ed: EditorController, onResize: (Float) -> Unit) {
    val st = ed.status
    Row(Modifier.fillMaxWidth().height(FcSize.Transport).padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier
                .size(48.dp)
                .pointerInput(Unit) { detectVerticalDragGestures { change, dy -> change.consume(); onResize(dy) } }
                .testTag("editor_resize_player_button")
                .semantics { contentDescription = "Resize player" },
            contentAlignment = Alignment.Center,
        ) {
            io.github.artcraftandroid.filmcraft.ui.GlyphIcon(LucideIcons.ChevronsUpDown.glyph(), Fc.Icon, size = 22.dp)
        }
        Spacer(Modifier.weight(1f))
        val has = (ed.timeline?.duration ?: 0L) > 0L
        FcIconButton(Glyphs.StepBack, "Previous frame", { ed.step(-1) }, enabled = has, size = 36.dp, iconSize = 22.dp, modifier = Modifier.testTag("editor_previous_frame_button"))
        FcIconButton(if (ed.playing) Glyphs.Pause else Glyphs.Play, if (ed.playing) "Pause" else "Play", { ed.togglePlay() }, enabled = has, size = 36.dp, iconSize = 22.dp, modifier = Modifier.testTag("editor_play_button"))
        FcIconButton(Glyphs.StepForward, "Next frame", { ed.step(1) }, enabled = has, size = 36.dp, iconSize = 22.dp, modifier = Modifier.testTag("editor_next_frame_button"))
        Spacer(Modifier.weight(1f))
        KeyframeButton(ed, 36.dp)
        KeyframeEaseButton(ed, 36.dp)
        FcIconButton(LucideIcons.Undo2.glyph(), "Undo", { ed.undo() }, enabled = st?.canUndo == true, size = 36.dp, iconSize = 22.dp, modifier = Modifier.testTag("editor_undo_button"))
        FcIconButton(LucideIcons.Redo2.glyph(), "Redo", { ed.redo() }, enabled = st?.canRedo == true, size = 36.dp, iconSize = 22.dp, modifier = Modifier.testTag("editor_redo_button"))
        Spacer(Modifier.width(4.dp))
    }
}

/** The program monitor: the picture at the playhead, and the selected item's frame to move it by. */
@Composable
private fun Preview(ed: EditorController, modifier: Modifier) {
    val t = ed.timeline
    val density = LocalDensity.current
    val haptic = LocalHapticFeedback.current
    val scope = rememberCoroutineScope()
    val sel = ed.selectedClip
    val movable = sel != null && sel.kind != ClipKind.AUDIO && sel.kind != ClipKind.MISSING && ed.panel !is Panel.TextInput
    var placement by remember { mutableStateOf<Placement?>(null) }
    // While a finger moves/scales/turns the item the frame follows the finger. Re-reading the engine's
    // (older) placement after each refresh made the outline jump back and forth, so it waits for the lift.
    var draggingPlacement by remember { mutableStateOf(false) }
    // when the last tap landed on the selected text (for a double tap that edits its words)
    var lastTextTapAt by remember { mutableStateOf(0L) }
    LaunchedEffect(sel?.id, t?.revision, draggingPlacement) {
        if (!draggingPlacement) placement = if (movable && sel != null) ed.placementOf(sel.id) else null
    }
    BoxWithConstraints(modifier.background(Fc.Black).testTag("editor_player_area"), contentAlignment = Alignment.Center) {
        val aspect = if (t != null && t.height.toInt() > 0) t.width.toFloat() / t.height.toFloat() else 9f / 16f
        // an empty project shows the whole monitor; otherwise the frame, fitted
        val empty = (t?.duration ?: 0L) == 0L
        val boxW = if (empty) maxWidth else min(maxWidth.value, maxHeight.value * aspect).dp
        val boxH = if (empty) maxHeight else boxW / aspect
        val px = with(density) { max(boxW.toPx(), boxH.toPx()) }
        LaunchedEffect(px) { ed.previewSide = px.roundToInt() }
        Box(
            Modifier
                .size(boxW, boxH)
                .border(1.dp, Fc.Raised)
                .pointerInput(sel?.id, movable, t?.width, t?.height) {
                    val frameW = t?.width?.toFloat() ?: return@pointerInput
                    val k = size.width / frameW // screen px per frame px
                    awaitEachGesture {
                        val down = awaitFirstDown(requireUnconsumed = false)
                        // a touch on one of the frame's corner icons belongs to that icon, not to the player
                        val corner = placement
                        if (movable && corner != null && frameIconCenters(corner, k, size.width.toFloat(), size.height.toFloat(), 14.dp.toPx())
                                .any { (it - down.position).getDistance() <= 22.dp.toPx() }) return@awaitEachGesture
                        var moved = false
                        var p = placement
                        var snapState = 0
                        // the first event of a gesture starts its undo step, the rest fold into it
                        var firstEvent = true
                        try {
                        while (true) {
                            val ev = awaitPointerEvent()
                            val pressed = ev.changes.any { it.pressed }
                            if (!pressed) break
                            val pan = ev.calculatePan()
                            val zoom = ev.calculateZoom()
                            val rot = ev.calculateRotation()
                            if (!moved && (pan.getDistance() > viewConfiguration.touchSlop / 4 || zoom != 1f || rot != 0f) && ev.changes.any { it.positionChanged() }) moved = true
                            if (moved && movable && !draggingPlacement) draggingPlacement = true
                            if (moved && movable && p != null && sel != null) {
                                var nx = p.x + pan.x / k
                                var ny = p.y + pan.y / k
                                var nr = p.rotation + rot
                                val ns = p.scale * zoom
                                // snapping: centre to 0/50/100 % of the frame, rotation to 45°
                                val fw = frameW.toDouble()
                                val fh = (t?.height?.toFloat() ?: 1f).toDouble()
                                var snapped = 0
                                for (gx in doubleArrayOf(0.0, fw / 2, fw)) if (abs(nx - gx) < fw * 0.02) { nx = gx; snapped = snapped or 1 }
                                for (gy in doubleArrayOf(0.0, fh / 2, fh)) if (abs(ny - gy) < fh * 0.02) { ny = gy; snapped = snapped or 2 }
                                val r45 = Math.round(nr / 45.0) * 45.0
                                if (abs(nr - r45) < 5.0) { nr = r45; snapped = snapped or 4 }
                                if (snapped != snapState) {
                                    if (snapped != 0) haptic.performHapticFeedback(HapticFeedbackType.SegmentTick)
                                    snapState = snapped
                                }
                                val q = Placement(x = nx, y = ny, width = p.width, height = p.height, scale = ns, rotation = nr)
                                placement = q
                                p = Placement(x = p.x + pan.x / k, y = p.y + pan.y / k, width = p.width, height = p.height, scale = ns, rotation = p.rotation + rot)
                                ed.setPlacement(sel.id, q, merge = !firstEvent)
                                firstEvent = false
                                ev.changes.forEach { it.consume() }
                            } else if (moved) {
                                ev.changes.forEach { it.consume() }
                            }
                        }
                        } finally {
                            draggingPlacement = false
                        }
                        if (!moved) {
                            // a tap on the selected text is a touch on the text, not on the player: a
                            // second one in a row opens its words for editing
                            val onText = sel != null && sel.kind == ClipKind.TEXT && p != null && hitsFrame(p, down.position.x / k, down.position.y / k, viewConfiguration.touchSlop * 2 / k)
                            if (onText && sel != null) {
                                val now = android.os.SystemClock.uptimeMillis()
                                if (lastTextTapAt != 0L && now - lastTextTapAt <= viewConfiguration.doubleTapTimeoutMillis) {
                                    lastTextTapAt = 0L
                                    ed.editText(sel.id)
                                } else {
                                    lastTextTapAt = now
                                }
                            } else {
                                lastTextTapAt = 0L
                                ed.togglePlay()
                            }
                        }
                    }
                }
                .semantics { contentDescription = "Preview" },
        ) {
            ed.picture?.let { Image(it, contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Fit, filterQuality = androidx.compose.ui.graphics.FilterQuality.High) }
            // the text being typed, where the new clip will put it
            if (ed.typing.isNotBlank() && t != null) {
                val k = with(density) { boxW.toPx() } / t.width.toFloat()
                val px = minOf(t.width, t.height).toFloat() * 0.1f * k
                Text(
                    ed.typing,
                    style = androidx.compose.ui.text.TextStyle(
                        fontFamily = io.github.artcraftandroid.filmcraft.ui.Inter,
                        fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold,
                        fontSize = with(density) { px.toSp() },
                        color = Color.White,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                    ),
                    modifier = Modifier.align(Alignment.Center).fillMaxWidth(),
                )
            }
            val pl = placement
            if (movable && pl != null && t != null) {
                Canvas(Modifier.fillMaxSize()) {
                    val k = size.width / t.width.toFloat()
                    val w = (pl.width * pl.scale * k).toFloat()
                    val h = (pl.height * pl.scale * k).toFloat()
                    val cx = (pl.x * k).toFloat()
                    val cy = (pl.y * k).toFloat()
                    val a = Math.toRadians(pl.rotation).toFloat()
                    val corners = listOf(-w / 2 to -h / 2, w / 2 to -h / 2, w / 2 to h / 2, -w / 2 to h / 2).map { (x, y) ->
                        Offset(cx + x * cos(a) - y * sin(a), cy + x * sin(a) + y * cos(a))
                    }
                    val path = Path().apply {
                        moveTo(corners[0].x, corners[0].y)
                        for (c in corners.drop(1)) lineTo(c.x, c.y)
                        close()
                    }
                    drawPath(path, Color.White, style = Stroke(2.dp.toPx()))
                }
                val kPx = with(density) { boxW.toPx() } / t.width.toFloat()
                val centers = frameIconCenters(pl, kPx, with(density) { boxW.toPx() }, with(density) { boxH.toPx() }, with(density) { 14.dp.toPx() })
                FrameIcon(LucideIcons.Trash2.glyph(), "Delete", "editor_frame_delete", centers[0], density) { ed.delete() }
                FrameIcon(LucideIcons.CopyPlus.glyph(), "Duplicate", "editor_frame_duplicate", centers[1], density) { ed.duplicate() }
                // the turn handle: drag it round the item's centre
                val rotateId = sel?.id
                val latestCenters by rememberUpdatedState(centers)
                if (rotateId != null) {
                    val centre = Offset((pl.x * kPx).toFloat(), (pl.y * kPx).toFloat())
                    FrameIcon(
                        LucideIcons.RotateCcw.glyph(), "Rotate", "editor_frame_rotate", centers[2], density,
                        modifier = Modifier.pointerInput(rotateId, kPx) {
                            var at = Offset.Zero
                            var startAngle = 0.0
                            var startRot = 0.0
                            var first = true
                            var base: Placement? = null
                            detectDragGestures(
                                onDragStart = {
                                    base = placement; first = true
                                    at = latestCenters[2]
                                    startAngle = Math.toDegrees(kotlin.math.atan2((at.y - centre.y).toDouble(), (at.x - centre.x).toDouble()))
                                    startRot = base?.rotation ?: 0.0
                                    draggingPlacement = true
                                },
                                onDragEnd = { draggingPlacement = false },
                                onDragCancel = { draggingPlacement = false },
                            ) { change, drag ->
                                change.consume()
                                at += drag
                                val b = base ?: return@detectDragGestures
                                val now = Math.toDegrees(kotlin.math.atan2((at.y - centre.y).toDouble(), (at.x - centre.x).toDouble()))
                                var nr = startRot + (now - startAngle)
                                val r45 = Math.round(nr / 45.0) * 45.0
                                if (abs(nr - r45) < 5.0) nr = r45
                                val q = Placement(x = b.x, y = b.y, width = b.width, height = b.height, scale = b.scale, rotation = nr)
                                placement = q
                                ed.setPlacement(rotateId, q, merge = !first)
                                first = false
                            }
                        },
                    )
                }
            }
        }
    }
}

/**
 * Where the delete, duplicate and rotate icons sit: on the frame's top-left, bottom-left and
 * bottom-right corners (they turn with the item), kept [margin] px inside the picture so they stay touchable.
 */
private fun frameIconCenters(p: Placement, k: Float, w: Float, h: Float, margin: Float): List<Offset> {
    val hw = (p.width * p.scale * k).toFloat() / 2
    val hh = (p.height * p.scale * k).toFloat() / 2
    val a = Math.toRadians(p.rotation).toFloat()
    val cx = (p.x * k).toFloat()
    val cy = (p.y * k).toFloat()
    return listOf(-hw to -hh, -hw to hh, hw to hh).map { (x, y) ->
        Offset(
            (cx + x * cos(a) - y * sin(a)).coerceIn(margin, max(margin, w - margin)),
            (cy + x * sin(a) + y * cos(a)).coerceIn(margin, max(margin, h - margin)),
        )
    }
}

/** One round icon on the selection frame, centred on [centre] (px). */
@Composable
private fun FrameIcon(
    glyph: io.github.artcraftandroid.filmcraft.ui.Glyph,
    label: String,
    tag: String,
    centre: Offset,
    density: androidx.compose.ui.unit.Density,
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
) {
    val half = with(density) { 14.dp.roundToPx() }
    Box(
        Modifier
            .offset { androidx.compose.ui.unit.IntOffset(centre.x.roundToInt() - half, centre.y.roundToInt() - half) }
            .size(28.dp)
            .clip(androidx.compose.foundation.shape.CircleShape)
            .background(Color.White)
            .then(if (onClick != null) Modifier.clickable(role = androidx.compose.ui.semantics.Role.Button, onClickLabel = label) { onClick() } else modifier)
            .testTag(tag)
            .semantics { contentDescription = label },
        contentAlignment = Alignment.Center,
    ) {
        GlyphIcon(glyph, Color.Black, size = 16.dp)
    }
}

/**
 * Whether the point ([fx], [fy]) in frame pixels is inside [p]'s outline (a rectangle of the item's
 * size × scale turned by its rotation about its centre), with [slop] frame pixels to spare.
 */
private fun hitsFrame(p: Placement, fx: Float, fy: Float, slop: Float): Boolean {
    val a = Math.toRadians(p.rotation)
    val dx = fx - p.x
    val dy = fy - p.y
    val lx = dx * cos(a) + dy * sin(a)
    val ly = -dx * sin(a) + dy * cos(a)
    return abs(lx) <= p.width * p.scale / 2 + slop && abs(ly) <= p.height * p.scale / 2 + slop
}

@Suppress("unused")
private fun Dp.half() = this / 2
