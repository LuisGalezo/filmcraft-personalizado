package io.github.artcraftandroid.filmcraft.ui.editor

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.sp
import io.github.artcraftandroid.filmcraft.core.KeyInterpInfo
import io.github.artcraftandroid.filmcraft.ui.GlyphIcon
import io.github.artcraftandroid.filmcraft.ui.LucideIcons
import io.github.artcraftandroid.filmcraft.ui.ToolPanel
import io.github.artcraftandroid.filmcraft.ui.glyph
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import io.github.artcraftandroid.filmcraft.core.ClipKind
import io.github.artcraftandroid.filmcraft.ui.Fc

/**
 * Add or remove a keyframe at the playhead on the selected layer. An empty diamond adds one (the
 * clip's position, scale, rotation, opacity and its sound's volume keep the values they have right
 * there, and from then on edits at other times make their own keys); a filled one says there is a
 * key at the playhead and removes it. Shown only while a layer is selected, beside Undo and Redo.
 */
@Composable
fun KeyframeButton(ed: EditorController, size: Dp, modifier: Modifier = Modifier) {
    val clip = ed.selectedClip ?: return
    if (clip.kind == ClipKind.MISSING) return
    val here = ed.keysOf(clip).any { Math.abs(it - ed.playhead) <= ed.frameTicks / 2 }
    val label = if (here) "Remove keyframe" else "Add keyframe"
    Box(
        modifier
            .size(size)
            .clickable(role = Role.Button, onClickLabel = label) { ed.toggleKeyframe() }
            .testTag(if (here) "editor_keyframe_remove_button" else "editor_keyframe_add_button")
            .semantics { contentDescription = label },
        contentAlignment = Alignment.Center,
    ) {
        Canvas(Modifier.size(size * 0.5f)) {
            val c = Offset(this.size.width / 2, this.size.height / 2)
            val d = this.size.width / 2 - 1.dp.toPx()
            val diamond = Path().apply {
                moveTo(c.x, c.y - d)
                lineTo(c.x + d, c.y)
                lineTo(c.x, c.y + d)
                lineTo(c.x - d, c.y)
                close()
            }
            if (here) {
                drawPath(diamond, Color(0xFFFFD54A))
            }
            drawPath(diamond, if (here) Color(0xFF3A2E00) else Fc.Icon, style = Stroke(2.dp.toPx()))
        }
    }
}

/** Opens the interpolation panel (Linear, Bezier, Hold, Ease In/Out...) for the keys of the selected layer. */
@Composable
fun KeyframeEaseButton(ed: EditorController, size: Dp, modifier: Modifier = Modifier) {
    val clip = ed.selectedClip ?: return
    if (clip.kind == ClipKind.MISSING || ed.keysOf(clip).isEmpty()) return
    Box(
        modifier
            .size(size)
            .clickable(role = Role.Button, onClickLabel = "Keyframe interpolation") { ed.panel = Panel.KeyInterp }
            .testTag("editor_keyframe_ease_button")
            .semantics { contentDescription = "Keyframe interpolation" },
        contentAlignment = Alignment.Center,
    ) {
        GlyphIcon(LucideIcons.ChartSpline.glyph(), Fc.Icon, size = size * 0.5f)
    }
}

/**
 * The interpolation types of the keyframe at the playhead (Premiere Pro's set). Tapping one sets it
 * and plays that segment, from the key to the next one; tapping the current one plays it again.
 */
@Composable
fun KeyInterpPanel(ed: EditorController, clip: ClipInfo, close: () -> Unit, modifier: Modifier = Modifier) {
    val info by produceState<KeyInterpInfo?>(null, clip.id, ed.timeline?.revision, ed.playhead) {
        value = runCatching { ed.keyInterpInfo(clip.id) }.getOrNull()
    }
    ToolPanel("Keyframe curves", close, modifier, tag = "editor_keyframe_interp_panel") {
        val i = info
        if (i != null && !i.hasKeys) {
            Text("Add a keyframe first", color = Fc.Secondary, fontSize = 14.sp, modifier = Modifier.padding(16.dp))
        } else {
            Row(
                Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 6.dp),
                horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(10.dp),
            ) {
                for (kind in KeyEase.values()) {
                    val on = i?.current == kind.id
                    Column(
                        Modifier
                            .width(66.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(Fc.Raised)
                            .border(if (on) 2.dp else 0.dp, if (on) Fc.Accent else Color.Transparent, RoundedCornerShape(10.dp))
                            .clickable(role = Role.Button, onClickLabel = kind.label) { ed.applyKeyInterp(kind) }
                            .testTag("editor_key_interp_" + kind.id)
                            .padding(6.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        Canvas(Modifier.size(38.dp)) {
                            val w = size.width; val h = size.height
                            drawRect(Fc.Divider, style = Stroke(1.dp.toPx()))
                            val path = Path()
                            val n = 40
                            for (k in 0..n) {
                                val u = k / n.toFloat()
                                val x = u * w; val y = h - kind.at(u.toDouble()).toFloat() * h
                                if (k == 0) path.moveTo(x, y) else path.lineTo(x, y)
                            }
                            drawPath(path, if (on) Fc.Accent else Fc.Icon, style = Stroke(2.dp.toPx()))
                        }
                        Text(kind.label, color = if (on) Fc.Title else Fc.Secondary, fontSize = 11.sp, textAlign = TextAlign.Center, maxLines = 1, modifier = Modifier.padding(top = 2.dp))
                    }
                }
            }
        }
    }
}
