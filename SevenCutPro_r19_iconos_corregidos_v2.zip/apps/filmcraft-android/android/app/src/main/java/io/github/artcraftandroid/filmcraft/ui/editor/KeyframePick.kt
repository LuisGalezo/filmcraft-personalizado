package io.github.artcraftandroid.filmcraft.ui.editor

/**
 * Choosing a keyframe on the timeline by touch. The reach is measured in screen pixels, so it is the
 * same at every zoom: nobody has to zoom in to hit a key, and when two keys are close together the
 * nearer one wins, so a neighbour is never picked by accident.
 */
object KeyframePick {
    /** How far from a key's centre (dp) a touch still means that key. */
    const val REACH_DP = 22f

    /** How long a key is held (ms) before it can be moved in time. */
    const val HOLD_MS = 3000L

    /** The index in [xs] (screen x of each key) of the key nearest to [x] within [reach], or -1. */
    fun pick(xs: List<Float>, x: Float, reach: Float): Int {
        var best = -1
        var bestDistance = Float.MAX_VALUE
        for (i in xs.indices) {
            val d = kotlin.math.abs(xs[i] - x)
            if (d <= reach && d < bestDistance) {
                best = i
                bestDistance = d
            }
        }
        return best
    }

    /** Where a key held at [from] lands after a finger drag of [ticks], kept strictly inside the clip. */
    fun movedTo(from: Long, ticks: Long, clipStart: Long, clipDuration: Long): Long {
        val lo = clipStart + 1
        val hi = (clipStart + clipDuration - 1).coerceAtLeast(lo)
        return (from + ticks).coerceIn(lo, hi)
    }
}
