package io.github.artcraftandroid.filmcraft.ui.editor

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import io.github.artcraftandroid.filmcraft.core.ClipInfo
import io.github.artcraftandroid.filmcraft.core.RampInfo
import io.github.artcraftandroid.filmcraft.ui.Fc
import io.github.artcraftandroid.filmcraft.ui.FcSize
import io.github.artcraftandroid.filmcraft.ui.FcType
import io.github.artcraftandroid.filmcraft.ui.LucideIcons
import io.github.artcraftandroid.filmcraft.ui.PanelAction
import io.github.artcraftandroid.filmcraft.ui.ToolPanel
import io.github.artcraftandroid.filmcraft.ui.glyph
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.roundToLong

private const val RAMP_TICKS_PER_SECOND = 254_016_000_000.0

/**
 * Speed ramp: the speed of the video changing as it plays. The graph is the clip's speed over its own
 * length (the dots are its points); a point is made at the playhead and holds its speed from there
 * to the next one, easing smoothly between them. The clip keeps its length: a slower stretch plays
 * less footage, a faster one more (the footage has to exist, or the edit is refused). The sound
 * follows the same curve, so picture and sound stay together (its pitch follows the speed).
 */
@Composable
fun RampPanel(ed: EditorController, clip: ClipInfo, close: () -> Unit, modifier: Modifier = Modifier) {
    val revision = ed.timeline?.revision
    val info by produceState<RampInfo?>(null, clip.id, revision, ed.playhead) {
        value = runCatching { ed.rampInfo(clip.id) }.getOrNull()
    }
    val r = info
    ToolPanel(
        "Speed ramp", close, modifier, tag = "ramp_panel",
        actions = { PanelAction(LucideIcons.Undo2.glyph(), "Reset speed ramp", { ed.rampEdit("clear", 0, 0.0) }, enabled = r?.points?.isNotEmpty() == true, tag = "ramp_reset_button") },
    ) {
        if (r == null || !r.eligible) {
            Text("This clip can't have a speed ramp.", style = FcType.Caption, color = Fc.Detail, modifier = Modifier.padding(FcSize.PanelPadding))
            return@ToolPanel
        }
        val dur = max(clip.duration, 1L).toDouble()
        Canvas(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = FcSize.PanelPadding, vertical = 6.dp)
                .height(84.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(Fc.Raised)
                .testTag("ramp_graph"),
        ) {
            val top = max(200.0, (r.curve.maxOrNull() ?: 100.0) * 1.15)
            fun y(p: Double) = size.height * (1f - (p / top).toFloat().coerceIn(0f, 1f))
            fun x(u: Double) = size.width * u.toFloat()
            drawLine(Fc.Divider, Offset(0f, y(100.0)), Offset(size.width, y(100.0)), 1.dp.toPx())
            val path = Path()
            r.curve.forEachIndexed { i, p ->
                val px = x((i + 0.5) / r.curve.size)
                if (i == 0) path.moveTo(px, y(p)) else path.lineTo(px, y(p))
            }
            drawPath(path, Fc.Accent, style = Stroke(2.dp.toPx()))
            val u = ((ed.playhead - clip.start).toDouble() / dur).coerceIn(0.0, 1.0)
            drawLine(Color.White.copy(alpha = 0.6f), Offset(x(u), 0f), Offset(x(u), size.height), 1.dp.toPx())
            for (p in r.points) {
                drawCircle(if (p.index.toInt() == r.pointAtPlayhead) Fc.Accent else Color.White, 5.dp.toPx(), Offset(x(p.at), y(p.percent)))
            }
        }
        Text(
            "Plays ${secs(r.played)} of footage in ${secs(clip.duration)}" + if (r.available > 0) " (${secs(r.available)} available)" else "",
            style = FcType.Caption, color = Fc.Detail, modifier = Modifier.padding(horizontal = FcSize.PanelPadding),
        )
        Spacer(Modifier.height(8.dp))
        // the speed at the playhead: − / + edit its point, or make one there
        val setSpeed = { v: Double ->
            if (r.pointAtPlayhead >= 0) ed.rampEdit("speed", r.pointAtPlayhead, v) else ed.rampEdit("add", 0, v)
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = FcSize.PanelPadding), verticalAlignment = Alignment.CenterVertically) {
            Text("Speed", style = FcType.Label, color = Fc.Secondary, modifier = Modifier.width(64.dp))
            RampButton("−", "Slower", "ramp_slower") { setSpeed(r.percentAtPlayhead - 10.0) }
            Text("${pct(r.percentAtPlayhead)}%", style = FcType.Header, color = Fc.Title, textAlign = TextAlign.Center, modifier = Modifier.weight(1f).testTag("ramp_speed_value"))
            RampButton("+", "Faster", "ramp_faster") { setSpeed(r.percentAtPlayhead + 10.0) }
        }
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth().padding(horizontal = FcSize.PanelPadding), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            RampChip("Add point", r.pointAtPlayhead < 0, "ramp_add_point") { ed.rampEdit("add", 0, r.percentAtPlayhead) }
            RampChip("Remove point", r.pointAtPlayhead >= 0, "ramp_remove_point") { ed.rampEdit("remove", r.pointAtPlayhead, 0.0) }
        }
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth().padding(horizontal = FcSize.PanelPadding), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Ramp in", style = FcType.Caption, color = Fc.Detail, modifier = Modifier.width(64.dp))
            for (v in listOf(25.0, 50.0)) RampChip("${pct(v)}%", true, "ramp_in_${pct(v)}") { ed.rampEdit("ease_in", 0, v) }
            Spacer(Modifier.width(8.dp))
            Text("Ramp out", style = FcType.Caption, color = Fc.Detail)
            for (v in listOf(25.0, 50.0)) RampChip("${pct(v)}%", true, "ramp_out_${pct(v)}") { ed.rampEdit("ease_out", 0, v) }
        }
        Spacer(Modifier.height(12.dp))
    }
}

@Composable
private fun RampButton(text: String, description: String, tag: String, onClick: () -> Unit) {
    Box(
        Modifier.size(44.dp).clip(CircleShape).background(Fc.PillButton).clickable(role = Role.Button, onClick = onClick).testTag(tag).semantics { contentDescription = description },
        contentAlignment = Alignment.Center,
    ) { Text(text, style = FcType.Header, color = Fc.Title) }
}

@Composable
private fun RampChip(text: String, enabled: Boolean, tag: String, onClick: () -> Unit) {
    Box(
        Modifier.height(36.dp).clip(RoundedCornerShape(18.dp)).background(if (enabled) Fc.PillButton else Fc.Raised)
            .clickable(enabled = enabled, role = Role.Button, onClick = onClick).padding(horizontal = 14.dp).testTag(tag),
        contentAlignment = Alignment.Center,
    ) { Text(text, style = FcType.Caption, color = if (enabled) Fc.Title else Fc.Disabled) }
}

private fun secs(ticks: Long) = String.format(java.util.Locale.US, "%.1fs", ticks / RAMP_TICKS_PER_SECOND)

private fun pct(v: Double): String = if (abs(v - v.roundToLong()) < 0.05) v.roundToLong().toString() else String.format(java.util.Locale.US, "%.1f", v)
