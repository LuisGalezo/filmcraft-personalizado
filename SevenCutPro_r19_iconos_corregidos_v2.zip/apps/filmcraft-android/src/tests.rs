use std::path::{Path, PathBuf};
use std::sync::atomic::{AtomicU32, Ordering};

use filmcraft_engine::export as fx;
use filmcraft_media::generators::GeneratorSource;
use filmcraft_media::{DemoScene, Generator, MediaSource};
use filmcraft_project::{ItemId, ItemKind, Label, MediaClip, MediaRef, Project, SequenceSettings, TrackKind};
use filmcraft_time::{FrameRate, TimeRange};

use super::*;
use crate::model::{ClipKind, LaneKind};

static COUNTER: AtomicU32 = AtomicU32::new(0);

fn tmp() -> PathBuf {
    let d = std::env::temp_dir().join(format!("filmcraft-android-test-{}-{}", std::process::id(), COUNTER.fetch_add(1, Ordering::Relaxed)));
    std::fs::create_dir_all(&d).unwrap();
    d
}

/// A `frames`-frame 24 fps 320×180 H.264 + AAC movie of a demo scene (with its sound).
fn movie(dir: &Path, name: &str, scene: DemoScene, frames: i64) -> String {
    let path = dir.join(name);
    let (w, h, rate) = (320, 180, FrameRate::FPS_24);
    let dur = rate.tick_of(frames);
    let src = GeneratorSource::new(Generator::Demo(scene), w, h, rate, dur);
    let mut p = Project::new("fixture");
    let clip = MediaClip {
        media: MediaRef::Generator(Generator::Demo(scene)),
        info: src.info().clone(),
        interpret: Default::default(),
        mark_in: None,
        mark_out: None,
        markers: vec![],
        offline: false,
        proxy: None,
        identity: None,
    };
    let item = p.add_item("scene", Label::Iris, ItemKind::Media(Box::new(clip)), None);
    let seq = p.new_sequence("s", SequenceSettings { width: w, height: h, frame_rate: rate, ..Default::default() }, 1, 1, None);
    let r = TimeRange::new(Tick::ZERO, dur);
    let mut v = p.make_track_item(item, TrackKind::Video, Tick::ZERO, r, rate).unwrap();
    for e in &mut v.effects {
        filmcraft_project::resolve_auto_points(e, (w, h), (w, h));
    }
    let a = p.make_track_item(item, TrackKind::Audio, Tick::ZERO, r, rate).unwrap();
    let q = p.sequence_mut(seq).unwrap();
    q.video_tracks[0].items.push(v);
    q.audio_tracks[0].items.push(a);
    let settings = fx::ExportSettings { format: fx::Format::H264, path: path.to_string_lossy().into_owned(), bitrate_kbps: 800, ..Default::default() };
    let shared: filmcraft_media::SharedSource = std::sync::Arc::new(src);
    let provider = move |id: ItemId| (id == item).then(|| shared.clone());
    fx::export(&std::sync::Arc::new(p), seq, &settings, &provider, &Default::default()).unwrap();
    path.to_string_lossy().into_owned()
}

/// A 64×64 PNG still.
fn picture(dir: &Path) -> String {
    let path = dir.join("still.png");
    let rgba: Vec<u8> = (0..64 * 64).flat_map(|i| [(i % 64 * 4) as u8, 120, 200, 255]).collect();
    std::fs::write(&path, fx::encode_png(rgba, 64, 64).unwrap()).unwrap();
    path.to_string_lossy().into_owned()
}

/// A mono 16-bit WAV of a 440 Hz tone, `seconds` long.
fn tone(dir: &Path, seconds: f64) -> String {
    let path = dir.join("tone.wav");
    let rate = 48_000u32;
    let n = (seconds * f64::from(rate)) as u32;
    let mut b = Vec::new();
    b.extend_from_slice(b"RIFF");
    b.extend_from_slice(&(36 + n * 2).to_le_bytes());
    b.extend_from_slice(b"WAVEfmt ");
    b.extend_from_slice(&16u32.to_le_bytes());
    b.extend_from_slice(&1u16.to_le_bytes());
    b.extend_from_slice(&1u16.to_le_bytes());
    b.extend_from_slice(&rate.to_le_bytes());
    b.extend_from_slice(&(rate * 2).to_le_bytes());
    b.extend_from_slice(&2u16.to_le_bytes());
    b.extend_from_slice(&16u16.to_le_bytes());
    b.extend_from_slice(b"data");
    b.extend_from_slice(&(n * 2).to_le_bytes());
    for i in 0..n {
        let v = ((f64::from(i) * 440.0 * std::f64::consts::TAU / f64::from(rate)).sin() * 12000.0) as i16;
        b.extend_from_slice(&v.to_le_bytes());
    }
    std::fs::write(&path, b).unwrap();
    path.to_string_lossy().into_owned()
}

const SEC: i64 = TICKS_PER_SECOND;

/// A portrait 30 fps project with two clips (2 s and 3 s) on the main track.
fn two_clips() -> (Arc<MobileSession>, PathBuf, Vec<u64>) {
    let d = tmp();
    let a = movie(&d, "a.mp4", DemoScene::Aurora, 48);
    let b = movie(&d, "b.mp4", DemoScene::Dunes, 72);
    let m = MobileSession::new();
    m.new_project("Test".into(), 1080, 1920, 30).unwrap();
    let ids = m.add_media(vec![a, b]).unwrap();
    (m, d, ids)
}

#[test]
fn the_media_a_project_starts_with_cannot_be_undone_away() {
    let (m, _d, ids) = two_clips();
    m.forget_history();
    assert!(!m.poll().can_undo);
    assert_eq!(m.undo(), None);
    assert_eq!(main_clips(&m).len(), ids.len());
    m.set_playhead(SEC);
    m.split(ids[0]).unwrap();
    assert!(m.undo().is_some());
    assert_eq!(m.undo(), None, "only the split was undoable");
    assert_eq!(main_clips(&m).len(), ids.len());
}

fn lane(t: &TimelineInfo, kind: LaneKind) -> &model::LaneInfo {
    t.lanes.iter().find(|l| l.kind == kind).unwrap()
}

fn main_clips(m: &MobileSession) -> Vec<model::ClipInfo> {
    lane(&m.timeline().unwrap(), LaneKind::Main).clips.clone()
}

fn clip(m: &MobileSession, id: u64) -> model::ClipInfo {
    m.timeline().unwrap().lanes.iter().flat_map(|l| l.clips.iter()).find(|c| c.id == id).cloned().unwrap()
}

#[test]
fn a_new_project_is_an_empty_portrait_sequence() {
    let m = MobileSession::new();
    let t = m.new_project("Oct 13, 2026".into(), 1080, 1920, 30).unwrap();
    assert_eq!((t.width, t.height, t.rate_num, t.rate_den, t.duration), (1080, 1920, 30, 1, 0));
    assert_eq!(t.lanes.len(), 1);
    assert_eq!(t.lanes[0].kind, LaneKind::Main);
    assert!(!m.poll().can_undo, "a new project starts with nothing to undo");
}

#[test]
fn media_goes_onto_the_main_track_back_to_back_and_the_first_is_selected() {
    let (m, _d, ids) = two_clips();
    let t = m.timeline().unwrap();
    let main = lane(&t, LaneKind::Main);
    assert_eq!(main.clips.iter().map(|c| c.id).collect::<Vec<_>>(), ids);
    assert_eq!(main.clips[0].start, 0);
    assert_eq!(main.clips[1].start, main.clips[0].duration);
    assert_eq!(main.clips[0].duration, 2 * SEC);
    assert!(main.clips.iter().all(|c| c.kind == ClipKind::Video && c.has_audio && c.audio_clip.is_some()));
    // the clips' sound is inside them, not a lane of its own
    assert!(t.lanes.iter().all(|l| l.kind != LaneKind::Audio));
    assert_eq!(t.selected, Some(ids[0]));
    assert_eq!(m.poll().undo_label.as_deref(), Some("Add Media"));
}

#[test]
fn new_media_goes_after_the_clip_under_the_playhead_and_before_one_starting_there() {
    let (m, d, ids) = two_clips();
    let c = movie(&d, "c.mp4", DemoScene::Plasma, 24);
    m.set_playhead(SEC); // inside the first clip
    let added = m.add_media(vec![c.clone()]).unwrap();
    assert_eq!(main_clips(&m).iter().map(|c| c.id).collect::<Vec<_>>(), vec![ids[0], added[0], ids[1]]);
    m.set_playhead(0); // exactly at the first clip
    let first = m.add_media(vec![c]).unwrap();
    assert_eq!(main_clips(&m)[0].id, first[0]);
}

#[test]
fn pictures_last_four_seconds_and_sounds_go_to_an_audio_lane() {
    let (m, d, _) = two_clips();
    let pic = m.add_media(vec![picture(&d)]).unwrap();
    let p = clip(&m, pic[0]);
    assert_eq!((p.kind, p.duration, p.has_audio), (ClipKind::Image, 4 * SEC, false));
    m.set_playhead(SEC);
    let snd = m.add_audio(vec![tone(&d, 1.5)]).unwrap();
    let t = m.timeline().unwrap();
    let audio = lane(&t, LaneKind::Audio);
    assert_eq!(audio.index, -1);
    assert_eq!(audio.clips[0].id, snd[0]);
    assert_eq!((audio.clips[0].kind, audio.clips[0].start), (ClipKind::Audio, SEC));
    // lanes run overlays, main, audio from top to bottom
    assert_eq!(t.lanes.last().map(|l| l.kind), Some(LaneKind::Audio));
}

#[test]
fn split_cuts_at_the_playhead_and_refuses_near_the_ends() {
    let (m, _d, ids) = two_clips();
    m.set_playhead(SEC);
    let right = m.split(ids[0]).unwrap();
    let main = main_clips(&m);
    assert_eq!(main.len(), 3);
    assert_eq!((main[0].duration, main[1].id, main[1].start), (SEC, right, SEC));
    assert_eq!(m.timeline().unwrap().selected, Some(right));
    // one frame from the start is too close
    m.set_playhead(SEC + SEC / 30);
    assert!(matches!(m.split(right), Err(MobileError::Command(_))));
}

#[test]
fn deleting_on_the_main_track_closes_the_gap() {
    let (m, _d, ids) = two_clips();
    m.delete_clip(ids[0]).unwrap();
    let main = main_clips(&m);
    assert_eq!(main.len(), 1);
    assert_eq!((main[0].id, main[0].start), (ids[1], 0));
    m.undo();
    assert_eq!(main_clips(&m).len(), 2);
}

#[test]
fn duplicate_puts_the_copy_right_after_the_original() {
    let (m, _d, ids) = two_clips();
    let copy = m.duplicate(ids[0]).unwrap();
    let main = main_clips(&m);
    assert_eq!(main.iter().map(|c| c.id).collect::<Vec<_>>(), vec![ids[0], copy, ids[1]]);
    assert_eq!((main[1].start, main[2].start), (2 * SEC, 4 * SEC));
    assert!(main[1].audio_clip.is_some(), "the copy keeps its sound");
}

#[test]
fn speed_changes_the_length_and_ripples_the_main_track() {
    let (m, _d, ids) = two_clips();
    m.set_speed(ids[0], 2.0).unwrap();
    let main = main_clips(&m);
    assert_eq!((main[0].duration, main[0].speed), (SEC, 2.0));
    assert_eq!(main[1].start, SEC);
    let keeps = m.lock().active_sequence().and_then(|q| q.find_item(filmcraft_project::ClipId(ids[0]))).is_some_and(|(_, c)| c.maintain_pitch);
    assert!(keeps, "the sound keeps its pitch");
    // out-of-range speeds are clamped, not refused
    m.set_speed(ids[0], 50.0).unwrap();
    assert_eq!(main_clips(&m)[0].speed, 10.0);
    assert!(m.set_speed(ids[0], f64::NAN).is_err());
}

#[test]
fn replace_keeps_place_and_length_and_refuses_a_shorter_video() {
    let (m, d, ids) = two_clips();
    m.forget_history();
    let longer = movie(&d, "longer.mp4", DemoScene::Dunes, 96);
    m.replace(ids[0], longer).unwrap();
    let main = main_clips(&m);
    assert_eq!((main.len(), main[0].start, main[0].duration), (2, 0, 2 * SEC));
    // a shorter one is refused, and leaves nothing to redo
    let shorter = movie(&d, "shorter.mp4", DemoScene::Aurora, 24);
    let before: Vec<(u64, i64, i64)> = main_clips(&m).iter().map(|c| (c.id, c.start, c.duration)).collect();
    assert!(matches!(m.replace(ids[1], shorter), Err(MobileError::Command(_))));
    assert_eq!(main_clips(&m).iter().map(|c| (c.id, c.start, c.duration)).collect::<Vec<_>>(), before);
    assert!(!m.poll().can_redo);
    // a picture of another shape fits the frame as the video did, centred on its own middle
    let motion = |m: &MobileSession| {
        let s = m.lock();
        let c = s.active_sequence().and_then(|q| q.find_item(filmcraft_project::ClipId(ids[0]))).map(|(_, c)| c.clone()).unwrap();
        let e = c.effects.iter().find(|e| e.effect == "motion").unwrap().clone();
        (e.vec2_at("anchor", c.source_in), e.f64_at("scale", c.source_in))
    };
    let (_, scale) = motion(&m);
    let linked_audio_before = clip(&m, ids[0]).audio_clip;
    assert!(linked_audio_before.is_some(), "the source video starts with linked audio");
    m.replace(ids[0], picture(&d)).unwrap();
    let (anchor, now) = motion(&m);
    let replaced = clip(&m, ids[0]);
    assert_eq!(replaced.kind, ClipKind::Image, "a video clip can be replaced by a still image");
    assert!(!replaced.has_audio, "the still image must not be reported as having embedded audio");
    assert_eq!(replaced.audio_clip, linked_audio_before, "replacing the picture must not discard the original linked audio clip");
    assert_eq!((anchor.x, anchor.y), (32.0, 32.0), "the middle of the 64 px picture");
    assert!((now / scale - 5.0).abs() < 1e-9, "320 px wide fitted 1080, 64 px fits it at five times the scale: {scale} → {now}");
    assert_eq!(main_clips(&m)[0].duration, 2 * SEC);
    m.undo();
    assert_eq!(motion(&m).1, scale, "one undo step");
}

#[test]
fn replacing_a_still_with_a_short_video_is_refused_without_changing_the_still() {
    let (m, d, ids) = two_clips();
    let still = picture(&d);
    m.replace(ids[0], still).unwrap();
    m.forget_history();

    let too_short = movie(&d, "too-short-for-still.mp4", DemoScene::Aurora, 24);
    let before = clip(&m, ids[0]);
    assert_eq!(before.kind, ClipKind::Image);
    let result = m.replace(ids[0], too_short);

    assert!(matches!(result, Err(MobileError::Command(_))));
    let after = clip(&m, ids[0]);
    assert_eq!(after.kind, ClipKind::Image, "a rejected video must not replace the still");
    assert_eq!((after.start, after.duration), (before.start, before.duration));
    assert!(!m.poll().can_redo, "a rejected replacement must not create redo history");
}

#[test]
fn freeze_inserts_a_four_second_still() {
    let (m, _d, ids) = two_clips();
    m.set_playhead(SEC);
    let held = m.freeze(ids[0]).unwrap();
    let t = m.timeline().unwrap();
    assert_eq!(t.duration, 9 * SEC);
    let h = clip(&m, held);
    assert_eq!((h.start, h.duration), (SEC, 4 * SEC));
}

#[test]
fn volume_mute_and_fades_round_trip() {
    let (m, _d, ids) = two_clips();
    m.set_volume(ids[0], 1.5, true).unwrap();
    m.set_volume(ids[0], 0.5, true).unwrap();
    let c = clip(&m, ids[0]);
    assert!((c.volume - 0.5).abs() < 1e-6, "{}", c.volume);
    // a drag is one undo step
    m.undo();
    assert!((clip(&m, ids[0]).volume - 1.0).abs() < 1e-6);
    m.set_volume(ids[0], 0.0, false).unwrap();
    assert_eq!(clip(&m, ids[0]).volume, 0.0);
    m.set_muted(ids[0], true).unwrap();
    assert!(clip(&m, ids[0]).muted);
    m.set_fades(ids[1], SEC / 2, SEC, false).unwrap();
    let c = clip(&m, ids[1]);
    assert_eq!((c.fade_in, c.fade_out), (SEC / 2, SEC));
    // the neighbour's sound is not crossfaded
    assert_eq!((clip(&m, ids[0]).fade_in, clip(&m, ids[0]).fade_out), (0, 0));
    m.set_fades(ids[1], 0, 0, false).unwrap();
    assert_eq!(clip(&m, ids[1]).fade_out, 0);
}

#[test]
fn extract_audio_makes_a_standalone_clip_under_the_video() {
    let (m, _d, ids) = two_clips();
    let a = m.extract_audio(ids[1]).unwrap();
    let t = m.timeline().unwrap();
    let audio = lane(&t, LaneKind::Audio);
    let c = audio.clips.iter().find(|c| c.id == a).unwrap();
    // in sync: same start and length as the video it came from
    assert_eq!((c.start, c.duration, c.kind), (2 * SEC, 3 * SEC, ClipKind::Audio));
    assert!(c.name.starts_with("Extracted"));
    assert!(c.has_audio && !c.muted, "the extracted sound plays");
    // the video's own sound is switched off (not removed), so nothing is heard twice
    let v = clip(&m, ids[1]);
    assert!(v.muted && v.audio_clip.is_some());
    // the neighbour keeps its sound
    assert!(!clip(&m, ids[0]).muted);
}

#[test]
fn extracting_again_makes_no_second_clip_and_undo_redo_follow() {
    let (m, _d, ids) = two_clips();
    m.forget_history();
    let a = m.extract_audio(ids[1]).unwrap();
    let audio_clips = |m: &MobileSession| -> usize {
        m.timeline().unwrap().lanes.iter().filter(|l| l.kind == LaneKind::Audio).map(|l| l.clips.len()).sum()
    };
    assert_eq!(audio_clips(&m), 1);
    // a repeat finds the clip already made: same clip, no copy, no new lane
    assert_eq!(m.extract_audio(ids[1]).unwrap(), a);
    assert_eq!(audio_clips(&m), 1);
    assert_eq!(m.timeline().unwrap().lanes.iter().filter(|l| l.kind == LaneKind::Audio).count(), 1);
    // one undo takes the whole extraction back: the video sounds again
    assert!(m.undo().is_some());
    assert_eq!(audio_clips(&m), 0);
    assert!(!clip(&m, ids[1]).muted);
    assert_eq!(m.undo(), None, "the repeat made no history of its own");
    // redo brings the extraction and the silence back together
    assert!(m.redo().is_some());
    assert_eq!(audio_clips(&m), 1);
    assert!(clip(&m, ids[1]).muted);
    // a video muted by hand first still gives a sound that plays
    let (m2, _d2, ids2) = two_clips();
    m2.set_muted(ids2[0], true).unwrap();
    let b = m2.extract_audio(ids2[0]).unwrap();
    assert!(!clip(&m2, b).muted);
}

#[test]
fn an_extracted_sound_edits_on_its_own_and_keeps_its_fades() {
    let (m, _d, ids) = two_clips();
    m.set_fades(ids[1], SEC / 2, SEC, false).unwrap();
    let a = m.extract_audio(ids[1]).unwrap();
    // its fades travelled with the copy
    let c = clip(&m, a);
    assert_eq!((c.fade_in, c.fade_out), (SEC / 2, SEC));
    // and it edits apart from the video
    m.set_volume(a, 0.5, false).unwrap();
    m.set_fades(a, 0, 0, false).unwrap();
    assert!((clip(&m, a).volume - 0.5).abs() < 1e-6);
    assert!((clip(&m, ids[1]).volume - 1.0).abs() < 1e-6);
    assert_eq!((clip(&m, a).fade_in, clip(&m, a).fade_out), (0, 0));
    assert!(clip(&m, ids[1]).muted);
}

#[test]
fn a_sound_fade_changes_neither_the_volume_nor_the_picture_and_undoes_in_one_step() {
    let (m, _d, ids) = two_clips();
    m.set_fades(ids[1], SEC / 2, SEC, false).unwrap();
    let c = clip(&m, ids[1]);
    assert_eq!((c.fade_in, c.fade_out), (SEC / 2, SEC));
    assert!((c.volume - 1.0).abs() < 1e-6 && (c.opacity - 1.0).abs() < 1e-6);
    assert!(!c.muted);
    // the neighbour is untouched
    assert_eq!((clip(&m, ids[0]).fade_in, clip(&m, ids[0]).fade_out), (0, 0));
    // a slider drag (merge) is one undo step, and the last value wins
    m.set_fades(ids[1], SEC / 4, SEC, true).unwrap();
    m.set_fades(ids[1], SEC / 2, SEC / 2, true).unwrap();
    assert_eq!((clip(&m, ids[1]).fade_in, clip(&m, ids[1]).fade_out), (SEC / 2, SEC / 2));
    m.undo();
    assert_eq!((clip(&m, ids[1]).fade_in, clip(&m, ids[1]).fade_out), (SEC / 2, SEC));
    m.redo();
    assert_eq!((clip(&m, ids[1]).fade_in, clip(&m, ids[1]).fade_out), (SEC / 2, SEC / 2));
    m.set_fades(ids[1], 0, 0, false).unwrap();
    assert_eq!((clip(&m, ids[1]).fade_in, clip(&m, ids[1]).fade_out), (0, 0));
}

#[test]
fn a_fade_longer_than_the_clip_allows_is_kept_inside_it() {
    let (m, _d, ids) = two_clips();
    m.set_fades(ids[0], 10 * SEC, 10 * SEC, false).unwrap();
    let c = clip(&m, ids[0]);
    assert!(c.fade_in + c.fade_out <= c.duration);
}

#[test]
fn a_fade_follows_a_split_and_a_duplicate() {
    let (m, _d, ids) = two_clips();
    m.set_fades(ids[1], SEC / 2, SEC, false).unwrap();
    m.set_playhead(3 * SEC + SEC / 2);
    let right = m.split(ids[1]).unwrap();
    let (l, r) = (clip(&m, ids[1]), clip(&m, right));
    // the fade in stays on the first piece, the fade out goes with the last
    assert_eq!((l.fade_in, l.fade_out), (SEC / 2, 0));
    assert_eq!((r.fade_in, r.fade_out), (0, SEC));
    assert_eq!(l.start + l.duration, r.start);
    m.set_fades(ids[0], SEC / 2, 0, false).unwrap();
    let copy = m.duplicate(ids[0]).unwrap();
    assert_eq!(clip(&m, copy).fade_in, SEC / 2, "a duplicate keeps the fade");
}

#[test]
fn a_fade_survives_a_save_and_reopen_and_a_change_of_length() {
    let (m, d, ids) = two_clips();
    m.set_fades(ids[1], SEC / 4, SEC / 2, false).unwrap();
    let path = d.join("fades.fcproj").to_string_lossy().into_owned();
    m.save_project(path.clone()).unwrap();
    let n = MobileSession::new();
    let t = n.open_project(path).unwrap();
    let c = lane(&t, LaneKind::Main).clips.iter().find(|c| c.id == ids[1]).cloned().unwrap();
    assert_eq!((c.fade_in, c.fade_out), (SEC / 4, SEC / 2));
    // trimming the clip's end keeps the fade out on the new end, inside the clip
    m.trim(ids[1], false, -SEC).unwrap();
    let c = clip(&m, ids[1]);
    assert_eq!(c.duration, 2 * SEC);
    assert_eq!((c.fade_in, c.fade_out), (SEC / 4, SEC / 2));
}

#[test]
fn muting_and_unmuting_a_video_or_an_extracted_sound_reads_back_as_the_real_state() {
    let (m, _d, ids) = two_clips();
    assert!(!clip(&m, ids[0]).muted);
    m.set_muted(ids[0], true).unwrap();
    assert!(clip(&m, ids[0]).muted && clip(&m, ids[0]).has_audio);
    m.set_muted(ids[0], false).unwrap();
    assert!(!clip(&m, ids[0]).muted);
    let a = m.extract_audio(ids[1]).unwrap();
    assert!(clip(&m, ids[1]).muted && !clip(&m, a).muted);
    m.set_muted(a, true).unwrap();
    assert!(clip(&m, a).muted);
    m.undo();
    assert!(!clip(&m, a).muted);
}

#[test]
fn every_filter_effect_and_transition_reads_back_as_itself() {
    let (m, _d, ids) = two_clips();
    for f in filter_presets() {
        m.set_filter(ids[0], f.id.clone(), 140.0, false, false).unwrap();
        let c = clip(&m, ids[0]);
        assert_eq!(c.filter, f.id);
        assert!((c.filter_amount - 140.0).abs() < 1e-6, "{} {}", f.id, c.filter_amount);
    }
    m.set_filter(ids[0], String::new(), 0.0, false, false).unwrap();
    assert_eq!(clip(&m, ids[0]).filter, "");
    for e in effect_presets() {
        m.set_effect(ids[0], e.id.clone(), 30.0, false, false).unwrap();
        let c = clip(&m, ids[0]);
        assert_eq!(c.effect, e.id);
        assert!((c.effect_amount - 30.0).abs() < 1e-6, "{} {}", e.id, c.effect_amount);
        assert_eq!(c.filter, "");
    }
    for tr in transition_presets() {
        let id = m.set_transition(Some(ids[0]), Some(ids[1]), tr.id.clone(), 0.4, false).unwrap().unwrap();
        let t = m.timeline().unwrap();
        let found = t.transitions.iter().find(|x| x.id == id).unwrap();
        assert_eq!(found.preset, tr.id);
        assert_eq!(t.transitions.len(), 1, "a new transition replaces the old one");
    }
}

#[test]
fn a_filter_drag_is_one_undo_step_and_apply_to_all_reaches_every_picture() {
    let (m, _d, ids) = two_clips();
    m.set_filter(ids[0], "warm".into(), 100.0, false, false).unwrap();
    m.set_filter(ids[0], "warm".into(), 120.0, true, false).unwrap();
    m.set_filter(ids[0], "warm".into(), 160.0, true, false).unwrap();
    m.undo();
    assert_eq!(clip(&m, ids[0]).filter_amount, 100.0);
    m.set_filter(ids[0], "cool".into(), 80.0, false, true).unwrap();
    assert!(main_clips(&m).iter().all(|c| c.filter == "cool"));
}

#[test]
fn transitions_go_between_clips_and_at_the_ends() {
    let (m, _d, ids) = two_clips();
    let cut = m.set_transition(Some(ids[0]), Some(ids[1]), "dissolve".into(), 0.4, false).unwrap().unwrap();
    let intro = m.set_transition(None, Some(ids[0]), "fade".into(), 0.5, false).unwrap().unwrap();
    let t = m.timeline().unwrap();
    let c = t.transitions.iter().find(|x| x.id == cut).unwrap();
    assert_eq!((c.from, c.to, c.duration), (Some(ids[0]), Some(ids[1]), 12 * SEC / 30));
    // centred on the cut, which moved: the clips gave up the footage they lacked
    let first = &main_clips(&m)[0];
    assert_eq!(c.start + c.duration / 2, first.start + first.duration, "centred on the cut");
    let i = t.transitions.iter().find(|x| x.id == intro).unwrap();
    assert_eq!((i.from, i.to, i.start), (None, Some(ids[0]), 0));
    assert_eq!(t.selected_transition, Some(intro));
    m.select(None).unwrap();
    assert_eq!(m.timeline().unwrap().selected_transition, None, "selecting nothing clears a transition too");
    m.set_transition_duration(cut, 0.6).unwrap();
    assert_eq!(m.timeline().unwrap().transitions.iter().find(|x| x.id == cut).unwrap().duration, 18 * SEC / 30);
    // too long: held to the shorter clip
    m.set_transition_duration(cut, 9.0).unwrap();
    assert!(m.timeline().unwrap().transitions.iter().find(|x| x.id == cut).unwrap().duration <= 2 * SEC);
    m.set_transition(Some(ids[0]), Some(ids[1]), String::new(), 0.4, false).unwrap();
    assert_eq!(m.timeline().unwrap().transitions.len(), 1);
}

#[test]
fn opacity_mirror_and_flip_round_trip() {
    let (m, _d, ids) = two_clips();
    m.set_opacity(ids[0], 0.25, false, false).unwrap();
    m.set_flip(ids[0], true, true).unwrap();
    m.set_flip(ids[0], false, true).unwrap();
    let c = clip(&m, ids[0]);
    assert_eq!((c.opacity, c.mirrored, c.flipped), (0.25, true, true));
    m.set_flip(ids[0], true, false).unwrap();
    assert!(!clip(&m, ids[0]).mirrored);
    m.set_opacity(ids[0], 0.5, false, true).unwrap();
    assert!(main_clips(&m).iter().all(|c| c.opacity == 0.5));
}

#[test]
fn text_is_added_at_the_playhead_styled_and_blank_text_removes_it() {
    let (m, _d, _) = two_clips();
    m.set_playhead(SEC);
    assert_eq!(m.add_text("   ".into()).unwrap(), None);
    let id = m.add_text("Hello".into()).unwrap().unwrap();
    let t = m.timeline().unwrap();
    let overlay = lane(&t, LaneKind::Overlay);
    let c = overlay.clips.iter().find(|c| c.id == id).unwrap();
    assert_eq!((c.kind, c.start, c.duration, c.text.as_str()), (ClipKind::Text, SEC, 4 * SEC, "Hello"));
    assert_eq!(overlay.index, 1);
    let st = m.text_style(id).unwrap();
    assert_eq!((st.align, st.color, st.background), (text::TextAlign::Center, 0xffff_ffff, None));
    assert!((st.width - 1.0).abs() < 1e-6, "{}", st.width);
    let boxed = m.text_preset_style(id, "pop".into()).unwrap();
    m.set_text_style(id, boxed.clone(), false, false).unwrap();
    let back = m.text_style(id).unwrap();
    assert_eq!((back.background, back.font_style.as_str()), (boxed.background, "Bold"));
    m.set_text_style(id, text::TextStyle { width: 0.5, align: text::TextAlign::Left, ..back }, false, false).unwrap();
    let back = m.text_style(id).unwrap();
    assert_eq!(back.align, text::TextAlign::Left);
    assert!((back.width - 0.5).abs() < 0.01);
    m.set_text(id, "World".into()).unwrap();
    assert_eq!(clip(&m, id).text, "World");
    let p = m.placement(id).unwrap();
    assert!(p.width > 0.0 && p.height > 0.0, "{p:?}");
    m.set_text(id, "".into()).unwrap();
    assert!(m.timeline().unwrap().lanes.iter().all(|l| l.clips.iter().all(|c| c.id != id)));
    assert!(!m.fonts().is_empty());
}

#[test]
fn trimming_the_main_track_ripples_and_an_overlay_stops_at_its_neighbour() {
    let (m, _d, ids) = two_clips();
    let applied = m.trim(ids[0], false, -SEC / 2).unwrap();
    assert_eq!(applied, -SEC / 2);
    assert_eq!(main_clips(&m)[1].start, SEC + SEC / 2);
    let applied = m.trim(ids[1], true, SEC / 2).unwrap();
    assert_eq!(applied, SEC / 2);
    assert_eq!(main_clips(&m)[1].duration, 2 * SEC + SEC / 2);
    // overlays
    m.set_playhead(0);
    let a = m.add_text("A".into()).unwrap().unwrap();
    m.move_clip(a, 1, 0).unwrap();
    m.set_playhead(5 * SEC);
    let b = m.add_text("B".into()).unwrap().unwrap();
    m.move_clip(b, 1, 5 * SEC).unwrap();
    assert_eq!(clip(&m, b).start, 5 * SEC);
    let applied = m.trim(a, false, 3 * SEC).unwrap();
    assert_eq!(applied, SEC, "stops at the next text");
}

#[test]
fn overlay_text_can_move_earlier_on_the_timeline() {
    let (m, _d, _) = two_clips();
    m.set_playhead(6 * SEC);
    let text = m.add_text("Move left".into()).unwrap().unwrap();
    m.move_clip(text, 1, 6 * SEC).unwrap();
    m.move_clip(text, 1, 2 * SEC).unwrap();
    assert_eq!(clip(&m, text).start, 2 * SEC);
}

#[test]
fn main_video_clip_can_be_moved_to_an_overlay_track() {
    let (m, _d, ids) = two_clips();
    let moved = ids[0];
    m.move_clip(moved, 1, 0).unwrap();
    let t = m.timeline().unwrap();
    assert!(t.lanes.iter().filter(|l| l.kind == LaneKind::Main).flat_map(|l| &l.clips).all(|c| c.id != moved));
    let overlay = t.lanes.iter().find(|l| l.kind == LaneKind::Overlay && l.index == 1).unwrap();
    assert!(overlay.clips.iter().any(|c| c.id == moved));
}

#[test]
fn moving_to_an_occupied_requested_overlay_lane_returns_an_error_instead_of_redirecting() {
    let (m, _d, ids) = two_clips();
    m.move_clip(ids[0], 1, 0).unwrap(); // V2 at time zero

    let result = m.move_clip(ids[1], 1, 0); // V2 is occupied at this time
    assert!(result.is_err(), "an explicit V2 drop must not silently fall back to V3 or V4");

    let timeline = m.timeline().unwrap();
    let v2 = timeline.lanes.iter()
        .find(|lane| lane.kind == LaneKind::Overlay && lane.index == 1)
        .expect("V2 remains present");
    assert!(v2.clips.iter().any(|clip| clip.id == ids[0]));
    assert!(!v2.clips.iter().any(|clip| clip.id == ids[1]));
    assert!(timeline.lanes.iter()
        .filter(|lane| lane.kind == LaneKind::Overlay && lane.index > 1)
        .flat_map(|lane| &lane.clips)
        .all(|clip| clip.id != ids[1]));
}

#[test]
fn requested_v4_and_v5_lanes_are_created_even_when_lower_overlays_are_empty() {
    let (m, _d, ids) = two_clips();
    m.move_clip(ids[0], 3, 0).unwrap(); // V4 (zero-based index 3)
    let t = m.timeline().unwrap();
    let v4 = t.lanes.iter().find(|l| l.kind == LaneKind::Overlay && l.index == 3).unwrap();
    assert!(v4.clips.iter().any(|c| c.id == ids[0]));

    // A fresh sequence with only V1 must materialize every missing lane up to V5.
    let (m, _d, ids) = two_clips();
    m.move_clip(ids[0], 4, 0).unwrap(); // V5
    let t = m.timeline().unwrap();
    let v5 = t.lanes.iter().find(|l| l.kind == LaneKind::Overlay && l.index == 4).unwrap();
    assert!(v5.clips.iter().any(|c| c.id == ids[0]));
}

#[test]
fn failed_overlay_import_rolls_back_the_imported_project_item() {
    let (m, dir, ids) = two_clips();
    m.move_clip(ids[0], 1, 0).unwrap(); // Occupy V2 at the playhead.
    let before = m.lock().project.items.len();
    let path = movie(&dir, "occupied-overlay.mp4", DemoScene::Plasma, 48);

    let result = m.add_media_to_overlay(vec![path], 1);
    assert!(result.is_err(), "placing into occupied V2 must fail");
    assert_eq!(m.lock().project.items.len(), before,
        "a failed placement must not leave imported media orphaned in the project bin");
}

#[test]
fn imported_video_can_be_placed_directly_on_v3_with_its_audio_preserved() {
    let (m, dir, _ids) = two_clips();
    let path = movie(&dir, "direct-overlay.mp4", DemoScene::Plasma, 48);
    let added = m.add_media_to_overlay(vec![path], 2).unwrap(); // V3
    assert_eq!(added.len(), 1);
    let timeline = m.timeline().unwrap();
    let v3 = timeline.lanes.iter().find(|lane| lane.kind == LaneKind::Overlay && lane.index == 2).unwrap();
    let video = v3.clips.iter().find(|clip| clip.id == added[0]).unwrap();
    assert!(video.has_audio, "the overlay video must retain its audio stream");
    assert!(timeline.lanes.iter().filter(|lane| lane.kind == LaneKind::Main)
        .flat_map(|lane| &lane.clips).all(|clip| clip.id != added[0]));
    assert!(timeline.lanes.iter().filter(|lane| lane.kind == LaneKind::Audio)
        .flat_map(|lane| &lane.clips)
        .any(|clip| clip.start == video.start && clip.duration == video.duration));
}

#[test]
fn overlay_video_clip_can_return_to_gapless_main_track() {
    let (m, _d, ids) = two_clips();
    let moved = ids[0];
    m.move_clip(moved, 1, 0).unwrap();
    m.move_clip(moved, 0, 0).unwrap();
    let main = main_clips(&m);
    assert!(main.iter().any(|c| c.id == moved));
    assert_eq!(main[0].start, 0);
    for pair in main.windows(2) {
        assert_eq!(pair[1].start, pair[0].start + pair[0].duration);
    }
    assert!(m.timeline().unwrap().lanes.iter()
        .filter(|l| l.kind == LaneKind::Overlay)
        .flat_map(|l| &l.clips).all(|c| c.id != moved));
}

#[test]
fn empty_overlay_lanes_are_not_listed_but_occupied_ones_stay() {
    let (m, d, ids) = two_clips();
    // a third clip, so the main track is never emptied by the moves below
    let third = m.add_media(vec![movie(&d, "third.mp4", DemoScene::Plasma, 48)]).unwrap()[0];
    let overlays = |m: &MobileSession| -> Vec<i32> {
        m.timeline().unwrap().lanes.iter().filter(|l| l.kind == LaneKind::Overlay).map(|l| l.index).collect()
    };
    assert!(overlays(&m).is_empty());

    m.move_clip(ids[0], 1, 0).unwrap(); // V2
    assert_eq!(overlays(&m), vec![1]);

    m.move_clip(third, 3, 0).unwrap(); // V4; the engine creates V3 empty below it
    assert_eq!(overlays(&m), vec![3, 1], "empty V3 stays hidden, V4 is listed above V2");

    m.move_clip(ids[0], 0, 0).unwrap(); // V2 -> V1: V2 is now empty
    assert_eq!(overlays(&m), vec![3], "V2 disappears once empty; V4 keeps its clip");
    let v4_has_clip = m.timeline().unwrap().lanes.iter()
        .any(|l| l.kind == LaneKind::Overlay && l.index == 3 && l.clips.iter().any(|c| c.id == third));
    assert!(v4_has_clip);

    m.move_clip(third, 0, 0).unwrap(); // V4 -> V1
    assert!(overlays(&m).is_empty());
}

#[test]
fn reordering_moves_a_main_track_clip_and_keeps_the_track_gapless() {
    let (m, d, ids) = two_clips();
    m.set_playhead(5 * SEC);
    let c = m.add_media(vec![movie(&d, "c.mp4", DemoScene::Plasma, 24)]).unwrap()[0];
    m.reorder(ids[0], 2).unwrap();
    let main = main_clips(&m);
    assert_eq!(main.iter().map(|c| c.id).collect::<Vec<_>>(), vec![ids[1], c, ids[0]]);
    assert_eq!(main[0].start, 0);
    assert_eq!(main[1].start, main[0].duration);
    assert_eq!(main[2].start, main[1].start + main[1].duration);
    m.reorder(ids[0], 0).unwrap();
    assert_eq!(main_clips(&m)[0].id, ids[0]);
    assert_eq!(m.timeline().unwrap().duration, 6 * SEC);
    m.undo();
    assert_eq!(main_clips(&m)[2].id, ids[0], "a reorder is one undo step");
}

#[test]
fn blank_clips_and_aspect_ratios() {
    let (m, _d, ids) = two_clips();
    m.set_playhead(SEC);
    let blank = m.add_blank().unwrap();
    let b = clip(&m, blank);
    assert_eq!((b.kind, b.start, b.duration), (ClipKind::Blank, 2 * SEC, 4 * SEC));
    assert_eq!(main_clips(&m)[2].id, ids[1]);
    let t = m.set_aspect(16, 9).unwrap();
    assert_eq!((t.width, t.height), (1920, 1080));
    assert_eq!(frame_size_for(4, 5), vec![1080, 1350]);
    assert_eq!(frame_size_for(21, 9), vec![2520, 1080]);
}

#[test]
fn another_aspect_ratio_and_back_gives_the_same_pictures() {
    let (m, _d, ids) = two_clips();
    m.set_placement(ids[0], 300.0, 500.0, 2.0, 15.0, false).unwrap();
    let text = m.add_text("Hi".into()).unwrap().unwrap();
    let look =
        |m: &MobileSession| [ids[0], ids[1], text].map(|c| m.placement(c).unwrap()).map(|p| [p.x, p.y, p.width * p.scale, p.height * p.scale, p.rotation]);
    let before = look(&m);
    // a 16:9 picture fills a 16:9 frame
    m.set_aspect(16, 9).unwrap();
    let b = m.placement(ids[1]).unwrap();
    assert!((b.width * b.scale - 1920.0).abs() < 0.5 && (b.x, b.y) == (960.0, 540.0), "{b:?}");
    m.set_aspect(1, 1).unwrap();
    m.set_aspect(9, 16).unwrap();
    for (a, b) in before.iter().flatten().zip(look(&m).iter().flatten()) {
        assert!((a - b).abs() < 1e-6, "{before:?} became {:?}", look(&m));
    }
    m.undo();
    assert_eq!(m.timeline().unwrap().height, 1080, "each change is one undo step: back to 1:1");
}

#[test]
fn edits_across_a_text_never_fail_and_later_items_follow_the_main_track() {
    let (m, _d, ids) = two_clips();
    // a text across the cut at 2 s, and one later
    m.set_playhead(SEC);
    let across = m.add_text("across".into()).unwrap().unwrap();
    m.set_playhead(4 * SEC);
    let later = m.add_text("later".into()).unwrap().unwrap();
    let starts = |m: &MobileSession| (clip(m, across).start, clip(m, later).start);
    // the clips have no spare footage: the cut gives up 0.4 s
    m.set_transition(Some(ids[0]), Some(ids[1]), "dissolve".into(), 0.4, false).unwrap().unwrap();
    assert_eq!(starts(&m), (SEC, 4 * SEC - 12 * SEC / 30), "a transition");
    m.undo();
    m.set_speed(ids[0], 2.0).unwrap();
    assert_eq!(starts(&m), (SEC, 3 * SEC), "twice as fast");
    m.undo();
    m.trim(ids[0], false, -SEC / 2).unwrap();
    assert_eq!(starts(&m), (SEC, 4 * SEC - SEC / 2), "a trim");
    m.undo();
    m.delete_clip(ids[0]).unwrap();
    assert_eq!(starts(&m), (SEC, 2 * SEC), "a delete");
    assert_eq!(clip(&m, across).duration, 4 * SEC, "nothing is cut");
    m.undo();
    assert_eq!(starts(&m), (SEC, 4 * SEC));
}

#[test]
fn captions_follow_the_footage_they_were_made_from() {
    let (m, _d, ids) = two_clips();
    // a caption one second into the second clip (2 s to 5 s)
    m.execute("captions.add".into(), json!({"seconds": 3.0, "durationSeconds": 1.0}).to_string()).unwrap();
    let at = |m: &MobileSession| m.timeline().unwrap().captions.iter().map(|c| c.start).collect::<Vec<_>>();
    m.delete_clip(ids[0]).unwrap();
    assert_eq!(at(&m), vec![SEC], "the clip before it went");
    m.undo();
    assert_eq!((at(&m), main_clips(&m).len()), (vec![3 * SEC], 2), "one undo step");
    m.set_speed(ids[1], 2.0).unwrap();
    assert_eq!(at(&m), vec![2 * SEC + SEC / 2], "twice as fast");
    m.undo();
    m.trim(ids[1], true, SEC / 2).unwrap();
    assert_eq!(at(&m), vec![2 * SEC + SEC / 2], "half a second trimmed off its head");
    m.undo();
    m.reorder(ids[1], 0).unwrap();
    assert_eq!(at(&m), vec![SEC], "moved first");
    m.undo();
    m.delete_clip(ids[1]).unwrap();
    assert!(at(&m).is_empty(), "its footage is gone");
    m.undo();
    assert_eq!(at(&m), vec![3 * SEC]);
}

#[test]
fn a_main_track_insert_moves_later_items_whole_and_cuts_none() {
    let (m, _d, ids) = two_clips();
    // a text and a caption across the cut at 2 s, and one of each after it
    m.set_playhead(SEC);
    let across = m.add_text("across".into()).unwrap().unwrap();
    m.set_playhead(3 * SEC);
    let later = m.add_text("later".into()).unwrap().unwrap();
    m.execute("captions.add".into(), json!({"seconds": 1.0, "durationSeconds": 2.0}).to_string()).unwrap();
    m.execute("captions.add".into(), json!({"seconds": 3.0, "durationSeconds": 1.0}).to_string()).unwrap();
    let above = |m: &MobileSession| m.timeline().unwrap().lanes.iter().filter(|l| l.kind != LaneKind::Main).map(|l| l.clips.len()).sum::<usize>();
    let captions = |m: &MobileSession| m.timeline().unwrap().captions.iter().map(|c| (c.start, c.duration)).collect::<Vec<_>>();
    let texts = above(&m);
    let check = |m: &MobileSession, grew: i64, what: &str| {
        assert_eq!((clip(m, across).start, clip(m, across).duration), (SEC, 4 * SEC), "{what}: an item across the insert stays whole");
        assert_eq!(clip(m, later).start, 3 * SEC + grew, "{what}: a later item moves with the main track");
        assert_eq!(above(m), texts, "{what}: nothing is cut");
        assert_eq!(captions(m), vec![(SEC, 2 * SEC), (3 * SEC + grew, SEC)], "{what}: captions move the same way");
    };
    // the blank goes after the clip under the playhead: at 2 s
    m.set_playhead(SEC);
    m.add_blank().unwrap();
    check(&m, 4 * SEC, "blank");
    m.undo();
    check(&m, 0, "undone");
    m.select(Some(ids[0])).unwrap();
    m.duplicate(ids[0]).unwrap();
    check(&m, 2 * SEC, "duplicate");
    m.undo();
    // the still goes in at the playhead, after the start of the text across it
    m.set_playhead(SEC + SEC / 2);
    m.freeze(ids[0]).unwrap();
    check(&m, 4 * SEC, "freeze");
    m.undo();
    check(&m, 0, "each insert is one undo step");
}

#[test]
fn the_renderer_draws_mixes_and_reads_waveforms_without_the_session() {
    let (m, _d, ids) = two_clips();
    let r = m.renderer().unwrap();
    let f = r.frame(SEC / 2, 480, true, None).unwrap();
    assert_eq!((f.width, f.height), (270, 480));
    assert_eq!(f.rgba.len(), 270 * 480 * 4);
    // an edit while the snapshot is held doesn't change it
    m.delete_clip(ids[0]).unwrap();
    assert!(r.revision() < m.poll().revision);
    let pcm = r.mix(0, 4800);
    assert_eq!(pcm.len(), 4800 * 8);
    assert!(pcm.chunks(4).any(|b| f32::from_le_bytes([b[0], b[1], b[2], b[3]]).abs() > 1e-4), "the demo scene has sound");
    let c = clip(&m, ids[1]);
    let peaks = r.peaks(c.item, 0, SEC, 50);
    assert_eq!(peaks.len(), 50);
    assert!(peaks.iter().all(|p| (0.0..=1.0).contains(p)));
    let thumb = r.thumbnail(c.item, 0, 64, None).unwrap();
    assert!(thumb.width <= 128 && thumb.width > 0);
    let token = render::CancelToken::new();
    token.cancel();
    assert!(r.frame(0, 480, false, Some(token)).is_err());
}

#[test]
fn a_saved_project_opens_with_everything_in_place() {
    let (m, d, ids) = two_clips();
    m.set_filter(ids[0], "vivid".into(), 60.0, false, false).unwrap();
    m.set_transition(Some(ids[0]), Some(ids[1]), "push_left".into(), 0.4, false).unwrap();
    let path = d.join("project.fcproj").to_string_lossy().into_owned();
    m.save_project(path.clone()).unwrap();
    assert!(!m.poll().dirty);
    let n = MobileSession::new();
    let t = n.open_project(path).unwrap();
    assert_eq!(lane(&t, LaneKind::Main).clips.len(), 2);
    assert_eq!(lane(&t, LaneKind::Main).clips[0].filter, "vivid");
    assert_eq!(t.transitions[0].preset, "push_left");
}

#[test]
fn bad_input_is_an_error_not_a_crash() {
    let (m, _d, ids) = two_clips();
    assert!(m.split(999_999).is_err());
    assert!(m.set_filter(ids[0], "nope".into(), 50.0, false, false).is_err());
    assert!(m.set_effect(ids[0], "nope".into(), 50.0, false, false).is_err());
    assert!(m.set_transition(Some(ids[0]), Some(ids[1]), "nope".into(), 0.4, false).is_err());
    assert!(m.set_volume(ids[0], f64::INFINITY, false).is_ok());
    assert!(m.trim(ids[0], true, i64::MIN).is_ok());
    assert!(m.add_media(vec!["/no/such/file.mp4".into()]).is_err());
    assert!(m.execute("no.such.command".into(), String::new()).is_err());
    assert!(m.execute("timeline.razor".into(), "not json".into()).is_err());
    assert!(m.renderer().unwrap().frame(i64::MAX, 0, false, None).is_ok());
    assert!(m.renderer().unwrap().peaks(999_999, 0, SEC, 10).is_empty());
}

#[test]
fn the_export_plan_keeps_the_aspect_and_an_export_finishes() {
    let (m, d, _) = two_clips();
    let settings = |short, q| export::ExportSettings { short_side: short, fps: 30, quality: q };
    let p = m.export_plan(settings(1080, export::ExportQuality::High)).unwrap();
    assert_eq!((p.width, p.height), (1080, 1920));
    let low = m.export_plan(settings(1080, export::ExportQuality::Low)).unwrap();
    assert!(low.estimated_bytes < p.estimated_bytes);
    assert_eq!(m.export_plan(settings(2160, export::ExportQuality::High)).unwrap().height, 3840);
    let out = d.join("out.mp4").to_string_lossy().into_owned();
    let job = m.start_export(out.clone(), settings(720, export::ExportQuality::Low)).unwrap();
    let start = std::time::Instant::now();
    let status = loop {
        let st = m.export_status(job).unwrap();
        if st.finished || start.elapsed().as_secs() > 120 {
            break st;
        }
        std::thread::sleep(std::time::Duration::from_millis(100));
    };
    assert!(status.finished && status.error.is_none(), "{status:?}");
    assert!(std::fs::metadata(&out).unwrap().len() > 1000);
}

/// Opens a real clip when `FILMCRAFT_TEST_CLIP` names one, checks the frame size and timing.
#[test]
fn a_real_clip_opens_and_plays_when_one_is_given() {
    let Ok(path) = std::env::var("FILMCRAFT_TEST_CLIP") else { return };
    let m = MobileSession::new();
    let info = m.open_clip(path).unwrap();
    assert!(info.width > 0 && info.duration > 0, "{info:?}");
    let frame = TICKS_PER_SECOND * info.rate_den / info.rate_num;
    let r = m.renderer().unwrap();
    let start = std::time::Instant::now();
    for i in 0..30 {
        let f = r.frame(i * frame, 1080, false, None).unwrap();
        assert_eq!(f.time, i * frame);
    }
    eprintln!("{}x{}: {:.1} ms a frame", info.width, info.height, start.elapsed().as_secs_f64() * 1000.0 / 30.0);
}

#[test]
fn clips_are_moved_scaled_and_turned_on_the_frame_as_one_undo_step() {
    let (m, _d, ids) = two_clips();
    let p = m.placement(ids[0]).unwrap();
    // a 16:9 clip fitted across a 9:16 frame, centred
    assert_eq!((p.x, p.y), (540.0, 960.0));
    assert!((p.width * p.scale - 1080.0).abs() < 2.0, "{p:?}");
    m.set_placement(ids[0], 300.0, 700.0, p.scale * 0.5, 15.0, true).unwrap();
    m.set_placement(ids[0], 320.0, 720.0, p.scale * 0.5, 30.0, true).unwrap();
    let q = m.placement(ids[0]).unwrap();
    assert_eq!((q.x, q.y, q.rotation), (320.0, 720.0, 30.0));
    assert!((q.scale - p.scale * 0.5).abs() < 1e-9);
    m.undo();
    assert_eq!(m.placement(ids[0]).unwrap().x, 540.0);
    assert!(m.set_placement(ids[0], f64::NAN, 0.0, 1.0, 0.0, false).is_err());
    // text moves by its centre too
    let t = m.add_text("Hi".into()).unwrap().unwrap();
    let before = m.placement(t).unwrap();
    m.set_placement(t, before.x + 100.0, before.y - 50.0, before.scale, 0.0, false).unwrap();
    let after = m.placement(t).unwrap();
    assert!((after.x - before.x - 100.0).abs() < 2.0 && (after.y - before.y + 50.0).abs() < 2.0, "{before:?} {after:?}");
}

#[test]
fn look_and_transition_previews_draw_the_clip_with_the_candidate() {
    let (m, _d, ids) = two_clips();
    let r = m.renderer().unwrap();
    let plain = r.frame(SEC / 2, 120, false, None).unwrap();
    let noir = r.look_preview(ids[0], "noir".into(), 100.0, String::new(), 0.0, SEC / 2, 120).unwrap();
    // cut to the clip's own 16:9 picture, not the portrait frame around it
    assert!(noir.width > noir.height && (f64::from(noir.width) / f64::from(noir.height) - 16.0 / 9.0).abs() < 0.1, "{}x{}", noir.width, noir.height);
    // grey: red, green and blue close together
    let grey =
        noir.rgba.chunks(4).filter(|p| p[3] > 0).all(|p| (i32::from(p[0]) - i32::from(p[1])).abs() < 12 && (i32::from(p[1]) - i32::from(p[2])).abs() < 12);
    assert!(grey);
    // the project itself is untouched
    assert_eq!(clip(&m, ids[0]).filter, "");
    let fx = r.look_preview(ids[0], String::new(), 0.0, "gaussian".into(), 80.0, SEC / 2, 120).unwrap();
    assert_ne!(fx.rgba, plain.rgba);
    for tr in ["dissolve", "push_left", "fade"] {
        let f = r.transition_preview(Some(ids[0]), Some(ids[1]), tr.into(), 0.8, 120).unwrap();
        assert!(f.width > 0);
    }
    assert!(r.transition_preview(None, Some(ids[0]), "fade".into(), 0.4, 120).is_ok());
    assert!(r.transition_preview(None, None, "fade".into(), 0.4, 120).is_err());
}

#[test]
fn picker_samples_draw_every_effect_and_transition() {
    for e in effect_presets() {
        let f = samples::effect_sample(e.id.clone(), 50.0, 96).unwrap();
        assert_eq!((f.width, f.height), (96, 96), "{}", e.id);
    }
    let plain = samples::transition_sample(String::new(), 0.4, 96).unwrap();
    let mut differ = 0;
    for t in transition_presets() {
        let f = samples::transition_sample(t.id.clone(), 0.4, 96).unwrap();
        if f.rgba != plain.rgba {
            differ += 1;
        }
    }
    // nearly every transition shows something different from a plain cut
    assert!(differ >= transition_presets().len() - 3, "{differ}");
    // the tiles play: the same transition differs along the way, and odd progress is clamped
    let first = transition_presets().into_iter().next().unwrap();
    let early = samples::transition_sample(first.id.clone(), 0.1, 96).unwrap();
    let late = samples::transition_sample(first.id.clone(), 0.9, 96).unwrap();
    assert_ne!(early.rgba, late.rgba);
    assert!(samples::transition_sample(first.id.clone(), f64::NAN, 96).is_ok());
    assert!(samples::transition_sample(first.id, 7.0, 96).is_ok());
    assert!(samples::effect_sample("nope".into(), 50.0, 96).is_err());
}

#[test]
fn new_text_sits_in_the_middle_of_the_frame_and_stays_centred_when_edited() {
    let m = MobileSession::new();
    m.new_project("P".into(), 1080, 1920, 30).unwrap();
    let id = m.add_text("Hello".into()).unwrap().unwrap();
    let p = m.placement(id).unwrap();
    assert!((p.x - 540.0).abs() < 1.0 && (p.y - 960.0).abs() < 1.0, "{p:?}");
    // the outline hugs the word, not the box it wraps in
    assert!(p.width > 150.0 && p.width < 900.0 && p.height > 50.0 && p.height < 300.0, "{p:?}");
    m.set_text(id, "Hello\nsecond line".into()).unwrap();
    let q = m.placement(id).unwrap();
    assert!((q.y - 960.0).abs() < 1.0 && q.height > p.height * 1.5, "{q:?}");
    let st = m.text_style(id).unwrap();
    m.set_text_style(id, text::TextStyle { width: 0.5, ..st }, false, false).unwrap();
    let r = m.placement(id).unwrap();
    assert!((r.x - 540.0).abs() < 1.0 && (r.y - 960.0).abs() < 1.0 && r.width <= 540.0, "{r:?}");
    // left-aligned, the letters start at the box's left edge (a quarter of the way in)
    m.set_text_style(id, text::TextStyle { width: 0.5, align: text::TextAlign::Left, ..m.text_style(id).unwrap() }, false, false).unwrap();
    let l = m.placement(id).unwrap();
    assert!((l.x - l.width / 2.0 - 270.0).abs() < 2.0, "{l:?}");
    // the text is drawn inside the frame
    let f = m.renderer().unwrap().frame(0, 270, false, None).unwrap();
    let lit = f.rgba.chunks(4).filter(|p| p[0] > 200 && p[1] > 200 && p[2] > 200).count();
    assert!(lit > 50, "{lit}");
}

fn say(text: &str) -> speech::SpeechSettings {
    speech::SpeechSettings { text: text.into(), voice: "basic-female".into(), pace: 1.0, pitch: 0 }
}

#[test]
fn speech_is_heard_first_added_on_an_audio_lane_and_said_again_in_its_place() {
    let (m, d, ids) = two_clips();
    let dir = d.to_string_lossy().into_owned();
    let heard = m.preview_speech(say("Hello there")).unwrap();
    assert!(heard.sample_rate > 0 && heard.pcm.len() > 4000, "{}", heard.pcm.len());
    m.set_playhead(SEC);
    let first = m.add_speech(say("Hello there"), dir.clone()).unwrap();
    let t = m.timeline().unwrap();
    let l = t.lanes.iter().find(|l| l.clips.iter().any(|c| c.id == first)).unwrap();
    // never the hidden lane that carries the videos' sound
    assert_eq!((l.kind, l.index), (LaneKind::Audio, -1));
    let c = clip(&m, first);
    assert!(c.speech && !c.voiceover && c.start == SEC && c.duration > SEC / 2, "{c:?}");
    assert_eq!(c.text, "Hello there");
    assert_eq!(t.selected, Some(first));
    assert_eq!(m.speech_settings(first).unwrap(), say("Hello there"));
    assert!(m.speech_settings(ids[0]).is_none() && !clip(&m, ids[0]).speech);
    // more words: a longer clip where the first was
    let longer = m.edit_speech(first, speech::SpeechSettings { pace: 0.8, ..say("Hello there, this sentence is a good deal longer") }, dir.clone()).unwrap();
    let c2 = clip(&m, longer);
    assert!(c2.start == SEC && c2.duration > c.duration, "{c2:?}");
    assert!(m.timeline().unwrap().lanes.iter().all(|l| l.clips.iter().all(|x| x.id != first)));
    assert_eq!(m.speech_settings(longer).unwrap().pace, 0.8);
    // one undo step back
    m.undo();
    assert_eq!(clip(&m, first).duration, c.duration);
    // a second one at the same time goes on another lane
    let other = m.add_speech(say("Again"), dir).unwrap();
    let t = m.timeline().unwrap();
    let lane_of = |id: u64| t.lanes.iter().find(|l| l.clips.iter().any(|c| c.id == id)).unwrap().index;
    assert_ne!(lane_of(other), lane_of(first));
    assert!(m.preview_speech(say("   ")).is_err());
}

#[test]
fn captions_come_from_what_is_said_fit_the_frame_and_can_be_edited() {
    use filmcraft_project::{Speaker, Transcript, Word};
    let (m, _d, ids) = two_clips();
    assert!(m.timeline().unwrap().captions.is_empty() && m.caption_look().is_none());
    let item = clip(&m, ids[0]).item;
    let w = |text: &str, a: f64, b: f64| Word {
        text: text.into(),
        start: Tick::from_seconds_f64(a),
        end: Tick::from_seconds_f64(b),
        speaker: None,
        confidence: 1.0,
    };
    let heard = Transcript {
        language: "en".into(),
        source: "whisper-tiny".into(),
        speakers: vec![Speaker { name: "Speaker 1".into() }],
        words: vec![w("Hello", 0.1, 0.4), w("phone", 0.45, 0.8), w("world.", 0.85, 1.3)],
    };
    let plain = m.renderer().unwrap().frame(SEC / 2, 270, false, None).unwrap();
    let n = speech::make_captions(&mut m.lock(), vec![(ItemId(item), heard)]).unwrap();
    assert_eq!(n, 1);
    let t = m.timeline().unwrap();
    assert_eq!(t.captions.len(), 1);
    assert_eq!(t.captions[0].text, "Hello phone world.");
    let look = m.caption_look().unwrap();
    assert!((look.scale - 1.0).abs() < 0.01 && look.position == speech::CaptionPosition::Bottom && look.background, "{look:?}");
    // drawn on the picture
    let shown = m.renderer().unwrap().frame(SEC / 2, 270, false, None).unwrap();
    assert_ne!(plain.rgba, shown.rgba);
    let undo_before = m.poll().undo_label;
    for k in 1..=5 {
        let scale = 1.0 + 0.1 * f64::from(k);
        m.set_caption_look(speech::CaptionLook { scale, position: speech::CaptionPosition::Top, background: false }, true).unwrap();
    }
    m.undo();
    // a drag is one undo step
    assert_eq!(m.poll().undo_label, undo_before);
    m.set_caption_look(speech::CaptionLook { scale: 1.5, position: speech::CaptionPosition::Top, background: false }, false).unwrap();
    let look = m.caption_look().unwrap();
    assert!((look.scale - 1.5).abs() < 0.01 && look.position == speech::CaptionPosition::Top && !look.background, "{look:?}");
    let id = t.captions[0].id;
    m.set_caption_text(id, "Hi world".into()).unwrap();
    assert_eq!(m.timeline().unwrap().captions[0].text, "Hi world");
    // without the box the words get a dark edge
    assert!(m.lock().active_sequence().unwrap().caption_tracks[0].style.outline > 0.0);
    // making them again replaces them, on one track, from the kept transcript, in the same look
    assert_eq!(speech::make_captions(&mut m.lock(), vec![]).unwrap(), 1);
    assert_eq!(m.lock().active_sequence().unwrap().caption_tracks.len(), 1);
    assert_eq!(m.caption_look().unwrap(), look);
    m.set_caption_text(m.timeline().unwrap().captions[0].id, " ".into()).unwrap();
    assert!(m.timeline().unwrap().captions.is_empty());
    m.undo();
    assert_eq!(m.timeline().unwrap().captions.len(), 1);
    m.delete_captions().unwrap();
    assert!(m.timeline().unwrap().captions.is_empty());
    m.undo();
    assert_eq!(m.timeline().unwrap().captions.len(), 1);
}

#[test]
fn caption_jobs_need_sound_and_a_known_model_and_report_how_they_end() {
    let m = MobileSession::new();
    m.new_project("P".into(), 1080, 1920, 30).unwrap();
    assert!(m.start_captions("whisper-tiny".into(), "auto".into()).is_err(), "nothing to listen to");
    let (m, _d, _) = two_clips();
    assert!(m.start_captions("whisper-huge".into(), "auto".into()).is_err());
    let job = m.start_captions("whisper-tiny".into(), "en".into()).unwrap();
    let mut st = m.caption_status(job).unwrap();
    for _ in 0..1200 {
        if st.finished {
            break;
        }
        std::thread::sleep(std::time::Duration::from_millis(100));
        st = m.caption_status(job).unwrap();
    }
    // without the model downloaded it says so; with it, the demo scenes' sound has no words
    assert!(st.finished, "{st:?}");
    assert!(st.error.is_some() || st.captions == 0, "{st:?}");
    assert!(m.caption_status(job).is_err(), "a finished job is gone");
    let job = m.start_captions("whisper-tiny".into(), "en".into()).unwrap();
    m.cancel_captions(job);
    for _ in 0..1200 {
        if m.caption_status(job).map(|s| s.finished).unwrap_or(true) {
            break;
        }
        std::thread::sleep(std::time::Duration::from_millis(100));
    }
}

/// Makes captions with the real speech model when `FILMCRAFT_TEST_SPEECH` names a clip of clear
/// English speech (and `FILMCRAFT_DATA_DIR` holds `models/whisper-tiny`).
#[test]
fn captions_from_real_speech() {
    let Ok(path) = std::env::var("FILMCRAFT_TEST_SPEECH") else { return };
    let m = MobileSession::new();
    m.new_project("P".into(), 1080, 1920, 30).unwrap();
    m.add_media(vec![path]).unwrap();
    let t0 = std::time::Instant::now();
    let job = m.start_captions("whisper-tiny".into(), "auto".into()).unwrap();
    let mut st = m.caption_status(job).unwrap();
    while !st.finished {
        std::thread::sleep(std::time::Duration::from_millis(200));
        st = m.caption_status(job).unwrap();
    }
    let t = m.timeline().unwrap();
    let words: Vec<String> = t.captions.iter().map(|c| c.text.replace('\n', " / ")).collect();
    eprintln!("{st:?} in {:.1} s: {words:#?}", t0.elapsed().as_secs_f64());
    assert!(st.error.is_none() && st.captions > 0, "{st:?}");
    assert!(words.join(" ").to_lowercase().contains("fox"));
    // a picture to look at: FILMCRAFT_TEST_SPEECH_PNG names where
    if let Ok(out) = std::env::var("FILMCRAFT_TEST_SPEECH_PNG") {
        let c = &t.captions[1];
        let f = m.renderer().unwrap().frame(c.start + c.duration / 2, 960, false, None).unwrap();
        std::fs::write(out, fx::encode_png(f.rgba, f.width, f.height).unwrap()).unwrap();
    }
}

/// A natural voice says a sentence and the speech model hears it back, when `FILMCRAFT_TEST_VOICES`
/// is set (and `FILMCRAFT_DATA_DIR` holds `models/kokoro-82m` and `models/whisper-tiny`).
#[test]
fn natural_speech_is_heard_back_as_captions() {
    if std::env::var("FILMCRAFT_TEST_VOICES").is_err() {
        return;
    }
    assert!(speech::voice_package().installed);
    let v = speech::voices();
    assert!(v.iter().any(|v| v.natural && v.installed && v.id == "kokoro-heart"), "{v:?}");
    let (m, d, _) = two_clips();
    let t0 = std::time::Instant::now();
    let st = speech::SpeechSettings { text: "Captions and voices are made right on the phone.".into(), voice: "kokoro-heart".into(), pace: 1.0, pitch: 0 };
    let clip = m.add_speech(st, d.to_string_lossy().into_owned()).unwrap();
    eprintln!("speech in {:.1} s: {:?}", t0.elapsed().as_secs_f64(), self::clip(&m, clip).duration as f64 / SEC as f64);
    let job = m.start_captions("whisper-tiny".into(), "en".into()).unwrap();
    let mut s = m.caption_status(job).unwrap();
    while !s.finished {
        std::thread::sleep(std::time::Duration::from_millis(200));
        s = m.caption_status(job).unwrap();
    }
    let words: Vec<String> = m.timeline().unwrap().captions.iter().map(|c| c.text.replace('\n', " ")).collect();
    eprintln!("{s:?}: {words:?}");
    let all = words.join(" ").to_lowercase();
    assert!(all.contains("captions") && all.contains("phone"), "{all}");
}

#[test]
fn words_over_a_video_with_no_words_are_captioned_and_talking_over_is_heard_once() {
    use filmcraft_project::{Transcript, Word};
    let (m, d, ids) = two_clips();
    m.set_playhead(SEC / 2);
    let over = m.add_audio(vec![tone(&d, 1.5)]).unwrap()[0];
    let w = |text: &str, a: f64, b: f64| Word {
        text: text.into(),
        start: Tick::from_seconds_f64(a),
        end: Tick::from_seconds_f64(b),
        speaker: None,
        confidence: 1.0,
    };
    let t = |words: Vec<Word>| Transcript { language: "en".into(), source: "whisper-tiny".into(), speakers: vec![], words };
    let video = clip(&m, ids[0]).item;
    let voice = clip(&m, over).item;
    // the video's own sound has no words: the voice-over above it is captioned
    let n =
        speech::make_captions(&mut m.lock(), vec![(ItemId(video), t(vec![])), (ItemId(voice), t(vec![w("Over", 0.1, 0.4), w("here.", 0.5, 0.9)]))]).unwrap();
    assert_eq!(n, 1);
    let c = &m.timeline().unwrap().captions[0];
    assert_eq!(c.text, "Over here.");
    // the voice-over starts half a second in: its words do too
    assert!(c.start >= SEC / 2, "{c:?}");
    // when the video's sound says something at the same moment, that is what is captioned
    let n = speech::make_captions(&mut m.lock(), vec![(ItemId(video), t(vec![w("Hello", 0.6, 0.9), w("there.", 1.0, 1.3)]))]).unwrap();
    assert_eq!(n, 1);
    assert_eq!(m.timeline().unwrap().captions[0].text, "Hello there.");
}

#[test]
fn a_transition_on_a_cut_without_spare_footage_shortens_the_video_by_its_length() {
    let (m, _d, ids) = two_clips();
    let before = m.timeline().unwrap().duration;
    assert_eq!(before, 5 * SEC);
    // each 2 s / 3 s clip lends a third of itself: the cut takes at most 2 × 2/3 s
    let max = m.max_transition(Some(ids[0]), Some(ids[1]));
    assert!((max - 4.0 / 3.0).abs() < 0.01, "{max}");
    let t = m.set_transition(Some(ids[0]), Some(ids[1]), "dissolve".into(), 0.4, false).unwrap().unwrap();
    let tl = m.timeline().unwrap();
    // 0.2 s off the end of the first clip and the start of the second
    assert_eq!(tl.duration, before - 2 * SEC / 5, "{}", tl.duration);
    let main = main_clips(&m);
    assert_eq!(main[0].duration, 2 * SEC - SEC / 5);
    assert_eq!(main[1].source_in, SEC / 5);
    assert_eq!(tl.transitions.iter().find(|x| x.id == t).unwrap().duration, 2 * SEC / 5);
    // longer: the clips give up a little more; taking it away gives nothing back
    m.set_transition_duration(t, 0.8).unwrap();
    assert_eq!(m.timeline().unwrap().duration, before - 4 * SEC / 5);
    m.set_transition(Some(ids[0]), Some(ids[1]), String::new(), 0.0, false).unwrap();
    assert_eq!(m.timeline().unwrap().duration, before - 4 * SEC / 5);
    // one undo step each
    m.undo();
    m.undo();
    assert_eq!(m.timeline().unwrap().duration, before - 2 * SEC / 5);
    m.undo();
    assert_eq!(m.timeline().unwrap().duration, before);
}

// ---- r5 round: V1 ripple on exit ----

/// A portrait project with `n` main-track clips of 1 s, 2 s, 3 s… (24 fps fixtures).
fn n_clips(n: usize) -> (Arc<MobileSession>, PathBuf, Vec<u64>) {
    let d = tmp();
    let m = MobileSession::new();
    m.new_project("Test".into(), 1080, 1920, 30).unwrap();
    let paths: Vec<String> = (0..n).map(|i| movie(&d, &format!("c{i}.mp4"), DemoScene::Aurora, 24 * (i as i64 + 1))).collect();
    let ids = m.add_media(paths).unwrap();
    (m, d, ids)
}

fn main_ids(m: &MobileSession) -> Vec<u64> {
    main_clips(m).iter().map(|c| c.id).collect()
}

fn audio_lanes_listed(m: &MobileSession) -> usize {
    m.timeline().unwrap().lanes.iter().filter(|l| l.kind == LaneKind::Audio).count()
}

#[test]
fn the_third_of_five_clips_leaving_v1_closes_up_the_fourth_and_fifth() {
    let (m, _d, ids) = n_clips(5);
    assert_eq!(ids.len(), 5);
    let before = main_clips(&m);
    m.move_clip(ids[2], 1, 20 * SEC).unwrap();
    let main = main_clips(&m);
    assert_eq!(main.iter().map(|c| c.id).collect::<Vec<_>>(), vec![ids[0], ids[1], ids[3], ids[4]]);
    assert_eq!((main[0].start, main[1].start), (before[0].start, before[1].start), "earlier clips stay");
    assert_eq!(main[2].start, before[2].start, "the fourth takes the space of the third");
    assert_eq!(main[3].start, before[3].start - before[2].duration);
    assert_eq!((main[2].duration, main[3].duration), (before[3].duration, before[4].duration), "no clip changes length");
    // the moved clip keeps its length, source and sound, and the sound is not a visible lane
    let moved = clip(&m, ids[2]);
    assert_eq!((moved.start, moved.duration, moved.source_in), (20 * SEC, before[2].duration, before[2].source_in));
    assert!(moved.has_audio && moved.audio_clip.is_some());
    assert_eq!(audio_lanes_listed(&m), 0, "linked sound stays inside its clip");
    // the sound of every main clip still sits under its picture
    let s = m.lock();
    let seq = s.active_sequence().unwrap();
    for c in seq.video_tracks.iter().flat_map(|t| t.items.iter()) {
        let a = model::partner(seq, c, TrackKind::Audio).expect("linked sound");
        assert_eq!((a.clip.start, a.clip.duration), (c.start, c.duration));
    }
}

#[test]
fn leaving_v1_first_or_last_moves_only_what_follows() {
    let (m, _d, ids) = n_clips(2);
    let before = main_clips(&m);
    m.move_clip(ids[0], 1, 0).unwrap();
    let main = main_clips(&m);
    assert_eq!((main.len(), main[0].id, main[0].start), (1, ids[1], 0), "the second moves from after the first to 0");
    m.undo();
    assert_eq!(main_clips(&m).iter().map(|c| (c.id, c.start)).collect::<Vec<_>>(), before.iter().map(|c| (c.id, c.start)).collect::<Vec<_>>(), "one undo step");

    let (m, _d, ids) = n_clips(2);
    m.move_clip(ids[1], 1, 0).unwrap();
    let main = main_clips(&m);
    assert_eq!((main.len(), main[0].id, main[0].start), (1, ids[0], 0), "the first stays");
}

#[test]
fn a_gap_that_was_already_on_v1_survives_a_clip_leaving() {
    let (m, _d, ids) = n_clips(5);
    // open a one-second gap before the fourth clip (and its sound), as older projects may have
    {
        let mut s = m.lock();
        s.edit_sequence("gap", |q, _, _| {
            for t in q.video_tracks.iter_mut().take(1).chain(q.audio_tracks.iter_mut().take(1)) {
                for it in t.items.iter_mut().skip(3) {
                    it.start += Tick(SEC);
                }
            }
            Ok(())
        })
        .unwrap();
    }
    let before = main_clips(&m);
    m.move_clip(ids[2], 1, 30 * SEC).unwrap();
    let main = main_clips(&m);
    assert_eq!(main[2].start, before[3].start - before[2].duration, "moved left by the clip's length only");
    assert_eq!(main[2].start - (main[1].start + main[1].duration), SEC, "the old one-second gap is still there");
    assert_eq!(main[3].start - main[2].start, before[4].start - before[3].start);
}

#[test]
fn leaving_v1_never_moves_other_lanes_or_unselected_overlays() {
    let (m, _d, ids) = n_clips(4);
    m.move_clip(ids[3], 1, 7 * SEC).unwrap(); // V2
    let overlay_before = clip(&m, ids[3]);
    m.move_clip(ids[1], 2, 9 * SEC).unwrap(); // V3
    let after = clip(&m, ids[3]);
    assert_eq!((after.start, after.duration), (overlay_before.start, overlay_before.duration));
    assert_eq!(main_ids(&m), vec![ids[0], ids[2]]);
    assert_eq!(audio_lanes_listed(&m), 0);
}

#[test]
fn a_refused_exit_from_v1_changes_nothing() {
    let (m, _d, ids) = n_clips(3);
    m.move_clip(ids[0], 1, 0).unwrap();
    let before: Vec<(u64, i64)> = main_clips(&m).iter().map(|c| (c.id, c.start)).collect();
    assert!(m.move_clip(ids[1], 1, 0).is_err(), "V2 is taken at that time");
    assert_eq!(main_clips(&m).iter().map(|c| (c.id, c.start)).collect::<Vec<_>>(), before);
}

// ---- r5 round: project size from the first media ----

#[test]
fn an_empty_project_takes_the_exact_size_of_the_first_media_and_then_keeps_it() {
    let m = MobileSession::new();
    m.new_project("T".into(), 1080, 1920, 30).unwrap();
    assert!(m.fit_empty_frame(1700, 500).unwrap(), "an unusual 17:5 frame is taken as it is");
    let t = m.timeline().unwrap();
    assert_eq!((t.width, t.height), (1700, 500));
    assert!(!m.poll().can_undo, "a just-made project has nothing to undo");
    assert!(!m.fit_empty_frame(1700, 500).unwrap(), "same size: nothing to do");
    assert!(m.fit_empty_frame(1921, 1081).unwrap());
    let t = m.timeline().unwrap();
    assert_eq!((t.width, t.height), (1920, 1080), "sides are made even for the encoder");
    assert_eq!(m.timeline().unwrap().lanes.len(), 1);
}

#[test]
fn a_project_with_media_is_never_resized_by_a_later_import() {
    let (m, d, _ids) = two_clips();
    let before = m.timeline().unwrap();
    assert!(!m.fit_empty_frame(1920, 1080).unwrap());
    let still = m.add_media(vec![picture(&d)]).unwrap();
    assert_eq!(still.len(), 1);
    let t = m.timeline().unwrap();
    assert_eq!((t.width, t.height), (before.width, before.height));
    // an empty project that gets a picture first and then a video of another shape keeps the first shape
    let m = MobileSession::new();
    m.new_project("T".into(), 1080, 1920, 30).unwrap();
    m.fit_empty_frame(64, 64).unwrap();
    m.add_media(vec![picture(&d)]).unwrap();
    assert!(!m.fit_empty_frame(320, 180).unwrap());
    m.add_media(vec![movie(&d, "wide.mp4", DemoScene::Aurora, 24)]).unwrap();
    let t = m.timeline().unwrap();
    assert_eq!((t.width, t.height), (64, 64));
}

// ---- r5 round: live text editing ----

#[test]
fn typing_into_an_existing_text_shows_at_once_and_cancel_restores_everything() {
    let m = MobileSession::new();
    m.new_project("P".into(), 1080, 1920, 30).unwrap();
    let id = m.add_text("Hello".into()).unwrap().unwrap();
    let boxed = m.text_preset_style(id, "pop".into()).unwrap();
    m.set_text_style(id, boxed.clone(), false, false).unwrap();
    m.forget_history();
    let (style0, place0) = (m.text_style(id).unwrap(), m.placement(id).unwrap());

    m.begin_text_edit(id).unwrap();
    for typed in ["Hello w", "Hello wor", "Hello world and more"] {
        m.preview_text(id, typed.into()).unwrap();
        assert_eq!(clip(&m, id).text, typed, "each keystroke is on the clip before anything is accepted");
    }
    let mid = m.placement(id).unwrap();
    assert!((mid.x - place0.x).abs() < 1.0 && (mid.y - place0.y).abs() < 1.0, "the box stays where it was: {mid:?}");
    assert_eq!(m.text_style(id).unwrap(), style0, "font, size and colour are untouched while typing");

    m.cancel_text_edit().unwrap();
    assert_eq!(clip(&m, id).text, "Hello");
    assert_eq!(m.text_style(id).unwrap(), style0);
    let back = m.placement(id).unwrap();
    assert!((back.x - place0.x).abs() < 1e-6 && (back.y - place0.y).abs() < 1e-6 && (back.width - place0.width).abs() < 1e-6);
    assert!(!m.poll().can_undo && !m.poll().can_redo, "a cancelled edit leaves no history behind");
    m.cancel_text_edit().unwrap(); // cancelling twice is harmless
}

#[test]
fn accepting_a_live_text_edit_is_one_undo_step_and_blank_text_still_removes_the_clip() {
    let m = MobileSession::new();
    m.new_project("P".into(), 1080, 1920, 30).unwrap();
    let id = m.add_text("Hello".into()).unwrap().unwrap();
    m.forget_history();
    m.begin_text_edit(id).unwrap();
    m.preview_text(id, "Hel".into()).unwrap();
    m.preview_text(id, "Hello there".into()).unwrap();
    m.finish_text_edit(id, "Hello there".into()).unwrap();
    assert_eq!(clip(&m, id).text, "Hello there");
    assert!(m.undo().is_some());
    assert_eq!(clip(&m, id).text, "Hello", "the whole edit is one undo step");
    assert_eq!(m.undo(), None);

    // an accepted edit that ends up blank removes the clip, as before
    m.begin_text_edit(id).unwrap();
    m.preview_text(id, "".into()).unwrap();
    assert_eq!(clip(&m, id).text, "", "blank is only shown, nothing is deleted while typing");
    m.finish_text_edit(id, "".into()).unwrap();
    assert!(m.timeline().unwrap().lanes.iter().all(|l| l.clips.iter().all(|c| c.id != id)));
}

#[test]
fn a_new_text_edit_cancels_one_left_open() {
    let m = MobileSession::new();
    m.new_project("P".into(), 1080, 1920, 30).unwrap();
    let id = m.add_text("One".into()).unwrap().unwrap();
    m.begin_text_edit(id).unwrap();
    m.preview_text(id, "changed".into()).unwrap();
    m.begin_text_edit(id).unwrap();
    assert_eq!(clip(&m, id).text, "One");
    m.cancel_text_edit().unwrap();
    assert_eq!(clip(&m, id).text, "One");
}

// ---- r5 round: replacing a picture with a video ----

#[test]
fn a_picture_replaced_by_a_video_becomes_a_real_video_clip_with_its_sound_inside_it() {
    let d = tmp();
    let m = MobileSession::new();
    m.new_project("T".into(), 1080, 1920, 30).unwrap();
    let a = m.add_media(vec![movie(&d, "first.mp4", DemoScene::Aurora, 48)]).unwrap()[0];
    let pic = m.add_media(vec![picture(&d)]).unwrap()[0];
    let tail = m.add_media(vec![movie(&d, "tail.mp4", DemoScene::Dunes, 48)]).unwrap()[0];
    let before = clip(&m, pic);
    assert_eq!(before.kind, ClipKind::Image);
    assert!(!before.has_audio && before.audio_clip.is_none());
    m.forget_history();

    let video = movie(&d, "long.mp4", DemoScene::Plasma, 120); // 5 s, longer than the 4 s picture
    m.replace(pic, video).unwrap();

    let now = clip(&m, pic);
    assert_eq!(now.kind, ClipKind::Video, "a real video clip, not a still");
    assert!(now.media_duration > 0, "it knows the media's length");
    assert!(now.has_audio && now.audio_clip.is_some(), "its sound is there");
    assert_eq!((now.start, now.duration), (before.start, before.duration), "place and length are kept");
    assert_eq!(audio_lanes_listed(&m), 0, "the sound is drawn inside the clip, not as a lane");
    assert_eq!(main_ids(&m).len(), 3);
    assert!(main_ids(&m).contains(&a) && main_ids(&m).contains(&tail));
    // the sound is linked, sits under the picture and is exactly as long
    {
        let s = m.lock();
        let seq = s.active_sequence().unwrap();
        let (_, v) = seq.find_item(filmcraft_project::ClipId(pic)).unwrap();
        let snd = model::partner(seq, v, TrackKind::Audio).expect("linked sound");
        assert_eq!((snd.clip.start, snd.clip.duration, snd.clip.source_in), (v.start, v.duration, v.source_in));
    }
    // a later move or delete of the clip takes the sound along: it is one unit
    m.set_volume(pic, 0.5, false).unwrap();
    assert!((clip(&m, pic).volume - 0.5).abs() < 0.01);
    m.undo(); // volume
    m.undo(); // the replacement, in one step
    let back = clip(&m, pic);
    assert_eq!(back.kind, ClipKind::Image);
    assert!(!back.has_audio && back.audio_clip.is_none(), "undo leaves no stray sound behind");
}

#[test]
fn an_overlay_picture_replaced_by_a_video_also_gets_hidden_linked_sound() {
    let d = tmp();
    let m = MobileSession::new();
    m.new_project("T".into(), 1080, 1920, 30).unwrap();
    m.add_media(vec![movie(&d, "base.mp4", DemoScene::Aurora, 240)]).unwrap();
    let pic = m.add_media_to_overlay(vec![picture(&d)], 1).unwrap()[0];
    m.replace(pic, movie(&d, "ov.mp4", DemoScene::Dunes, 120)).unwrap();
    let c = clip(&m, pic);
    assert!(c.kind == ClipKind::Video && c.has_audio);
    assert_eq!(audio_lanes_listed(&m), 0);
}

// ---- r5 round: group move on V2 and above ----

fn lane_of(m: &MobileSession, id: u64) -> i32 {
    m.timeline().unwrap().lanes.iter().find(|l| l.clips.iter().any(|c| c.id == id)).map(|l| l.index).unwrap()
}

/// A project with a long main clip and overlays: (project, [x on V2 at 1 s, y on V3 at 2 s, z on V2 at 10 s, u on V4 at 0 s]).
fn overlays() -> (Arc<MobileSession>, PathBuf, Vec<u64>) {
    let d = tmp();
    let m = MobileSession::new();
    m.new_project("T".into(), 1080, 1920, 30).unwrap();
    m.add_media(vec![movie(&d, "base.mp4", DemoScene::Aurora, 24 * 30)]).unwrap();
    let put = |name: &str, frames: i64, lane: u32, at: i64| {
        m.set_playhead(at * SEC);
        let p = movie(&d, name, DemoScene::Dunes, frames);
        m.add_media_to_overlay(vec![p], lane).unwrap()[0]
    };
    let x = put("x.mp4", 48, 1, 1);
    let y = put("y.mp4", 72, 2, 2);
    let z = put("z.mp4", 48, 1, 10);
    let u = put("u.mp4", 240, 3, 0);
    m.set_playhead(0);
    (m, d, vec![x, y, z, u])
}

#[test]
fn a_group_moves_together_keeping_distances_lengths_and_lanes_and_nothing_else_moves() {
    let (m, _d, ids) = overlays();
    let (x, y, z, u) = (ids[0], ids[1], ids[2], ids[3]);
    let before: Vec<_> = ids.iter().map(|&i| (clip(&m, i).start, clip(&m, i).duration, lane_of(&m, i))).collect();
    m.move_clips(vec![x, y], 0, 4 * SEC).unwrap();
    for (i, &id) in [x, y].iter().enumerate() {
        let c = clip(&m, id);
        assert_eq!((c.start, c.duration, lane_of(&m, id)), (before[i].0 + 4 * SEC, before[i].1, before[i].2));
        assert!(c.has_audio, "sound still inside the clip");
    }
    assert_eq!(clip(&m, y).start - clip(&m, x).start, before[1].0 - before[0].0, "distance kept");
    for (i, id) in [z, u].iter().enumerate() {
        let c = clip(&m, *id);
        assert_eq!((c.start, c.duration, lane_of(&m, *id)), (before[i + 2].0, before[i + 2].1, before[i + 2].2), "unselected clips stay");
    }
    assert_eq!(audio_lanes_listed(&m), 0);
    // sound travelled with each picture
    {
        let s = m.lock();
        let seq = s.active_sequence().unwrap();
        for id in [x, y] {
            let (_, v) = seq.find_item(filmcraft_project::ClipId(id)).unwrap();
            let a = model::partner(seq, v, TrackKind::Audio).expect("sound");
            assert_eq!((a.clip.start, a.clip.duration), (v.start, v.duration));
        }
    }
    assert!(m.undo().is_some());
    for (i, &id) in ids.iter().enumerate() {
        assert_eq!((clip(&m, id).start, lane_of(&m, id)), (before[i].0, before[i].2), "one undo step restores all");
    }
}

#[test]
fn a_group_moves_up_to_free_lanes_when_the_target_is_taken_and_keeps_its_lane_spacing() {
    let (m, _d, ids) = overlays();
    let (x, y, u) = (ids[0], ids[1], ids[3]);
    let u_before = (clip(&m, u).start, lane_of(&m, u));
    // one lane up would put y on V4, which u holds for the first ten seconds
    m.move_clips(vec![x, y], 1, 0).unwrap();
    let (lx, ly) = (lane_of(&m, x), lane_of(&m, y));
    assert_eq!(ly - lx, 1, "the lanes between the clips are kept");
    assert!(lx > 1 && ly > 3, "went up past u: {lx} {ly}");
    assert_eq!((clip(&m, u).start, lane_of(&m, u)), u_before);
    assert_eq!((clip(&m, x).start, clip(&m, y).start), (SEC, 2 * SEC), "time is as asked");
    assert!(m.undo().is_some());
    assert_eq!((lane_of(&m, x), lane_of(&m, y)), (1, 2));
}

#[test]
fn a_group_never_goes_before_zero_or_under_v2_and_refuses_main_track_clips() {
    let (m, _d, ids) = overlays();
    let (x, y) = (ids[0], ids[1]);
    m.move_clips(vec![x, y], 0, -100 * SEC).unwrap();
    assert_eq!(clip(&m, x).start, 0);
    assert_eq!(clip(&m, y).start, SEC, "the distance is kept when the group stops at zero");
    m.move_clips(vec![x, y], -5, 0).unwrap();
    assert_eq!(lane_of(&m, x), 1, "never below V2");
    let main = main_clips(&m)[0].id;
    let before = main_clips(&m)[0].start;
    assert!(m.move_clips(vec![x, main], 0, SEC).is_err());
    assert_eq!(main_clips(&m)[0].start, before);
    assert_eq!(clip(&m, x).start, 0, "a refused group changes nothing");
}

// ---- r6 round: overlays dropped on V1 insert magnetically ----

/// Main clips as (id, start, duration), in order.
fn main_spans(m: &MobileSession) -> Vec<(u64, i64, i64)> {
    main_clips(m).iter().map(|c| (c.id, c.start, c.duration)).collect()
}

#[test]
fn an_overlay_dropped_between_two_main_clips_pushes_the_next_ones_right_and_cuts_nothing() {
    let (m, _d, ids) = n_clips(3); // 1 s, 2 s, 3 s
    let before = main_spans(&m);
    let o = m.add_media_to_overlay(vec![movie(&_d, "o.mp4", DemoScene::Plasma, 36)], 1).unwrap()[0]; // 1.5 s on V2
    let od = clip(&m, o).duration;
    // dropped near the boundary between the first and second main clip
    m.move_clip(o, 0, before[1].1 + SEC / 4).unwrap();
    let after = main_spans(&m);
    assert_eq!(after.len(), 4);
    assert_eq!(after[0], before[0], "the clip before is untouched");
    assert_eq!(after[1].0, o);
    assert_eq!((after[1].1, after[1].2), (before[1].1, od), "it takes the room at the boundary, with its own length");
    assert_eq!(after[2], (before[1].0, before[1].1 + od, before[1].2), "the next clip moves right by its length, uncut");
    assert_eq!(after[3], (before[2].0, before[2].1 + od, before[2].2));
    for pair in after.windows(2) {
        assert_eq!(pair[1].1, pair[0].1 + pair[0].2, "no gaps and no overlaps");
    }
    // the sound of each main clip is under its picture, and nothing shows as an audio lane
    let s = m.lock();
    let seq = s.active_sequence().unwrap();
    for c in seq.video_tracks[0].items.iter() {
        let a = model::partner(seq, c, TrackKind::Audio).expect("linked sound");
        assert_eq!((a.clip.start, a.clip.duration), (c.start, c.duration));
    }
    drop(s);
    assert_eq!(audio_lanes_listed(&m), 0);
    assert!(m.undo().is_some());
    assert_eq!(main_spans(&m), before, "one undo step");
}

#[test]
fn an_overlay_dropped_in_the_middle_of_a_main_clip_snaps_to_a_boundary_instead_of_cutting_it() {
    let (m, d, _ids) = n_clips(2);
    let before = main_spans(&m);
    let o = m.add_media_to_overlay(vec![movie(&d, "o.mp4", DemoScene::Plasma, 24)], 1).unwrap()[0];
    let middle = before[1].1 + before[1].2 / 2 + SEC / 10; // past the middle of the second clip
    m.move_clip(o, 0, middle).unwrap();
    let after = main_spans(&m);
    assert_eq!(after.len(), 3);
    assert_eq!(after[0], before[0]);
    assert_eq!(after[1].0, before[1].0, "the second clip is whole, still in place");
    assert_eq!((after[1].1, after[1].2), (before[1].1, before[1].2));
    assert_eq!(after[2].0, o, "the overlay went to the end, the nearer boundary");
    assert_eq!(after[2].1, before[1].1 + before[1].2);
}

#[test]
fn dropping_an_overlay_at_the_start_of_the_main_track_makes_room_for_it() {
    let (m, d, _ids) = n_clips(2);
    let before = main_spans(&m);
    let o = m.add_media_to_overlay(vec![movie(&d, "o.mp4", DemoScene::Plasma, 24)], 1).unwrap()[0];
    m.move_clip(o, 0, 0).unwrap();
    let after = main_spans(&m);
    assert_eq!(after[0].0, o);
    assert_eq!(after[0].1, 0);
    assert_eq!(after[1], (before[0].0, SEC, before[0].2));
    assert_eq!(after[2], (before[1].0, SEC + before[0].2, before[1].2));
}

#[test]
fn an_overlay_dropped_on_v1_leaves_other_overlays_alone() {
    let (m, d, ids) = n_clips(2);
    m.move_clip(ids[1], 1, 7 * SEC).unwrap(); // V2
    let other = clip(&m, ids[1]);
    let o = m.add_media_to_overlay(vec![movie(&d, "o.mp4", DemoScene::Plasma, 24)], 2).unwrap()[0]; // V3
    m.move_clip(o, 0, 0).unwrap();
    let still = clip(&m, ids[1]);
    assert_eq!((still.start, still.duration), (other.start, other.duration));
    assert_eq!(main_clips(&m)[0].id, o);
}

// ---- r6 round: compositions ----

fn open_sequence(m: &MobileSession, item: u64) {
    m.lock().execute("sequence.open", json!({ "item": item })).unwrap();
}

fn lane_and_clip(m: &MobileSession, id: u64) -> Option<(i32, model::ClipInfo)> {
    m.timeline().unwrap().lanes.iter().find_map(|l| l.clips.iter().find(|c| c.id == id).map(|c| (l.index, c.clone())))
}

#[test]
fn a_composition_keeps_positions_lanes_durations_and_sound_of_its_clips() {
    let (m, _d, ids) = overlays();
    let (x, y, z, u) = (ids[0], ids[1], ids[2], ids[3]);
    let (xb, yb) = (clip(&m, x), clip(&m, y));
    let (zb, ub) = (clip(&m, z), clip(&m, u));
    let nest = m.create_composition(vec![x, y], "Composition".into()).unwrap();
    let (lane, comp) = lane_and_clip(&m, nest).expect("the composition is on the timeline");
    assert!(lane >= 1, "on an overlay lane");
    assert!(comp.composition && comp.kind == ClipKind::Video);
    assert_eq!(comp.start, xb.start, "it starts where the group started");
    assert_eq!(comp.duration, yb.start + yb.duration - xb.start, "and lasts as long as the group");
    assert!(comp.has_audio, "the group's sound plays with it");
    assert_eq!(audio_lanes_listed(&m), 0, "no sound lane appears");
    assert!(lane_and_clip(&m, x).is_none() && lane_and_clip(&m, y).is_none(), "the grouped clips left this sequence");
    // clips outside the group did not move
    for (id, before) in [(z, zb), (u, ub)] {
        let (_, c) = lane_and_clip(&m, id).unwrap();
        assert_eq!((c.start, c.duration), (before.start, before.duration));
    }
    // inside: same distances, durations and lane relation, each with its sound
    open_sequence(&m, comp.item);
    let (lx, cx) = lane_and_clip(&m, x).unwrap();
    let (ly, cy) = lane_and_clip(&m, y).unwrap();
    assert_eq!((cx.start, cx.duration), (0, xb.duration));
    assert_eq!((cy.start, cy.duration), (yb.start - xb.start, yb.duration));
    assert_eq!(ly - lx, 1);
    assert!(cx.has_audio && cy.has_audio);
    assert!(cx.volume > 0.0 && (cx.opacity - xb.opacity).abs() < 1e-9);
}

#[test]
fn making_a_composition_is_one_undo_step_and_it_can_be_moved_like_any_clip() {
    let (m, _d, ids) = overlays();
    let (x, y) = (ids[0], ids[1]);
    let before = ((clip(&m, x).start, lane_of(&m, x)), (clip(&m, y).start, lane_of(&m, y)));
    let nest = m.create_composition(vec![x, y], "Composition".into()).unwrap();
    m.move_clips(vec![nest], 0, 3 * SEC).unwrap();
    assert_eq!(clip(&m, nest).start, before.0.0 + 3 * SEC);
    assert!(m.undo().is_some()); // the move
    assert!(m.undo().is_some()); // the composition, in one step
    assert!(lane_and_clip(&m, nest).is_none());
    assert_eq!(((clip(&m, x).start, lane_of(&m, x)), (clip(&m, y).start, lane_of(&m, y))), before);
    assert_eq!(audio_lanes_listed(&m), 0);
}

#[test]
fn a_composition_needs_two_clips() {
    let (m, _d, ids) = overlays();
    assert!(m.create_composition(vec![ids[0]], "C".into()).is_err());
    let (m2, _d2, main) = n_clips(3);
    let before = main_spans(&m2);
    let nest = m2.create_composition(vec![main[0], main[1]], "C".into()).unwrap();
    let after = main_spans(&m2);
    assert_eq!(after.len(), 2);
    assert_eq!((after[0].0, after[0].1, after[0].2), (nest, 0, before[0].2 + before[1].2));
    assert_eq!(after[1], (before[2].0, before[2].1, before[2].2), "the clip after is where it was");
}

#[test]
fn v1_clips_chosen_apart_follow_each_other_from_the_start_inside_and_the_clips_between_close_up() {
    let (m, _d, main) = n_clips(7);
    let before = main_spans(&m);
    let chosen = [1usize, 2, 4, 6]; // positions 2, 3, 5 and 7
    let nest = m.create_composition(chosen.iter().map(|&i| main[i]).collect(), "C".into()).unwrap();
    // the clips that stay keep their order and close up: no gap on V1, nothing else moved
    let rest: Vec<usize> = (0..7).filter(|i| !chosen.contains(i)).collect();
    let after = main_spans(&m);
    assert_eq!(after.len(), rest.len());
    let mut t = 0;
    for (k, &i) in rest.iter().enumerate() {
        assert_eq!(after[k], (main[i], t, before[i].2), "clip {} keeps its length and closes up", i + 1);
        t += before[i].2;
    }
    // the composition: where the first chosen clip was, as long as the chosen clips together
    let (lane, comp) = lane_and_clip(&m, nest).expect("the composition exists");
    assert!(lane >= 1, "V1 still holds clips between the chosen ones' places");
    assert_eq!(comp.start, before[1].1);
    assert_eq!(comp.duration, chosen.iter().map(|&i| before[i].2).sum::<i64>());
    // inside they follow each other from the start, in their order, without a gap
    open_sequence(&m, comp.item);
    let inside = main_spans(&m);
    let mut t = 0;
    for (k, &i) in chosen.iter().enumerate() {
        assert_eq!(inside[k], (main[i], t, before[i].2), "chosen clip {} sits at {} inside", i + 1, t);
        t += before[i].2;
    }
    assert_eq!(inside.len(), chosen.len());
}

#[test]
fn a_layer_chosen_over_a_later_v1_clip_keeps_its_distance_to_that_clip_inside() {
    let (m, d, main) = n_clips(3);
    let before = main_spans(&m);
    m.set_playhead(before[2].1 + SEC / 2);
    let o = m.add_media_to_overlay(vec![movie(&d, "o.mp4", DemoScene::Plasma, 12)], 1).unwrap()[0]; // 0.5 s, half a second into the third clip
    let ob = clip(&m, o);
    let nest = m.create_composition(vec![main[0], main[2], o], "C".into()).unwrap();
    let comp = clip(&m, nest);
    open_sequence(&m, comp.item);
    let inside = main_spans(&m);
    assert_eq!(inside[1], (main[2], before[0].2, before[2].2), "the third clip follows the first");
    let (_, inner_o) = lane_and_clip(&m, o).expect("the layer is inside");
    assert_eq!(inner_o.start, before[0].2 + SEC / 2, "still half a second into the clip it sat over");
    assert_eq!(inner_o.duration, ob.duration);
}

#[test]
fn clips_chosen_apart_leave_the_original_clips_between_them_untouched() {
    let (m, _d, main) = n_clips(3);
    let before = main_spans(&m);
    m.create_composition(vec![main[0], main[2]], "C".into()).unwrap();
    let after = main_spans(&m);
    assert_eq!(after, vec![(main[1], 0, before[1].2)], "the middle clip keeps its length and closes up to the start");
    assert!(m.undo().is_some());
    assert_eq!(main_spans(&m), before, "one undo restores every position");
}

#[test]
fn a_saved_project_always_opens_on_its_main_sequence_even_if_saved_inside_a_composition() {
    let (m, d, ids) = overlays();
    let root = m.sequence_info().unwrap().id;
    let nest = m.create_composition(vec![ids[0], ids[1]], "Composition".into()).unwrap();
    let item = clip(&m, nest).item;
    open_sequence(&m, item);
    assert_ne!(m.sequence_info().unwrap().id, root);
    let path = d.join("c.fcproj").to_string_lossy().to_string();
    m.save_project(path.clone()).unwrap();
    let again = MobileSession::new();
    again.open_project(path).unwrap();
    assert_eq!(again.sequence_info().unwrap().id, root);
    assert!(lane_and_clip(&again, nest).is_some(), "and the composition survived the save");
}

// ---- r7 round: tools on several chosen clips ----

#[test]
fn tools_apply_to_every_chosen_clip_as_one_undo_step() {
    let (m, _d, ids) = overlays();
    let (x, y, z) = (ids[0], ids[1], ids[2]);
    let set = vec![x, y, z];
    m.forget_history();

    m.edit_clips(set.clone(), "filter".into(), "warm".into(), 100.0, false, false).unwrap();
    assert!(set.iter().all(|&i| clip(&m, i).filter == "warm"), "every chosen clip has the filter");
    assert_eq!(clip(&m, ids[3]).filter, "", "an unchosen clip is untouched");
    m.edit_clips(set.clone(), "filter".into(), "".into(), 0.0, false, false).unwrap();
    assert!(set.iter().all(|&i| clip(&m, i).filter.is_empty()), "the filter is removed from all");

    m.edit_clips(set.clone(), "mirror".into(), "".into(), 0.0, true, false).unwrap();
    assert!(set.iter().all(|&i| clip(&m, i).mirrored));
    m.edit_clips(set.clone(), "flip".into(), "".into(), 0.0, true, false).unwrap();
    assert!(set.iter().all(|&i| clip(&m, i).flipped));

    m.edit_clips(set.clone(), "opacity".into(), "".into(), 0.5, false, false).unwrap();
    assert!(set.iter().all(|&i| (clip(&m, i).opacity - 0.5).abs() < 0.01));
    m.edit_clips(set.clone(), "mute".into(), "".into(), 0.0, true, false).unwrap();
    assert!(set.iter().all(|&i| clip(&m, i).muted));
    m.edit_clips(set.clone(), "mute".into(), "".into(), 0.0, false, false).unwrap();
    m.edit_clips(set.clone(), "volume".into(), "".into(), 0.5, false, false).unwrap();
    assert!(set.iter().all(|&i| (clip(&m, i).volume - 0.5).abs() < 0.01));

    let before: Vec<i64> = set.iter().map(|&i| clip(&m, i).duration).collect();
    m.edit_clips(set.clone(), "speed".into(), "".into(), 2.0, false, false).unwrap();
    for (i, &id) in set.iter().enumerate() {
        assert_eq!(clip(&m, id).speed, 2.0);
        assert_eq!(clip(&m, id).duration, before[i] / 2, "twice as fast is half as long");
    }
    // each of those was one undo step: undoing the speed change restores all three
    assert!(m.undo().is_some());
    assert!(set.iter().all(|&i| clip(&m, i).speed == 1.0));
}

#[test]
fn deleting_duplicating_and_splitting_several_clips_at_once() {
    let (m, _d, ids) = overlays();
    let (x, y, z, u) = (ids[0], ids[1], ids[2], ids[3]);
    m.forget_history();
    let count = |m: &MobileSession| m.timeline().unwrap().lanes.iter().map(|l| l.clips.len()).sum::<usize>();
    let start = count(&m);
    m.edit_clips(vec![x, y], "duplicate".into(), "".into(), 0.0, false, false).unwrap();
    assert_eq!(count(&m), start + 2);
    assert!(m.undo().is_some());
    assert_eq!(count(&m), start, "both copies undone together");

    // x (1–3 s) and y (2–5 s) are both under 2.5 s; z (10 s on) and u are not both: only those under the playhead split
    m.set_playhead(2 * SEC + SEC / 2);
    m.edit_clips(vec![x, y, z], "split".into(), "".into(), 0.0, false, false).unwrap();
    assert_eq!(count(&m), start + 2, "x and y were cut, z was not under the playhead");
    assert!(m.undo().is_some());
    assert!(m.edit_clips(vec![z], "split".into(), "".into(), 0.0, false, false).is_err(), "nothing under the playhead to split");

    m.edit_clips(vec![x, y, z], "delete".into(), "".into(), 0.0, false, false).unwrap();
    assert_eq!(count(&m), start - 3);
    assert!(lane_and_clip(&m, u).is_some(), "an unchosen clip stays");
    assert!(m.undo().is_some());
    assert_eq!(count(&m), start, "one undo brings them all back");
}

#[test]
fn a_tool_skips_chosen_clips_it_does_not_apply_to() {
    let m = MobileSession::new();
    m.new_project("T".into(), 1080, 1920, 30).unwrap();
    let t = m.add_text("hi".into()).unwrap().unwrap();
    let d = tmp();
    let v = m.add_media_to_overlay(vec![movie(&d, "v.mp4", DemoScene::Plasma, 48)], 1).unwrap()[0];
    m.edit_clips(vec![t, v], "filter".into(), "warm".into(), 100.0, false, false).unwrap();
    assert_eq!(clip(&m, v).filter, "warm");
    assert_eq!(clip(&m, t).filter, "", "text takes no filter");
    assert!(m.edit_clips(vec![t], "filter".into(), "warm".into(), 100.0, false, false).is_err());
}

#[test]
fn a_composition_of_a_main_clip_and_overlays_leaves_no_gap_on_v1() {
    let (m, d, main) = n_clips(3); // V1: 0–1 s, 1–3 s, 3–6 s
    let before = main_spans(&m);
    m.set_playhead(5 * SEC / 2);
    // an overlay that runs past the end of the second main clip, so the composition can't take V1
    let o = m.add_media_to_overlay(vec![movie(&d, "o.mp4", DemoScene::Plasma, 48)], 1).unwrap()[0];
    let nest = m.create_composition(vec![main[1], o], "Composition".into()).unwrap();
    let (lane, _) = lane_and_clip(&m, nest).expect("the composition exists");
    assert!(lane >= 1, "it is placed as before, on an overlay lane");
    let after = main_spans(&m);
    assert_eq!(after.len(), 2);
    assert_eq!(after[0], before[0]);
    assert_eq!(after[1], (before[2].0, before[1].1, before[2].2), "the next clip moved up to where the chosen one began");
    for pair in after.windows(2) {
        assert_eq!(pair[1].1, pair[0].1 + pair[0].2, "no gap");
    }
    let s = m.lock();
    let seq = s.active_sequence().unwrap();
    for c in seq.video_tracks[0].items.iter() {
        let a = model::partner(seq, c, TrackKind::Audio).expect("its sound");
        assert_eq!(a.clip.start, c.start, "sound stays under its picture");
    }
}

// ---- r7 round: composition sound ----

#[test]
fn a_composition_of_pictures_alone_still_has_its_sound_clip_and_keeps_it_through_cut_and_copy() {
    let d = tmp();
    let m = MobileSession::new();
    m.new_project("T".into(), 1080, 1920, 30).unwrap();
    m.add_media(vec![movie(&d, "base.mp4", DemoScene::Aurora, 24 * 20)]).unwrap();
    let a = m.add_media_to_overlay(vec![picture(&d)], 1).unwrap()[0];
    let b = m.add_media_to_overlay(vec![picture(&d)], 2).unwrap()[0];
    let nest = m.create_composition(vec![a, b], "Composition".into()).unwrap();
    let comp = clip(&m, nest);
    assert!(comp.composition && comp.has_audio, "the composition has its sound even if made of pictures");
    assert!(comp.media_duration > 0, "and knows how long its contents are");
    assert_eq!(audio_lanes_listed(&m), 0, "the sound is inside the clip, not a lane");

    // cutting it keeps the sound on both pieces
    m.set_playhead(comp.start + comp.duration / 2);
    let right = m.split(nest).unwrap();
    assert!(clip(&m, nest).has_audio && clip(&m, right).has_audio);
    assert_eq!(audio_lanes_listed(&m), 0);

    // a copy plays too
    let copy = m.duplicate(right).unwrap();
    assert!(clip(&m, copy).has_audio);
    assert!(clip(&m, copy).composition, "it is the same composition, reused");
}

#[test]
fn a_composition_that_lost_its_sound_gets_it_back() {
    let (m, _d, ids) = overlays();
    let nest = m.create_composition(vec![ids[0], ids[1]], "Composition".into()).unwrap();
    assert!(clip(&m, nest).has_audio);
    m.lock()
        .edit_sequence("lose", |q, _, _| {
            for t in q.audio_tracks.iter_mut() {
                t.items.clear();
            }
            Ok(())
        })
        .unwrap();
    assert!(!clip(&m, nest).has_audio);
    assert_eq!(m.restore_composition_sound().unwrap(), 1);
    assert!(clip(&m, nest).has_audio);
    assert_eq!(m.restore_composition_sound().unwrap(), 0, "nothing more to restore");
    assert_eq!(audio_lanes_listed(&m), 0);
}

#[test]
fn a_compositions_sound_survives_opening_editing_and_returning() {
    let (m, _d, ids) = overlays();
    let root = m.sequence_info().unwrap().id;
    let nest = m.create_composition(vec![ids[0], ids[1]], "Composition".into()).unwrap();
    let item = clip(&m, nest).item;
    open_sequence(&m, item);
    // inside, the clips keep their own sound
    assert!(clip(&m, ids[0]).has_audio && clip(&m, ids[1]).has_audio);
    m.set_volume(ids[0], 0.5, false).unwrap();
    open_sequence(&m, root);
    m.restore_composition_sound().unwrap();
    assert!(clip(&m, nest).has_audio);
    assert_eq!(audio_lanes_listed(&m), 0);
}

// ---- r7 round: extending an overlay cut from V1 ----

#[test]
fn extending_the_half_of_a_cut_main_clip_moved_to_v2_moves_nothing() {
    let (m, _d, ids) = n_clips(1);
    let whole = clip(&m, ids[0]); // 1 s of media
    let d = tmp();
    // a longer clip, so the half has media to grow into: 8 s, cut at 3 s
    let long = m.add_media(vec![movie(&d, "long.mp4", DemoScene::Dunes, 24 * 8)]).unwrap()[0];
    let c = clip(&m, long);
    m.set_playhead(c.start + 3 * SEC);
    let right = m.split(long).unwrap();
    let before_v1 = main_spans(&m);
    // the first half goes to V2 where it was (0 s offset within the clip)
    m.move_clip(long, 1, c.start).unwrap();
    let v1 = main_spans(&m);
    assert_eq!(v1.iter().filter(|s| s.0 == right).count(), 1);
    let at = clip(&m, long);
    assert_eq!((at.start, at.duration), (c.start, 3 * SEC));
    // extend its tail by 4 s (media allows it): the start, the V1 clips and its sound stay put
    let main_after_move = main_spans(&m);
    let done = m.trim(long, false, 4 * SEC).unwrap();
    assert!(done > 0, "the tail extended");
    let after = clip(&m, long);
    assert_eq!(after.start, c.start, "the clip does not move when its tail is extended");
    assert_eq!(after.duration, 3 * SEC + done);
    assert_eq!(main_spans(&m), main_after_move, "no main-track clip moves either");
    assert!(after.has_audio);
    let s = m.lock();
    let seq = s.active_sequence().unwrap();
    let (_, v) = seq.find_item(filmcraft_project::ClipId(long)).unwrap();
    let a = model::partner(seq, v, TrackKind::Audio).expect("sound");
    assert_eq!((a.clip.start, a.clip.duration), (v.start, v.duration), "its sound grew with it");
    let _ = (whole, before_v1);
}

// ---- r8 round: linked compositions ----

/// Clips listed in the open sequence (every lane).
fn clips_listed(m: &MobileSession) -> usize {
    m.timeline().unwrap().lanes.iter().map(|l| l.clips.len()).sum()
}

#[test]
fn a_duplicated_composition_is_linked_and_a_lone_one_is_not() {
    let (m, _d, ids) = overlays();
    let nest = m.create_composition(vec![ids[0], ids[1]], "Composition".into()).unwrap();
    let item = clip(&m, nest).item;
    assert_eq!(m.composition_links(item), 0, "alone, nothing to ask");
    let copy = m.duplicate(nest).unwrap();
    assert_eq!(clip(&m, copy).item, item, "a duplicate plays the same composition");
    assert_eq!(m.composition_links(item), 1, "so each now has one other linked to it");
}

#[test]
fn a_cut_composition_is_linked_too() {
    let (m, _d, ids) = overlays();
    let nest = m.create_composition(vec![ids[0], ids[1]], "Composition".into()).unwrap();
    let item = clip(&m, nest).item;
    let c = clip(&m, nest);
    m.set_playhead(c.start + c.duration / 2);
    let right = m.split(nest).unwrap();
    assert_eq!(clip(&m, right).item, item);
    assert_eq!(m.composition_links(item), 1);
}

#[test]
fn keeping_a_change_for_one_composition_leaves_the_others_as_they_were_and_parts_them_for_good() {
    let (m, _d, ids) = overlays();
    let root = m.sequence_info().unwrap().id;
    let nest = m.create_composition(vec![ids[0], ids[1]], "Composition".into()).unwrap();
    let copy = m.duplicate(nest).unwrap();
    let item = clip(&m, nest).item;

    open_sequence(&m, item);
    m.begin_composition_edit(item);
    let before = clips_listed(&m);
    assert!(before >= 2);
    // the edit: remove one clip from the composition
    let inside = m.timeline().unwrap().lanes.iter().flat_map(|l| l.clips.iter().map(|c| c.id)).next().unwrap();
    m.delete_clip(inside).unwrap();
    assert_eq!(clips_listed(&m), before - 1);
    open_sequence(&m, root);

    m.end_composition_edit(item, nest, false).unwrap();
    let mine = clip(&m, nest).item;
    assert_ne!(mine, item, "the edited clip now plays a composition of its own");
    assert_eq!(clip(&m, copy).item, item, "the other still plays the old one");
    assert_eq!(m.composition_links(item), 0);
    assert_eq!(m.composition_links(mine), 0, "so the question is never asked again for it");

    open_sequence(&m, mine);
    assert_eq!(clips_listed(&m), before - 1, "it keeps the change");
    open_sequence(&m, item);
    assert_eq!(clips_listed(&m), before, "the others are as they were");
    open_sequence(&m, root);
    assert!(clip(&m, nest).has_audio && clip(&m, copy).has_audio, "both keep their sound");
}

#[test]
fn applying_a_change_to_all_keeps_the_composition_shared() {
    let (m, _d, ids) = overlays();
    let root = m.sequence_info().unwrap().id;
    let nest = m.create_composition(vec![ids[0], ids[1]], "Composition".into()).unwrap();
    let copy = m.duplicate(nest).unwrap();
    let item = clip(&m, nest).item;

    open_sequence(&m, item);
    m.begin_composition_edit(item);
    let before = clips_listed(&m);
    let inside = m.timeline().unwrap().lanes.iter().flat_map(|l| l.clips.iter().map(|c| c.id)).next().unwrap();
    m.delete_clip(inside).unwrap();
    open_sequence(&m, root);

    m.end_composition_edit(item, nest, true).unwrap();
    assert_eq!(clip(&m, nest).item, item);
    assert_eq!(clip(&m, copy).item, item);
    open_sequence(&m, item);
    assert_eq!(clips_listed(&m), before - 1, "every linked composition shows the change");
}

#[test]
fn keeping_apart_without_the_earlier_version_changes_nothing() {
    let (m, _d, ids) = overlays();
    let nest = m.create_composition(vec![ids[0], ids[1]], "Composition".into()).unwrap();
    let _copy = m.duplicate(nest).unwrap();
    let item = clip(&m, nest).item;
    // no begin_composition_edit: there is nothing to give the others back
    assert!(m.end_composition_edit(item, nest, false).is_err());
    assert_eq!(clip(&m, nest).item, item);
}

#[test]
fn sound_chosen_on_its_own_goes_into_the_composition_and_does_not_stay_behind() {
    let (m, d, ids) = overlays();
    m.set_playhead(SEC);
    let tone1 = m.add_audio(vec![tone(&d, 1.5)]).unwrap()[0];
    let before = audio_lanes_listed(&m);
    assert!(before >= 1, "the sound is on a lane of its own");
    let nest = m.create_composition(vec![ids[0], ids[1], tone1], "Composition".into()).unwrap();
    assert_eq!(audio_lanes_listed(&m), 0, "the chosen sound left this sequence with the rest");
    assert!(clip(&m, nest).has_audio);
    open_sequence(&m, clip(&m, nest).item);
    assert!(audio_lanes_listed(&m) >= 1, "and it plays inside the composition");
}

// ---- r8 round: moving a clip with sound to V2 makes no sound of its own ----

#[test]
fn moving_a_main_clip_with_sound_to_v2_keeps_one_linked_sound_and_adds_none() {
    let (m, _d, ids) = n_clips(2);
    let sounds = |m: &MobileSession| {
        let s = m.lock();
        let seq = s.active_sequence().unwrap();
        seq.audio_tracks.iter().map(|t| t.items.len()).sum::<usize>()
    };
    let before = sounds(&m);
    assert_eq!(audio_lanes_listed(&m), 0);
    m.move_clip(ids[0], 1, 0).unwrap();
    assert_eq!(sounds(&m), before, "no sound clip was created or lost");
    assert_eq!(audio_lanes_listed(&m), 0, "the sound stays linked to its picture, no lane of its own appears");
    assert!(clip(&m, ids[0]).has_audio);
}

#[test]
fn a_composition_of_a_later_main_clip_and_overlays_leaves_v1_without_gaps_wherever_it_lands() {
    for (o1_at, o2_at) in [(3, 4), (2, 5), (5, 6)] {
        let (m, d, main) = n_clips(3); // V1: 0–1 s, 1–3 s, 3–6 s
        let total: i64 = main_spans(&m).iter().map(|s| s.2).sum();
        let put = |name: &str, frames: i64, lane: u32, at: i64| {
            m.set_playhead(at * SEC / 2);
            m.add_media_to_overlay(vec![movie(&d, name, DemoScene::Plasma, frames)], lane).unwrap()[0]
        };
        let o1 = put("o1.mp4", 24, 1, o1_at);
        let o2 = put("o2.mp4", 24, 2, o2_at);
        let nest = m.create_composition(vec![main[1], o1, o2], "Composition".into()).unwrap();
        let (lane, comp) = lane_and_clip(&m, nest).expect("the composition exists");
        let spans = main_spans(&m);
        assert_eq!(spans.first().map(|s| s.1), Some(0), "V1 starts at 0");
        for pair in spans.windows(2) {
            assert_eq!(pair[1].1, pair[0].1 + pair[0].2, "no gap on V1 (overlays at {o1_at}/{o2_at} half-seconds)");
        }
        if lane == 0 {
            let now: i64 = spans.iter().map(|s| s.2).sum();
            assert_eq!(now, total, "the composition took the place of what it grouped");
        }
        assert!(comp.has_audio);
        assert_eq!(audio_lanes_listed(&m), 0, "no stray sound lane");
    }
}

// ---- r9 round: a plain trim keeps the layers above; taking a composition apart ----

/// Every clip of the open sequence with its lane index, in lane order.
fn all_clips(m: &MobileSession) -> Vec<(i32, model::ClipInfo)> {
    m.timeline().unwrap().lanes.iter().flat_map(|l| l.clips.iter().map(|c| (l.index, c.clone()))).collect()
}

/// (lane, start, duration) of every clip, sorted: what a restore must reproduce, whatever the ids.
fn layout(m: &MobileSession) -> Vec<(i32, i64, i64)> {
    let mut v: Vec<_> = all_clips(m).iter().map(|(l, c)| (*l, c.start, c.duration)).collect();
    v.sort();
    v
}

#[test]
fn trimming_a_main_clip_moves_the_main_clips_after_it_but_not_the_layers_above() {
    let (m, d, main) = n_clips(3); // V1: 0–1 s, 1–3 s, 3–6 s
    m.set_playhead(4 * SEC);
    let o = m.add_media_to_overlay(vec![movie(&d, "o.mp4", DemoScene::Plasma, 24)], 1).unwrap()[0]; // V2, 4–5 s
    let before_o = clip(&m, o);
    let before_main = main_spans(&m);
    // shorten the first main clip's tail by half a second
    let done = m.trim(main[0], false, -SEC / 2).unwrap();
    assert!(done < 0, "the tail was trimmed");
    let after = main_spans(&m);
    assert_eq!(after[0].2, before_main[0].2 + done, "only that clip changed length");
    assert_eq!(after[1].1, before_main[1].1 + done, "the main clips after it close up");
    assert_eq!(after[2].1, before_main[2].1 + done);
    let o_now = clip(&m, o);
    assert_eq!((o_now.start, o_now.duration), (before_o.start, before_o.duration), "the overlay keeps its place in time");
}

#[test]
fn deleting_a_main_clip_still_carries_the_layers_above_with_it() {
    let (m, d, main) = n_clips(3);
    m.set_playhead(4 * SEC);
    let o = m.add_media_to_overlay(vec![movie(&d, "o.mp4", DemoScene::Plasma, 24)], 1).unwrap()[0];
    let before_o = clip(&m, o);
    let first = clip(&m, main[0]);
    m.delete_clip(main[0]).unwrap();
    assert_eq!(clip(&m, o).start, before_o.start - first.duration, "a ripple delete moves what lies after it");
}

#[test]
fn taking_a_composition_apart_puts_each_clip_back_at_its_place_plus_the_compositions_start() {
    let (m, _d, ids) = overlays();
    let (x, y) = (ids[0], ids[1]);
    let (xb, yb) = (clip(&m, x), clip(&m, y));
    let (lx, ly) = (lane_of(&m, x), lane_of(&m, y));
    let nest = m.create_composition(vec![x, y], "Composition".into()).unwrap();
    assert_eq!(m.composition_transitions_at_risk(nest).unwrap(), 0);
    // the composition is moved to start 4 s later: its contents keep their inside times
    m.move_clips(vec![nest], 0, 4 * SEC).unwrap();
    let start = clip(&m, nest).start;
    assert_eq!(start, xb.start + 4 * SEC);
    let back = m.ungroup_composition(nest).unwrap();
    assert!(back.len() >= 2);
    assert!(lane_and_clip(&m, nest).is_none(), "the composition is gone");
    let find = |len: i64, at: i64| all_clips(&m).into_iter().find(|(_, c)| c.start == at && c.duration == len && c.kind == ClipKind::Video);
    let (lane_x, _) = find(xb.duration, xb.start + 4 * SEC).expect("x is back, 4 s later");
    let (lane_y, _) = find(yb.duration, yb.start + 4 * SEC).expect("y is back, keeping its distance from x");
    assert_eq!((lane_x, lane_y), (lx, ly), "on the lanes they came from");
    assert!(all_clips(&m).iter().filter(|(_, c)| c.kind == ClipKind::Video).all(|(_, c)| c.has_audio), "each picture keeps its sound");
    assert_eq!(audio_lanes_listed(&m), 0, "the sound stays linked, no lane of its own");
}

#[test]
fn a_clip_that_cannot_go_back_to_its_lane_takes_the_next_free_one_above() {
    let (m, _d, ids) = overlays();
    let (x, y, z) = (ids[0], ids[1], ids[2]); // z: V2 at 10–12 s
    let (xb, yb, zb) = (clip(&m, x), clip(&m, y), clip(&m, z));
    let nest = m.create_composition(vec![x, y], "Composition".into()).unwrap();
    // put the composition so its contents land over z on V2
    let shift = zb.start - xb.start;
    m.move_clips(vec![nest], 0, shift).unwrap();
    m.ungroup_composition(nest).unwrap();
    let z_now = clip(&m, z);
    assert_eq!((z_now.start, z_now.duration), (zb.start, zb.duration), "what was already there did not move");
    let at = |len: i64, start: i64| all_clips(&m).into_iter().find(|(_, c)| c.start == start && c.duration == len).map(|(l, _)| l);
    let lane_x = at(xb.duration, zb.start).expect("x is back at the composition's start");
    let lane_y = at(yb.duration, zb.start + yb.start - xb.start).expect("y keeps its distance from x");
    assert!(lane_x > lane_of(&m, z), "x found V2 taken and went above it");
    // nothing overlaps on any lane
    let all = all_clips(&m);
    for (i, (la, a)) in all.iter().enumerate() {
        for (lb, b) in all.iter().skip(i + 1) {
            if la == lb {
                assert!(a.start + a.duration <= b.start || b.start + b.duration <= a.start, "two clips overlap on lane {la}");
            }
        }
    }
    let _ = lane_y;
}

#[test]
fn clips_that_were_on_v1_inside_a_composition_go_up_to_v2_and_v1_closes_over_the_place() {
    let (m, _d, main) = n_clips(3); // V1: 0–1 s, 1–3 s, 3–6 s
    let (a, b, c) = (clip(&m, main[0]), clip(&m, main[1]), clip(&m, main[2]));
    let nest = m.create_composition(vec![main[0], main[1]], "Composition".into()).unwrap();
    assert_eq!(lane_and_clip(&m, nest).unwrap().0, 0, "it took V1");
    m.ungroup_composition(nest).unwrap();
    let all = all_clips(&m);
    let on_v1: Vec<_> = all.iter().filter(|(l, _)| *l == 0).map(|(_, x)| (x.start, x.duration)).collect();
    assert_eq!(on_v1, vec![(0, c.duration)], "V1 holds only what was not in the composition, closed up to the start");
    let mut up: Vec<_> = all.iter().filter(|(l, _)| *l >= 1).map(|(l, x)| (*l, x.start, x.duration)).collect();
    up.sort();
    assert_eq!(up, vec![(1, a.start, a.duration), (1, b.start, b.duration)], "both went to V2, in their places");
    assert!(all.iter().filter(|(l, _)| *l >= 1).all(|(_, x)| x.has_audio), "with their sound");
}

#[test]
fn a_main_clip_and_an_overlay_taken_out_of_a_composition_keep_their_times_with_the_main_clip_above_v1() {
    for (at_half_seconds, frames) in [(3, 24), (5, 48)] {
        // 3 → inside the second main clip; 5 → runs past its end, so the composition left V1
        let (m, d, main) = n_clips(3);
        m.set_playhead(at_half_seconds * SEC / 2);
        let o = m.add_media_to_overlay(vec![movie(&d, "o.mp4", DemoScene::Plasma, frames)], 1).unwrap()[0];
        let (b, ob) = (clip(&m, main[1]), clip(&m, o));
        let nest = m.create_composition(vec![main[1], o], "Composition".into()).unwrap();
        m.ungroup_composition(nest).unwrap();
        let all = all_clips(&m);
        let find = |start: i64, len: i64| all.iter().find(|(_, x)| x.start == start && x.duration == len).map(|(l, _)| *l);
        let lane_b = find(b.start, b.duration).expect("the main clip is back at its time");
        let lane_o = find(ob.start, ob.duration).expect("the overlay is back at its time");
        assert!(lane_b >= 1, "the clip that was on V1 is above V1 ({at_half_seconds} half-seconds)");
        assert!(lane_o >= 1);
        for pair in main_spans(&m).windows(2) {
            assert_eq!(pair[1].1, pair[0].1 + pair[0].2, "V1 stays gapless");
        }
    }
}

#[test]
fn taking_a_composition_apart_is_one_undo_step_and_refuses_what_is_not_a_composition() {
    let (m, _d, ids) = overlays();
    assert!(m.ungroup_composition(ids[0]).is_err(), "an ordinary clip is not a composition");
    let nest = m.create_composition(vec![ids[0], ids[1]], "Composition".into()).unwrap();
    let grouped = layout(&m);
    m.ungroup_composition(nest).unwrap();
    assert!(m.undo().is_some());
    assert_eq!(layout(&m), grouped, "one undo brings the composition back");
}

#[test]
fn a_later_main_clip_grouped_with_overlays_that_start_with_or_after_it_begins_at_zero_inside() {
    let (m, d, main) = n_clips(3); // V1: 0–1 s, 1–3 s, 3–6 s
    let b = clip(&m, main[1]);
    m.set_playhead(b.start + SEC / 2);
    let o = m.add_media_to_overlay(vec![movie(&d, "o.mp4", DemoScene::Plasma, 24)], 1).unwrap()[0]; // 1.5–2.5 s
    let ob = clip(&m, o);
    let nest = m.create_composition(vec![main[1], o], "Composition".into()).unwrap();
    let comp = clip(&m, nest);
    assert_eq!(comp.start, b.start, "the composition begins where the V1 clip did");
    open_sequence(&m, comp.item);
    let (_, inner_b) = lane_and_clip(&m, main[1]).expect("the V1 clip is inside");
    let (_, inner_o) = lane_and_clip(&m, o).expect("the overlay is inside");
    assert_eq!(inner_b.start, 0, "the V1 clip is the reference: it starts at second 0");
    assert_eq!(inner_o.start, ob.start - b.start, "the overlay keeps its distance from it");
}

#[test]
fn a_layer_that_starts_before_the_first_chosen_v1_clip_loses_only_that_head_so_the_clip_begins_at_zero() {
    let (m, d, main) = n_clips(3); // V1: 0–1 s, 1–3 s, 3–6 s
    let b = clip(&m, main[1]);
    m.set_playhead(SEC / 2);
    let o = m.add_media_to_overlay(vec![movie(&d, "o.mp4", DemoScene::Plasma, 48)], 1).unwrap()[0]; // 0.5–2.5 s
    let ob = clip(&m, o);
    assert!(ob.start < b.start && ob.start + ob.duration > b.start);
    let nest = m.create_composition(vec![main[1], o], "Composition".into()).unwrap();
    let comp = clip(&m, nest);
    assert_eq!(comp.start, b.start);
    open_sequence(&m, comp.item);
    let (_, inner_b) = lane_and_clip(&m, main[1]).expect("the V1 clip is inside");
    let (_, inner_o) = lane_and_clip(&m, o).expect("the overlay is inside");
    assert_eq!(inner_b.start, 0, "the V1 clip is the reference");
    assert_eq!(inner_o.start, 0, "the overlay begins with it");
    assert_eq!(inner_o.start + inner_o.duration, ob.start + ob.duration - b.start, "its end kept its place");
}

#[test]
fn a_layer_that_ends_before_the_first_chosen_v1_clip_cannot_join_the_composition() {
    let (m, d, main) = n_clips(3);
    m.set_playhead(0);
    let early = m.add_media_to_overlay(vec![movie(&d, "early.mp4", DemoScene::Plasma, 12)], 1).unwrap()[0]; // 0–0.5 s
    let before = layout(&m);
    assert!(m.create_composition(vec![main[1], early], "Composition".into()).is_err());
    assert_eq!(layout(&m), before, "nothing changed");
}

// ---- r12: Transform tool, text rotation and the history of a drag ----

#[test]
fn a_texts_rotation_is_reported_so_its_outline_turns_and_moving_or_scaling_keeps_it() {
    let m = MobileSession::new();
    m.new_project("P".into(), 1080, 1920, 30).unwrap();
    let id = m.add_text("Hello".into()).unwrap().unwrap();
    let p = m.placement(id).unwrap();
    assert_eq!(p.rotation, 0.0);
    m.set_placement(id, p.x, p.y, p.scale, 30.0, false).unwrap();
    assert!((m.placement(id).unwrap().rotation - 30.0).abs() < 1e-9, "the outline must be told the text is turned");
    // what the phone does on the next gesture: it starts from the placement it read
    let r = m.placement(id).unwrap();
    m.set_placement(id, r.x + 40.0, r.y - 20.0, r.scale, r.rotation, false).unwrap();
    let moved = m.placement(id).unwrap();
    assert!((moved.rotation - 30.0).abs() < 1e-9, "moving must not reset the turn: {moved:?}");
    assert!((moved.x - r.x - 40.0).abs() < 2.0 && (moved.y - r.y + 20.0).abs() < 2.0, "{r:?} {moved:?}");
    m.set_placement(id, moved.x, moved.y, moved.scale * 1.5, moved.rotation, false).unwrap();
    let scaled = m.placement(id).unwrap();
    assert!((scaled.rotation - 30.0).abs() < 1e-9 && (scaled.scale - moved.scale * 1.5).abs() < 1e-6, "{scaled:?}");
    // the turn survives editing the words and the style
    m.set_text(id, "Hello again".into()).unwrap();
    assert!((m.placement(id).unwrap().rotation - 30.0).abs() < 1e-9);
    let st = m.text_style(id).unwrap();
    m.set_text_style(id, st, false, false).unwrap();
    assert!((m.placement(id).unwrap().rotation - 30.0).abs() < 1e-9);
}

#[test]
fn a_text_rotation_is_kept_after_saving_and_opening_the_project_again() {
    let d = tmp();
    let m = MobileSession::new();
    m.new_project("P".into(), 1080, 1920, 30).unwrap();
    let id = m.add_text("Hello".into()).unwrap().unwrap();
    let p = m.placement(id).unwrap();
    m.set_placement(id, p.x + 100.0, p.y, p.scale, 25.0, false).unwrap();
    let path = d.join("p.filmcraft").to_string_lossy().into_owned();
    m.save_project(path.clone()).unwrap();
    let n = MobileSession::new();
    n.open_project(path).unwrap();
    n.select(Some(id)).unwrap();
    let q = n.placement(id).unwrap();
    assert!((q.rotation - 25.0).abs() < 1e-9, "{q:?}");
}

#[test]
fn dragging_a_text_is_one_undo_step_ending_where_the_finger_was_lifted() {
    let m = MobileSession::new();
    m.new_project("P".into(), 1080, 1920, 30).unwrap();
    let id = m.add_text("Hello".into()).unwrap().unwrap();
    m.forget_history();
    let start = m.placement(id).unwrap();
    // a drag: the first event starts the step, the rest are folded into it
    for i in 0..20 {
        let step = f64::from(i + 1) * 10.0;
        m.set_placement(id, start.x + step, start.y + step / 2.0, start.scale, start.rotation, i > 0).unwrap();
    }
    let end = m.placement(id).unwrap();
    assert!((end.x - start.x - 200.0).abs() < 2.0 && (end.y - start.y - 100.0).abs() < 2.0, "{start:?} {end:?}");
    m.undo();
    let back = m.placement(id).unwrap();
    assert!((back.x - start.x).abs() < 1e-6 && (back.y - start.y).abs() < 1e-6, "one undo goes straight back: {back:?}");
    assert!(!m.poll().can_undo, "the whole drag was a single step");
    m.redo();
    let again = m.placement(id).unwrap();
    assert!((again.x - end.x).abs() < 1e-6 && (again.y - end.y).abs() < 1e-6, "one redo goes straight to the end: {again:?}");
    assert!(!m.poll().can_redo);
}

#[test]
fn two_drags_in_a_row_are_two_undo_steps_for_a_text_and_for_a_picture() {
    let (m, _d, ids) = two_clips();
    let t = m.add_text("Hi".into()).unwrap().unwrap();
    for id in [ids[0], t] {
        m.forget_history();
        let p = m.placement(id).unwrap();
        for i in 0..5 {
            m.set_placement(id, p.x + f64::from(i) * 10.0, p.y, p.scale, p.rotation, i > 0).unwrap();
        }
        let mid = m.placement(id).unwrap();
        for i in 0..5 {
            m.set_placement(id, mid.x + f64::from(i) * 10.0, mid.y, mid.scale, mid.rotation, i > 0).unwrap();
        }
        m.undo();
        let one = m.placement(id).unwrap();
        assert!((one.x - mid.x).abs() < 1e-6, "the second drag alone is undone: {one:?} {mid:?}");
        m.undo();
        assert!((m.placement(id).unwrap().x - p.x).abs() < 1e-6, "the first drag is undone by the next step");
        assert!(!m.poll().can_undo);
    }
}

#[test]
fn transform_moves_exactly_in_percent_of_the_frame_and_past_its_edges_without_blocking() {
    let (m, _d, ids) = two_clips(); // a 1080×1920 frame
    let p = m.placement(ids[0]).unwrap();
    assert_eq!((p.x, p.y), (540.0, 960.0));
    m.transform_clips(vec![ids[0]], "position".into(), Some(25.0), Some(-10.0), false).unwrap();
    let a = m.placement(ids[0]).unwrap();
    assert!((a.x - (540.0 + 270.0)).abs() < 1e-6 && (a.y - (960.0 - 192.0)).abs() < 1e-6, "{a:?}");
    // beyond 100 %: wholly outside the frame, on every side
    m.transform_clips(vec![ids[0]], "position".into(), Some(150.0), Some(0.0), false).unwrap();
    assert!((m.placement(ids[0]).unwrap().x - (540.0 + 1620.0)).abs() < 1e-6);
    m.transform_clips(vec![ids[0]], "position".into(), Some(-300.0), Some(120.0), false).unwrap();
    let c = m.placement(ids[0]).unwrap();
    assert!((c.x - (540.0 - 3240.0)).abs() < 1e-6 && (c.y - (960.0 + 2304.0)).abs() < 1e-6, "{c:?}");
    // one axis only
    m.transform_clips(vec![ids[0]], "position".into(), None, Some(0.0), false).unwrap();
    let d = m.placement(ids[0]).unwrap();
    assert!((d.x - c.x).abs() < 1e-6 && (d.y - 960.0).abs() < 1e-6, "{d:?}");
    // steps add to what is there
    m.transform_clips(vec![ids[0]], "position".into(), Some(1.0), Some(-1.0), true).unwrap();
    let e = m.placement(ids[0]).unwrap();
    assert!((e.x - d.x - 10.8).abs() < 1e-6 && (e.y - d.y + 19.2).abs() < 1e-6, "{e:?}");
    // a technical limit, not a wall at the edge
    m.transform_clips(vec![ids[0]], "position".into(), Some(1.0e9), Some(0.0), false).unwrap();
    assert!((m.placement(ids[0]).unwrap().x - (540.0 + 10_800.0)).abs() < 1e-6);
    assert!(m.transform_clips(vec![ids[0]], "position".into(), Some(f64::NAN), None, false).is_err());
    assert!(m.transform_clips(vec![ids[0]], "sideways".into(), Some(1.0), None, false).is_err());
}

#[test]
fn transform_works_on_several_clips_and_text_as_one_undo_step_and_each_part_resets_alone() {
    let (m, _d, ids) = two_clips();
    let t = m.add_text("Hi".into()).unwrap().unwrap();
    let all = vec![ids[0], ids[1], t];
    m.forget_history();
    let before: Vec<_> = all.iter().map(|c| m.placement(*c).unwrap()).collect();
    m.transform_clips(all.clone(), "position".into(), Some(10.0), Some(5.0), true).unwrap();
    m.transform_clips(all.clone(), "zoom".into(), Some(50.0), None, false).unwrap();
    m.transform_clips(all.clone(), "rotate".into(), Some(90.0), None, false).unwrap();
    for (c, b) in all.iter().zip(&before) {
        let p = m.placement(*c).unwrap();
        // text turns and scales about its box's centre, so its letters' centre may drift a little
        let tol = if *c == t { 40.0 } else { 2.0 };
        assert!((p.x - b.x - 108.0).abs() < tol && (p.y - b.y - 96.0).abs() < tol, "{b:?} {p:?}");
        assert!((p.scale - 0.5).abs() < 1e-6 && (p.rotation - 90.0).abs() < 1e-9, "{p:?}");
    }
    // each reset puts back only its own part
    m.transform_clips(all.clone(), "reset_rotate".into(), None, None, false).unwrap();
    for c in &all {
        let p = m.placement(*c).unwrap();
        assert_eq!(p.rotation, 0.0);
        assert!((p.scale - 0.5).abs() < 1e-6, "zoom untouched: {p:?}");
        assert!(p.x > 600.0, "position untouched: {p:?}");
    }
    m.transform_clips(all.clone(), "reset_zoom".into(), None, None, false).unwrap();
    for (c, b) in all.iter().zip(&before) {
        assert!((m.placement(*c).unwrap().scale - b.scale).abs() < 1e-6 || *c == t);
    }
    m.transform_clips(all.clone(), "reset_position".into(), None, None, false).unwrap();
    for c in &all {
        let p = m.placement(*c).unwrap();
        assert!((p.x - 540.0).abs() < 2.0 && (p.y - 960.0).abs() < 2.0, "{p:?}");
    }
    // six calls: six undo steps, however many clips each one changed
    for _ in 0..6 {
        assert!(m.undo().is_some());
    }
    assert!(!m.poll().can_undo);
    for (c, b) in all.iter().zip(&before) {
        let p = m.placement(*c).unwrap();
        assert!((p.x - b.x).abs() < 1e-6 && (p.y - b.y).abs() < 1e-6 && (p.scale - b.scale).abs() < 1e-9 && p.rotation == b.rotation, "{b:?} {p:?}");
    }
}

#[test]
fn transform_skips_clips_without_a_picture_and_refuses_when_none_has_one() {
    let (m, d, ids) = two_clips();
    let sound = m.add_audio(vec![tone(&d, 1.0)]).unwrap();
    assert!(m.transform_clips(sound.clone(), "position".into(), Some(5.0), Some(5.0), false).is_err());
    let before = m.placement(ids[0]).unwrap();
    m.transform_clips(vec![ids[0], sound[0]], "position".into(), Some(5.0), None, false).unwrap();
    assert!((m.placement(ids[0]).unwrap().x - before.x - 54.0).abs() < 1e-6);
}

// ---- Files ▸ Composition: a saved project added as an independent composition ----

/// A saved project with two clips, at `<dir>/other.filmcraft`; a new empty project to add it to.
fn saved_project_and_a_new_one() -> (Arc<MobileSession>, Arc<MobileSession>, PathBuf, String, PathBuf) {
    let (other, d, _ids) = two_clips();
    let path = d.join("other.filmcraft").to_string_lossy().into_owned();
    other.save_project(path.clone()).unwrap();
    let cur = MobileSession::new();
    cur.new_project("Current".into(), 1080, 1920, 30).unwrap();
    let media = d.join("current-media");
    (other, cur, d, path, media)
}

#[test]
fn a_saved_project_is_added_as_a_composition_on_v2_with_its_sound_and_its_own_media() {
    let (_other, cur, d, path, media) = saved_project_and_a_new_one();
    let clip_id = cur.add_project_as_composition(path, "Other".into(), media.to_string_lossy().into_owned()).unwrap();
    let (lane, c) = lane_and_clip(&cur, clip_id).expect("the composition is on the timeline");
    assert_eq!(lane, 1, "V2 was free");
    assert!(c.composition && c.has_audio, "an editable composition with its sound");
    assert_eq!(c.start, 0);
    // its media were copied into this project: nothing points into the other one
    let paths: Vec<String> = cur
        .lock()
        .project
        .items
        .values()
        .filter_map(|i| i.as_media())
        .filter_map(|m| match &m.media {
            MediaRef::File { path } => Some(path.clone()),
            MediaRef::Generator(_) => None,
        })
        .collect();
    assert!(paths.len() >= 2);
    assert!(paths.iter().all(|p| Path::new(p).starts_with(&media) && Path::new(p).is_file()), "{paths:?} in {media:?} (originals in {d:?})");
}

#[test]
fn a_second_composition_takes_the_next_free_track_and_the_whole_add_is_one_undo_step() {
    let (_other, cur, _d, path, media) = saved_project_and_a_new_one();
    let media = media.to_string_lossy().into_owned();
    cur.forget_history();
    let first = cur.add_project_as_composition(path.clone(), "Other".into(), media.clone()).unwrap();
    let second = cur.add_project_as_composition(path, "Other".into(), media).unwrap();
    assert_eq!(lane_and_clip(&cur, first).unwrap().0, 1);
    assert_eq!(lane_and_clip(&cur, second).unwrap().0, 2, "V2 is taken, so V3");
    assert!(cur.undo().is_some());
    assert!(lane_and_clip(&cur, second).is_none() && lane_and_clip(&cur, first).is_some(), "one undo takes back the last add only");
    assert!(cur.undo().is_some());
    assert!(cur.timeline().unwrap().lanes.iter().all(|l| l.clips.is_empty()));
}

#[test]
fn the_added_composition_opens_edits_and_saves_without_touching_the_original() {
    let (other, cur, d, path, media) = saved_project_and_a_new_one();
    let root = cur.sequence_info().unwrap().id;
    let clip_id = cur.add_project_as_composition(path.clone(), "Other".into(), media.to_string_lossy().into_owned()).unwrap();
    let item = clip(&cur, clip_id).item;
    // opening it enters the composition (the same sequence of this project), not the other project
    open_sequence(&cur, item);
    assert_eq!(cur.sequence_info().unwrap().id, item);
    assert_eq!(clips_listed(&cur), 2, "the other project's two clips");
    let inside = cur.timeline().unwrap().lanes.iter().flat_map(|l| l.clips.iter().map(|c| c.id)).next().unwrap();
    cur.delete_clip(inside).unwrap();
    assert_eq!(clips_listed(&cur), 1);
    open_sequence(&cur, root);
    // the saved original still has both clips
    let again = MobileSession::new();
    again.open_project(path.clone()).unwrap();
    assert_eq!(clips_listed(&again), 2, "editing the composition did not change the project it came from");
    // and changing the original afterwards does not change the composition
    let first = other.timeline().unwrap().lanes.iter().flat_map(|l| l.clips.iter().map(|c| c.id)).next().unwrap();
    other.delete_clip(first).unwrap();
    other.save_project(path).unwrap();
    open_sequence(&cur, item);
    assert_eq!(clips_listed(&cur), 1, "the composition keeps what was edited in it");
    open_sequence(&cur, root);
    // it survives a save and a reopen of the current project
    let file = d.join("current.filmcraft").to_string_lossy().into_owned();
    cur.save_project(file.clone()).unwrap();
    let reopened = MobileSession::new();
    reopened.open_project(file).unwrap();
    let (_, c) = lane_and_clip(&reopened, clip_id).expect("the composition is saved with the project");
    assert!(c.composition);
}

#[test]
fn the_added_composition_still_plays_when_the_project_it_came_from_is_deleted() {
    let (_other, cur, d, path, media) = saved_project_and_a_new_one();
    let clip_id = cur.add_project_as_composition(path, "Other".into(), media.to_string_lossy().into_owned()).unwrap();
    // the other project's files go away
    for f in ["a.mp4", "b.mp4", "other.filmcraft"] {
        let _ = std::fs::remove_file(d.join(f));
    }
    let c = clip(&cur, clip_id);
    cur.set_playhead(c.start + c.duration / 2);
    let frame = cur.renderer().unwrap().frame(c.start + c.duration / 2, 270, false, None);
    assert!(frame.is_ok(), "the copy's media are its own files");
}

#[test]
fn a_project_with_nothing_on_its_timeline_is_not_added_and_leaves_no_files() {
    let d = tmp();
    let empty = MobileSession::new();
    empty.new_project("Empty".into(), 1080, 1920, 30).unwrap();
    let path = d.join("empty.filmcraft").to_string_lossy().into_owned();
    empty.save_project(path.clone()).unwrap();
    let cur = MobileSession::new();
    cur.new_project("Current".into(), 1080, 1920, 30).unwrap();
    let media = d.join("media");
    assert!(cur.add_project_as_composition(path, "Empty".into(), media.to_string_lossy().into_owned()).is_err());
    assert!(cur.timeline().unwrap().lanes.iter().all(|l| l.clips.is_empty()));
    assert!(!media.exists() || std::fs::read_dir(&media).unwrap().next().is_none(), "no stray media files");
    assert!(cur.add_project_as_composition(d.join("missing.filmcraft").to_string_lossy().into_owned(), "x".into(), media.to_string_lossy().into_owned()).is_err());
}

// ---- r15 round: a video moved or copied to V2/V3 never cuts or frees anyone's sound ----

/// (start, length) of the sound linked to video clip `id`.
fn sound_span(m: &MobileSession, id: u64) -> (i64, i64) {
    let s = m.lock();
    let seq = s.active_sequence().unwrap();
    let (_, v) = seq.find_item(filmcraft_project::ClipId(id)).unwrap();
    let a = model::partner(seq, v, TrackKind::Audio).expect("a video with sound has its sound linked");
    (a.clip.start.0, a.clip.duration.0)
}

fn sound_clip_count(m: &MobileSession) -> usize {
    let s = m.lock();
    s.active_sequence().unwrap().audio_tracks.iter().map(|t| t.items.len()).sum()
}

/// Every sound clip belongs to a picture (none is left on its own, which is how an "extracted"
/// sound looks), and no audio lane is listed.
fn assert_no_loose_sound(m: &MobileSession) {
    {
        let s = m.lock();
        let seq = s.active_sequence().unwrap();
        for t in &seq.audio_tracks {
            for it in &t.items {
                assert!(model::is_hidden_audio(seq, it), "a sound clip lost its picture: {:?}", it.name);
            }
        }
    }
    assert_eq!(audio_lanes_listed(m), 0);
}

fn overlay_at(m: &MobileSession, d: &Path, name: &str, frames: i64, lane: u32, at: i64) -> u64 {
    m.set_playhead(at);
    m.add_media_to_overlay(vec![movie(d, name, DemoScene::Dunes, frames)], lane).unwrap()[0]
}

#[test]
fn moving_an_overlay_video_never_cuts_the_sound_of_another_clip() {
    let d = tmp();
    let m = MobileSession::new();
    m.new_project("T".into(), 1080, 1920, 30).unwrap();
    m.add_media(vec![movie(&d, "base.mp4", DemoScene::Aurora, 24 * 30)]).unwrap();
    let a = overlay_at(&m, &d, "a.mp4", 48, 1, 0); // V2 0–2 s: its sound sits on the first free audio lane
    let b = overlay_at(&m, &d, "b.mp4", 48, 2, 5 * SEC); // V3 5–7 s: its sound is on that same lane, later
    m.set_playhead(0);
    let (a_sound, count) = (sound_span(&m, a), sound_clip_count(&m));
    // V3 is free at 0–2 s, but b's sound would land on a's sound lane over a's sound
    m.move_clip(b, 2, 0).unwrap();
    assert_eq!(clip(&m, b).start, 0);
    assert_eq!(sound_span(&m, a), a_sound, "a's sound is whole and where it was");
    assert_eq!(sound_span(&m, b), (0, clip(&m, b).duration), "b's sound went with it, as long as it");
    assert_eq!(sound_clip_count(&m), count, "no sound was added, cut or lost");
    assert_no_loose_sound(&m);
    assert!(clip(&m, a).has_audio && clip(&m, b).has_audio);
    // and the same in one undo step
    assert!(m.undo().is_some());
    assert_eq!(clip(&m, b).start, 5 * SEC);
    assert_eq!(sound_span(&m, b), (5 * SEC, clip(&m, b).duration));
    assert_no_loose_sound(&m);
}

#[test]
fn duplicating_an_overlay_video_never_cuts_the_sound_of_another_clip() {
    let d = tmp();
    let m = MobileSession::new();
    m.new_project("T".into(), 1080, 1920, 30).unwrap();
    m.add_media(vec![movie(&d, "base.mp4", DemoScene::Aurora, 24 * 30)]).unwrap();
    let a = overlay_at(&m, &d, "a.mp4", 48, 1, 0); // V2 0–2 s
    let c = overlay_at(&m, &d, "c.mp4", 48, 2, 2 * SEC); // V3 2–4 s: its sound is on a's sound lane at 2–4 s
    m.set_playhead(0);
    let (c_sound, count) = (sound_span(&m, c), sound_clip_count(&m));
    let copy = m.duplicate(a).unwrap(); // the copy goes to V2 at 2–4 s, where c's sound lane is taken
    assert_eq!(clip(&m, copy).start, 2 * SEC);
    assert!(clip(&m, copy).has_audio, "the copy has its own sound");
    assert_eq!(sound_span(&m, copy), (2 * SEC, clip(&m, a).duration));
    assert_eq!(sound_span(&m, c), c_sound, "c's sound was not cut");
    assert_eq!(sound_clip_count(&m), count + 1, "exactly one sound was added: the copy's");
    assert_no_loose_sound(&m);
    assert!(m.undo().is_some());
    assert_eq!(sound_clip_count(&m), count);
}

#[test]
fn a_main_clip_whose_sound_is_longer_than_its_picture_leaves_v1_without_cutting_other_sound() {
    let d = tmp();
    let m = MobileSession::new();
    m.new_project("T".into(), 1080, 1920, 30).unwrap();
    let x = m.add_media(vec![movie(&d, "x.mp4", DemoScene::Aurora, 24 * 3)]).unwrap()[0];
    let y = overlay_at(&m, &d, "y.mp4", 24, 1, 2 * SEC + SEC / 5); // V2, 2.2–3.2 s, its sound on A2 there
    m.set_playhead(0);
    {
        let mut s = m.lock();
        s.edit_sequence("shorten the picture", |q, _, _| {
            q.find_item_mut(filmcraft_project::ClipId(x)).unwrap().1.duration -= Tick(SEC);
            Ok(())
        })
        .unwrap();
    }
    let (y_sound, count) = (sound_span(&m, y), sound_clip_count(&m));
    assert!(sound_span(&m, x).1 > clip(&m, x).duration, "the sound is longer than the picture");
    m.move_clip(x, 2, 0).unwrap(); // V3 at 0–2 s; its 3 s of sound would reach y's sound on A2
    assert_eq!(sound_span(&m, y), y_sound, "y's sound was not cut by the longer sound");
    assert_eq!(sound_clip_count(&m), count);
    assert_no_loose_sound(&m);
}

#[test]
fn adding_a_video_to_an_overlay_lane_extracts_nothing() {
    let d = tmp();
    let m = MobileSession::new();
    m.new_project("T".into(), 1080, 1920, 30).unwrap();
    m.add_media(vec![movie(&d, "base.mp4", DemoScene::Aurora, 24 * 30)]).unwrap();
    for (i, lane) in [1u32, 2, 3].iter().enumerate() {
        let v = overlay_at(&m, &d, &format!("v{i}.mp4"), 48, *lane, SEC);
        assert!(clip(&m, v).has_audio);
        assert!(m.timeline().unwrap().lanes.iter().all(|l| l.kind != LaneKind::Audio), "no audio lane after adding to V{}", lane + 1);
        assert_no_loose_sound(&m);
    }
    // moving each of them around, then splitting one, still leaves no loose sound
    let ids: Vec<u64> = all_clips_ids(&m);
    for (i, id) in ids.iter().enumerate() {
        let _ = m.move_clip(*id, 1 + (i as i32 % 3), (i as i64) * 3 * SEC);
        assert_no_loose_sound(&m);
    }
}

fn all_clips_ids(m: &MobileSession) -> Vec<u64> {
    m.timeline().unwrap().lanes.iter().filter(|l| l.kind == LaneKind::Overlay).flat_map(|l| l.clips.iter().map(|c| c.id)).collect()
}

// ---- r16: keyframes and speed ramp ----

#[test]
fn keyframes_animate_between_their_times_keep_working_with_transform_and_undo() {
    let (m, _d, ids) = two_clips();
    let id = ids[0];
    let c = clip(&m, id);
    assert!(c.keyframes.is_empty());
    let start = m.set_playhead(c.start);
    let p0 = m.placement(id).unwrap();
    assert!(m.toggle_keyframe(id, "transform".into()).unwrap(), "no key here yet: one is added");
    assert_eq!(clip(&m, id).keyframes.len(), 1);
    let end = m.set_playhead(c.start + c.duration * 3 / 4);
    assert!(m.toggle_keyframe(id, "transform".into()).unwrap());
    // Transform at the second key moves the clip there and leaves the first key as it was
    m.transform_clips(vec![id], "position".into(), Some(40.0), Some(0.0), false).unwrap();
    let at_end = m.placement(id).unwrap();
    assert!((at_end.x - (540.0 + 0.4 * 1080.0)).abs() < 1e-6, "{at_end:?}");
    m.set_playhead(start);
    assert!((m.placement(id).unwrap().x - p0.x).abs() < 1e-6, "the first key is kept");
    // halfway between the keys the clip is halfway between the positions
    let mid = m.set_playhead((start + end) / 2);
    let f = (mid - start) as f64 / (end - start) as f64;
    let at_mid = m.placement(id).unwrap();
    assert!((at_mid.x - (p0.x + (at_end.x - p0.x) * f)).abs() < 2.0, "{at_mid:?} {f}");
    assert_eq!(clip(&m, id).keyframes.len(), 2, "one diamond per key time");
    // undo goes back to before the move; a key at the playhead can be taken away again
    m.undo();
    m.set_playhead(end);
    assert!((m.placement(id).unwrap().x - p0.x).abs() < 1e-6);
    m.set_playhead(start);
    assert!(!m.toggle_keyframe(id, "transform".into()).unwrap(), "a key is there: it is removed");
    assert_eq!(clip(&m, id).keyframes.len(), 1);
    m.undo();
    assert_eq!(clip(&m, id).keyframes.len(), 2);
}

#[test]
fn a_speed_ramp_changes_the_footage_played_not_the_clip_length_and_respects_the_footage() {
    let (m, _d, ids) = two_clips();
    let id = ids[0];
    let c = clip(&m, id);
    assert!(m.ramp_info(id).eligible);
    assert!(m.ramp_info(id).points.is_empty());
    m.set_playhead(c.start + c.duration / 2);
    // slower from the middle on: plays less footage, in the same length
    m.ramp_edit(id, "add".into(), 0, 50.0).unwrap();
    let r = m.ramp_info(id);
    assert_eq!(r.points.len(), 2, "the start (normal speed) and the point");
    assert!(r.played < c.duration, "{r:?}");
    assert_eq!(clip(&m, id).duration, c.duration, "the clip keeps its length");
    assert!(r.curve.first().unwrap() > r.curve.last().unwrap(), "{:?}", r.curve);
    // faster than the footage allows is refused and changes nothing
    let before = m.ramp_info(id);
    assert!(m.ramp_edit(id, "speed".into(), 1, 1600.0).is_err());
    assert_eq!(m.ramp_info(id).points.len(), before.points.len());
    // a ramp out, then undo and redo
    m.ramp_edit(id, "ease_out".into(), 0, 25.0).unwrap();
    assert!(m.ramp_info(id).curve.last().unwrap() < &60.0);
    m.undo();
    assert_eq!(m.ramp_info(id).points.len(), 2);
    m.undo();
    assert!(m.ramp_info(id).points.is_empty());
    m.redo();
    assert_eq!(m.ramp_info(id).points.len(), 2);
    m.ramp_edit(id, "clear".into(), 0, 0.0).unwrap();
    assert!(m.ramp_info(id).points.is_empty());
}

#[test]
fn only_a_video_longer_than_two_frames_can_have_a_speed_ramp() {
    let (m, d, _ids) = two_clips();
    let t = m.add_text("Hi".into()).unwrap().unwrap();
    assert!(!m.ramp_info(t).eligible);
    assert!(m.ramp_edit(t, "add".into(), 0, 50.0).is_err());
    let _ = d;
}

#[test]
fn a_keyframe_takes_each_of_the_premiere_interpolations_and_undo_restores_it() {
    let (m, _d, ids) = two_clips();
    let id = ids[0];
    let c = clip(&m, id);
    assert!(!m.key_interp_info(id, "transform".into()).has_keys);
    assert!(m.set_key_interp(id, "transform".into(), "linear".into()).is_err(), "no keyframe yet");
    let start = m.set_playhead(c.start);
    m.toggle_keyframe(id, "transform".into()).unwrap();
    let end = m.set_playhead(c.start + c.duration * 3 / 4);
    m.toggle_keyframe(id, "transform".into()).unwrap();
    m.transform_clips(vec![id], "position".into(), Some(40.0), Some(0.0), false).unwrap();
    // on the first key: it is the key, the stretch runs to the second one
    m.set_playhead(start);
    let i = m.key_interp_info(id, "transform".into());
    assert!(i.has_keys && i.prev == -1 && i.key == start && i.next == end, "{i:?}");
    assert_eq!(i.current, "linear");
    let halfway = |m: &MobileSession| {
        m.set_playhead((start + end) / 2);
        m.placement(id).unwrap().x
    };
    let linear = halfway(&m);
    m.set_playhead(start);
    for kind in ["bezier", "auto_bezier", "continuous_bezier", "hold", "ease_in", "ease_out", "linear"] {
        let now = m.set_key_interp(id, "transform".into(), kind.into()).unwrap();
        assert_eq!(now.current, kind);
        assert_eq!(m.key_interp_info(id, "transform".into()).current, kind);
        m.set_playhead(start);
    }
    assert!(m.set_key_interp(id, "transform".into(), "nonsense".into()).is_err());
    // hold keeps the first value until the next key; ease out starts slowly; linear is steady again
    m.set_key_interp(id, "transform".into(), "hold".into()).unwrap();
    let held = halfway(&m);
    m.set_playhead(start);
    m.set_key_interp(id, "transform".into(), "ease_out".into()).unwrap();
    let eased = halfway(&m);
    assert!(held < linear && eased < linear, "hold {held}, ease out {eased}, linear {linear}");
    m.set_playhead(start);
    m.set_key_interp(id, "transform".into(), "linear".into()).unwrap();
    assert!((halfway(&m) - linear).abs() < 1e-6);
    // on the second key the stretch before it is the one to show
    m.set_playhead(end);
    let i = m.key_interp_info(id, "transform".into());
    assert!(i.key == end && i.prev == start, "{i:?}");
    // undo takes an interpolation back
    m.set_playhead(start);
    m.set_key_interp(id, "transform".into(), "ease_out".into()).unwrap();
    m.undo();
    assert_eq!(m.key_interp_info(id, "transform".into()).current, "linear");
}

#[test]
fn a_keyframe_can_be_moved_in_time_and_not_onto_another() {
    let (m, _d, ids) = two_clips();
    let id = ids[0];
    let c = clip(&m, id);
    let a = m.set_playhead(c.start);
    m.toggle_keyframe(id, "transform".into()).unwrap();
    let b = m.set_playhead(c.start + c.duration * 3 / 4);
    m.toggle_keyframe(id, "transform".into()).unwrap();
    let mid = c.start + c.duration / 2;
    let now = m.move_key(id, "transform".into(), a, mid).unwrap();
    assert!((now - mid).abs() <= 2);
    m.set_playhead(now);
    assert!(m.key_interp_info(id, "transform".into()).key == now, "the key is where it was moved to");
    assert!(m.move_key(id, "transform".into(), now, b).is_err(), "not onto the other key");
    m.undo();
    m.set_playhead(a);
    assert_eq!(m.key_interp_info(id, "transform".into()).key, a, "undo puts it back");
}

// ---- r18: transform and audio keyframes are separate families ----

#[test]
fn transform_and_audio_keyframes_have_their_own_keys_removal_and_undo() {
    let (m, _d, ids) = two_clips();
    let id = ids[0];
    let c = clip(&m, id);
    let t0 = m.set_playhead(c.start);
    let t1 = m.set_playhead(c.start + c.duration / 2);
    let t2 = m.set_playhead(c.start + c.duration * 3 / 4);
    assert!(t0 < t1 && t1 < t2);
    // transform keys at t0 and t1; audio keys at t1 and t2
    m.set_playhead(t0);
    assert!(m.toggle_keyframe(id, "transform".into()).unwrap());
    m.set_playhead(t1);
    assert!(m.toggle_keyframe(id, "transform".into()).unwrap());
    assert!(m.toggle_keyframe(id, "audio".into()).unwrap());
    m.set_playhead(t2);
    assert!(m.toggle_keyframe(id, "audio".into()).unwrap());
    let k = clip(&m, id);
    assert_eq!((k.transform_keyframes.len(), k.audio_keyframes.len()), (2, 2));
    // a key of one family at a time never turns up in the other
    assert!(!k.audio_keyframes.iter().any(|a| (a - t0).abs() <= SEC / 240));
    assert!(!k.transform_keyframes.iter().any(|a| (a - t2).abs() <= SEC / 240));
    // taking the audio key at t1 away leaves both transform keys
    m.set_playhead(t1);
    assert!(!m.toggle_keyframe(id, "audio".into()).unwrap());
    let k = clip(&m, id);
    assert_eq!((k.transform_keyframes.len(), k.audio_keyframes.len()), (2, 1));
    // taking the transform key at t1 away leaves the audio key at t2
    assert!(!m.toggle_keyframe(id, "transform".into()).unwrap());
    let k = clip(&m, id);
    assert_eq!((k.transform_keyframes.len(), k.audio_keyframes.len()), (1, 1));
    // undo brings back only the last operation
    m.undo();
    let k = clip(&m, id);
    assert_eq!((k.transform_keyframes.len(), k.audio_keyframes.len()), (2, 1));
    m.undo();
    let k = clip(&m, id);
    assert_eq!((k.transform_keyframes.len(), k.audio_keyframes.len()), (2, 2));
    // an unknown family is refused
    assert!(m.toggle_keyframe(id, "everything".into()).is_err());
}

#[test]
fn editing_one_family_does_not_touch_the_keys_of_the_other() {
    let (m, _d, ids) = two_clips();
    let id = ids[0];
    let c = clip(&m, id);
    let t0 = m.set_playhead(c.start);
    let t1 = m.set_playhead(c.start + c.duration / 2);
    let t2 = m.set_playhead(c.start + c.duration * 3 / 4);
    m.set_playhead(t0);
    m.toggle_keyframe(id, "transform".into()).unwrap();
    m.set_playhead(t1);
    m.toggle_keyframe(id, "transform".into()).unwrap();
    m.toggle_keyframe(id, "audio".into()).unwrap();
    m.set_playhead(t2);
    m.toggle_keyframe(id, "audio".into()).unwrap();
    let transform_before = clip(&m, id).transform_keyframes.clone();
    let audio_before = clip(&m, id).audio_keyframes.clone();
    // moving the volume (a key is at the playhead) and a transform value changes values, not key lists
    m.set_playhead(t1);
    m.set_volume(id, 0.5, false).unwrap();
    assert_eq!(clip(&m, id).transform_keyframes, transform_before);
    m.transform_clips(vec![id], "position".into(), Some(10.0), Some(0.0), false).unwrap();
    assert_eq!(clip(&m, id).audio_keyframes, audio_before);
    // interpolation of an audio key leaves the transform key at the same moment as it was
    let before = m.key_interp_info(id, "transform".into()).current;
    let now = m.set_key_interp(id, "audio".into(), "hold".into()).unwrap();
    assert_eq!(now.current, "hold");
    assert_eq!(m.key_interp_info(id, "transform".into()).current, before);
    // moving an audio key leaves the transform keys exactly where they are
    let from = clip(&m, id).audio_keyframes[1];
    let to = (t1 + t2) / 2;
    let moved = m.move_key(id, "audio".into(), from, to).unwrap();
    let k = clip(&m, id);
    assert_eq!(k.transform_keyframes, transform_before);
    assert!(k.audio_keyframes.iter().any(|a| (a - moved).abs() <= SEC / 240));
    // and the other way round
    let audio_now = k.audio_keyframes.clone();
    let tfrom = clip(&m, id).transform_keyframes[0];
    m.move_key(id, "transform".into(), tfrom, t0 + (t1 - t0) / 2).unwrap();
    assert_eq!(clip(&m, id).audio_keyframes, audio_now);
    // one undo step per operation: undoing the transform move brings back only that key
    m.undo();
    assert_eq!(clip(&m, id).transform_keyframes, transform_before);
    assert_eq!(clip(&m, id).audio_keyframes, audio_now);
}

#[test]
fn both_families_of_keyframes_survive_saving_and_opening_the_project() {
    let (m, d, ids) = two_clips();
    let id = ids[0];
    let c = clip(&m, id);
    let t0 = m.set_playhead(c.start);
    let t1 = m.set_playhead(c.start + c.duration / 2);
    m.set_playhead(t0);
    m.toggle_keyframe(id, "transform".into()).unwrap();
    m.set_playhead(t1);
    m.toggle_keyframe(id, "audio".into()).unwrap();
    let (tk, ak) = (clip(&m, id).transform_keyframes.clone(), clip(&m, id).audio_keyframes.clone());
    assert_eq!((tk.len(), ak.len()), (1, 1));
    let path = d.join("keys.fcproj").to_string_lossy().into_owned();
    m.save_project(path.clone()).unwrap();
    m.open_project(path).unwrap();
    let again = main_clips(&m).into_iter().next().unwrap();
    assert_eq!(again.transform_keyframes, tk);
    assert_eq!(again.audio_keyframes, ak);
}

// ---- r18 task 3: animated values change progressively in playback, and survive save, extract and export ----

/// The RMS of the mix over `frames` samples from `sec` seconds, read through the same `Renderer` the phone plays.
fn mix_rms(m: &MobileSession, sec: f64, frames: u32) -> f64 {
    let r = m.renderer().unwrap();
    let bytes = r.mix((sec * f64::from(r.sample_rate())) as i64, frames);
    let v: Vec<f32> = bytes.chunks_exact(4).map(|b| f32::from_le_bytes([b[0], b[1], b[2], b[3]])).collect();
    (v.iter().map(|x| f64::from(*x).powi(2)).sum::<f64>() / v.len().max(1) as f64).sqrt()
}

/// A 2 s tone on its own audio layer over the two muted clips: (session, folder, the tone's id).
fn tone_layer() -> (Arc<MobileSession>, PathBuf, u64) {
    let (m, d, ids) = two_clips();
    m.set_muted(ids[0], true).unwrap();
    m.set_muted(ids[1], true).unwrap();
    m.set_playhead(0);
    let snd = m.add_audio(vec![tone(&d, 2.0)]).unwrap()[0];
    (m, d, snd)
}

/// Volume 0 at 0 s and 100 % at 1.5 s, on audio layer `id`.
fn ramp_volume(m: &MobileSession, id: u64) {
    m.set_playhead(0);
    assert!(m.toggle_keyframe(id, "audio".into()).unwrap());
    m.set_volume(id, 0.0, false).unwrap();
    m.set_playhead(3 * SEC / 2);
    assert!(m.toggle_keyframe(id, "audio".into()).unwrap());
    m.set_volume(id, 1.0, false).unwrap();
}

#[test]
fn a_volume_from_zero_to_full_rises_progressively_in_playback() {
    let (m, _d, snd) = tone_layer();
    let points = [0.375, 0.75, 1.125];
    let full: Vec<f64> = points.iter().map(|s| mix_rms(&m, *s, 2048)).collect();
    assert!(full.iter().all(|x| *x > 1e-4), "the tone must be audible: {full:?}");
    ramp_volume(&m, snd);
    let got: Vec<f64> = points.iter().zip(&full).map(|(s, f)| mix_rms(&m, *s, 2048) / f).collect();
    // a quarter, a half and three quarters of the way up, not silent and then a jump
    for (g, want) in got.iter().zip([0.25, 0.5, 0.75]) {
        assert!((g - want).abs() < 0.08, "{got:?} (want about {want})");
    }
    assert!(got[0] < got[1] && got[1] < got[2]);
    assert!(mix_rms(&m, 0.0, 256) < 0.02 * full[0], "it starts from silence");
    // past the last key the level holds at full: the same level as before any animation
    let full_late = {
        let (m2, _d2, _snd2) = tone_layer();
        mix_rms(&m2, 1.75, 2048)
    };
    assert!((mix_rms(&m, 1.75, 2048) / full_late - 1.0).abs() < 0.03, "full level once the last key is passed");
}

#[test]
fn the_animation_and_its_values_survive_saving_and_opening_the_project() {
    let (m, d, snd) = tone_layer();
    ramp_volume(&m, snd);
    let (keys, volume) = (clip(&m, snd).audio_keyframes.clone(), mix_rms(&m, 0.75, 2048));
    assert_eq!(keys.len(), 2);
    let path = d.join("anim.fcproj").to_string_lossy().into_owned();
    m.save_project(path.clone()).unwrap();
    let n = MobileSession::new();
    n.open_project(path).unwrap();
    assert_eq!(clip(&n, snd).audio_keyframes, keys);
    assert!((mix_rms(&n, 0.75, 2048) - volume).abs() < 1e-6, "the reopened ramp sounds the same");
    assert!(volume > 1e-4);
}

#[test]
fn extracting_the_audio_keeps_the_volume_keyframes() {
    let (m, _d, ids) = two_clips();
    let id = ids[0];
    let c = clip(&m, id);
    m.set_playhead(c.start);
    m.toggle_keyframe(id, "audio".into()).unwrap();
    m.set_volume(id, 0.0, false).unwrap();
    m.set_playhead(c.start + c.duration * 3 / 4);
    m.toggle_keyframe(id, "audio".into()).unwrap();
    m.set_volume(id, 1.0, false).unwrap();
    let keys = clip(&m, id).audio_keyframes.clone();
    assert_eq!(keys.len(), 2);
    let a = m.extract_audio(id).unwrap();
    assert_eq!(clip(&m, a).audio_keyframes, keys, "the extracted sound keeps the same keys at the same times");
    // and the video's own sound still carries them (it is only switched off)
    assert_eq!(clip(&m, id).audio_keyframes, keys);
}

#[test]
fn a_composition_keeps_its_animated_values_through_a_save() {
    let (m, d, ids) = two_clips();
    let nest = m.create_composition(vec![ids[0], ids[1]], "Composition".into()).unwrap();
    let c = clip(&m, nest);
    m.set_playhead(c.start);
    assert!(m.toggle_keyframe(nest, "transform".into()).unwrap());
    m.set_playhead(c.start + c.duration / 2);
    assert!(m.toggle_keyframe(nest, "transform".into()).unwrap());
    let keys = clip(&m, nest).transform_keyframes.clone();
    assert_eq!(keys.len(), 2);
    let path = d.join("comp.fcproj").to_string_lossy().into_owned();
    m.save_project(path.clone()).unwrap();
    let n = MobileSession::new();
    n.open_project(path).unwrap();
    assert_eq!(clip(&n, nest).transform_keyframes, keys);
}

#[test]
fn an_export_with_an_animated_volume_finishes() {
    let (m, d, snd) = tone_layer();
    ramp_volume(&m, snd);
    let out = d.join("anim.mp4").to_string_lossy().into_owned();
    let job = m.start_export(out.clone(), export::ExportSettings { short_side: 720, fps: 30, quality: export::ExportQuality::Low }).unwrap();
    let start = std::time::Instant::now();
    let status = loop {
        let st = m.export_status(job).unwrap();
        if st.finished || start.elapsed().as_secs() > 120 {
            break st;
        }
        std::thread::sleep(std::time::Duration::from_millis(100));
    };
    assert!(status.finished && status.error.is_none(), "{status:?}");
    assert!(std::fs::metadata(&out).unwrap().len() > 1000);
}
