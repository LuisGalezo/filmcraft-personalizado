# Python REPLICA of Timeline.kt Geometry + TimelineMath.laneTops (not the Kotlin code itself).
import itertools
DP=1.0; M=8*DP; GAP=2*DP; RULER=19*DP
def lane_tops(hs, main, gap, area, scroll):
    tops=[];y=0
    for h in hs: tops.append(y); y+=h+gap
    total=y-gap; mc=tops[main]+hs[main]/2
    off=area/2-mc
    off = min(max(off,0),area-total) if total<=area else min(max(off-scroll,area-total),0)
    return [t+off for t in tops], total
def geom(kinds, H, scroll, captions=False):
    hs=[64*DP if k=='M' else 48*DP for k in kinds]
    area=max(H-RULER,1); sa=max(area-2*M,1)
    lh=([28*DP] if captions else [])+hs
    main=kinds.index('M')+(1 if captions else 0)
    mc=sum(lh[:main])+GAP*main+lh[main]/2
    total=sum(lh)+GAP*(len(lh)-1)
    smin=sa/2-mc; smax=smin+max(total-sa,0)
    tops,_=lane_tops(lh,main,GAP,sa,scroll)
    tops=[t+RULER+M for t in tops]
    return tops,lh,total,sa,smin,smax
configs=[list('M'),list('OM'),list('OMA'),list('OOMA'),list('OOOOOMAA'),list('MA'),list('OOM')]
bad=0;n=0
for kinds in configs:
  for caps in (False,True):
    for H in range(60,500,7):
        tops,lh,total,sa,smin,smax=geom(kinds,H,0,caps)
        if total>sa:
            # reachable: at smin first lane at top margin, at smax last lane at bottom margin
            t0,*_ = geom(kinds,H,smin,caps)[:1]; t1=geom(kinds,H,smax,caps)[0]
            ok = abs(t0[0]-(RULER+M))<1e-6 and abs(t1[-1]+lh[-1]-(H-M))<1e-6
            # scrolling through the range never leaves a gap bigger than the margin at either end
            for s in (smin+(smax-smin)*k/10 for k in range(11)):
                tt=geom(kinds,H,s,caps)[0]
                ok &= tt[0] <= RULER+M+1e-6 and tt[-1]+lh[-1] >= H-M-1e-6
        else:
            ok = all(t>=RULER+M-1e-6 and t+h<=H-M+1e-6 for t,h in zip(tops,lh))
        n+=1
        if not ok: bad+=1; print('FAIL',kinds,caps,H)
print(f'{n} layouts checked, {bad} failures')
# smallest timeline that shows V1 alone completely
print('min height to show V1 whole (dp):',RULER+2*M+64)
