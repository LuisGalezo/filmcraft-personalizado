# Seven Cut Pro r35 — «Diagnóstico y aceleración de hardware» (pantalla interna, interruptores, estado CPU/GPU/MediaCodec)

Base: r34. **No se compiló nada ni se ejecutó ninguna prueba** (este entorno no tiene Rust, Kotlin, Gradle ni Android SDK, ni red). Todo el código está revisado a mano, nada más. Tampoco se ha visto la pantalla en un teléfono.

## Qué se implementó (escrito, sin compilar)

**1. Sección interna** — *Ajustes → Diagnóstico y aceleración de hardware* (una fila nueva en la pantalla de Ajustes que ya existía; la interfaz principal no cambia). Nueva pantalla `ui/home/HardwareScreen.kt`, con el mismo aspecto que Ajustes (`Page`/`Row48`, que pasan de `private` a `internal` para reutilizarlos).

**2. Diagnóstico GPU desde la app, con resultados en pantalla** — botón «Ejecutar diagnóstico GPU» (unos segundos, hilo aparte, con tiempo límite y protección ante cuelgues del driver). Muestra: GPU elegida o por qué no hay ninguna, duración y RAM, y lo de los puntos 3 y 4.

**3. Qué enseña** — dispositivo (modelo, Android, SoC, ABIs, RAM, **versión/nivel de Vulkan declarados, versión de OpenGL ES**), por cada backend (**Vulkan** y **OpenGL ES**) sus adaptadores con driver, límites, **formatos de textura compatibles** (muestreo, dibujo, mezcla, filtrado, copia), reservas de prueba, **memoria** (presupuesto, tamaño máximo de fotograma, compositores a la vez), las **15 funciones acelerables** con ✓ / ~ / ✕ y motivo, y la **integración progresiva** (7 pasos: composición, efectos, filtros, transiciones, máscaras/croma, texto, lectura en 8 bits) diciendo qué puede el teléfono y que el motor **aún no los implementa**.

**4. Compartir sin entrar en Android/data** — «Compartir informe» (hoja de compartir del sistema, archivo de texto por el `FileProvider` que la app ya tenía, carpeta `cache/share`) y «Copiar informe» (portapapeles). El informe incluye dispositivo, sistema en uso, codificadores de MediaCodec, detección para exportar y el diagnóstico GPU.

**5. GPU desactivada por defecto** — interruptor «Aceleración GPU (experimental)», **apagado** y **bloqueado hasta que un diagnóstico en el teléfono encuentre una GPU utilizable**. Al reiniciar solo se restaura si **esa misma versión de la app** lo validó. Honestidad: **el motor aún no tiene compositor GPU, así que activarlo no cambia nada salvo el estado**: todo se sigue componiendo en CPU y la pantalla lo dice («solicitada, pero aún no implementado»). La petición ya viaja en la exportación como `gpuRendering: "auto" | "off"`; sin compositor registrado el motor usa la CPU (comprobado leyendo el código).

**6. Preparación de la integración progresiva de wgpu** — `crates/gpu/src/stages.rs`: los 7 pasos con las funciones del dispositivo que necesita cada uno y un indicador `implemented` (todo `false` hoy; una prueba lo documenta). Cuando se implemente una etapa, solo cambia ese indicador (y `GPU_COMPOSITOR_AVAILABLE` en `hardware.rs`).

**7. MediaCodec se mantiene, con respaldo por software** — interruptor «Usar MediaCodec al exportar», **activado por defecto** como desde r32. Cambio de fondo: la fábrica de MediaCodec ahora **respeta el ajuste oficial del motor `hardwareEncoding`** (la app lo manda como `auto`/`off`) y **actualiza los contadores que el motor ya tenía** (`hw_encode_stats`: sesiones, fotogramas, rechazos). Si MediaCodec no admite la configuración, no se abre o falla, se usa el software como antes.

**8. Qué sistema está trabajando** — tarjeta «Sistema en uso» con etiquetas **CPU / GPU / GPU + CPU / MediaCodec / Software** para: decodificación (CPU), vista previa (CPU), composición, efectos, filtros y transiciones en exportación (CPU hoy; GPU solo si los contadores del motor registran fotogramas compuestos en GPU), texto (CPU) y codificación H.264 (MediaCodec o software según la última exportación, con contadores). **GPU y MediaCodec se muestran y se controlan por separado**: la GPU compone imágenes; MediaCodec solo codifica el vídeo ya compuesto.

## Cambio de comportamiento que debes conocer
- **wgpu ahora va en la compilación normal de Android** (antes solo con una opción): hace falta para que la app pueda diagnosticar sin GitHub Actions cada vez. Es la propiedad `-Pfilmcraft.gpuProbe`, ahora **activada por defecto**; `-Pfilmcraft.gpuProbe=false` compila sin wgpu (en el flujo *Compilar…*, desmarcar `gpu_probe`; el APK sale como `…-sin-wgpu.apk`) y la pantalla lo dice.
- **Riesgo real:** el código de wgpu (`probe_wgpu.rs`, de r34) **nunca se ha compilado**. Si falla, la primera compilación fallará. Salida: ejecutar el flujo con `gpu_probe` desmarcado para seguir teniendo APK, y enviarme el log. Las compilaciones por *push* usan siempre el valor por defecto (con wgpu).
- Cambia `Cargo.lock` (dependencias de wgpu): hace falta red y no sirve `--locked`.
- El arranque con sondeo automático ahora solo ocurre si existe el archivo `gpu_probe.enable` (opcional, para pruebas); lo normal es la pantalla.

## Archivos
Nuevos: `crates/gpu/src/stages.rs`, `apps/filmcraft-android/src/hardware.rs`, `…/ui/HardwareModel.kt`, `…/ui/home/HardwareScreen.kt`, `…/engine/HardwareInfo.kt`, prueba `HardwareInfoTest.kt`.
Modificados: `crates/export/src/hw_h264.rs` y `hw_h264_tests.rs` (respeta `hardwareEncoding`, contadores), `crates/gpu/src/lib.rs` y `Cargo.toml`, `apps/filmcraft-android/src/{gpu.rs, export.rs, lib.rs}` y `Cargo.toml`, `…/engine/MediaCodecH264.kt`, `FilmcraftApplication.kt`, `ui/{AppViewModel, AppRoot}.kt`, `ui/home/SettingsScreens.kt` (una fila y dos `internal`), `app/build.gradle.kts`, `.github/workflows/compilar-apk.yml`.
Sin tocar: interfaz principal, editor, herramientas, render por CPU, importación de fuentes, Speed Ramp.

## Pruebas escritas (NO ejecutadas)
- **Rust, motor:** `hardware_encoding_off…` (Off ⇒ software y MediaCodec ni se abre), contadores del motor tras una exportación con el respaldo simulado y tras un rechazo; las de r32/r33 ajustadas para `hardwareEncoding: auto`.
- **Rust, GPU:** `stages` (4: nada implementado, «tan bueno como lo peor que necesita», función no comprobada = no soportada, títulos).
- **Rust, app:** `hardware.rs` (6: valores por defecto, CPU en decodificación/vista previa/texto, composición CPU con su motivo, GPU / GPU+CPU solo con contadores, nombre del codificador desde la nota del motor, MediaCodec desactivado ⇒ software); `gpu.rs` (3: teléfono capaz con adaptador, formatos, funciones, pasos y presupuesto; sin GPU utilizable; sin wgpu).
- **Kotlin (JVM):** `HardwareInfoTest` (versiones de Vulkan y OpenGL ES, megabytes, informe con todas sus secciones y vacío).

## Lo que NO se pudo comprobar
Compilación de Rust y de Android; ninguna prueba; la API de wgpu 24; el aspecto y comportamiento de la pantalla; que Compartir/Copiar funcionen en tu teléfono; el nombre exacto de los campos que genera UniFFI en Kotlin (p. ej. `compositor1080pF16Mb`); tiempos, memoria y consumo reales; nada de GPU real.

## Siguiente paso
1. Ejecutar *Compilar…* (con `gpu_probe` activado) y pasarme el log; lo probable es corregir errores pequeños de `probe_wgpu.rs` y de nombres de UniFFI. Si wgpu no compila, usar `gpu_probe` desmarcado para tener APK mientras se corrige.
2. Abrir *Ajustes → Diagnóstico y aceleración de hardware*, pulsar *Ejecutar diagnóstico GPU* y *Compartir informe*.
3. Con ese informe decidimos la etapa de composición GPU.
