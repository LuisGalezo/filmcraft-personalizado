//! Speed ramps: a clip whose speed changes as it plays.
//!
//! The ramp is the Time Remapping effect's `speed` parameter with keyframes. Like every keyframed
//! parameter its keys sit on *media* time (so trimming, splitting or moving the clip keeps each key
//! on the same moment of the footage), and its value is the speed in % of the clip's own speed at
//! that moment of the footage. How far the footage has played after `rel` timeline ticks is
//! therefore the solution of `dm/dt = speed(m)`; it is found piece by piece between keys (Simpson's
//! rule for the time a piece takes, bisection to invert it). The clip keeps its length on the
//! timeline; what changes is how much footage it plays.
use filmcraft_time::Tick;

use crate::{Param, TrackItem};

/// The slowest a ramp may go (1 % of the clip's speed): media time always moves forward.
pub const MIN_RAMP_PERCENT: f64 = 1.0;
/// The fastest (1600 %).
pub const MAX_RAMP_PERCENT: f64 = 1600.0;

impl TrackItem {
    /// The speed curve of a ramped clip (Time Remapping ▸ Speed with keyframes), if it has one.
    pub fn speed_ramp(&self) -> Option<&Param> {
        self.effect("time_remap").filter(|e| e.enabled).and_then(|e| e.param("speed")).filter(|p| p.is_animated())
    }

    /// Media ticks per timeline tick at media tick `m` of a ramped clip.
    pub fn ramp_speed(&self, p: &Param, m: f64) -> f64 {
        let percent = p.f64_at(Tick(m.round() as i64));
        let percent = if percent.is_finite() { percent.clamp(MIN_RAMP_PERCENT, MAX_RAMP_PERCENT) } else { 100.0 };
        (self.speed.abs().max(1e-6) * percent / 100.0).max(1e-6)
    }

    /// Timeline ticks it takes to play media ticks `a..b` (Simpson over 1/speed).
    fn ramp_span(&self, p: &Param, a: f64, b: f64) -> f64 {
        if b <= a {
            return 0.0;
        }
        const N: usize = 16;
        let h = (b - a) / N as f64;
        // the last sample stops one tick short of a key so a Hold key's jump is not read early
        let f = |m: f64| 1.0 / self.ramp_speed(p, m);
        let mut sum = f(a) + f((b - 1.0).max(a));
        for i in 1..N {
            sum += f(a + h * i as f64) * if i % 2 == 1 { 4.0 } else { 2.0 };
        }
        sum * h / 3.0
    }

    fn ramp_breaks(&self, p: &Param) -> Vec<f64> {
        let start = self.source_in.0 as f64;
        p.keyframes.iter().map(|k| k.time.0 as f64).filter(|&t| t > start).collect()
    }

    /// Media ticks played after `rel` timeline ticks of the clip (forward, from its source in).
    pub fn ramp_media_after(&self, p: &Param, rel: f64) -> f64 {
        let start = self.source_in.0 as f64;
        if rel <= 0.0 {
            return rel * self.ramp_speed(p, start);
        }
        let mut a = start;
        let mut left = rel;
        for b in self.ramp_breaks(p) {
            let seg = self.ramp_span(p, a, b);
            if seg >= left {
                // inside this piece: bisect for the media tick that takes `left`
                let (mut lo, mut hi) = (a, b);
                for _ in 0..28 {
                    let mid = (lo + hi) / 2.0;
                    if self.ramp_span(p, a, mid) < left {
                        lo = mid;
                    } else {
                        hi = mid;
                    }
                }
                return (lo + hi) / 2.0 - start;
            }
            left -= seg;
            a = b;
        }
        // past the last key the speed stays where it ended
        a + left * self.ramp_speed(p, a) - start
    }

    /// Timeline ticks it takes to play `off` media ticks of a ramped clip from its source in.
    pub fn ramp_time_to(&self, p: &Param, off: f64) -> f64 {
        let start = self.source_in.0 as f64;
        if off <= 0.0 {
            return off / self.ramp_speed(p, start);
        }
        let target = start + off;
        let mut a = start;
        let mut acc = 0.0;
        for b in self.ramp_breaks(p) {
            if b >= target {
                break;
            }
            acc += self.ramp_span(p, a, b);
            a = b;
        }
        acc + self.ramp_span(p, a, target)
    }

    /// Media ticks the item plays over its whole length (its source out minus its source in).
    pub fn media_played(&self) -> Tick {
        match self.speed_ramp() {
            Some(p) => Tick(self.ramp_media_after(p, self.duration.0 as f64).round() as i64),
            None => Tick((self.duration.0 as f64 * self.speed.abs()).round() as i64),
        }
    }

    /// The timeline time at which the item shows media time `m` (the inverse of
    /// [`TrackItem::source_time_at`] ignoring frame holds).
    pub fn timeline_time_of(&self, m: Tick) -> Tick {
        let off = (m.0 - self.source_in.0) as f64;
        let dur = self.duration.0 as f64;
        let rel = match self.speed_ramp() {
            Some(p) => {
                let total = self.ramp_media_after(p, dur);
                self.ramp_time_to(p, if self.reverse { total - off - 1.0 } else { off })
            }
            None => {
                let sp = self.speed.abs().max(1e-6);
                if self.reverse { dur - (off + 1.0) / sp } else { off / sp }
            }
        };
        self.start + Tick(rel.round() as i64)
    }
}
