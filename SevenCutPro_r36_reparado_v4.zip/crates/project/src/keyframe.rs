//! Keyframed parameters.
//!
//! A parameter is a static value or a list of keyframes (clip-relative ticks). Interpolation per
//! keyframe governs the segment leaving it: Linear, Hold, Bezier (with influence/speed handles),
//! Auto Bezier, Continuous Bezier, Ease In/Out (Bezier presets) — Premiere's temporal set.

use filmcraft_geom::Vec2;
use filmcraft_time::Tick;
use serde::{Deserialize, Serialize};

#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
pub enum ParamValue {
    Float(f64),
    /// A point. A coordinate may be NaN: point parameters use NaN for "auto" (the frame or source
    /// centre) until [`crate::resolve_auto_points`] fills it in. JSON has no NaN and writes it as
    /// `null`, so `null` reads back as NaN here, and only here: a `null` coordinate anywhere else
    /// in a project (a mask vertex, a layer rectangle) is still a damaged file.
    Vec2(#[serde(deserialize_with = "point_or_auto")] Vec2),
    Color([f32; 4]),
    Bool(bool),
    Choice(u32),
    Text(String),
    /// Curve control points (x, y) in 0..1, sorted by x (Lumetri curves).
    Curve(Vec<[f32; 2]>),
    /// A mask path (Bézier vertices in clip pixels); interpolates vertex-wise.
    Path(crate::mask::MaskPath),
}

/// Read a point parameter's value, taking a `null` coordinate as NaN ("auto").
fn point_or_auto<'de, D: serde::Deserializer<'de>>(d: D) -> Result<Vec2, D::Error> {
    fn nan_if_null<'de, D: serde::Deserializer<'de>>(d: D) -> Result<f64, D::Error> {
        Ok(Option::<f64>::deserialize(d)?.unwrap_or(f64::NAN))
    }
    #[derive(Deserialize)]
    struct Point {
        #[serde(deserialize_with = "nan_if_null")]
        x: f64,
        #[serde(deserialize_with = "nan_if_null")]
        y: f64,
    }
    let p = Point::deserialize(d)?;
    Ok(Vec2::new(p.x, p.y))
}

impl ParamValue {
    pub fn as_f64(&self) -> Option<f64> {
        match self {
            ParamValue::Float(v) => Some(*v),
            ParamValue::Choice(c) => Some(*c as f64),
            ParamValue::Bool(b) => Some(*b as u8 as f64),
            _ => None,
        }
    }
    pub fn as_vec2(&self) -> Option<Vec2> {
        match self {
            ParamValue::Vec2(v) => Some(*v),
            _ => None,
        }
    }
    pub fn as_color(&self) -> Option<[f32; 4]> {
        match self {
            ParamValue::Color(c) => Some(*c),
            _ => None,
        }
    }
    pub fn as_curve(&self) -> Option<&[[f32; 2]]> {
        match self {
            ParamValue::Curve(c) => Some(c),
            _ => None,
        }
    }
    pub fn as_bool(&self) -> Option<bool> {
        match self {
            ParamValue::Bool(b) => Some(*b),
            _ => None,
        }
    }
    /// Whether values of this kind can be interpolated (others hold).
    pub fn interpolates(&self) -> bool {
        matches!(self, ParamValue::Float(_) | ParamValue::Vec2(_) | ParamValue::Color(_) | ParamValue::Path(_))
    }
    pub fn as_path(&self) -> Option<&crate::mask::MaskPath> {
        match self {
            ParamValue::Path(p) => Some(p),
            _ => None,
        }
    }
    fn components(&self) -> Vec<f64> {
        match self {
            ParamValue::Float(v) => vec![*v],
            ParamValue::Vec2(v) => vec![v.x, v.y],
            ParamValue::Color(c) => c.iter().map(|&x| x as f64).collect(),
            ParamValue::Path(p) => p.components(),
            _ => vec![],
        }
    }
    fn from_components(template: &ParamValue, c: &[f64]) -> ParamValue {
        match template {
            ParamValue::Float(_) => ParamValue::Float(c[0]),
            ParamValue::Vec2(_) => ParamValue::Vec2(Vec2::new(c[0], c[1])),
            ParamValue::Color(_) => ParamValue::Color([c[0] as f32, c[1] as f32, c[2] as f32, c[3] as f32]),
            ParamValue::Path(p) => ParamValue::Path(p.with_components(c)),
            other => other.clone(),
        }
    }
}

#[derive(Clone, Copy, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
pub enum Interpolation {
    #[default]
    Linear,
    Hold,
    Bezier,
    AutoBezier,
    ContinuousBezier,
    EaseIn,
    EaseOut,
}

impl Interpolation {
    pub const ALL: [Interpolation; 7] = [
        Interpolation::Linear,
        Interpolation::Bezier,
        Interpolation::AutoBezier,
        Interpolation::ContinuousBezier,
        Interpolation::Hold,
        Interpolation::EaseIn,
        Interpolation::EaseOut,
    ];
    pub fn label(self) -> &'static str {
        match self {
            Interpolation::Linear => "Linear",
            Interpolation::Hold => "Hold",
            Interpolation::Bezier => "Bezier",
            Interpolation::AutoBezier => "Auto Bezier",
            Interpolation::ContinuousBezier => "Continuous Bezier",
            Interpolation::EaseIn => "Ease In",
            Interpolation::EaseOut => "Ease Out",
        }
    }
}

/// The most points one stretch's curve may have between its two keyframes.
pub const MAX_CURVE_POINTS: usize = 16;

/// A point inside the curve from one keyframe to the next, with its two handles. Every number is in the stretch's
/// normalized space: `x` is the time along the stretch (0 at the first key, 1 at the next), `y` the value (0 at the
/// first key's value, 1 at the next's; it may leave 0..1). The handles are absolute points of that same space: `in_*`
/// shapes the curve arriving at the point, `out_*` the curve leaving it. With the two end handles of the stretch
/// (`out_influence`/`out_y` of the first key, `in_influence`/`in_y` of the next) they make a curve of several cubic
/// Bezier pieces, one between each two neighbouring points.
#[derive(Clone, Copy, Debug, PartialEq, Serialize, Deserialize)]
pub struct CurvePoint {
    pub x: f64,
    pub y: f64,
    pub in_x: f64,
    pub in_y: f64,
    pub out_x: f64,
    pub out_y: f64,
}

impl CurvePoint {
    /// The points a curve keeps: finite, strictly inside the stretch in time, each handle on its own side of its
    /// point, values within -1..2, sorted by time, no two closer than 0.002, and at most [`MAX_CURVE_POINTS`].
    /// Whatever is read from a file or sent by the app goes through this before it is used.
    pub fn sanitize(list: &[CurvePoint]) -> Vec<CurvePoint> {
        let mut out: Vec<CurvePoint> = list
            .iter()
            .filter(|p| [p.x, p.y, p.in_x, p.in_y, p.out_x, p.out_y].iter().all(|v| v.is_finite()) && p.x > 0.001 && p.x < 0.999)
            .map(|p| CurvePoint {
                x: p.x,
                y: p.y.clamp(-1.0, 2.0),
                in_x: p.in_x.clamp(0.0, p.x),
                in_y: p.in_y.clamp(-1.0, 2.0),
                out_x: p.out_x.clamp(p.x, 1.0),
                out_y: p.out_y.clamp(-1.0, 2.0),
            })
            .collect();
        out.sort_by(|a, b| a.x.total_cmp(&b.x));
        let mut kept: Vec<CurvePoint> = Vec::with_capacity(out.len());
        for p in out {
            if kept.last().is_some_and(|l| p.x - l.x < 0.002) {
                continue;
            }
            kept.push(p);
        }
        kept.truncate(MAX_CURVE_POINTS);
        kept
    }
}

#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
pub struct Keyframe {
    /// Time relative to the start of the track item (clip time).
    pub time: Tick,
    pub value: ParamValue,
    /// Interpolation of the segment leaving this keyframe.
    pub interp: Interpolation,
    /// Temporal ease: influence (0..1) of the outgoing/incoming handles.
    #[serde(default = "default_influence")]
    pub out_influence: f64,
    #[serde(default = "default_influence")]
    pub in_influence: f64,
    /// Height of the outgoing handle (0 = flat, the default). With `out_influence` it is the first
    /// control point of the curve to the next keyframe; above 1 or below 0 the value overshoots.
    /// Not written to the file while it is the default, so older projects and their render hashes are unchanged.
    #[serde(default = "default_out_y", skip_serializing_if = "is_default_out_y")]
    pub out_y: f64,
    /// Height of the incoming handle (1 = flat, the default); see `out_y`.
    #[serde(default = "default_in_y", skip_serializing_if = "is_default_in_y")]
    pub in_y: f64,
    /// Points inside the curve to the next keyframe (see [`CurvePoint`]): empty for the usual single cubic Bezier.
    /// Not written to the file while empty, so older projects, and their render hashes, read and save exactly as before.
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub mid: Vec<CurvePoint>,
}

fn default_out_y() -> f64 {
    0.0
}

fn default_in_y() -> f64 {
    1.0
}

fn is_default_out_y(v: &f64) -> bool {
    *v == 0.0
}

fn is_default_in_y(v: &f64) -> bool {
    *v == 1.0
}

fn default_influence() -> f64 {
    1.0 / 3.0
}

impl Keyframe {
    pub fn new(time: Tick, value: ParamValue) -> Self {
        Self { time, value, interp: Interpolation::Linear, out_influence: default_influence(), in_influence: default_influence(), out_y: 0.0, in_y: 1.0, mid: Vec::new() }
    }
}

/// A (possibly animated) parameter.
#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
pub struct Param {
    pub value: ParamValue,
    /// Sorted by time. Empty = static.
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub keyframes: Vec<Keyframe>,
}

impl Param {
    pub fn new(value: ParamValue) -> Self {
        Self { value, keyframes: Vec::new() }
    }
    pub fn is_animated(&self) -> bool {
        !self.keyframes.is_empty()
    }
    /// Apply `f` to the static value and every keyframe value.
    pub fn map_values(&mut self, f: impl Fn(ParamValue) -> ParamValue) {
        self.value = f(std::mem::replace(&mut self.value, ParamValue::Float(0.0)));
        for k in &mut self.keyframes {
            k.value = f(std::mem::replace(&mut k.value, ParamValue::Float(0.0)));
        }
    }

    /// Set a value at `t`: updates the static value, or adds/replaces a keyframe when animated.
    pub fn set_at(&mut self, t: Tick, value: ParamValue) {
        if self.keyframes.is_empty() {
            self.value = value;
            return;
        }
        match self.keyframes.binary_search_by_key(&t, |k| k.time) {
            Ok(i) => self.keyframes[i].value = value,
            Err(i) => {
                let interp = self.keyframes.get(i.saturating_sub(1)).map(|k| k.interp).unwrap_or_default();
                let mut k = Keyframe::new(t, value);
                k.interp = interp;
                self.keyframes.insert(i, k);
            }
        }
    }

    /// Toggle animation (the stopwatch): on → one keyframe at `t` with the current value; off → keep value at `t`.
    pub fn toggle_animation(&mut self, t: Tick) {
        if self.keyframes.is_empty() {
            self.keyframes.push(Keyframe::new(t, self.value.clone()));
        } else {
            self.value = self.value_at(t);
            self.keyframes.clear();
        }
    }

    pub fn add_keyframe(&mut self, t: Tick) {
        let v = self.value_at(t);
        if self.keyframes.is_empty() {
            self.value = v.clone();
        }
        self.set_at_force(t, v);
    }

    /// Add or replace a keyframe at `t` (the parameter becomes animated).
    pub fn put_keyframe(&mut self, t: Tick, value: ParamValue) {
        self.set_at_force(t, value);
    }

    fn set_at_force(&mut self, t: Tick, value: ParamValue) {
        match self.keyframes.binary_search_by_key(&t, |k| k.time) {
            Ok(i) => self.keyframes[i].value = value,
            Err(i) => self.keyframes.insert(i, Keyframe::new(t, value)),
        }
    }

    pub fn remove_keyframe_at(&mut self, t: Tick) -> bool {
        if let Ok(i) = self.keyframes.binary_search_by_key(&t, |k| k.time) {
            let removed = self.keyframes.remove(i);
            if self.keyframes.is_empty() {
                self.value = removed.value;
            }
            true
        } else {
            false
        }
    }

    /// Evaluate at clip time `t`.
    pub fn value_at(&self, t: Tick) -> ParamValue {
        let k = &self.keyframes;
        if k.is_empty() {
            return self.value.clone();
        }
        if t <= k[0].time {
            return k[0].value.clone();
        }
        let last = &k[k.len() - 1];
        if t >= last.time {
            return last.value.clone();
        }
        let i = match k.binary_search_by_key(&t, |kf| kf.time) {
            Ok(i) => return k[i].value.clone(),
            Err(i) => i - 1,
        };
        let (a, b) = (&k[i], &k[i + 1]);
        if a.interp == Interpolation::Hold || !a.value.interpolates() {
            return a.value.clone();
        }
        let span = (b.time - a.time).0 as f64;
        let u = (t - a.time).0 as f64 / span;
        let e = ease(a, b, u);
        let ca = a.value.components();
        let cb = b.value.components();
        if ca.len() != cb.len() {
            // e.g. mask paths with different vertex counts: hold
            return a.value.clone();
        }
        let c: Vec<f64> = ca.iter().zip(&cb).map(|(x, y)| x + (y - x) * e).collect();
        ParamValue::from_components(&a.value, &c)
    }

    pub fn f64_at(&self, t: Tick) -> f64 {
        self.value_at(t).as_f64().unwrap_or(0.0)
    }

    /// [`Self::f64_at`] for a Float parameter whose keyframe values are blended after being passed through
    /// `to`, and returned in `to`'s domain. The keyframes, their times and each segment's interpolation
    /// (Linear, Hold, Bezier, Ease In/Out...) are exactly those of `value_at`; only the numbers the curve
    /// runs between change. A Volume level is stored in dB, where silence is far below −96 dB: blended
    /// there, a rise from 0 to 100 % is inaudible for most of the segment and then jumps. Blended through
    /// `dB -> gain` it rises as the percentage the user set.
    pub fn f64_at_through(&self, t: Tick, to: impl Fn(f64) -> f64) -> f64 {
        let k = &self.keyframes;
        let f = |v: &ParamValue| to(v.as_f64().unwrap_or(0.0));
        if k.is_empty() {
            return f(&self.value);
        }
        if t <= k[0].time {
            return f(&k[0].value);
        }
        let last = &k[k.len() - 1];
        if t >= last.time {
            return f(&last.value);
        }
        let i = match k.binary_search_by_key(&t, |kf| kf.time) {
            Ok(i) => return f(&k[i].value),
            Err(i) => i - 1,
        };
        let (a, b) = (&k[i], &k[i + 1]);
        if a.interp == Interpolation::Hold || !a.value.interpolates() {
            return f(&a.value);
        }
        let span = (b.time - a.time).0 as f64;
        let u = (t - a.time).0 as f64 / span;
        let e = ease(a, b, u);
        let (x, y) = (f(&a.value), f(&b.value));
        x + (y - x) * e
    }

    /// Borrowing text evaluation for read-only observers (the Program monitor's IME producer).
    ///
    /// Text parameters never interpolate, so the result is the applicable static or keyframed
    /// `ParamValue::Text`; an interpolating non-text value yields `None`. Unlike
    /// [`Self::value_at`] this does not clone the document-sized string.
    pub fn text_ref_at(&self, t: Tick) -> Option<&str> {
        fn text(v: &ParamValue) -> Option<&str> {
            match v {
                ParamValue::Text(s) => Some(s.as_str()),
                _ => None,
            }
        }
        let k = &self.keyframes;
        if k.is_empty() {
            return text(&self.value);
        }
        if t <= k[0].time {
            return text(&k[0].value);
        }
        let last = &k[k.len() - 1];
        if t >= last.time {
            return text(&last.value);
        }
        let i = match k.binary_search_by_key(&t, |kf| kf.time) {
            Ok(i) => return text(&k[i].value),
            Err(i) => i - 1,
        };
        // Hold semantics match `value_at`: non-interpolating values (including text) stay until
        // the next keyframe; an interpolating segment never evaluates to text.
        if k[i].interp == Interpolation::Hold || !k[i].value.interpolates() { text(&k[i].value) } else { None }
    }

    /// Allocation-free [`Param::f64_at`] for scalar parameters (Float / Choice / Bool), for
    /// per-sample evaluation in the audio mixer. Non-scalar values evaluate to 0.
    pub fn scalar_at(&self, t: Tick) -> f64 {
        let k = &self.keyframes;
        let s = |v: &ParamValue| v.as_f64().unwrap_or(0.0);
        if k.is_empty() {
            return s(&self.value);
        }
        if t <= k[0].time {
            return s(&k[0].value);
        }
        let last = &k[k.len() - 1];
        if t >= last.time {
            return s(&last.value);
        }
        let i = match k.binary_search_by_key(&t, |kf| kf.time) {
            Ok(i) => return s(&k[i].value),
            Err(i) => i - 1,
        };
        let (a, b) = (&k[i], &k[i + 1]);
        let (va, vb) = (s(&a.value), s(&b.value));
        if a.interp == Interpolation::Hold || !matches!(a.value, ParamValue::Float(_)) {
            return va;
        }
        let u = (t - a.time).0 as f64 / (b.time - a.time).0 as f64;
        va + (vb - va) * ease(a, b, u)
    }

    pub fn vec2_at(&self, t: Tick) -> Vec2 {
        self.value_at(t).as_vec2().unwrap_or_default()
    }

    /// Previous/next keyframe times for navigation.
    pub fn prev_keyframe(&self, t: Tick) -> Option<Tick> {
        self.keyframes.iter().rev().map(|k| k.time).find(|&k| k < t)
    }
    pub fn next_keyframe(&self, t: Tick) -> Option<Tick> {
        self.keyframes.iter().map(|k| k.time).find(|&k| k > t)
    }
}

/// The control points `(x1, y1, x2, y2)` of the curve from `a` to `b` in normalized (time, value)
/// space: what [`ease`] draws. Flat handles (the default) are an ease; keys that do not ease use the
/// straight-line points.
pub fn segment_curve(a: &Keyframe, b: &Keyframe) -> (f64, f64, f64, f64) {
    let out_ease = matches!(a.interp, Interpolation::Bezier | Interpolation::AutoBezier | Interpolation::ContinuousBezier | Interpolation::EaseOut);
    let in_ease = matches!(b.interp, Interpolation::Bezier | Interpolation::AutoBezier | Interpolation::ContinuousBezier | Interpolation::EaseIn)
        || matches!(a.interp, Interpolation::Bezier | Interpolation::ContinuousBezier);
    let x1 = if out_ease { a.out_influence.clamp(0.01, 1.0) } else { 1.0 / 3.0 };
    let y1 = if out_ease { a.out_y.clamp(-2.0, 3.0) } else { 1.0 / 3.0 };
    let x2 = if in_ease { 1.0 - b.in_influence.clamp(0.01, 1.0) } else { 2.0 / 3.0 };
    let y2 = if in_ease { b.in_y.clamp(-2.0, 3.0) } else { 2.0 / 3.0 };
    (x1, y1, x2, y2)
}

/// Temporal easing for u∈[0,1] between two keyframes (1D cubic Bezier in time/value space).
fn ease(a: &Keyframe, b: &Keyframe, u: f64) -> f64 {
    if !a.mid.is_empty() {
        return ease_through_points(a, b, u);
    }
    let out_ease = matches!(a.interp, Interpolation::Bezier | Interpolation::AutoBezier | Interpolation::ContinuousBezier | Interpolation::EaseOut);
    let in_ease = matches!(b.interp, Interpolation::Bezier | Interpolation::AutoBezier | Interpolation::ContinuousBezier | Interpolation::EaseIn)
        || matches!(a.interp, Interpolation::Bezier | Interpolation::ContinuousBezier);
    if !out_ease && !in_ease {
        return u;
    }
    let (x1, y1, x2, y2) = segment_curve(a, b);
    cubic_bezier_y_for_x(x1, y1, x2, y2, u)
}

/// Solve a CSS-style cubic-bezier(x1,y1,x2,y2) for y at x (Newton + bisection).
pub fn cubic_bezier_y_for_x(x1: f64, y1: f64, x2: f64, y2: f64, x: f64) -> f64 {
    let bx = |s: f64| 3.0 * (1.0 - s) * (1.0 - s) * s * x1 + 3.0 * (1.0 - s) * s * s * x2 + s * s * s;
    let by = |s: f64| 3.0 * (1.0 - s) * (1.0 - s) * s * y1 + 3.0 * (1.0 - s) * s * s * y2 + s * s * s;
    let dbx = |s: f64| 3.0 * (1.0 - s) * (1.0 - s) * x1 + 6.0 * (1.0 - s) * s * (x2 - x1) + 3.0 * s * s * (1.0 - x2);
    let mut s = x;
    for _ in 0..8 {
        let d = dbx(s);
        if d.abs() < 1e-9 {
            break;
        }
        let ns = s - (bx(s) - x) / d;
        if !(0.0..=1.0).contains(&ns) {
            break;
        }
        s = ns;
    }
    if (bx(s) - x).abs() > 1e-7 {
        let (mut lo, mut hi) = (0.0, 1.0);
        for _ in 0..60 {
            s = (lo + hi) / 2.0;
            if bx(s) < x { lo = s } else { hi = s }
        }
    }
    by(s)
}

/// The curve from `a` to `b` when `a` has points inside it: the time `u` (0..1) along the stretch to the value (0 at
/// `a`, 1 at `b`). The nodes are the start (0, 0), the sanitized points and the end (1, 1); between each two
/// neighbours runs one cubic Bezier made of the first node's out handle and the second's in handle. The stretch's end
/// handles are the usual ones ([`segment_curve`]). A curve without points never comes here (see [`ease`]).
fn ease_through_points(a: &Keyframe, b: &Keyframe, u: f64) -> f64 {
    // (x, y, in handle, out handle)
    type Node = (f64, f64, (f64, f64), (f64, f64));
    let (x1, y1, x2, y2) = segment_curve(a, b);
    let mut nodes: Vec<Node> = Vec::with_capacity(a.mid.len() + 2);
    nodes.push((0.0, 0.0, (0.0, 0.0), (x1, y1)));
    for p in CurvePoint::sanitize(&a.mid) {
        nodes.push((p.x, p.y, (p.in_x, p.in_y), (p.out_x, p.out_y)));
    }
    nodes.push((1.0, 1.0, (x2, y2), (1.0, 1.0)));
    let u = u.clamp(0.0, 1.0);
    let last = nodes.len() - 2;
    let i = (0..last).find(|i| u <= nodes[i + 1].0).unwrap_or(last);
    let (n0, n1) = (nodes[i], nodes[i + 1]);
    cubic_y_at_x((n0.0, n0.1), n0.3, n1.2, (n1.0, n1.1), u)
}

/// The value at time `x` of the cubic Bezier through `p0` and `p3` with control points `p1` and `p2`, any ends (not just
/// (0, 0) and (1, 1)). The time runs forward along it (a piece of a valid curve does), so the point is found by bisection.
fn cubic_y_at_x(p0: (f64, f64), p1: (f64, f64), p2: (f64, f64), p3: (f64, f64), x: f64) -> f64 {
    if p3.0 - p0.0 < 1e-9 {
        return p3.1;
    }
    let at = |s: f64, a: f64, b: f64, c: f64, d: f64| {
        let m = 1.0 - s;
        m * m * m * a + 3.0 * m * m * s * b + 3.0 * m * s * s * c + s * s * s * d
    };
    let (mut lo, mut hi) = (0.0f64, 1.0f64);
    for _ in 0..60 {
        let s = (lo + hi) / 2.0;
        if at(s, p0.0, p1.0, p2.0, p3.0) < x {
            lo = s;
        } else {
            hi = s;
        }
    }
    let s = (lo + hi) / 2.0;
    at(s, p0.1, p1.1, p2.1, p3.1)
}

#[cfg(test)]
mod tests {
    use super::*;

    /// Two keys with handles at `(x1, y1)`, `(x2, y2)` set the way the phone does it.
    fn curved(x1: f64, y1: f64, x2: f64, y2: f64) -> Param {
        let mut p = Param::new(ParamValue::Float(0.0));
        p.put_keyframe(Tick(0), ParamValue::Float(0.0));
        p.put_keyframe(Tick(1000), ParamValue::Float(100.0));
        p.keyframes[0].interp = Interpolation::Bezier;
        p.keyframes[0].out_influence = x1;
        p.keyframes[0].out_y = y1;
        p.keyframes[1].in_influence = 1.0 - x2;
        p.keyframes[1].in_y = y2;
        p
    }

    #[test]
    fn default_handles_give_the_same_curve_as_before_the_handles_were_editable() {
        // the old Bezier: flat handles, a third of the way along
        let mut old = Param::new(ParamValue::Float(0.0));
        old.put_keyframe(Tick(0), ParamValue::Float(0.0));
        old.put_keyframe(Tick(1000), ParamValue::Float(100.0));
        old.keyframes[0].interp = Interpolation::Bezier;
        for t in (0..=1000).step_by(50) {
            let want = 100.0 * cubic_bezier_y_for_x(1.0 / 3.0, 0.0, 2.0 / 3.0, 1.0, f64::from(t) / 1000.0);
            assert!((old.f64_at(Tick(t)) - want).abs() < 1e-9, "t={t}");
        }
        assert_eq!((old.keyframes[0].out_y, old.keyframes[1].in_y), (0.0, 1.0));
    }

    #[test]
    fn a_hand_edited_curve_changes_the_value_and_can_overshoot() {
        let linear = curved(1.0 / 3.0, 1.0 / 3.0, 2.0 / 3.0, 2.0 / 3.0);
        for t in (0..=1000).step_by(100) {
            assert!((linear.f64_at(Tick(t)) - f64::from(t) / 10.0).abs() < 1e-6, "a straight-line handle pair is linear");
        }
        // starts fast, ends soft: well ahead of linear at 25 %, and still going up at the end
        let fast = curved(0.1, 0.9, 0.5, 1.0);
        assert!(fast.f64_at(Tick(250)) > 50.0, "{}", fast.f64_at(Tick(250)));
        // a handle above 1 overshoots the end value before settling
        let over = curved(0.3, 0.0, 0.6, 1.6);
        let peak = (0..=1000).map(|t| over.f64_at(Tick(t))).fold(0.0, f64::max);
        assert!(peak > 100.0, "{peak}");
        assert!((over.f64_at(Tick(1000)) - 100.0).abs() < 1e-9 && over.f64_at(Tick(0)).abs() < 1e-9);
    }

    #[test]
    fn default_handles_are_not_written_and_old_files_read_with_the_defaults() {
        let plain = Keyframe::new(Tick(5), ParamValue::Float(1.0));
        let json = serde_json::to_string(&plain).unwrap();
        assert!(!json.contains("out_y") && !json.contains("in_y"), "{json}");
        let back: Keyframe = serde_json::from_str(&json).unwrap();
        assert_eq!((back.out_y, back.in_y), (0.0, 1.0));
        // (a file from before the handles existed is exactly this JSON: it has no `out_y` / `in_y`)
        // an edited key keeps its handles through save and open
        let mut edited = Keyframe::new(Tick(5), ParamValue::Float(1.0));
        edited.out_y = 0.8;
        edited.in_y = 1.4;
        let again: Keyframe = serde_json::from_str(&serde_json::to_string(&edited).unwrap()).unwrap();
        assert_eq!((again.out_y, again.in_y), (0.8, 1.4));
    }

    #[test]
    fn linear_and_hold() {
        let mut p = Param::new(ParamValue::Float(0.0));
        p.toggle_animation(Tick(0));
        p.set_at(Tick(100), ParamValue::Float(10.0));
        assert_eq!(p.f64_at(Tick(50)), 5.0);
        assert_eq!(p.f64_at(Tick(-5)), 0.0);
        assert_eq!(p.f64_at(Tick(500)), 10.0);
        p.keyframes[0].interp = Interpolation::Hold;
        assert_eq!(p.f64_at(Tick(99)), 0.0);
    }

    /// The Volume level is in dB with silence at -287.5 dB: blended there, 0 -> 100 % is silent for most of the
    /// segment and then jumps. Blended as a gain it rises as the percentage.
    #[test]
    fn a_blend_through_gain_rises_progressively_where_a_db_blend_jumps() {
        let gain = |db: f64| if db <= -96.0 { 0.0 } else { 10f64.powf(db / 20.0) };
        let mut p = Param::new(ParamValue::Float(0.0));
        p.put_keyframe(Tick(0), ParamValue::Float(-287.5));
        p.put_keyframe(Tick(8000), ParamValue::Float(0.0));
        for (t, want) in [(0, 0.0), (2000, 0.25), (4000, 0.5), (6000, 0.75), (8000, 1.0), (9000, 1.0)] {
            assert!((p.f64_at_through(Tick(t), gain) - want).abs() < 1e-9, "t={t}: {}", p.f64_at_through(Tick(t), gain));
        }
        // the same keys blended in dB are still silent halfway: the jump this replaces
        assert!(gain(p.f64_at(Tick(4000))) == 0.0);
        // Hold keeps the first key until the next
        p.keyframes[0].interp = Interpolation::Hold;
        assert_eq!(p.f64_at_through(Tick(7999), gain), 0.0);
        // Bezier eases: slower than linear at the start, never going backwards
        p.keyframes[0].interp = Interpolation::Bezier;
        p.keyframes[1].interp = Interpolation::Bezier;
        assert!(p.f64_at_through(Tick(800), gain) < 0.1);
        let mut last = 0.0;
        for t in (0..=8000).step_by(100) {
            let g = p.f64_at_through(Tick(t), gain);
            assert!(g >= last - 1e-12);
            last = g;
        }
        // with no keys it is just the static value
        assert!((Param::new(ParamValue::Float(-6.0)).f64_at_through(Tick(5), gain) - gain(-6.0)).abs() < 1e-12);
    }

    #[test]
    fn a_position_and_an_opacity_move_progressively_between_their_keys() {
        let mut pos = Param::new(ParamValue::Vec2(Vec2::new(0.0, 0.0)));
        pos.put_keyframe(Tick(0), ParamValue::Vec2(Vec2::new(0.0, 0.0)));
        pos.put_keyframe(Tick(1000), ParamValue::Vec2(Vec2::new(100.0, 40.0)));
        let m = pos.vec2_at(Tick(250));
        assert!((m.x - 25.0).abs() < 1e-9 && (m.y - 10.0).abs() < 1e-9);
        let mut op = Param::new(ParamValue::Float(100.0));
        op.put_keyframe(Tick(0), ParamValue::Float(0.0));
        op.put_keyframe(Tick(1000), ParamValue::Float(100.0));
        assert!((op.f64_at(Tick(500)) - 50.0).abs() < 1e-9);
    }

    #[test]
    fn bezier_eases() {
        let mut p = Param::new(ParamValue::Vec2(Vec2::new(0.0, 0.0)));
        p.toggle_animation(Tick(0));
        p.set_at(Tick(1000), ParamValue::Vec2(Vec2::new(100.0, 50.0)));
        p.keyframes[0].interp = Interpolation::Bezier;
        p.keyframes[1].interp = Interpolation::Bezier;
        let early = p.vec2_at(Tick(100)).x;
        let mid = p.vec2_at(Tick(500)).x;
        assert!(early < 10.0, "ease-in start should be slow: {early}");
        assert!((mid - 50.0).abs() < 1.0, "symmetric ease midpoint: {mid}");
        // monotonic
        let mut last = -1.0;
        for i in 0..=100 {
            let v = p.vec2_at(Tick(i * 10)).x;
            assert!(v >= last - 1e-9);
            last = v;
        }
    }

    // ---- curves with points inside them (several Bezier pieces) ----

    fn two_keys(mid: Vec<CurvePoint>, handles: (f64, f64, f64, f64)) -> (Keyframe, Keyframe) {
        let mut a = Keyframe::new(Tick(0), ParamValue::Float(0.0));
        let mut b = Keyframe::new(Tick(1000), ParamValue::Float(1.0));
        a.interp = Interpolation::Bezier;
        a.out_influence = handles.0;
        a.out_y = handles.1;
        b.in_influence = 1.0 - handles.2;
        b.in_y = handles.3;
        a.mid = mid;
        (a, b)
    }

    fn point(x: f64, y: f64, dx: f64) -> CurvePoint {
        CurvePoint { x, y, in_x: x - dx, in_y: y, out_x: x + dx, out_y: y }
    }

    #[test]
    fn a_curve_without_points_is_the_old_single_cubic() {
        for (x1, y1, x2, y2) in [(1.0 / 3.0, 0.0, 2.0 / 3.0, 1.0), (0.2, -0.4, 0.9, 1.5), (0.7, 0.0, 0.3, 1.0)] {
            let (a, b) = two_keys(Vec::new(), (x1, y1, x2, y2));
            for i in 0..=40 {
                let u = f64::from(i) / 40.0;
                assert!((ease(&a, &b, u) - cubic_bezier_y_for_x(x1, y1, x2, y2, u)).abs() < 1e-9, "u={u}");
            }
        }
    }

    #[test]
    fn a_curve_goes_through_its_points_and_follows_the_reference_values() {
        // reference values from an independent implementation of the same maths (see the r25 report)
        let (a, b) = two_keys(vec![point(0.5, 0.8, 0.1)], (1.0 / 3.0, 0.0, 2.0 / 3.0, 1.0));
        let table = [(0.0, 0.0), (0.1, 0.026507), (0.25, 0.197116), (0.5, 0.8), (0.75, 0.950721), (0.9, 0.993373), (1.0, 1.0)];
        for (u, want) in table {
            assert!((ease(&a, &b, u) - want).abs() < 1e-5, "u={u}: {}", ease(&a, &b, u));
        }
        let (a, b) = two_keys(vec![point(0.3, 0.9, 0.1), point(0.7, 0.1, 0.1)], (1.0 / 3.0, 1.0 / 3.0, 2.0 / 3.0, 2.0 / 3.0));
        let table = [(0.0, 0.0), (0.1, 0.126989), (0.25, 0.71619), (0.5, 0.5), (0.75, 0.28381), (0.9, 0.873011), (1.0, 1.0)];
        for (u, want) in table {
            assert!((ease(&a, &b, u) - want).abs() < 1e-5, "u={u}: {}", ease(&a, &b, u));
        }
    }

    #[test]
    fn the_value_at_a_time_between_two_keys_uses_the_points() {
        // through the Param, as the engine reads it: halfway along the stretch the curve is at its point
        let mut p = Param::new(ParamValue::Float(0.0));
        p.put_keyframe(Tick(0), ParamValue::Float(10.0));
        p.put_keyframe(Tick(1000), ParamValue::Float(20.0));
        let (a, _) = two_keys(vec![point(0.5, 0.8, 0.1)], (1.0 / 3.0, 0.0, 2.0 / 3.0, 1.0));
        p.keyframes[0].interp = Interpolation::Bezier;
        p.keyframes[0].mid = a.mid;
        assert!((p.f64_at(Tick(500)) - 18.0).abs() < 1e-6, "{}", p.f64_at(Tick(500)));
        // and a Hold key still holds, whatever points it keeps
        p.keyframes[0].interp = Interpolation::Hold;
        assert_eq!(p.f64_at(Tick(999)), 10.0);
    }

    #[test]
    fn points_are_sanitized_before_they_are_used() {
        let wild = vec![
            CurvePoint { x: 0.7, y: 9.0, in_x: -3.0, in_y: 0.5, out_x: 9.0, out_y: 0.5 },
            point(0.3, 0.4, 0.1),
            point(0.3005, 0.4, 0.1),
            point(0.0, 0.0, 0.0),
            point(1.5, 0.0, 0.0),
            CurvePoint { x: f64::NAN, y: 0.0, in_x: 0.0, in_y: 0.0, out_x: 0.0, out_y: 0.0 },
        ];
        let clean = CurvePoint::sanitize(&wild);
        assert_eq!(clean.len(), 2, "{clean:?}");
        assert_eq!((clean[0].x, clean[1].x), (0.3, 0.7), "sorted, no twin, none outside the stretch, no NaN");
        assert_eq!((clean[1].y, clean[1].in_x, clean[1].out_x), (2.0, 0.0, 1.0), "values and handles kept within their limits");
        let many: Vec<CurvePoint> = (1..40).map(|i| point(f64::from(i) / 40.0, 0.5, 0.005)).collect();
        assert_eq!(CurvePoint::sanitize(&many).len(), MAX_CURVE_POINTS);
        // a curve with hostile points still gives finite values
        let (a, b) = two_keys(wild, (1.0 / 3.0, 0.0, 2.0 / 3.0, 1.0));
        for i in 0..=50 {
            assert!(ease(&a, &b, f64::from(i) / 50.0).is_finite());
        }
    }

    #[test]
    fn points_are_only_written_when_there_are_some_and_old_files_read_as_before() {
        // an old keyframe (no `mid` in the file) reads with no points and is written back without the field
        let plain = Keyframe::new(Tick(5), ParamValue::Float(1.0));
        let json = serde_json::to_string(&plain).unwrap();
        assert!(!json.contains("mid"), "{json}");
        let back: Keyframe = serde_json::from_str(&json).unwrap();
        assert!(back.mid.is_empty());
        assert_eq!(back, plain);
        // a keyframe with points survives a round trip
        let mut edited = plain.clone();
        edited.mid = vec![point(0.4, 0.7, 0.1), point(0.8, 0.2, 0.05)];
        let text = serde_json::to_string(&edited).unwrap();
        assert!(text.contains("mid"));
        let again: Keyframe = serde_json::from_str(&text).unwrap();
        assert_eq!(again, edited);
    }

    #[test]
    fn text_ref_at_borrows_without_cloning_and_holds_non_interpolating_values() {
        let p = Param::new(ParamValue::Text("abc".into()));
        assert_eq!(p.text_ref_at(Tick(0)), Some("abc"));
        let f = Param::new(ParamValue::Float(1.0));
        assert_eq!(f.text_ref_at(Tick(0)), None);
        let mut p = Param::new(ParamValue::Text("a".into()));
        p.toggle_animation(Tick(0));
        p.set_at(Tick(100), ParamValue::Text("b".into()));
        assert_eq!(p.text_ref_at(Tick(50)), Some("a"), "text does not interpolate");
        assert_eq!(p.text_ref_at(Tick(100)), Some("b"));
    }

    #[test]
    fn toggle_off_keeps_value() {
        let mut p = Param::new(ParamValue::Float(1.0));
        p.toggle_animation(Tick(0));
        p.set_at(Tick(10), ParamValue::Float(3.0));
        p.toggle_animation(Tick(5));
        assert!(!p.is_animated());
        assert_eq!(p.value, ParamValue::Float(2.0));
    }
}
