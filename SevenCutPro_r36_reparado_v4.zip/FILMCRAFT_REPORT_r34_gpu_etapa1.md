# Seven Cut Pro r34 — GPU, etapa 1: detección y diagnóstico (módulo `crates/gpu` nuevo, wgpu)

Base: r33. **Solo diagnóstico: no hay composición ni renderizado por GPU, y no se tocó el pipeline de exportación ni el render por CPU.**

## Léelo primero
- **Nada de esto se compiló ni se ejecutó.** Este entorno no tiene Rust, Kotlin, Gradle ni Android SDK, ni red. Las 27 pruebas (25 sin GPU, 2 con wgpu) están escritas y **ninguna se ha corrido**.
- La parte de wgpu (`probe_wgpu.rs`, ~270 líneas) está escrita **de memoria contra la API de wgpu 24** sin poder compilarla: es el sitio más probable de errores de compilación (nombres/firmas). Va aislada en un solo archivo y detrás de una característica desactivada por defecto, para que **si falla no rompa ninguna compilación normal**.
- No copié nada del proyecto de escritorio (no lo tengo). Todo el código es nuevo. Dependencias nuevas (solo con la característica activada): `wgpu 24.0` (MIT/Apache-2.0) y `pollster 0.4` (Apache-2.0/MIT).
- Sin medidas reales: no sé qué dice tu teléfono. El informe lo dirá cuando se ejecute.

## Qué se implementó (escrito, sin compilar)
**`crates/gpu` (`filmcraft-gpu`)**, miembro nuevo del workspace (la dependencia `filmcraft-gpu` que ya apuntaba a `crates/gpu` ahora existe):
| Archivo | Qué hace | Necesita GPU/wgpu |
|---|---|---|
| `report.rs` | Datos del informe (JSON y texto legible) | no |
| `formats.rs` | Formatos de textura que necesitaría el compositor y su función | no |
| `verdict.rs` | De capacidades a "qué se puede acelerar" (15 funciones, con motivo) | no |
| `budget.rs` | Modelo de memoria: presupuesto según RAM, tamaño máximo de fotograma, nº de compositores | no |
| `guard.rs` | Marca en disco ante cuelgues nativos del driver (un build que se colgó no vuelve a sondear hasta actualizar) | no |
| `lib.rs` | `run_probe`: hilo aparte con tiempo límite, protección, selección del mejor adaptador | solo la sonda |
| `probe_wgpu.rs` | Lo único que toca wgpu: backends Vulkan y GLES, adaptadores, límites, características, formatos, creación de dispositivo, reservas de prueba, errores y pérdida de dispositivo | sí |
| `tests.rs` | Pruebas del crate | parte con wgpu |

**Qué detecta** (todo lo pedido): dispositivo y backend (Vulkan primero, GLES después), nombre/tipo/driver del adaptador, límites reales (textura máx., buffer, bind groups, texturas por etapa…), características relevantes y banderas "downlevel", compatibilidad de los 7 formatos de textura necesarios (muestreo, render, mezcla, filtrado, copia, almacenamiento), **si se puede crear un dispositivo** (con límites básicos y, si falla, con los aún más básicos de GLES), reservas reales de prueba (destinos de trabajo 1080p y 4K en f16, 4K en f32 si el modelo de memoria lo permite, plano de luma 4K, buffers de lectura 1080p/4K), errores de validación/memoria con ámbitos de error, errores sin captura, **pérdida de dispositivo**, todos los fallos de inicialización, y un presupuesto de memoria.
**Qué concluye** (`verdict.rs`): Supported / Limited / Unsupported con motivo para: entrada YUV 8 y 16 bit, composición f16, escalado filtrado, los 27 modos de fusión, lectura en RGBA8, precisión f32, efectos de color y desenfoque, máscaras y croma, transiciones simples, texto, fotogramas 1080p/4K/8K y HDR (siempre CPU por diseño). Un adaptador de software (llvmpipe/SwiftShader) o sin dispositivo ⇒ nada se acelera.

**Integración Android (sin tocar interfaz):**
- `apps/filmcraft-android/src/gpu.rs`: funciones UniFFI `gpu_probe(...)` y `gpu_probe_reset(...)`.
- Interruptor oculto, **apagado por defecto**: (a) propiedad de Gradle `-Pfilmcraft.gpuProbe=true` (compila wgpu y activa el sondeo) — en GitHub Actions, *Compilar Seven Cut Pro para Android → Run workflow → gpu_probe*, que genera `SevenCutPro-<versión>-gpuprobe.apk`; (b) en esa compilación, el archivo vacío `gpu_probe.enable` en `Android/data/io.github.artcraftandroid.filmcraft/files/` también lo activa.
- `FilmcraftApplication.kt`: si el interruptor está activo, sondea **una vez por arranque**, en un hilo de baja prioridad tras iniciar el motor, y escribe `gpu_report.txt` y `gpu_report.json` en esa carpeta y en logcat (etiqueta `FilmcraftGpu`).
- `build.gradle.kts`: propiedad `filmcraft.gpuProbe`, característica de cargo `gpu-probe` solo cuando se pide, `BuildConfig.GPU_PROBE` (default `false`).
- CI: nuevo `pruebas-gpu.yml` (lógica pura y sonda real con Vulkan por software "lavapipe") y la entrada `gpu_probe` en `compilar-apk.yml`.

**Compilaciones normales:** sin el interruptor, wgpu **no se compila ni se enlaza** en el APK. Sí cambia `Cargo.lock` en la primera compilación (Cargo añade las dependencias opcionales): hace falta red, y no sirve `--locked` hasta subir el lock actualizado.

## Lo que NO se pudo comprobar
Compilación de Rust y de Android; ejecución de las pruebas; que la API de wgpu 24 coincida con lo escrito; el tamaño del APK con wgpu; cualquier dato de una GPU real; que los archivos de informe se escriban en tu teléfono (en Android 11+ `Android/data` puede no abrirse con algunos gestores de archivos: usa logcat o `adb pull`).

## Pruebas escritas (no ejecutadas)
Sin GPU: protección ante cuelgues (3), modelo de memoria (6), formatos (2), veredicto (7: teléfono capaz, sin f16, parcial, f32 fallido, pocas texturas, dispositivo fallido/software, límites de textura y memoria), selección de adaptador (Vulkan > GL > software; sin ninguno), resumen y JSON, y "sin wgpu dice que no sondeó y no toca nada". Con `--features wgpu-probe` (CI con lavapipe): la sonda real termina, describe lo hallado, no deja marca; un build marcado como colgado no vuelve a sondear y uno nuevo sí.

## Cómo seguir
1. Ejecutar *Pruebas GPU* en GitHub Actions y pasarme el log (lo más probable: errores pequeños en `probe_wgpu.rs`).
2. Generar el APK de diagnóstico, abrir la app una vez y enviarme `gpu_report.txt` (o el logcat `FilmcraftGpu`).
3. Con ese informe decidimos la etapa 2 (registro del compositor y prueba "canario") o ajustamos el plan según lo que la GPU admita de verdad.
