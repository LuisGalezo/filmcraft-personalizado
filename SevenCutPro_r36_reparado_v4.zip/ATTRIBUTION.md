# Attribution

Every non-code asset in FilmCraft, with its author, source and licence. Each file listed here also has
a `<file>.attribution` sidecar with full details. The rules are in [AGENTS.md](AGENTS.md) §1: no Adobe
iconography, images or other Adobe assets; open licences only; every asset attributed.
`cargo xtask assets` checks that this index and the sidecars cover every asset in the repository.

## Asset files

| Asset | Author | Source | Licence |
|---|---|---|---|
| `crates/ui-egui/src/i18n/it.tsv` | FilmCraft contributors | Original work: clean-room Italian interface translations | MIT OR Apache-2.0 |
| `crates/ui-egui/src/i18n/id.tsv` | FilmCraft contributors | Original work: clean-room Indonesian interface translations | MIT OR Apache-2.0 |
| `crates/ui-egui/src/i18n/ko.tsv` | FilmCraft contributors | Original work: clean-room Korean interface translations | MIT OR Apache-2.0 |
| `crates/ui-egui/src/i18n/fr.tsv` | FilmCraft contributors | Original work: clean-room French interface translations | MIT OR Apache-2.0 |
| `crates/ui-egui/src/i18n/pt-br.tsv` | FilmCraft contributors | Original work: clean-room Brazilian Portuguese interface translations | MIT OR Apache-2.0 |
| `crates/ui-egui/src/i18n/ru.tsv` | FilmCraft contributors | Original work: clean-room Russian interface translations | MIT OR Apache-2.0 |
| `crates/ui-egui/src/i18n/uk.tsv` | FilmCraft contributors | Original work: clean-room Ukrainian interface translations | MIT OR Apache-2.0 |
| `assets/fonts/Inter-Regular.ttf` | The Inter Project Authors | https://github.com/rsms/inter | OFL-1.1 (`assets/fonts/OFL-Inter.txt`) |
| `assets/fonts/Inter-Medium.ttf` | The Inter Project Authors | https://github.com/rsms/inter | OFL-1.1 (`assets/fonts/OFL-Inter.txt`) |
| `assets/fonts/Inter-SemiBold.ttf` | The Inter Project Authors | https://github.com/rsms/inter | OFL-1.1 (`assets/fonts/OFL-Inter.txt`) |
| `assets/fonts/Inter-Bold.ttf` | The Inter Project Authors | https://github.com/rsms/inter | OFL-1.1 (`assets/fonts/OFL-Inter.txt`) |
| `assets/fonts/Inter-Italic.ttf` | The Inter Project Authors | https://github.com/rsms/inter | OFL-1.1 (`assets/fonts/OFL-Inter.txt`) |
| `assets/fonts/NotoSerif-Regular.ttf` | The Noto Project Authors | https://github.com/notofonts/latin-greek-cyrillic | OFL-1.1 (`assets/fonts/OFL-NotoSerif.txt`) |
| `assets/fonts/JetBrainsMono-Regular.ttf` | The JetBrains Mono Project Authors | https://github.com/JetBrains/JetBrainsMono | OFL-1.1 (`assets/fonts/OFL-JetBrainsMono.txt`) |
| `assets/icons/house.svg` | Lucide Contributors (portions Cole Bemis, Feather) | https://github.com/lucide-icons/lucide (npm lucide-static 1.49.0, icons/house.svg) | ISC (`assets/icons/LICENSE-lucide.txt`) |
| `assets/icons/undo-2.svg` | Lucide Contributors (portions Cole Bemis, Feather) | https://github.com/lucide-icons/lucide (npm lucide-static 1.49.0, icons/undo-2.svg) | ISC (`assets/icons/LICENSE-lucide.txt`) |
| `assets/icons/redo-2.svg` | Lucide Contributors (portions Cole Bemis, Feather) | https://github.com/lucide-icons/lucide (npm lucide-static 1.49.0, icons/redo-2.svg) | ISC (`assets/icons/LICENSE-lucide.txt`) |
| `assets/icons/chevrons-up-down.svg` | Lucide Contributors (portions Cole Bemis, Feather) | https://github.com/lucide-icons/lucide (npm lucide-static 1.49.0, icons/chevrons-up-down.svg) | ISC (`assets/icons/LICENSE-lucide.txt`) |
| `assets/icons/music.svg` | Lucide Contributors (portions Cole Bemis, Feather) | https://github.com/lucide-icons/lucide (npm lucide-static 1.49.0, icons/music.svg) | ISC (`assets/icons/LICENSE-lucide.txt`) |
| `assets/icons/type.svg` | Lucide Contributors (portions Cole Bemis, Feather) | https://github.com/lucide-icons/lucide (npm lucide-static 1.49.0, icons/type.svg) | ISC (`assets/icons/LICENSE-lucide.txt`) |
| `assets/icons/file.svg` | Lucide Contributors (portions Cole Bemis, Feather) | https://github.com/lucide-icons/lucide (npm lucide-static 1.49.0, icons/file.svg) | ISC (`assets/icons/LICENSE-lucide.txt`) |
| `assets/icons/rectangle-horizontal.svg` | Lucide Contributors (portions Cole Bemis, Feather) | https://github.com/lucide-icons/lucide (npm lucide-static 1.49.0, icons/rectangle-horizontal.svg) | ISC (`assets/icons/LICENSE-lucide.txt`) |
| `assets/icons/ratio.svg` | Lucide Contributors (portions Cole Bemis, Feather) | https://github.com/lucide-icons/lucide (npm lucide-static 1.49.0, icons/ratio.svg) | ISC (`assets/icons/LICENSE-lucide.txt`) |
| `assets/icons/scissors.svg` | Lucide Contributors (portions Cole Bemis, Feather) | https://github.com/lucide-icons/lucide (npm lucide-static 1.49.0, icons/scissors.svg) | ISC (`assets/icons/LICENSE-lucide.txt`) |
| `assets/icons/trash-2.svg` | Lucide Contributors (portions Cole Bemis, Feather) | https://github.com/lucide-icons/lucide (npm lucide-static 1.49.0, icons/trash-2.svg) | ISC (`assets/icons/LICENSE-lucide.txt`) |
| `assets/icons/timer.svg` | Lucide Contributors (portions Cole Bemis, Feather) | https://github.com/lucide-icons/lucide (npm lucide-static 1.49.0, icons/timer.svg) | ISC (`assets/icons/LICENSE-lucide.txt`) |
| `assets/icons/gauge.svg` | Lucide Contributors (portions Cole Bemis, Feather) | https://github.com/lucide-icons/lucide (npm lucide-static 1.49.0, icons/gauge.svg) | ISC (`assets/icons/LICENSE-lucide.txt`) |
| `assets/icons/snowflake.svg` | Lucide Contributors (portions Cole Bemis, Feather) | https://github.com/lucide-icons/lucide (npm lucide-static 1.49.0, icons/snowflake.svg) | ISC (`assets/icons/LICENSE-lucide.txt`) |
| `assets/icons/volume-2.svg` | Lucide Contributors (portions Cole Bemis, Feather) | https://github.com/lucide-icons/lucide (npm lucide-static 1.49.0, icons/volume-2.svg) | ISC (`assets/icons/LICENSE-lucide.txt`) |
| `assets/icons/volume-x.svg` | Lucide Contributors (portions Cole Bemis, Feather) | https://github.com/lucide-icons/lucide (npm lucide-static 1.49.0, icons/volume-x.svg) | ISC (`assets/icons/LICENSE-lucide.txt`) |
| `assets/icons/audio-lines.svg` | Lucide Contributors (portions Cole Bemis, Feather) | https://github.com/lucide-icons/lucide (npm lucide-static 1.49.0, icons/audio-lines.svg) | ISC (`assets/icons/LICENSE-lucide.txt`) |
| `assets/icons/chart-spline.svg` | Lucide Contributors (portions Cole Bemis, Feather) | https://github.com/lucide-icons/lucide (npm lucide-static 1.49.0, icons/chart-spline.svg) | ISC (`assets/icons/LICENSE-lucide.txt`) |
| `assets/icons/swatch-book.svg` | Lucide Contributors (portions Cole Bemis, Feather) | https://github.com/lucide-icons/lucide (npm lucide-static 1.49.0, icons/swatch-book.svg) | ISC (`assets/icons/LICENSE-lucide.txt`) |
| `assets/icons/wand-sparkles.svg` | Lucide Contributors (portions Cole Bemis, Feather) | https://github.com/lucide-icons/lucide (npm lucide-static 1.49.0, icons/wand-sparkles.svg) | ISC (`assets/icons/LICENSE-lucide.txt`) |
| `assets/icons/blend.svg` | Lucide Contributors (portions Cole Bemis, Feather) | https://github.com/lucide-icons/lucide (npm lucide-static 1.49.0, icons/blend.svg) | ISC (`assets/icons/LICENSE-lucide.txt`) |
| `assets/icons/flip-horizontal-2.svg` | Lucide Contributors (portions Cole Bemis, Feather) | https://github.com/lucide-icons/lucide (npm lucide-static 1.49.0, icons/flip-horizontal-2.svg) | ISC (`assets/icons/LICENSE-lucide.txt`) |
| `assets/icons/flip-vertical-2.svg` | Lucide Contributors (portions Cole Bemis, Feather) | https://github.com/lucide-icons/lucide (npm lucide-static 1.49.0, icons/flip-vertical-2.svg) | ISC (`assets/icons/LICENSE-lucide.txt`) |
| `assets/icons/copy-plus.svg` | Lucide Contributors (portions Cole Bemis, Feather) | https://github.com/lucide-icons/lucide (npm lucide-static 1.49.0, icons/copy-plus.svg) | ISC (`assets/icons/LICENSE-lucide.txt`) |
| `assets/icons/replace.svg` | Lucide Contributors (portions Cole Bemis, Feather) | https://github.com/lucide-icons/lucide (npm lucide-static 1.49.0, icons/replace.svg) | ISC (`assets/icons/LICENSE-lucide.txt`) |
| `assets/icons/mic.svg` | Lucide Contributors (portions Cole Bemis, Feather) | https://github.com/lucide-icons/lucide (npm lucide-static 1.49.0, icons/mic.svg) | ISC (`assets/icons/LICENSE-lucide.txt`) |
| `assets/icons/keyboard.svg` | Lucide Contributors (portions Cole Bemis, Feather) | https://github.com/lucide-icons/lucide (npm lucide-static 1.49.0, icons/keyboard.svg) | ISC (`assets/icons/LICENSE-lucide.txt`) |
| `assets/icons/paintbrush.svg` | Lucide Contributors (portions Cole Bemis, Feather) | https://github.com/lucide-icons/lucide (npm lucide-static 1.49.0, icons/paintbrush.svg) | ISC (`assets/icons/LICENSE-lucide.txt`) |
| `assets/icons/captions.svg` | Lucide Contributors (portions Cole Bemis, Feather) | https://github.com/lucide-icons/lucide (npm lucide-static 1.49.0, icons/captions.svg) | ISC (`assets/icons/LICENSE-lucide.txt`) |
| `assets/icons/speech.svg` | Lucide Contributors (portions Cole Bemis, Feather) | https://github.com/lucide-icons/lucide (npm lucide-static 1.49.0, icons/speech.svg) | ISC (`assets/icons/LICENSE-lucide.txt`) |
| `assets/icons/align-left.svg` | Lucide Contributors (portions Cole Bemis, Feather) | https://github.com/lucide-icons/lucide (npm lucide-static 1.49.0, icons/align-left.svg) | ISC (`assets/icons/LICENSE-lucide.txt`) |
| `assets/icons/align-center.svg` | Lucide Contributors (portions Cole Bemis, Feather) | https://github.com/lucide-icons/lucide (npm lucide-static 1.49.0, icons/align-center.svg) | ISC (`assets/icons/LICENSE-lucide.txt`) |
| `assets/icons/align-right.svg` | Lucide Contributors (portions Cole Bemis, Feather) | https://github.com/lucide-icons/lucide (npm lucide-static 1.49.0, icons/align-right.svg) | ISC (`assets/icons/LICENSE-lucide.txt`) |
| `assets/icons/copy.svg` | Lucide Contributors (portions Cole Bemis, Feather) | https://github.com/lucide-icons/lucide (npm lucide-static 1.49.0, icons/copy.svg) | ISC (`assets/icons/LICENSE-lucide.txt`) |
| `assets/icons/clipboard-paste.svg` | Lucide Contributors (portions Cole Bemis, Feather) | https://github.com/lucide-icons/lucide (npm lucide-static 1.49.0, icons/clipboard-paste.svg) | ISC (`assets/icons/LICENSE-lucide.txt`) |
| `assets/icons/copy-check.svg` | Lucide Contributors (portions Cole Bemis, Feather) | https://github.com/lucide-icons/lucide (npm lucide-static 1.49.0, icons/copy-check.svg) | ISC (`assets/icons/LICENSE-lucide.txt`) |
| `assets/icons/rotate-ccw.svg` | Lucide Contributors (portions Cole Bemis, Feather) | https://github.com/lucide-icons/lucide (npm lucide-static 1.49.0, icons/rotate-ccw.svg) | ISC (`assets/icons/LICENSE-lucide.txt`) |
| `assets/icons/ban.svg` | Lucide Contributors (portions Cole Bemis, Feather) | https://github.com/lucide-icons/lucide (npm lucide-static 1.49.0, icons/ban.svg) | ISC (`assets/icons/LICENSE-lucide.txt`) |
| `assets/icons/check.svg` | Lucide Contributors (portions Cole Bemis, Feather) | https://github.com/lucide-icons/lucide (npm lucide-static 1.49.0, icons/check.svg) | ISC (`assets/icons/LICENSE-lucide.txt`) |
| `assets/icons/x.svg` | Lucide Contributors (portions Cole Bemis, Feather) | https://github.com/lucide-icons/lucide (npm lucide-static 1.49.0, icons/x.svg) | ISC (`assets/icons/LICENSE-lucide.txt`) |
| `assets/icons/chevron-left.svg` | Lucide Contributors (portions Cole Bemis, Feather) | https://github.com/lucide-icons/lucide (npm lucide-static 1.49.0, icons/chevron-left.svg) | ISC (`assets/icons/LICENSE-lucide.txt`) |
| `assets/icons/chevrons-left.svg` | Lucide Contributors (portions Cole Bemis, Feather) | https://github.com/lucide-icons/lucide (npm lucide-static 1.49.0, icons/chevrons-left.svg) | ISC (`assets/icons/LICENSE-lucide.txt`) |
| `assets/icons/chevron-right.svg` | Lucide Contributors (portions Cole Bemis, Feather) | https://github.com/lucide-icons/lucide (npm lucide-static 1.49.0, icons/chevron-right.svg) | ISC (`assets/icons/LICENSE-lucide.txt`) |
| `assets/icons/chevron-down.svg` | Lucide Contributors (portions Cole Bemis, Feather) | https://github.com/lucide-icons/lucide (npm lucide-static 1.49.0, icons/chevron-down.svg) | ISC (`assets/icons/LICENSE-lucide.txt`) |
| `assets/icons/chevron-up.svg` | Lucide Contributors (portions Cole Bemis, Feather) | https://github.com/lucide-icons/lucide (npm lucide-static 1.49.0, icons/chevron-up.svg) | ISC (`assets/icons/LICENSE-lucide.txt`) |
| `assets/icons/ellipsis-vertical.svg` | Lucide Contributors (portions Cole Bemis, Feather) | https://github.com/lucide-icons/lucide (npm lucide-static 1.49.0, icons/ellipsis-vertical.svg) | ISC (`assets/icons/LICENSE-lucide.txt`) |
| `assets/icons/ellipsis.svg` | Lucide Contributors (portions Cole Bemis, Feather) | https://github.com/lucide-icons/lucide (npm lucide-static 1.49.0, icons/ellipsis.svg) | ISC (`assets/icons/LICENSE-lucide.txt`) |
| `assets/icons/settings.svg` | Lucide Contributors (portions Cole Bemis, Feather) | https://github.com/lucide-icons/lucide (npm lucide-static 1.49.0, icons/settings.svg) | ISC (`assets/icons/LICENSE-lucide.txt`) |
| `assets/icons/info.svg` | Lucide Contributors (portions Cole Bemis, Feather) | https://github.com/lucide-icons/lucide (npm lucide-static 1.49.0, icons/info.svg) | ISC (`assets/icons/LICENSE-lucide.txt`) |
| `assets/icons/plus.svg` | Lucide Contributors (portions Cole Bemis, Feather) | https://github.com/lucide-icons/lucide (npm lucide-static 1.49.0, icons/plus.svg) | ISC (`assets/icons/LICENSE-lucide.txt`) |
| `assets/icons/search.svg` | Lucide Contributors (portions Cole Bemis, Feather) | https://github.com/lucide-icons/lucide (npm lucide-static 1.49.0, icons/search.svg) | ISC (`assets/icons/LICENSE-lucide.txt`) |
| `assets/icons/pencil.svg` | Lucide Contributors (portions Cole Bemis, Feather) | https://github.com/lucide-icons/lucide (npm lucide-static 1.49.0, icons/pencil.svg) | ISC (`assets/icons/LICENSE-lucide.txt`) |
| `assets/icons/share-2.svg` | Lucide Contributors (portions Cole Bemis, Feather) | https://github.com/lucide-icons/lucide (npm lucide-static 1.49.0, icons/share-2.svg) | ISC (`assets/icons/LICENSE-lucide.txt`) |
| `assets/icons/download.svg` | Lucide Contributors (portions Cole Bemis, Feather) | https://github.com/lucide-icons/lucide (npm lucide-static 1.49.0, icons/download.svg) | ISC (`assets/icons/LICENSE-lucide.txt`) |
| `assets/icons/film.svg` | Lucide Contributors (portions Cole Bemis, Feather) | https://github.com/lucide-icons/lucide (npm lucide-static 1.49.0, icons/film.svg) | ISC (`assets/icons/LICENSE-lucide.txt`) |
| `assets/icons/image.svg` | Lucide Contributors (portions Cole Bemis, Feather) | https://github.com/lucide-icons/lucide (npm lucide-static 1.49.0, icons/image.svg) | ISC (`assets/icons/LICENSE-lucide.txt`) |
| `assets/icons/images.svg` | Lucide Contributors (portions Cole Bemis, Feather) | https://github.com/lucide-icons/lucide (npm lucide-static 1.49.0, icons/images.svg) | ISC (`assets/icons/LICENSE-lucide.txt`) |
| `assets/icons/folder-open.svg` | Lucide Contributors (portions Cole Bemis, Feather) | https://github.com/lucide-icons/lucide (npm lucide-static 1.49.0, icons/folder-open.svg) | ISC (`assets/icons/LICENSE-lucide.txt`) |
| `assets/icons/triangle-alert.svg` | Lucide Contributors (portions Cole Bemis, Feather) | https://github.com/lucide-icons/lucide (npm lucide-static 1.49.0, icons/triangle-alert.svg) | ISC (`assets/icons/LICENSE-lucide.txt`) |
| `assets/icons/columns-2.svg` | Lucide Contributors (portions Cole Bemis, Feather) | https://github.com/lucide-icons/lucide (npm lucide-static 1.49.0, icons/columns-2.svg) | ISC (`assets/icons/LICENSE-lucide.txt`) |
| `assets/icons/rows-2.svg` | Lucide Contributors (portions Cole Bemis, Feather) | https://github.com/lucide-icons/lucide (npm lucide-static 1.49.0, icons/rows-2.svg) | ISC (`assets/icons/LICENSE-lucide.txt`) |
| `assets/icons/maximize.svg` | Lucide Contributors (portions Cole Bemis, Feather) | https://github.com/lucide-icons/lucide (npm lucide-static 1.49.0, icons/maximize.svg) | ISC (`assets/icons/LICENSE-lucide.txt`) |
| `assets/icons/minimize.svg` | Lucide Contributors (portions Cole Bemis, Feather) | https://github.com/lucide-icons/lucide (npm lucide-static 1.49.0, icons/minimize.svg) | ISC (`assets/icons/LICENSE-lucide.txt`) |
| `assets/icons/file-plus.svg` | Lucide Contributors (portions Cole Bemis, Feather) | https://github.com/lucide-icons/lucide (npm lucide-static 1.49.0, icons/file-plus.svg) | ISC (`assets/icons/LICENSE-lucide.txt`) |
| `assets/icons/square-plus.svg` | Lucide Contributors (portions Cole Bemis, Feather) | https://github.com/lucide-icons/lucide (npm lucide-static 1.49.0, icons/square-plus.svg) | ISC (`assets/icons/LICENSE-lucide.txt`) |
| `assets/icons/circle-x.svg` | Lucide Contributors (portions Cole Bemis, Feather) | https://github.com/lucide-icons/lucide (npm lucide-static 1.49.0, icons/circle-x.svg) | ISC (`assets/icons/LICENSE-lucide.txt`) |
| `assets/icons/languages.svg` | Lucide Contributors (portions Cole Bemis, Feather) | https://github.com/lucide-icons/lucide (npm lucide-static 1.49.0, icons/languages.svg) | ISC (`assets/icons/LICENSE-lucide.txt`) |
| `assets/icons/text-cursor-input.svg` | Lucide Contributors (portions Cole Bemis, Feather) | https://github.com/lucide-icons/lucide (npm lucide-static 1.49.0, icons/text-cursor-input.svg) | ISC (`assets/icons/LICENSE-lucide.txt`) |
| `assets/icons/square-dashed.svg` | Lucide Contributors (portions Cole Bemis, Feather) | https://github.com/lucide-icons/lucide (npm lucide-static 1.49.0, icons/square-dashed.svg) | ISC (`assets/icons/LICENSE-lucide.txt`) |
| `assets/icons/layers.svg` | Lucide Contributors (portions Cole Bemis, Feather) | https://github.com/lucide-icons/lucide (npm lucide-static 1.49.0, icons/layers.svg) | ISC (`assets/icons/LICENSE-lucide.txt`) |
| `docs/images/filmcraft-hero.png` | FilmCraft contributors | Original work: FilmCraft screenshot; NASA Apollo 11 film and TV footage (images.nasa.gov; US Government work, public domain; NASA does not endorse this project), subtitles from the NASA Apollo 11 air-to-ground transcript (public domain), CC0 Chopin (Musopen) | MIT OR Apache-2.0; footage and transcript public domain |
| `docs/images/filmcraft-color.png` | FilmCraft contributors | Original work: FilmCraft screenshot; frames from Charade (1963, public domain) | MIT OR Apache-2.0; film frames public domain |
| `docs/images/filmcraft-keyframes.png` | FilmCraft contributors | Original work: FilmCraft screenshot; frames from Night of the Living Dead (1968, public domain) | MIT OR Apache-2.0; film frames public domain |
| `docs/images/filmcraft-export.png` | FilmCraft contributors | Original work: FilmCraft screenshot; frame from Night of the Living Dead (1968, public domain) | MIT OR Apache-2.0; film frames public domain |
| `docs/images/filmcraft-assembly.png` | FilmCraft contributors | Original work: FilmCraft screenshot; frames from Carnival of Souls (1962), Night of the Living Dead (1968), thumbnails of all demo media | MIT OR Apache-2.0; film frames public domain |
| `docs/images/filmcraft-color-panel.png` | FilmCraft contributors | Original work: FilmCraft UI crop (color grading panel) | MIT OR Apache-2.0 |
| `docs/images/filmcraft-scopes.png` | FilmCraft contributors | Original work: FilmCraft UI crop (scopes of a Charade (1963) frame, public domain) | MIT OR Apache-2.0 |
| `docs/images/filmcraft-effects.png` | FilmCraft contributors | Original work: FilmCraft screenshot crop; NASA Earth Views (US Government work, public domain) | MIT OR Apache-2.0; footage public domain |
| `docs/images/filmcraft-timeline.png` | FilmCraft contributors | Original work: FilmCraft UI crop; thumbnails from Night of the Living Dead (1968) and Carnival of Souls (1962), CC0 Chopin waveform | MIT OR Apache-2.0; film frames public domain |
| `assets/app-icon/filmcraft.svg` | Brandon Thomas (FilmCraft owner) | Original work: FilmCraft app icon (owl with ear tufts), drawn by the owner in ArtCraft and vectorised; canonical vector | MIT OR Apache-2.0 (`assets/app-icon/LICENSE.txt`) |
| `packaging/macos/dmg/background.svg` | @XusBadia | Original work: FilmCraft macOS DMG window background, derived from the FilmCraft app icon (`assets/app-icon/filmcraft.svg`); rendered to `background.tiff` by `packaging/macos/dmg/generate.py` | MIT OR Apache-2.0 (`LICENSE-MIT`, `LICENSE-APACHE`) |
| `packaging/macos/dmg/background.tiff` | @XusBadia | Rendered from `packaging/macos/dmg/background.svg` by `packaging/macos/dmg/generate.py` | MIT OR Apache-2.0 (`LICENSE-MIT`, `LICENSE-APACHE`) |
| `assets/app-icon/filmcraft-small.svg` | Brandon Thomas (FilmCraft owner) | Original work: FilmCraft app icon (owl with ear tufts), drawn by the owner in ArtCraft and vectorised; lighter vector | MIT OR Apache-2.0 (`assets/app-icon/LICENSE.txt`) |
| `assets/app-icon/filmcraft-1024.png` | Brandon Thomas (FilmCraft owner) | Original work: FilmCraft app icon (owl with ear tufts), drawn by the owner in ArtCraft and vectorised; 1024 px render | MIT OR Apache-2.0 (`assets/app-icon/LICENSE.txt`) |
| `assets/app-icon/filmcraft-macos-512.png` | Brandon Thomas (FilmCraft owner) | Original work: FilmCraft app icon (owl with ear tufts), drawn by the owner in ArtCraft and vectorised; macOS runtime Dock icon (512 px) | MIT OR Apache-2.0 (`assets/app-icon/LICENSE.txt`) |
| `assets/app-icon/filmcraft.icns` | Brandon Thomas (FilmCraft owner) | Original work: FilmCraft app icon (owl with ear tufts), drawn by the owner in ArtCraft and vectorised; macOS .icns | MIT OR Apache-2.0 (`assets/app-icon/LICENSE.txt`) |
| `assets/app-icon/filmcraft.ico` | Brandon Thomas (FilmCraft owner) | Original work: FilmCraft app icon (owl with ear tufts), drawn by the owner in ArtCraft and vectorised; Windows .ico (16-256 px) | MIT OR Apache-2.0 (`assets/app-icon/LICENSE.txt`) |
| `assets/app-icon/hicolor/16x16/apps/ai.storyteller.filmcraft.png` | Brandon Thomas (FilmCraft owner) | Original work: FilmCraft app icon (owl with ear tufts), drawn by the owner in ArtCraft and vectorised; Linux hicolor theme 16 px | MIT OR Apache-2.0 (`assets/app-icon/LICENSE.txt`) |
| `assets/app-icon/hicolor/24x24/apps/ai.storyteller.filmcraft.png` | Brandon Thomas (FilmCraft owner) | Original work: FilmCraft app icon (owl with ear tufts), drawn by the owner in ArtCraft and vectorised; Linux hicolor theme 24 px | MIT OR Apache-2.0 (`assets/app-icon/LICENSE.txt`) |
| `assets/app-icon/hicolor/32x32/apps/ai.storyteller.filmcraft.png` | Brandon Thomas (FilmCraft owner) | Original work: FilmCraft app icon (owl with ear tufts), drawn by the owner in ArtCraft and vectorised; Linux hicolor theme 32 px | MIT OR Apache-2.0 (`assets/app-icon/LICENSE.txt`) |
| `assets/app-icon/hicolor/48x48/apps/ai.storyteller.filmcraft.png` | Brandon Thomas (FilmCraft owner) | Original work: FilmCraft app icon (owl with ear tufts), drawn by the owner in ArtCraft and vectorised; Linux hicolor theme 48 px | MIT OR Apache-2.0 (`assets/app-icon/LICENSE.txt`) |
| `assets/app-icon/hicolor/64x64/apps/ai.storyteller.filmcraft.png` | Brandon Thomas (FilmCraft owner) | Original work: FilmCraft app icon (owl with ear tufts), drawn by the owner in ArtCraft and vectorised; Linux hicolor theme 64 px | MIT OR Apache-2.0 (`assets/app-icon/LICENSE.txt`) |
| `assets/app-icon/hicolor/128x128/apps/ai.storyteller.filmcraft.png` | Brandon Thomas (FilmCraft owner) | Original work: FilmCraft app icon (owl with ear tufts), drawn by the owner in ArtCraft and vectorised; Linux hicolor theme 128 px | MIT OR Apache-2.0 (`assets/app-icon/LICENSE.txt`) |
| `assets/app-icon/hicolor/256x256/apps/ai.storyteller.filmcraft.png` | Brandon Thomas (FilmCraft owner) | Original work: FilmCraft app icon (owl with ear tufts), drawn by the owner in ArtCraft and vectorised; Linux hicolor theme 256 px | MIT OR Apache-2.0 (`assets/app-icon/LICENSE.txt`) |
| `assets/app-icon/hicolor/512x512/apps/ai.storyteller.filmcraft.png` | Brandon Thomas (FilmCraft owner) | Original work: FilmCraft app icon (owl with ear tufts), drawn by the owner in ArtCraft and vectorised; Linux hicolor theme 512 px | MIT OR Apache-2.0 (`assets/app-icon/LICENSE.txt`) |
| `assets/app-icon/hicolor/scalable/apps/ai.storyteller.filmcraft.svg` | Brandon Thomas (FilmCraft owner) | Original work: FilmCraft app icon (owl with ear tufts), drawn by the owner in ArtCraft and vectorised; Linux hicolor theme scalable | MIT OR Apache-2.0 (`assets/app-icon/LICENSE.txt`) |
| `apps/filmcraft-web/web/favicon.png` | Brandon Thomas (FilmCraft owner) | Original work: FilmCraft app icon (owl with ear tufts), drawn by the owner in ArtCraft and vectorised; 128 px | MIT OR Apache-2.0 (`assets/app-icon/LICENSE.txt`) |

## Golden test images

Reference frames for the renderer golden tests (`crates/golden`), rendered by FilmCraft itself from
procedural demo footage (`crates/media/src/generators.rs`); no external media. Regenerate with
`FILMCRAFT_BLESS=1 cargo test -p filmcraft-golden`.

| Asset | Author | Source | Licence |
|---|---|---|---|
| `crates/golden/goldens/blend_modes.png` | FilmCraft contributors | Original work: golden reference rendered by FilmCraft (crates/golden/tests/golden.rs, scene `blend_modes`) from procedurally generated media | MIT OR Apache-2.0 |
| `crates/golden/goldens/crop.png` | FilmCraft contributors | Original work: golden reference rendered by FilmCraft (crates/golden/tests/golden.rs, scene `crop`) from procedurally generated media | MIT OR Apache-2.0 |
| `crates/golden/goldens/gaussian_blur.png` | FilmCraft contributors | Original work: golden reference rendered by FilmCraft (crates/golden/tests/golden.rs, scene `gaussian_blur`) from procedurally generated media | MIT OR Apache-2.0 |
| `crates/golden/goldens/graphic_shapes.png` | FilmCraft contributors | Original work: golden reference rendered by FilmCraft (crates/golden/tests/golden.rs, scene `graphic_shapes`) from procedurally generated media and bundled OFL fonts | MIT OR Apache-2.0 |
| `crates/golden/goldens/graphic_template.png` | FilmCraft contributors | Original work: golden reference rendered by FilmCraft (crates/golden/tests/golden.rs, scene `graphic_template`; a built-in FilmCraft graphics template) from procedurally generated media and bundled OFL fonts | MIT OR Apache-2.0 |
| `crates/golden/goldens/graphic_rich_text.png` | FilmCraft contributors | Original work: golden reference rendered by FilmCraft (crates/golden/tests/golden.rs, scene `graphic_rich_text`) from procedurally generated media and bundled OFL fonts | MIT OR Apache-2.0 |
| `crates/golden/goldens/log_to_rec709.png` | FilmCraft contributors | Original work: golden reference rendered by FilmCraft (crates/golden/tests/golden.rs, scene `log_to_rec709`) from procedurally generated media re-encoded as S-Log3 | MIT OR Apache-2.0 |
| `crates/golden/goldens/hdr_tone_map.png` | FilmCraft contributors | Original work: golden reference rendered by FilmCraft (crates/golden/tests/golden.rs, scene `hdr_tone_map`) from procedurally generated media re-encoded as Rec. 2100 PQ | MIT OR Apache-2.0 |
| `crates/golden/goldens/graphic_title.png` | FilmCraft contributors | Original work: golden reference rendered by FilmCraft (crates/golden/tests/golden.rs, scene `graphic_title`) from procedurally generated media and bundled OFL fonts | MIT OR Apache-2.0 |
| `crates/golden/goldens/lumetri_basic.png` | FilmCraft contributors | Original work: golden reference rendered by FilmCraft (crates/golden/tests/golden.rs, scene `lumetri_basic`) from procedurally generated media | MIT OR Apache-2.0 |
| `crates/golden/goldens/lumetri_hdr_pq.png` | FilmCraft contributors | Original work: golden reference rendered by FilmCraft (crates/golden/tests/golden.rs, scene `lumetri_hdr_pq`) from procedurally generated media re-encoded as Rec. 2100 PQ | MIT OR Apache-2.0 |
| `crates/golden/goldens/lumetri_presets_grid.png` | FilmCraft contributors | Original work: golden reference rendered by FilmCraft (crates/golden/tests/golden.rs, `lumetri_presets_grid`): FilmCraft's own Lumetri presets on its procedural preview picture | MIT OR Apache-2.0 |
| `crates/golden/goldens/text_burnin.png` | FilmCraft contributors | Original work: golden reference rendered by FilmCraft (crates/golden/tests/golden.rs, scene `text_burnin`) from procedurally generated media | MIT OR Apache-2.0 |
| `crates/golden/goldens/transform_opacity.png` | FilmCraft contributors | Original work: golden reference rendered by FilmCraft (crates/golden/tests/golden.rs, scene `transform_opacity`) from procedurally generated media | MIT OR Apache-2.0 |
| `crates/golden/goldens/transition_cross_dissolve.png` | FilmCraft contributors | Original work: golden reference rendered by FilmCraft (crates/golden/tests/golden.rs, scene `transition_cross_dissolve`) from procedurally generated media | MIT OR Apache-2.0 |
| `crates/golden/goldens/transition_dip_to_black.png` | FilmCraft contributors | Original work: golden reference rendered by FilmCraft (crates/golden/tests/golden.rs, scene `transition_dip_to_black`) from procedurally generated media | MIT OR Apache-2.0 |
| `crates/golden/goldens/transition_wipe.png` | FilmCraft contributors | Original work: golden reference rendered by FilmCraft (crates/golden/tests/golden.rs, scene `transition_wipe`) from procedurally generated media | MIT OR Apache-2.0 |
| `crates/golden/goldens/mask_blur.png` | FilmCraft contributors | Original work: golden reference rendered by FilmCraft (crates/golden/tests/golden.rs, scene `mask_blur`) from procedurally generated media | MIT OR Apache-2.0 |
| `crates/golden/goldens/mask_color.png` | FilmCraft contributors | Original work: golden reference rendered by FilmCraft (crates/golden/tests/golden.rs, scene `mask_color`) from procedurally generated media | MIT OR Apache-2.0 |
| `crates/golden/goldens/mask_inverted.png` | FilmCraft contributors | Original work: golden reference rendered by FilmCraft (crates/golden/tests/golden.rs, scene `mask_inverted`) from procedurally generated media | MIT OR Apache-2.0 |
| `crates/golden/goldens/mask_opacity.png` | FilmCraft contributors | Original work: golden reference rendered by FilmCraft (crates/golden/tests/golden.rs, scene `mask_opacity`) from procedurally generated media | MIT OR Apache-2.0 |
| `crates/golden/goldens/vfx_distort.png` | FilmCraft contributors | Original work: golden reference rendered by FilmCraft (crates/golden/tests/golden.rs, scene `vfx_distort`) from procedurally generated media | MIT OR Apache-2.0 |
| `crates/golden/goldens/vfx_ultra_key.png` | FilmCraft contributors | Original work: golden reference rendered by FilmCraft (crates/golden/tests/golden.rs, scene `vfx_ultra_key`) from procedurally generated media | MIT OR Apache-2.0 |
| `crates/golden/goldens/vfx_glows.png` | FilmCraft contributors | Original work: golden reference rendered by FilmCraft (crates/golden/tests/golden.rs, scene `vfx_glows`) from procedurally generated media | MIT OR Apache-2.0 |
| `crates/golden/goldens/vfx_spacer_stroke_shadow.png` | FilmCraft contributors | Original work: golden reference rendered by FilmCraft (crates/golden/tests/golden.rs, scene `vfx_spacer_stroke_shadow`) from procedurally generated media | MIT OR Apache-2.0 |
| `crates/golden/goldens/vfx_vr_rotate.png` | FilmCraft contributors | Original work: golden reference rendered by FilmCraft (crates/golden/tests/golden.rs, scene `vfx_vr_rotate`) from procedurally generated media | MIT OR Apache-2.0 |
| `crates/golden/goldens/vfx_stylize.png` | FilmCraft contributors | Original work: golden reference rendered by FilmCraft (crates/golden/tests/golden.rs, scene `vfx_stylize`) from procedurally generated media | MIT OR Apache-2.0 |

## Third-party media shown in screenshots

The README screenshots show frames from these works. The media files themselves are not in the
repository; each screenshot's sidecar lists exactly which appear.

| Work | Author | Status | Source |
|---|---|---|---|
| Night of the Living Dead (1968) | George A. Romero / Image Ten | US public domain (no copyright notice) | https://archive.org/details/night-of-the-living-dead-1968-english |
| Carnival of Souls (1962) | Herk Harvey / Harcourt Productions | US public domain | https://archive.org/details/CarnivalOfSoulsVideoQualityUpgrade |
| Charade (1963) | Stanley Donen / Universal | US public domain (defective notice) | https://archive.org/details/charade-1963-cary-grant-audrey-hepburn-comedy-mystery-romance-thriller-full-movie |
| Earth Views from the ISS (NHQ_2020_1221) | NASA | US Government work, public domain (no NASA endorsement implied) | https://images.nasa.gov/details/NHQ_2020_1221_Earth%20Views |
| Chopin: Nocturne Op. 48 No. 1, Ballade No. 1 | Musopen | CC0-1.0 | https://archive.org/details/musopen-chopin |

## Assets drawn or generated in code

These are original work by FilmCraft contributors under the project licence (MIT OR Apache-2.0). None
is traced or derived from Adobe artwork.

| Asset | Where |
|---|---|
| UI icons (tools, transport, panels, header) | `crates/ui-egui/src/icons.rs`: vector paths on a 16×16 grid |
| Source and Program range braces and trim hover cues | `crates/ui-egui/src/panels/monitor.rs` and `source_range.rs`: original generic vector shapes by FilmCraft contributors, MIT OR Apache-2.0; no third-party artwork |
| Align / distribute / paragraph-alignment glyphs in the graphics panel | `crates/ui-egui/src/panels/graphics.rs` (`align_glyph`): bars and lines drawn with the egui painter |
| Demo footage (ocean sunset, aurora, city night, dunes, forest, plasma), bars and tone, counting leader, colour matte | `crates/media/src/generators.rs` |
| Built-in graphics templates (Lower Third – Slab / Rule, Ticker – Crawl, Title – Centered / Boxed, End Credits – Roll, Callout – Pointer / Tag) and their placeholder text | `crates/project/src/gtemplate.rs` (`builtin_templates`): original designs defined in code with the bundled Inter font; thumbnails are rendered at runtime, no template, image or font files |
| Lumetri "Look" presets (Teal & Orange, Warm Film, …) | `crates/render/src/effects.rs` (`apply_look`): procedural colour transforms, not LUT files |
| Lumetri Presets (Effects panel: Cinematic, Film Emulation, Monochrome, Technical) and their preview picture | `crates/render/src/lumetri_presets.rs`: Lumetri parameter values chosen by contributors, descriptive names, and a procedural preview picture (dusk sky, ridges, lake, grey ramp, colour chips) |
| Colour palette and layout metrics | `crates/ui-egui/src/theme.rs`: colour values and sizes only; no artwork |

## Optional build input: craft-fonts

These fonts are **not files in this repository**. Builds made with the optional build input
`CRAFT_FONTS_DIR` (all official releases; see [docs/contributing.md](docs/contributing.md#building-with-craft-fonts))
embed them from [storytold/craft-fonts](https://github.com/storytold/craft-fonts), where each file,
its author, pinned upstream source and licence text are listed in its
[ATTRIBUTION.md](https://github.com/storytold/craft-fonts/blob/main/ATTRIBUTION.md). Release packages
carry each font's licence as `OFL-<family>.txt`.

| Font | Use in FilmCraft | Licence |
|---|---|---|
| BIZ UDPGothic Regular, Bold (Morisawa) | Japanese UI text; Japanese fallback for sans titles (the web build embeds only Regular) | OFL-1.1 |
| Shippori Mincho Regular (FONTDASU) | Japanese fallback for serif titles (native builds) | OFL-1.1 |
| BIZ UDMincho Regular (Morisawa) | Japanese fallback for serif titles (native builds) | OFL-1.1 |
| Noto Sans CJK SC Regular (Google, Adobe) | Chinese UI text and media names; Chinese fallback for titles (native builds) | OFL-1.1 |
| Noto Sans Arabic Regular (Google) | Arabic UI text; Arabic fallback for titles (native builds) | OFL-1.1 |
| Noto Sans Thai Regular (Google) | Thai fallback for titles (native builds) | OFL-1.1 |
| Noto Sans Georgian Regular (Google) | Georgian fallback for titles (native builds) | OFL-1.1 |

## First-party brand marks

The ArtCraft name, wordmark and logos are trademarks of the ArtCraft Team. They are not open source and
are not covered by the project licence; they may be used only unmodified and only in the context of
FilmCraft, under [`docs/brand/LICENSE-brand.txt`](docs/brand/LICENSE-brand.txt). Forks and modified versions must
remove them (AGENTS.md §1.8).

| File | Author | Source | Licence |
|---|---|---|---|
| `docs/brand/artcraft-logo-white.png` | ArtCraft Team | Original work: first-party ArtCraft brand mark (ArtCraft wordmark, light ink for dark backgrounds) | ArtCraft trademark, not open source; `docs/brand/LICENSE-brand.txt` (not MIT/Apache) |
| `docs/brand/artcraft-logo-white.svg` | ArtCraft Team | Original work: first-party ArtCraft brand mark (ArtCraft wordmark, light ink for dark backgrounds) | ArtCraft trademark, not open source; `docs/brand/LICENSE-brand.txt` (not MIT/Apache) |
| `docs/brand/artcraft-logo.png` | ArtCraft Team | Original work: first-party ArtCraft brand mark (ArtCraft wordmark (symbol + "ARTCRAFT"), dark ink for light backgrounds) | ArtCraft trademark, not open source; `docs/brand/LICENSE-brand.txt` (not MIT/Apache) |
| `docs/brand/artcraft-logo.svg` | ArtCraft Team | Original work: first-party ArtCraft brand mark (ArtCraft wordmark (symbol + "ARTCRAFT"), dark ink for light backgrounds) | ArtCraft trademark, not open source; `docs/brand/LICENSE-brand.txt` (not MIT/Apache) |
| `docs/brand/artcraft-mark-black.png` | ArtCraft Team | Original work: first-party ArtCraft brand mark (ArtCraft symbol ("A" mark), black) | ArtCraft trademark, not open source; `docs/brand/LICENSE-brand.txt` (not MIT/Apache) |
| `docs/brand/artcraft-mark-black.svg` | ArtCraft Team | Original work: first-party ArtCraft brand mark (ArtCraft symbol ("A" mark), black) | ArtCraft trademark, not open source; `docs/brand/LICENSE-brand.txt` (not MIT/Apache) |
| `docs/brand/artcraft-mark.png` | ArtCraft Team | Original work: first-party ArtCraft brand mark (ArtCraft symbol ("A" mark), blue) | ArtCraft trademark, not open source; `docs/brand/LICENSE-brand.txt` (not MIT/Apache) |
| `docs/brand/artcraft-mark.svg` | ArtCraft Team | Original work: first-party ArtCraft brand mark (ArtCraft symbol ("A" mark), blue) | ArtCraft trademark, not open source; `docs/brand/LICENSE-brand.txt` (not MIT/Apache) |

## Third-party source code

Source files that are transcribed from third-party code rather than written from scratch. Each keeps
the original copyright and permission notice in its header.

| File | Author | Source | Licence |
|---|---|---|---|
| `crates/platform/src/nvenc/ffi.rs` | NVIDIA Corporation (`nvEncodeAPI.h`); FilmCraft contributors (Rust transcription) | Structures (including `NV_ENC_CONFIG_HEVC` and its bit-field masks, `NV_ENC_PIC_PARAMS_HEVC`, `NV_ENC_SEI_PAYLOAD`, `NV_ENC_TIME_CODE`), function table, codec / profile GUIDs (H.264, HEVC Main, HEVC Main 10) and constants (`NV_ENC_LEVEL_HEVC_*`, tier, CU size, `NV_ENC_BUFFER_FORMAT_YUV420_10BIT`, `NV_ENC_CAPS_SUPPORT_10BIT_ENCODE`, BT.2020 / PQ / HLG VUI codes) transcribed from `nvEncodeAPI.h`, NVIDIA Video Codec SDK, API 12.1 (https://developer.nvidia.com/video-codec-sdk) | MIT (Copyright (c) 2010-2023 NVIDIA Corporation; notice kept in the file header) |

## Downloaded at runtime

These files are never in the repository or the app bundle. FilmCraft downloads them into the
per-user data directory (`<data dir>/models/<id>/`) only after the user confirms a dialog that shows
the size, the source URL and the licence. Every file is pinned to a revision and checked against its
SHA-256 (`crates/speech/src/models.rs`, `docs/transcripts.md`).

| Asset | Author | Source | Licence |
|---|---|---|---|
| Whisper tiny / base / small speech-recognition weights (`model.safetensors`, `config.json`, `generation_config.json`, `tokenizer.json`) | OpenAI | `https://huggingface.co/openai/whisper-{tiny,base,small}` (revisions `169d4a43…`, `e37978b9…`, `973afd24…`); weights released with `https://github.com/openai/whisper` | MIT (weights and code, github.com/openai/whisper); the Hugging Face conversion is labelled Apache-2.0 |

## egui dependency fonts

| Asset | Author | Source | Licence | Use |
|---|---|---|---|---|
| `epaint_default_fonts::EGUI_ICONS`, `epaint_default_fonts::EMOJI_ICON` (dependency font inputs) | John Slegers | [egui 6d518fc7](https://github.com/storytold/egui/tree/6d518fc799681571963842f95b55a6b68431b15a/crates/epaint_default_fonts/fonts), [emoji-icon-font](https://github.com/jslegers/emoji-icon-font) | MIT (Copyright (c) 2014 John Slegers; full upstream text in `NOTICE`) | egui-icons.ttf is the five-glyph subset, included by default_fonts independently of monochrome_emoji_fonts; emoji-icon-font.ttf is the full monochrome fallback. Dependency assets unmodified here; no font file copied into this repository. |
| `epaint_default_fonts::UBUNTU_LIGHT` (dependency font input) | Canonical Ltd. | [egui 6d518fc7](https://github.com/storytold/egui/tree/6d518fc799681571963842f95b55a6b68431b15a/crates/epaint_default_fonts/fonts) | Ubuntu Font Licence 1.0 (Copyright 2011 Canonical Ltd.; full upstream text in `NOTICE`) | Ubuntu-Light.ttf is egui's default proportional fallback, included by `default_fonts`; `system_fonts` is not enabled. Dependency asset unmodified here; no font file copied into this repository. |
| `epaint_default_fonts::NOTO_EMOJI_REGULAR` (dependency font input) | The Noto Project Authors (Google) | [egui 6d518fc7](https://github.com/storytold/egui/tree/6d518fc799681571963842f95b55a6b68431b15a/crates/epaint_default_fonts/fonts), [Noto Emoji](https://fonts.google.com/noto/specimen/Noto+Emoji) | OFL-1.1 (Copyright 2013 Google Inc.; full upstream text in `NOTICE`) | NotoEmoji-Regular.ttf is the monochrome emoji fallback, included because the workspace enables `monochrome_emoji_fonts`. Dependency asset unmodified here; no font file copied into this repository. |
| `epaint_default_fonts::HACK_REGULAR` (dependency font input) | Source Foundry Authors; Bitstream Inc.; DejaVu contributors | [egui 6d518fc7](https://github.com/storytold/egui/tree/6d518fc799681571963842f95b55a6b68431b15a/crates/epaint_default_fonts/fonts), [Hack](https://github.com/source-foundry/Hack) | MIT (Copyright (c) 2018 Source Foundry Authors) and the Bitstream Vera License (Copyright (c) 2003 Bitstream, Inc.); the DejaVu work is public domain; full upstream notices in `NOTICE` | Hack-Regular.ttf is egui's default monospace fallback, included by `default_fonts`. Dependency asset unmodified here; no font file copied into this repository. |
