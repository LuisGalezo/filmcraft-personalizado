# Seven Cut Pro r36 — Etapa 2, primera entrega: compositor GPU (wgpu) conectado a la exportación

Base: r35. **Nada se compiló ni se ejecutó** (este entorno no tiene Rust, Kotlin, Gradle ni Android SDK, ni red). **No hay tiempos, ni consumo de memoria, ni comparación visual reales.** Lo escrito está revisado a mano contra el código de la CPU, pero nada está verificado.

## Avance honesto
- **Código de esta primera entrega: ~85 % escrito.** Falta: compilarlo y corregir errores (casi seguro habrá, sobre todo en la API de wgpu 24 y en nombres de UniFFI), y medir.
- **Verificado de verdad (compilado + probado + medido en el teléfono): 0 %.**
- **Etapa 2 completa** (efectos, filtros, máscaras, croma, transiciones, decodificación YUV y conversión a 8 bits en GPU, entrega directa a MediaCodec): **~30 %** (solo la parte de capas).

## Análisis del código (lo que determina el diseño)
- Recorrido: decodificación (CPU) → `plan_frame` describe el fotograma (capas con matriz, opacidad, modo de fusión, efectos) → ejecución → imagen f32 lineal premultiplicada → a 8 bits (CPU) → MediaCodec o software. El exportador ya tenía el gancho `FrameRenderer` con respaldo a CPU por fotograma, y la CPU de referencia exacta `execute_cpu`.
- La CPU remuestrea con bilinear sobre f32 premultiplicado (transparente fuera de la imagen), reduce a la mitad mientras la capa se encoge ≥2×, y compone con 27 modos. Eso es lo que se copió.
- El diagnóstico solo confirma capacidades; **la GPU no estaba conectada a nada** hasta ahora.

## Implementado (escrito, sin compilar)
`crates/gpu/src/compose/` (característica `compositor`):
- **Compositor GPU real** que implementa `FrameRenderer`: planifica con `plan_frame`; si el plan son solo capas que sabe dibujar, las compone en GPU y entrega la imagen al exportador; si no, usa el ejecutor de plan de la CPU del motor (misma imagen que la CPU, nunca rechaza un fotograma).
- **Qué dibuja la GPU:** capas con posición, escala y rotación (matriz), remuestreo bilineal idéntico y reducción por mips, opacidad, orden de capas, y **26 de los 27 modos de fusión** (todos salvo Disolver, cuyo hash usa enteros de 64 bits). Lienzo de dos texturas f32 que se alternan sin volver a la CPU hasta la última capa.
- **Texturas y búfer de lectura reutilizados** entre fotogramas (pool por tamaño), un solo dispositivo compartido, presupuesto de memoria (uno a dos compositores según la RAM); fotogramas que no caben (p. ej. 8K) van a CPU.
- **Seguridad:** prueba canario contra la CPU antes de confiar en el dispositivo; errores de validación y de memoria capturados por fotograma; pérdida de dispositivo detectada; tras 3 fallos seguidos o pérdida se apaga para el resto de la sesión y todo va a CPU. Contadores propios (fotogramas GPU, capas, planes CPU, respaldos, sobre presupuesto, último error).
- **Validación en la app**: «Validar compositor GPU (paridad con CPU)» compara todos los modos de fusión y casos de geometría (rotación, escalado, mips, color plano, orden, opacidad, capa fuera del lienzo) con la CPU y **mide un fotograma 1080p de 4 capas en CPU y GPU**. El interruptor de GPU solo se ofrece si el diagnóstico encuentra GPU **y** esta validación pasa; sigue **desactivado por defecto**.
- **Integración con exportación y MediaCodec:** la petición de exportación lleva `gpuRendering` y `hardwareEncoding`. Flujo real hoy: decodificación (CPU) → composición de capas (GPU) → imagen → conversión a 8 bits (CPU) → MediaCodec H.264 (o software). Resolución, FPS, calidad y audio no se tocan; no se reduce nada por velocidad.
- La pantalla «Sistema en uso» muestra GPU / GPU + CPU / CPU con los contadores del compositor, y MediaCodec aparte.

## Sigue en CPU (no implementado)
Decodificación y conversión de YUV a lineal; efectos (34), filtros y corrección de color, máscaras, croma, transiciones, modo Disolver, texto (rasterizado); conversión a 8 bits y entrega a MediaCodec (la imagen vuelve a la CPU en f32); vista previa; 8K/fotogramas sobre el presupuesto. **Límite conocido de rendimiento:** leer de vuelta un 1080p en f32 son ~33 MB por fotograma; con pocas capas la GPU puede salir **más lenta** que la CPU. No se sabe sin medir: lo mide el botón de validación.

## Archivos
Nuevos: `crates/gpu/src/compose/{mod,context,exec,pool,shaders,stats,validate,tests}.rs`.
Modificados: `crates/gpu/{Cargo.toml,src/lib.rs,src/stages.rs}`, `apps/filmcraft-android/{Cargo.toml,src/hardware.rs,src/gpu.rs}`, `…/ui/HardwareModel.kt`, `…/ui/home/HardwareScreen.kt`, `app/build.gradle.kts`, `.github/workflows/{compilar-apk,pruebas-gpu}.yml`.
Sin tocar: interfaz principal, editor, herramientas, render CPU, fuentes, MediaCodec (salvo lo de r35).

## Pruebas escritas (no ejecutadas)
`compose/tests.rs`: modos «soportado» (Disolver excluido), estimación de memoria, canario, **paridad de todos los modos y casos de geometría contra la CPU con tolerancia** (≤0,2 % de valores distintos más de 0,01 y media <0,001), fábrica sin renderer si está apagado. Se ejecutan en CI con Vulkan por software (lavapipe) (`pruebas-gpu.yml`); sin adaptador se saltan y lo dicen. `stages` y `hardware.rs` actualizados.

## Riesgos y cómo salir si falla la compilación
- wgpu y el compositor van en la compilación normal por defecto. Si fallan, ejecuta el flujo *Compilar…* con `gpu_compositor` desmarcado (sigue el diagnóstico) o ambos desmarcados (APK sin wgpu). Pásame el log.
- Cambia `Cargo.lock` (wgpu, bytemuck): hace falta red y no `--locked`.

## Qué falta, en orden
1. Compilar y corregir errores (Rust y Android); ejecutar *Pruebas GPU*.
2. En el teléfono: Ajustes → Diagnóstico y aceleración de hardware → *Ejecutar diagnóstico* → *Validar compositor GPU*; enviarme el informe (diferencias, tiempos CPU/GPU).
3. Activar GPU, exportar un proyecto de varias capas (1080p y 4K), comparar visualmente y los tiempos; comprobar MediaCodec y el respaldo (apagar GPU, forzar fallo).
4. Si la paridad pasa y el rendimiento compensa: decodificación YUV en GPU, conversión a 8 bits en GPU y entrega directa al codificador (quita la lectura f32), después efectos, máscaras, croma y transiciones.
