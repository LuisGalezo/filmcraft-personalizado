//! Memory model and limits for the GPU compositor. These are estimates from the phone's RAM and the formats' sizes, not
//! measurements: wgpu cannot report video memory on Android, so the compositor has to keep its own account.

use crate::formats::bytes_per_pixel;
use crate::report::Budget;

const MIB: u64 = 1 << 20;
/// A share of the phone's RAM for the compositor; the rest stays for the app, the decoders and the system.
const RAM_SHARE_DIVISOR: u64 = 8;
const MIN_BUDGET: u64 = 64 * MIB;
const MAX_BUDGET: u64 = 768 * MIB;
/// Assumed when the app could not tell the RAM (a mid-range phone).
const UNKNOWN_RAM_MB: u64 = 4096;
/// A software rasteriser gets a token budget: it is not meant to be used.
const SOFTWARE_BUDGET: u64 = 64 * MIB;
/// Long sides tried, biggest first (16:9 frames).
const SIDES: [u32; 6] = [7680, 4096, 3840, 2560, 1920, 1280];

pub fn frame_bytes(width: u32, height: u32, format: &str) -> u64 {
    u64::from(width) * u64::from(height) * bytes_per_pixel(format).unwrap_or(0)
}

/// One compositor at `width` x `height`: three full-size targets (two to ping-pong, one for an effect's working image) and
/// four resident 8-bit YUV 4:2:0 sources.
pub fn compositor_bytes(width: u32, height: u32, f32_targets: bool) -> u64 {
    let target = frame_bytes(width, height, if f32_targets { "Rgba32Float" } else { "Rgba16Float" });
    let sources = 4 * (u64::from(width) * u64::from(height) * 3 / 2);
    3 * target + sources
}

fn frame_for_side(side: u32) -> (u32, u32) {
    (side, side * 9 / 16)
}

pub fn recommend(system_ram_mb: Option<u64>, device_type: &str, max_texture_dimension_2d: u32) -> Budget {
    let software = device_type == "cpu";
    let ram_mb = system_ram_mb.unwrap_or(UNKNOWN_RAM_MB);
    let mut budget = (ram_mb.saturating_mul(MIB) / RAM_SHARE_DIVISOR).clamp(MIN_BUDGET, MAX_BUDGET);
    if software {
        budget = budget.min(SOFTWARE_BUDGET);
    }
    let max_frame_side = SIDES
        .iter()
        .copied()
        .find(|&side| {
            let (w, h) = frame_for_side(side);
            side <= max_texture_dimension_2d && compositor_bytes(w, h, false) <= budget
        })
        .unwrap_or(0);
    let c16 = compositor_bytes(1920, 1080, false);
    let c32 = compositor_bytes(1920, 1080, true);
    let max_compositors = if software || max_frame_side == 0 || c16 == 0 { 0 } else { (budget / c16).min(2) as u32 };
    Budget { budget_bytes: budget, max_frame_side, max_compositors, compositor_1080p_f16_bytes: c16, compositor_1080p_f32_bytes: c32, software_renderer: software }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn the_model_for_1080p() {
        assert_eq!(frame_bytes(1920, 1080, "Rgba16Float"), 16_588_800);
        assert_eq!(compositor_bytes(1920, 1080, false), 3 * 16_588_800 + 4 * 3_110_400);
        assert_eq!(compositor_bytes(1920, 1080, false), 62_208_000);
        assert_eq!(compositor_bytes(1920, 1080, true), 3 * 33_177_600 + 12_441_600);
    }

    #[test]
    fn a_4gb_phone_gets_512_mb_and_4k_fits_one_compositor() {
        let b = recommend(Some(4096), "integrated_gpu", 16384);
        assert_eq!(b.budget_bytes, 512 * MIB);
        assert_eq!(b.max_frame_side, 4096); // 4096x2304 f16: about 270 MB <= 512 MB
        assert_eq!(b.max_compositors, 2);
        assert!(!b.software_renderer);
    }

    #[test]
    fn a_small_phone_gets_less() {
        let b = recommend(Some(2048), "integrated_gpu", 8192);
        assert_eq!(b.budget_bytes, 256 * MIB);
        assert_eq!(b.max_frame_side, 3840); // 4096x2304 needs about 270 MB (over), 3840x2160 about 237 MB (fits)
        assert!(compositor_bytes(3840, 2160, false) <= b.budget_bytes);
        assert!(compositor_bytes(4096, 2304, false) > b.budget_bytes);
        assert_eq!(b.max_compositors, 2);
        let tight = recommend(Some(256), "integrated_gpu", 8192);
        assert_eq!((tight.budget_bytes, tight.max_frame_side, tight.max_compositors), (MIN_BUDGET, 1920, 1));
    }

    #[test]
    fn the_texture_limit_caps_the_frame_size() {
        let b = recommend(Some(8192), "discrete_gpu", 2048);
        assert_eq!(b.max_frame_side, 1920);
        let tiny = recommend(Some(8192), "discrete_gpu", 1024);
        assert_eq!((tiny.max_frame_side, tiny.max_compositors), (0, 0));
    }

    #[test]
    fn unknown_ram_is_assumed_mid_range_and_the_budget_has_a_floor_and_a_ceiling() {
        assert_eq!(recommend(None, "integrated_gpu", 8192).budget_bytes, 512 * MIB);
        assert_eq!(recommend(Some(256), "integrated_gpu", 8192).budget_bytes, MIN_BUDGET);
        assert_eq!(recommend(Some(65536), "integrated_gpu", 16384).budget_bytes, MAX_BUDGET);
    }

    #[test]
    fn a_software_rasteriser_is_never_recommended() {
        let b = recommend(Some(16384), "cpu", 16384);
        assert!(b.software_renderer);
        assert_eq!(b.max_compositors, 0);
        assert!(b.budget_bytes <= SOFTWARE_BUDGET);
    }
}
