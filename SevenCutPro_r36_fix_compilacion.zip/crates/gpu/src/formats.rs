//! The texture formats the GPU compositor would need, and what each is for. The probe asks the adapter about exactly these.

/// One format the compositor wants.
pub struct Needed {
    /// The wgpu name (`wgpu::TextureFormat::<name>`).
    pub name: &'static str,
    pub role: &'static str,
    /// Without it the GPU compositor cannot work at all.
    pub required: bool,
}

pub const NEEDED: &[Needed] = &[
    Needed { name: "R8Unorm", role: "8-bit YUV planes (Y, U, V as three textures)", required: true },
    Needed { name: "Rg8Unorm", role: "semi-planar chroma (optional layout)", required: false },
    Needed { name: "R16Uint", role: "9-16 bit YUV planes, read as integers (R16Unorm is not universal)", required: false },
    Needed { name: "Rgba8Unorm", role: "8-bit RGBA sources (text, stills) and the 8-bit read-back target", required: true },
    Needed { name: "Rgba8UnormSrgb", role: "sRGB-encoded 8-bit target (optional)", required: false },
    Needed { name: "Rgba16Float", role: "SDR working targets (ping-pong), linear premultiplied", required: true },
    Needed { name: "Rgba32Float", role: "high-precision targets for effects that accumulate (large blurs, levels)", required: false },
];

/// Bytes per pixel of a format of [`NEEDED`].
pub fn bytes_per_pixel(name: &str) -> Option<u64> {
    Some(match name {
        "R8Unorm" => 1,
        "Rg8Unorm" | "R16Uint" => 2,
        "Rgba8Unorm" | "Rgba8UnormSrgb" => 4,
        "Rgba16Float" => 8,
        "Rgba32Float" => 16,
        _ => return None,
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn every_needed_format_has_a_size() {
        for n in NEEDED {
            assert!(bytes_per_pixel(n.name).is_some(), "{}", n.name);
        }
        assert_eq!(bytes_per_pixel("Rgba16Float"), Some(8));
        assert_eq!(bytes_per_pixel("Nope"), None);
    }

    #[test]
    fn the_required_set_is_what_a_compositor_cannot_do_without() {
        let req: Vec<_> = NEEDED.iter().filter(|n| n.required).map(|n| n.name).collect();
        assert_eq!(req, vec!["R8Unorm", "Rgba8Unorm", "Rgba16Float"]);
    }
}
