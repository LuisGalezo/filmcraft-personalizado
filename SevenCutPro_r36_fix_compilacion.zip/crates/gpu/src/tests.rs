use super::*;
use crate::report::{AdapterReport, BackendReport, DeviceReport, FormatReport, FormatSupport, LimitsReport};

fn full() -> Vec<FormatReport> {
    let s = |sampled, render, filterable| FormatSupport { sampled, render_attachment: render, copy_src: true, copy_dst: true, storage: false, filterable, blendable: render };
    [("R8Unorm", s(true, true, true)), ("R16Uint", s(true, true, false)), ("Rgba8Unorm", s(true, true, true)), ("Rgba16Float", s(true, true, true)), ("Rgba32Float", s(true, true, false))]
        .into_iter()
        .map(|(n, support)| FormatReport { name: n.into(), role: String::new(), required: false, support })
        .collect()
}

fn adapter(name: &str, device_type: &str, device_ok: bool, formats: Vec<FormatReport>) -> AdapterReport {
    AdapterReport {
        backend: String::new(),
        name: name.into(),
        vendor_id: 0x13b5,
        device_id: 0x1,
        device_type: device_type.into(),
        driver: "drv".into(),
        driver_info: "1.2.3".into(),
        features: vec!["FLOAT32_FILTERABLE".into()],
        limits: LimitsReport { max_texture_dimension_2d: 16384, max_sampled_textures_per_shader_stage: 16, max_bind_groups: 4, max_buffer_size: 1 << 30, ..Default::default() },
        formats,
        device: DeviceReport { attempted: true, ok: device_ok, error: if device_ok { None } else { Some("no device".into()) }, ..Default::default() },
        allocations: vec![],
        verdict: None,
        budget: None,
    }
}

fn backend(name: &str, adapters: Vec<AdapterReport>) -> BackendReport {
    BackendReport { backend: name.into(), adapters, error: None, elapsed_ms: 3 }
}

fn report(backends: Vec<BackendReport>) -> GpuReport {
    let mut r = GpuReport::new(true, Some(6144));
    r.backends = backends;
    finalize(&mut r);
    r
}

#[test]
fn a_real_gpu_on_vulkan_beats_gl_and_a_software_rasteriser() {
    let r = report(vec![
        backend("vulkan", vec![adapter("SwiftShader", "cpu", true, full()), adapter("Adreno", "integrated_gpu", true, full())]),
        backend("gl", vec![adapter("Adreno GL", "integrated_gpu", true, full())]),
    ]);
    let sel = r.selected.as_ref().unwrap();
    assert_eq!((sel.backend.as_str(), sel.name.as_str()), ("vulkan", "Adreno"));
    assert!(r.selected_adapter().is_some_and(|a| a.name == "Adreno"));
}

#[test]
fn gl_is_the_fallback_when_vulkan_has_no_usable_device() {
    let r = report(vec![backend("vulkan", vec![adapter("Broken", "integrated_gpu", false, full())]), backend("gl", vec![adapter("Mali GL", "integrated_gpu", true, full())])]);
    assert_eq!(r.selected.as_ref().unwrap().backend, "gl");
}

#[test]
fn with_nothing_usable_nothing_is_selected_and_it_says_so() {
    let none = report(vec![backend("vulkan", vec![]), backend("gl", vec![])]);
    assert!(none.selected.is_none());
    assert!(none.issues.iter().any(|i| i.message.contains("no GPU adapter found")));
    let software = report(vec![backend("vulkan", vec![adapter("llvmpipe", "cpu", true, full())])]);
    assert!(software.selected.is_none());
    assert!(software.issues.iter().any(|i| i.message.contains("no adapter can accelerate")));
}

#[test]
fn every_assessed_adapter_has_a_verdict_and_a_budget() {
    let r = report(vec![backend("vulkan", vec![adapter("Adreno", "integrated_gpu", true, full())])]);
    let a = &r.backends[0].adapters[0];
    assert_eq!(a.verdict.as_ref().unwrap().overall, Level::Supported);
    assert_eq!(a.budget.as_ref().unwrap().budget_bytes, 768 * 1024 * 1024); // 6 GB / 8 = 768 MB
}

#[test]
fn the_summary_and_the_json_carry_the_main_facts() {
    let r = report(vec![backend("vulkan", vec![adapter("Adreno 740", "integrated_gpu", true, full())])]);
    let text = r.summary();
    for needle in ["Adreno 740", "integrated_gpu", "Rgba16Float", "composition_f16", "selected: Adreno 740 on vulkan", "6144 MB"] {
        assert!(text.contains(needle), "summary lacks {needle}:\n{text}");
    }
    let json: serde_json::Value = serde_json::from_str(&r.to_json()).unwrap();
    assert_eq!(json["schema"], 1);
    assert_eq!(json["selected"]["name"], "Adreno 740");
    assert_eq!(json["status"]["state"], "ran");
    assert_eq!(json["backends"][0]["adapters"][0]["verdict"]["overall"], "supported");
    assert_eq!(json["backends"][0]["adapters"][0]["formats"][0]["name"], "R8Unorm");
}

#[test]
fn skipped_and_timed_out_reports_say_why_in_json() {
    let mut r = GpuReport::new(false, None);
    r.status = Status::Skipped("because".into());
    let json: serde_json::Value = serde_json::from_str(&r.to_json()).unwrap();
    assert_eq!(json["status"]["state"], "skipped");
    assert_eq!(json["status"]["why"], "because");
    assert_eq!(json["wgpu_compiled"], false);
}

#[cfg(not(feature = "wgpu-probe"))]
#[test]
fn a_build_without_wgpu_says_so_and_touches_nothing() {
    let dir = tempfile::tempdir().unwrap();
    let r = run_probe(&ProbeOptions { state_dir: Some(dir.path().to_path_buf()), ..Default::default() });
    assert!(!r.wgpu_compiled);
    assert!(matches!(r.status, Status::Skipped(ref w) if w.contains("does not include wgpu")));
    assert!(r.backends.is_empty() && r.selected.is_none());
    assert_eq!(std::fs::read_dir(dir.path()).unwrap().count(), 0, "no marker is written when nothing is probed");
}

// ---- with wgpu built in: these run the real probe on whatever the test machine has (maybe no GPU at all) ----

#[cfg(feature = "wgpu-probe")]
#[test]
fn the_real_probe_runs_to_the_end_and_describes_what_it_found() {
    let dir = tempfile::tempdir().unwrap();
    let r = run_probe(&ProbeOptions { state_dir: Some(dir.path().to_path_buf()), timeout: Duration::from_secs(60), ..Default::default() });
    assert!(r.wgpu_compiled);
    assert_eq!(r.status, Status::Ran, "{}", r.summary());
    assert_eq!(r.backends.len(), 2);
    assert_eq!(r.backends[0].backend, "vulkan");
    assert_eq!(r.backends[1].backend, "gl");
    for b in &r.backends {
        for a in &b.adapters {
            assert_eq!(a.formats.len(), formats::NEEDED.len());
            assert!(a.verdict.is_some() && a.budget.is_some());
            if a.device.ok {
                assert!(a.limits.max_texture_dimension_2d >= 1024, "{}", r.summary());
            } else {
                assert!(a.device.error.is_some());
            }
        }
    }
    // an adapter without GPU hardware (or none at all) is reported, never an error of the probe
    if r.selected.is_none() {
        assert!(r.issues.iter().any(|i| i.stage == "select"));
    }
    // a probe that ended leaves no marker behind
    assert!(!dir.path().join("gpu_probe.running").exists());
    // and the JSON is valid
    let _: serde_json::Value = serde_json::from_str(&r.to_json()).unwrap();
}

#[cfg(feature = "wgpu-probe")]
#[test]
fn a_build_that_crashed_in_the_probe_is_not_probed_again() {
    let dir = tempfile::tempdir().unwrap();
    // an earlier run died inside the driver: its marker is still there
    drop(match guard::begin(dir.path(), "crashy").unwrap() {
        guard::Begin::Go(a) => a,
        guard::Begin::Blocked(_) => unreachable!(),
    });
    let blocked = run_probe(&ProbeOptions { state_dir: Some(dir.path().to_path_buf()), build_id: "crashy".into(), ..Default::default() });
    assert!(matches!(blocked.status, Status::Skipped(ref w) if w.contains("never finished")), "{:?}", blocked.status);
    assert!(blocked.backends.is_empty());
    // a new build of the app tries again
    let again = run_probe(&ProbeOptions { state_dir: Some(dir.path().to_path_buf()), build_id: "fixed".into(), timeout: Duration::from_secs(60), ..Default::default() });
    assert_eq!(again.status, Status::Ran);
}
