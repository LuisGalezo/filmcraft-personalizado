//! Composing a plan's layers on the GPU, the way `filmcraft_render::plan::execute_cpu` does it on the CPU: for each layer, bottom to top, its
//! picture (decoded to premultiplied linear f32 by the same code as the CPU path) is placed through its matrix with the same bilinear
//! resampling (halving first while the layer is shrunk 2x or more, like `Image::transformed`) and composited with its opacity and blend mode.
//! The canvas lives on the GPU between layers: two textures that take turns being read and written, so nothing comes back to the CPU until
//! the last layer is done.

use super::context::GpuContext;
use super::pool::{texture_bytes, TexturePool};
use filmcraft_geom::{Affine, Rect};
use filmcraft_render::blend::Blend;
use filmcraft_render::plan::PlanLayer;
use filmcraft_render::Image;

/// A layer the GPU can draw: no effects (their CPU code runs on the picture first), no colour-managed input, no Dissolve (a 64-bit hash).
pub(crate) fn supported(layers: &[PlanLayer]) -> bool {
    layers.iter().all(|l| l.fx.is_none() && l.input.is_none() && l.blend != Blend::Dissolve)
}

/// A generous estimate of the GPU memory a frame needs: the two canvases, the read-back buffer, and the biggest layer picture with its mips.
pub(crate) fn estimate_bytes(width: usize, height: usize, layers: &[PlanLayer]) -> u64 {
    let canvas = texture_bytes(width as u32, height as u32);
    let biggest = layers.iter().map(|l| texture_bytes(l.frame.width, l.frame.height)).max().unwrap_or(0);
    canvas * 3 + biggest + biggest / 3
}

fn blend_number(b: Blend) -> u32 {
    Blend::ALL.iter().position(|x| *x == b).unwrap_or(0) as u32
}

/// The uniform block of the composite shader: four vec4<f32> (see `shaders::COMPOSITE`).
fn params(inv: &Affine, src: (u32, u32), opacity: f32, mode: u32, solid: bool, bounds: [f32; 4]) -> [u8; 64] {
    let v: [f32; 16] = [
        inv.a as f32,
        inv.b as f32,
        inv.c as f32,
        inv.d as f32,
        inv.e as f32,
        inv.f as f32,
        src.0 as f32,
        src.1 as f32,
        opacity,
        mode as f32,
        if solid { 1.0 } else { 0.0 },
        0.0,
        bounds[0],
        bounds[1],
        bounds[2],
        bounds[3],
    ];
    let mut out = [0u8; 64];
    for (i, x) in v.iter().enumerate() {
        out[i * 4..i * 4 + 4].copy_from_slice(&x.to_ne_bytes());
    }
    out
}

fn view(t: &wgpu::Texture) -> wgpu::TextureView {
    t.create_view(&wgpu::TextureViewDescriptor::default())
}

fn clear(ctx: &GpuContext, target: &wgpu::Texture) {
    let v = view(target);
    let mut enc = ctx.device.create_command_encoder(&wgpu::CommandEncoderDescriptor { label: Some("clear") });
    {
        let _pass = enc.begin_render_pass(&wgpu::RenderPassDescriptor {
            label: Some("clear"),
            color_attachments: &[Some(wgpu::RenderPassColorAttachment { view: &v, resolve_target: None, ops: wgpu::Operations { load: wgpu::LoadOp::Clear(wgpu::Color::TRANSPARENT), store: wgpu::StoreOp::Store } })],
            depth_stencil_attachment: None,
            timestamp_writes: None,
            occlusion_query_set: None,
        });
    }
    ctx.queue.submit(Some(enc.finish()));
}

fn upload(ctx: &GpuContext, tex: &wgpu::Texture, w: usize, h: usize, px: &[f32]) {
    ctx.queue.write_texture(
        wgpu::TexelCopyTextureInfo { texture: tex, mip_level: 0, origin: wgpu::Origin3d::ZERO, aspect: wgpu::TextureAspect::All },
        bytemuck::cast_slice(px),
        wgpu::TexelCopyBufferLayout { offset: 0, bytes_per_row: Some(w as u32 * 16), rows_per_image: Some(h as u32) },
        wgpu::Extent3d { width: w as u32, height: h as u32, depth_or_array_layers: 1 },
    );
}

fn run_pass(ctx: &GpuContext, pipeline: &wgpu::RenderPipeline, group: &wgpu::BindGroup, out: &wgpu::Texture) {
    let out_view = view(out);
    let mut enc = ctx.device.create_command_encoder(&wgpu::CommandEncoderDescriptor { label: Some("pass") });
    {
        let mut pass = enc.begin_render_pass(&wgpu::RenderPassDescriptor {
            label: Some("pass"),
            // the shader writes every pixel, so nothing needs loading
            color_attachments: &[Some(wgpu::RenderPassColorAttachment { view: &out_view, resolve_target: None, ops: wgpu::Operations { load: wgpu::LoadOp::Clear(wgpu::Color::TRANSPARENT), store: wgpu::StoreOp::Store } })],
            depth_stencil_attachment: None,
            timestamp_writes: None,
            occlusion_query_set: None,
        });
        pass.set_pipeline(pipeline);
        pass.set_bind_group(0, group, &[]);
        pass.draw(0..3, 0..1);
    }
    ctx.queue.submit(Some(enc.finish()));
}

fn downsample(ctx: &GpuContext, src: &wgpu::Texture, out: &wgpu::Texture) {
    let sv = view(src);
    let group = ctx.device.create_bind_group(&wgpu::BindGroupDescriptor {
        label: Some("downsample"),
        layout: &ctx.downsample_layout,
        entries: &[wgpu::BindGroupEntry { binding: 0, resource: wgpu::BindingResource::TextureView(&sv) }],
    });
    run_pass(ctx, &ctx.downsample, &group, out);
}

#[allow(clippy::too_many_arguments)]
fn composite(ctx: &GpuContext, uniform: &wgpu::Buffer, dst: &wgpu::Texture, src: &wgpu::Texture, out: &wgpu::Texture, block: &[u8; 64]) {
    // each layer is its own submit, so the one uniform buffer can be rewritten between layers (writes are ordered with submits)
    ctx.queue.write_buffer(uniform, 0, block);
    let (dv, sv) = (view(dst), view(src));
    let group = ctx.device.create_bind_group(&wgpu::BindGroupDescriptor {
        label: Some("composite"),
        layout: &ctx.composite_layout,
        entries: &[
            wgpu::BindGroupEntry { binding: 0, resource: uniform.as_entire_binding() },
            wgpu::BindGroupEntry { binding: 1, resource: wgpu::BindingResource::TextureView(&dv) },
            wgpu::BindGroupEntry { binding: 2, resource: wgpu::BindingResource::TextureView(&sv) },
        ],
    });
    run_pass(ctx, &ctx.composite, &group, out);
}

/// Compose `layers` onto a transparent canvas of `width` x `height` and bring the picture back. `Err` = the GPU could not do it (the caller
/// composes the frame on the CPU instead).
pub(crate) fn draw_layers(ctx: &GpuContext, pool: &mut TexturePool, uniform: &wgpu::Buffer, width: usize, height: usize, layers: &[PlanLayer]) -> Result<Image, String> {
    if width == 0 || height == 0 || width.max(height) as u32 > ctx.max_texture {
        return Err(format!("a {width}x{height} canvas is beyond the GPU's texture limit of {}", ctx.max_texture));
    }
    let (w32, h32) = (width as u32, height as u32);
    ctx.device.push_error_scope(wgpu::ErrorFilter::OutOfMemory);
    ctx.device.push_error_scope(wgpu::ErrorFilter::Validation);

    let mut canvas = pool.take(ctx, w32, h32);
    let mut other = pool.take(ctx, w32, h32);
    clear(ctx, &canvas);

    for l in layers {
        if l.matrix.inverse().is_none() {
            continue;
        }
        let (sw, sh, px) = l.frame.to_linear_f32_decimated_with(1, None);
        if sw == 0 || sh == 0 {
            continue;
        }
        // a flat colour layer (a 1x1 picture stretched over the canvas) is filled, not resampled, as on the CPU
        let solid = l.matrix == Affine::scale(width as f64, height as f64) && sw == 1 && sh == 1;
        let mut tex = pool.take(ctx, sw as u32, sh as u32);
        upload(ctx, &tex, sw, sh, &px);
        let (mut cw, mut ch) = (sw, sh);
        let mut m = l.matrix;
        let mut done: Vec<(u32, u32, wgpu::Texture)> = Vec::new();
        if !solid {
            // halve while the layer is shrunk 2x or more, as Image::transformed does
            loop {
                let sx = (m.a * m.a + m.b * m.b).sqrt();
                let sy = (m.c * m.c + m.d * m.d).sqrt();
                let minify = 1.0 / sx.min(sy).max(1e-6);
                if minify >= 2.0 && cw >= 4 && ch >= 4 {
                    let (nw, nh) = ((cw / 2).max(1), (ch / 2).max(1));
                    let next = pool.take(ctx, nw as u32, nh as u32);
                    downsample(ctx, &tex, &next);
                    done.push((cw as u32, ch as u32, std::mem::replace(&mut tex, next)));
                    cw = nw;
                    ch = nh;
                    m = m.then_apply(&Affine::scale(2.0, 2.0));
                } else {
                    break;
                }
            }
        }
        let bounds = if solid {
            Some([0.0, 0.0, width as f32, height as f32])
        } else {
            let b = m.bounds(&Rect::new(0.0, 0.0, cw as f64, ch as f64));
            let x0 = (b.x.floor().max(0.0) as usize).min(width);
            let y0 = (b.y.floor().max(0.0) as usize).min(height);
            let x1 = (b.right().ceil().max(0.0) as usize).min(width);
            let y1 = (b.bottom().ceil().max(0.0) as usize).min(height);
            (x0 < x1 && y0 < y1).then_some([x0 as f32, y0 as f32, x1 as f32, y1 as f32])
        };
        if let (Some(bounds), Some(inv)) = (bounds, m.inverse()) {
            let block = params(&inv, (cw as u32, ch as u32), l.opacity as f32, blend_number(l.blend), solid, bounds);
            composite(ctx, uniform, &canvas, &tex, &other, &block);
            std::mem::swap(&mut canvas, &mut other);
        }
        pool.give(cw as u32, ch as u32, tex);
        for (w, h, t) in done {
            pool.give(w, h, t);
        }
    }

    let image = read_back(ctx, pool, &canvas, width, height);
    pool.give(w32, h32, canvas);
    pool.give(w32, h32, other);
    let validation = pollster::block_on(ctx.device.pop_error_scope());
    let memory = pollster::block_on(ctx.device.pop_error_scope());
    if let Some(e) = validation {
        return Err(format!("GPU validation error: {e}"));
    }
    if let Some(e) = memory {
        return Err(format!("GPU out of memory: {e}"));
    }
    if ctx.is_lost() {
        return Err("the GPU device was lost".into());
    }
    image
}

/// Copy the canvas into the read-back buffer and turn it into an `Image` (rows in the buffer are padded to 256 bytes).
fn read_back(ctx: &GpuContext, pool: &mut TexturePool, canvas: &wgpu::Texture, width: usize, height: usize) -> Result<Image, String> {
    let row = width * 16;
    let padded = row.div_ceil(256) * 256;
    let size = (padded * height) as u64;
    let buffer = pool.readback(ctx, size);
    let mut enc = ctx.device.create_command_encoder(&wgpu::CommandEncoderDescriptor { label: Some("readback") });
    enc.copy_texture_to_buffer(
        wgpu::TexelCopyTextureInfo { texture: canvas, mip_level: 0, origin: wgpu::Origin3d::ZERO, aspect: wgpu::TextureAspect::All },
        wgpu::TexelCopyBufferInfo { buffer, layout: wgpu::TexelCopyBufferLayout { offset: 0, bytes_per_row: Some(padded as u32), rows_per_image: Some(height as u32) } },
        wgpu::Extent3d { width: width as u32, height: height as u32, depth_or_array_layers: 1 },
    );
    ctx.queue.submit(Some(enc.finish()));
    let slice = buffer.slice(0..size);
    let (tx, rx) = std::sync::mpsc::channel();
    slice.map_async(wgpu::MapMode::Read, move |r| {
        let _ = tx.send(r);
    });
    let _ = ctx.device.poll(wgpu::Maintain::Wait);
    match rx.recv_timeout(std::time::Duration::from_secs(20)) {
        Ok(Ok(())) => {}
        Ok(Err(e)) => return Err(format!("reading the GPU picture back failed: {e}")),
        Err(_) => return Err("reading the GPU picture back timed out".into()),
    }
    let mut px = vec![0f32; width * height * 4];
    {
        let data = slice.get_mapped_range();
        for y in 0..height {
            let src = &data[y * padded..y * padded + row];
            let dst = &mut px[y * width * 4..(y + 1) * width * 4];
            for (d, c) in dst.iter_mut().zip(src.chunks_exact(4)) {
                *d = f32::from_ne_bytes([c[0], c[1], c[2], c[3]]);
            }
        }
    }
    buffer.unmap();
    Ok(Image { w: width, h: height, px })
}
