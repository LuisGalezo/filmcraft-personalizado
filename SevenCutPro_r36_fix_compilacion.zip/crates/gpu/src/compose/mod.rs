//! The GPU compositor (stage 2a). It is a `FrameRenderer` the exporter asks for when GPU rendering is on: it plans the frame with the engine's own
//! `plan_frame`, and when the plan is only layers it can draw (no effects, no colour-managed input, no Dissolve) composes them on the GPU
//! (`exec`); every other plan it hands to the engine's CPU plan executor, which gives exactly the CPU renderer's picture. So it never changes
//! what an export looks like beyond the tolerance of `validate`, and it never refuses a frame.
//!
//! What the GPU really draws today: layer pictures through their matrix (position, scale, rotation) with the CPU renderer's bilinear
//! resampling and mip halving, opacity, layer order, and 26 of the 27 blend modes. Still on the CPU: decoding the video to linear float
//! (the same function the CPU renderer uses), effects, filters and colour correction, masks, chroma key, transitions, Dissolve, text
//! rasterising, and the conversion to 8 bits for the encoder.

mod context;
mod exec;
mod pool;
mod shaders;
mod stats;
mod validate;

pub use context::{context_status, reset, set_system_ram_mb, ContextStatus};
pub use stats::{enabled, reset_stats, set_enabled, stats, ComposeStats};
pub use validate::{validate, Validation};

use context::GpuContext;
use filmcraft_export::FrameRenderer;
use filmcraft_project::{ItemId, Project};
use filmcraft_render::plan::{execute_cpu, plan_frame, FramePlan, PlanLayer, PlanStep};
use filmcraft_render::{Image, RenderOptions, SourceProvider};
use filmcraft_time::Tick;
use pool::TexturePool;
use std::sync::atomic::{AtomicUsize, Ordering};
use std::sync::{Arc, Once};

/// Compositors alive now (the exporter asks for 2 to 4; the memory budget decides how many get a GPU one).
static LIVE: AtomicUsize = AtomicUsize::new(0);

/// Hand the compositor to the exporter's GPU path. Nothing is created until an export with GPU rendering asks for a renderer, and while
/// [`set_enabled`] is off every such request is declined (the CPU renders).
pub fn register() {
    static ONCE: Once = Once::new();
    ONCE.call_once(|| filmcraft_export::register_frame_renderer(factory));
}

fn factory() -> Option<Box<dyn FrameRenderer>> {
    if !enabled() {
        return None;
    }
    let ctx = context::get().ok()?;
    // at 1080p with f32 targets one compositor holds ~110 MB: as many as the budget allows, at most 2
    let one = crate::budget::compositor_bytes(1920, 1080, true).max(1);
    let allowed = ((ctx.budget_bytes / one) as usize).clamp(1, 2);
    if LIVE.fetch_add(1, Ordering::SeqCst) >= allowed {
        LIVE.fetch_sub(1, Ordering::SeqCst);
        return None;
    }
    Some(Box::new(GpuRenderer::new(ctx)))
}

/// What a compositor needs besides the shared device: its textures and the one uniform buffer.
pub(crate) struct Rig {
    pub ctx: Arc<GpuContext>,
    pub pool: TexturePool,
    pub uniform: wgpu::Buffer,
}

impl Rig {
    pub fn new(ctx: Arc<GpuContext>) -> Self {
        let uniform = ctx.device.create_buffer(&wgpu::BufferDescriptor { label: Some("filmcraft-compositor-params"), size: 64, usage: wgpu::BufferUsages::UNIFORM | wgpu::BufferUsages::COPY_DST, mapped_at_creation: false });
        Rig { ctx, pool: TexturePool::default(), uniform }
    }

    pub fn draw(&mut self, width: usize, height: usize, layers: &[PlanLayer]) -> Result<Image, String> {
        exec::draw_layers(&self.ctx, &mut self.pool, &self.uniform, width, height, layers)
    }
}

pub(crate) struct GpuRenderer {
    rig: Rig,
    errors_in_a_row: u32,
}

impl GpuRenderer {
    fn new(ctx: Arc<GpuContext>) -> Self {
        GpuRenderer { rig: Rig::new(ctx), errors_in_a_row: 0 }
    }
}

impl Drop for GpuRenderer {
    fn drop(&mut self) {
        LIVE.fetch_sub(1, Ordering::SeqCst);
    }
}

fn cpu(plan: FramePlan) -> Image {
    match plan {
        FramePlan::Image(img) => img,
        other => execute_cpu(&other),
    }
}

/// The plan's layers if it is nothing but layer runs (steps of a `Composite` composite onto one canvas in order: one list gives the same picture).
fn flat_layers(plan: &FramePlan) -> Option<(usize, usize, Vec<PlanLayer>)> {
    match plan {
        FramePlan::Layers { width, height, layers } => Some((*width, *height, layers.clone())),
        FramePlan::Composite { width, height, steps } => {
            let mut all = Vec::new();
            for s in steps {
                match s {
                    PlanStep::Layers(l) => all.extend(l.iter().cloned()),
                    PlanStep::Transition { .. } => return None,
                }
            }
            Some((*width, *height, all))
        }
        FramePlan::Image(_) => None,
    }
}

impl FrameRenderer for GpuRenderer {
    fn render(&mut self, project: &Project, seq: ItemId, t: Tick, opts: RenderOptions, sources: &dyn SourceProvider) -> Option<Image> {
        if !enabled() || self.rig.ctx.is_lost() {
            return None;
        }
        let plan = plan_frame(project, seq, t, opts, sources);
        if let Some((w, h, layers)) = flat_layers(&plan) {
            if exec::supported(&layers) {
                if exec::estimate_bytes(w, h, &layers) + self.rig.pool.held_bytes() > self.rig.ctx.budget_bytes {
                    // too big for the memory budget (8K, or a 4K frame with huge layers): this frame goes to the CPU
                    self.rig.pool.clear();
                    stats::note_over_budget();
                    return Some(cpu(plan));
                }
                match self.rig.draw(w, h, &layers) {
                    Ok(img) => {
                        self.errors_in_a_row = 0;
                        stats::note_gpu_frame(layers.len());
                        self.rig.pool.trim(Some((w as u32, h as u32)));
                        return Some(img);
                    }
                    Err(e) => {
                        stats::note_fallback(&e);
                        self.errors_in_a_row += 1;
                        self.rig.pool.clear();
                        // a device that keeps failing (or is gone) is switched off for the rest of the run
                        if self.errors_in_a_row >= 3 || self.rig.ctx.is_lost() {
                            context::disable(&e);
                        }
                        return Some(cpu(plan));
                    }
                }
            }
        }
        stats::note_cpu_plan();
        Some(cpu(plan))
    }
}

#[cfg(test)]
mod tests;
