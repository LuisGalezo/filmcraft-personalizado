//! The WGSL of the compositor. Every function is a port of the CPU renderer's own code, so that the two agree:
//! `composite` = `filmcraft_render::blend::composite_at`, `sample_bilinear` = `Image::sample_bilinear` (transparent outside the picture),
//! the colour maths = `blend_rgb`, `sep`, `lum`, `set_lum`, `set_sat`, `clip_color`. Pixels are premultiplied linear-light f32.
//! Blend mode numbers are the positions in `Blend::ALL`. Dissolve (1) is not here: its per-pixel hash needs 64-bit integers, so plans with a
//! Dissolve layer stay on the CPU.

/// One layer over the canvas: reads the canvas so far (`dst`) and the layer's picture (`src`), writes the new canvas.
pub(crate) const COMPOSITE: &str = r#"
struct Params {
    // the INVERSE of the layer's matrix (destination pixel -> source pixel): a, b, c, d
    inv_abcd: vec4<f32>,
    // inverse e, inverse f, source width, source height
    inv_ef_size: vec4<f32>,
    // opacity, blend mode number, 1 = fill the whole canvas with the source's only pixel, unused
    opacity_mode_solid: vec4<f32>,
    // the pixel rectangle the CPU renderer visits for this layer: x0, y0, x1, y1
    bounds: vec4<f32>,
};

@group(0) @binding(0) var<uniform> p: Params;
@group(0) @binding(1) var dst_tex: texture_2d<f32>;
@group(0) @binding(2) var src_tex: texture_2d<f32>;

@vertex
fn vs(@builtin(vertex_index) i: u32) -> @builtin(position) vec4<f32> {
    // one triangle that covers the whole target
    let x = f32(i32(i) / 2) * 4.0 - 1.0;
    let y = f32(i32(i) % 2) * 4.0 - 1.0;
    return vec4<f32>(x, y, 0.0, 1.0);
}

fn srgb_to_linear(v: f32) -> f32 {
    let c = max(v, 0.0);
    if (c <= 0.04045) { return c / 12.92; }
    return pow((c + 0.055) / 1.055, 2.4);
}

fn linear_to_srgb(v: f32) -> f32 {
    let c = max(v, 0.0);
    if (c <= 0.0031308) { return c * 12.92; }
    return 1.055 * pow(c, 1.0 / 2.4) - 0.055;
}

fn texel(x: i32, y: i32) -> vec4<f32> {
    let dims = vec2<i32>(textureDimensions(src_tex));
    if (x < 0 || y < 0 || x >= dims.x || y >= dims.y) { return vec4<f32>(0.0); }
    return textureLoad(src_tex, vec2<i32>(x, y), 0);
}

fn sample_bilinear(u: f32, v: f32) -> vec4<f32> {
    let fx = u - 0.5;
    let fy = v - 0.5;
    let x0 = floor(fx);
    let y0 = floor(fy);
    let tx = fx - x0;
    let ty = fy - y0;
    let xi = i32(x0);
    let yi = i32(y0);
    let a = texel(xi, yi);
    let b = texel(xi + 1, yi);
    let c = texel(xi, yi + 1);
    let d = texel(xi + 1, yi + 1);
    let top = a + (b - a) * tx;
    let bot = c + (d - c) * tx;
    return top + (bot - top) * ty;
}

fn f_burn(b: f32, s: f32) -> f32 {
    if (b >= 1.0) { return 1.0; }
    if (s <= 0.0) { return 0.0; }
    return 1.0 - min((1.0 - b) / s, 1.0);
}

fn f_dodge(b: f32, s: f32) -> f32 {
    if (b <= 0.0) { return 0.0; }
    if (s >= 1.0) { return 1.0; }
    return min(b / (1.0 - s), 1.0);
}

fn f_screen(b: f32, s: f32) -> f32 {
    return b + s - b * s;
}

fn f_hard_light(b: f32, s: f32) -> f32 {
    if (s <= 0.5) { return b * 2.0 * s; }
    return f_screen(b, 2.0 * s - 1.0);
}

fn f_vivid(b: f32, s: f32) -> f32 {
    if (s <= 0.5) { return f_burn(b, 2.0 * s); }
    return f_dodge(b, 2.0 * s - 1.0);
}

// separable modes on one channel of display-encoded colour
fn sep(mode: i32, b: f32, s: f32) -> f32 {
    switch (mode) {
        case 2: { return min(b, s); }
        case 3: { return b * s; }
        case 4: { return f_burn(b, s); }
        case 5: { return max(b + s - 1.0, 0.0); }
        case 7: { return max(b, s); }
        case 8: { return f_screen(b, s); }
        case 9: { return f_dodge(b, s); }
        case 10: { return min(b + s, 1.0); }
        case 12: { return f_hard_light(s, b); }
        case 13: {
            if (s <= 0.5) { return b - (1.0 - 2.0 * s) * b * (1.0 - b); }
            var d: f32;
            if (b <= 0.25) { d = ((16.0 * b - 12.0) * b + 4.0) * b; } else { d = sqrt(b); }
            return b + (2.0 * s - 1.0) * (d - b);
        }
        case 14: { return f_hard_light(b, s); }
        case 15: { return f_vivid(b, s); }
        case 16: { return clamp(b + 2.0 * s - 1.0, 0.0, 1.0); }
        case 17: {
            if (s <= 0.5) { return min(b, 2.0 * s); }
            return max(b, 2.0 * s - 1.0);
        }
        case 18: {
            if (f_vivid(b, s) >= 0.5) { return 1.0; }
            return 0.0;
        }
        case 19: { return abs(b - s); }
        case 20: { return b + s - 2.0 * b * s; }
        case 21: { return max(b - s, 0.0); }
        case 22: {
            if (s <= 0.0) { return 1.0; }
            return min(b / s, 1.0);
        }
        default: { return s; }
    }
}

fn lum(c: vec3<f32>) -> f32 {
    return 0.3 * c.x + 0.59 * c.y + 0.11 * c.z;
}

fn clip_color(c: vec3<f32>) -> vec3<f32> {
    let l = lum(c);
    let n = min(c.x, min(c.y, c.z));
    let x = max(c.x, max(c.y, c.z));
    var o = c;
    if (n < 0.0) { o = vec3<f32>(l) + (o - vec3<f32>(l)) * l / max(l - n, 1e-6); }
    if (x > 1.0) { o = vec3<f32>(l) + (o - vec3<f32>(l)) * (1.0 - l) / max(x - l, 1e-6); }
    return o;
}

fn set_lum(c: vec3<f32>, l: f32) -> vec3<f32> {
    let d = l - lum(c);
    return clip_color(c + vec3<f32>(d));
}

fn sat(c: vec3<f32>) -> f32 {
    return max(c.x, max(c.y, c.z)) - min(c.x, min(c.y, c.z));
}

fn set_sat(c: vec3<f32>, s: f32) -> vec3<f32> {
    let mx = max(c.x, max(c.y, c.z));
    let mn = min(c.x, min(c.y, c.z));
    if (mx - mn <= 1e-6) { return vec3<f32>(0.0); }
    return (c - vec3<f32>(mn)) * s / (mx - mn);
}

fn blend_rgb(mode: i32, b: vec3<f32>, s: vec3<f32>) -> vec3<f32> {
    switch (mode) {
        case 23: { return set_lum(set_sat(s, sat(b)), lum(b)); }
        case 24: { return set_lum(set_sat(b, sat(s)), lum(b)); }
        case 25: { return set_lum(s, lum(b)); }
        case 26: { return set_lum(b, lum(s)); }
        case 6: {
            if (lum(s) < lum(b)) { return s; }
            return b;
        }
        case 11: {
            if (lum(s) > lum(b)) { return s; }
            return b;
        }
        default: { return vec3<f32>(sep(mode, b.x, s.x), sep(mode, b.y, s.y), sep(mode, b.z, s.z)); }
    }
}

@fragment
fn fs(@builtin(position) pos: vec4<f32>) -> @location(0) vec4<f32> {
    let ix = i32(pos.x);
    let iy = i32(pos.y);
    let d = textureLoad(dst_tex, vec2<i32>(ix, iy), 0);
    // the CPU renderer only visits the pixel rectangle the layer covers
    let fx = f32(ix);
    let fy = f32(iy);
    if (fx < p.bounds.x || fy < p.bounds.y || fx >= p.bounds.z || fy >= p.bounds.w) {
        return d;
    }
    var s: vec4<f32>;
    if (p.opacity_mode_solid.z > 0.5) {
        s = textureLoad(src_tex, vec2<i32>(0, 0), 0);
    } else {
        // pos is the pixel centre (x + 0.5), exactly what the CPU renderer maps
        let u = p.inv_abcd.x * pos.x + p.inv_abcd.z * pos.y + p.inv_ef_size.x;
        let v = p.inv_abcd.y * pos.x + p.inv_abcd.w * pos.y + p.inv_ef_size.y;
        if (u < -1.0 || v < -1.0 || u > p.inv_ef_size.z + 1.0 || v > p.inv_ef_size.w + 1.0) {
            return d;
        }
        s = sample_bilinear(u, v);
    }
    let sp = s * p.opacity_mode_solid.x;
    let sa = sp.w;
    if (sa <= 0.0) { return d; }
    let mode = i32(p.opacity_mode_solid.y + 0.5);
    let da = d.w;
    if (mode == 0 || da <= 0.0) {
        return sp + d * (1.0 - sp.w);
    }
    let cs = vec3<f32>(linear_to_srgb(sp.x / sa), linear_to_srgb(sp.y / sa), linear_to_srgb(sp.z / sa));
    let cb = vec3<f32>(linear_to_srgb(d.x / da), linear_to_srgb(d.y / da), linear_to_srgb(d.z / da));
    let bl = blend_rgb(mode, cb, cs);
    let mixed = vec3<f32>(srgb_to_linear(clamp(bl.x, 0.0, 1.0)), srgb_to_linear(clamp(bl.y, 0.0, 1.0)), srgb_to_linear(clamp(bl.z, 0.0, 1.0)));
    let rgb = sp.xyz * (1.0 - da) + d.xyz * (1.0 - sa) + vec3<f32>(sa * da) * mixed;
    return vec4<f32>(rgb, sa + da - sa * da);
}
"#;

/// Half-size box filter, exactly `Image::downsample2`: each output pixel is the mean of four source pixels, the ones past the edge clamped.
pub(crate) const DOWNSAMPLE: &str = r#"
@group(0) @binding(0) var src_tex: texture_2d<f32>;

@vertex
fn vs(@builtin(vertex_index) i: u32) -> @builtin(position) vec4<f32> {
    let x = f32(i32(i) / 2) * 4.0 - 1.0;
    let y = f32(i32(i) % 2) * 4.0 - 1.0;
    return vec4<f32>(x, y, 0.0, 1.0);
}

fn get_clamped(x: i32, y: i32) -> vec4<f32> {
    let dims = vec2<i32>(textureDimensions(src_tex));
    return textureLoad(src_tex, vec2<i32>(clamp(x, 0, dims.x - 1), clamp(y, 0, dims.y - 1)), 0);
}

@fragment
fn fs(@builtin(position) pos: vec4<f32>) -> @location(0) vec4<f32> {
    let x = i32(pos.x);
    let y = i32(pos.y);
    let a = get_clamped(2 * x, 2 * y);
    let b = get_clamped(2 * x + 1, 2 * y);
    let c = get_clamped(2 * x, 2 * y + 1);
    let d = get_clamped(2 * x + 1, 2 * y + 1);
    return (a + b + c + d) * 0.25;
}
"#;
