//! GPU textures and the read-back buffer are kept between frames, not created and destroyed for every frame. Textures are pooled by size:
//! the two canvases and the layers' pictures of the next frame (usually the same sizes) come out of the pool.

use super::context::{GpuContext, TARGET_FORMAT};
use std::collections::HashMap;

/// Most textures of one size kept for reuse.
const PER_SIZE: usize = 4;

#[derive(Default)]
pub(crate) struct TexturePool {
    free: HashMap<(u32, u32), Vec<wgpu::Texture>>,
    readback: Option<(u64, wgpu::Buffer)>,
}

pub(crate) fn texture_bytes(w: u32, h: u32) -> u64 {
    u64::from(w) * u64::from(h) * 16
}

impl TexturePool {
    /// A texture of this size that can be drawn into, sampled, copied from and written to.
    pub fn take(&mut self, ctx: &GpuContext, w: u32, h: u32) -> wgpu::Texture {
        if let Some(t) = self.free.get_mut(&(w, h)).and_then(Vec::pop) {
            return t;
        }
        ctx.device.create_texture(&wgpu::TextureDescriptor {
            label: Some("filmcraft-compositor"),
            size: wgpu::Extent3d { width: w, height: h, depth_or_array_layers: 1 },
            mip_level_count: 1,
            sample_count: 1,
            dimension: wgpu::TextureDimension::D2,
            format: TARGET_FORMAT,
            usage: wgpu::TextureUsages::RENDER_ATTACHMENT | wgpu::TextureUsages::TEXTURE_BINDING | wgpu::TextureUsages::COPY_SRC | wgpu::TextureUsages::COPY_DST,
            view_formats: &[],
        })
    }

    pub fn give(&mut self, w: u32, h: u32, t: wgpu::Texture) {
        let list = self.free.entry((w, h)).or_default();
        if list.len() < PER_SIZE {
            list.push(t);
        } else {
            t.destroy();
        }
    }

    /// The buffer frames are read back into (at least `size` bytes, reused while it is big enough).
    pub fn readback(&mut self, ctx: &GpuContext, size: u64) -> &wgpu::Buffer {
        if self.readback.as_ref().is_none_or(|(have, _)| *have < size) {
            if let Some((_, old)) = self.readback.take() {
                old.destroy();
            }
            let buffer = ctx.device.create_buffer(&wgpu::BufferDescriptor {
                label: Some("filmcraft-compositor-readback"),
                size,
                usage: wgpu::BufferUsages::MAP_READ | wgpu::BufferUsages::COPY_DST,
                mapped_at_creation: false,
            });
            self.readback = Some((size, buffer));
        }
        match &self.readback {
            Some((_, b)) => b,
            None => unreachable!("the buffer was created above"),
        }
    }

    /// Bytes of GPU memory held by textures waiting for reuse.
    pub fn held_bytes(&self) -> u64 {
        self.free.iter().map(|((w, h), v)| texture_bytes(*w, *h) * v.len() as u64).sum::<u64>() + self.readback.as_ref().map_or(0, |(s, _)| *s)
    }

    /// Give back everything not needed for frames of `keep` size: called when the project's frame size changes or memory is tight.
    pub fn trim(&mut self, keep: Option<(u32, u32)>) {
        let sizes: Vec<_> = self.free.keys().copied().filter(|k| Some(*k) != keep).collect();
        for k in sizes {
            for t in self.free.remove(&k).unwrap_or_default() {
                t.destroy();
            }
        }
    }

    pub fn clear(&mut self) {
        self.trim(None);
        if let Some((_, b)) = self.readback.take() {
            b.destroy();
        }
    }
}

impl Drop for TexturePool {
    fn drop(&mut self) {
        self.clear();
    }
}
