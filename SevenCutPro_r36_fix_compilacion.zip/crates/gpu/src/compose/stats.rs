//! What the compositor really did, counted where it happens (the engine's own `GPU_FRAMES` counts every frame this renderer hands back,
//! including the ones it composited on the CPU, so the app's status uses these numbers instead).

use std::sync::atomic::{AtomicBool, AtomicU64, Ordering};
use std::sync::Mutex;

static GPU_FRAMES: AtomicU64 = AtomicU64::new(0);
static GPU_LAYERS: AtomicU64 = AtomicU64::new(0);
static CPU_PLANS: AtomicU64 = AtomicU64::new(0);
static FALLBACKS: AtomicU64 = AtomicU64::new(0);
static OVER_BUDGET: AtomicU64 = AtomicU64::new(0);
static ENABLED: AtomicBool = AtomicBool::new(false);
static LAST_ERROR: Mutex<String> = Mutex::new(String::new());

#[derive(Clone, Debug, Default, PartialEq, Eq)]
pub struct ComposeStats {
    /// Frames whose layers were composed on the GPU.
    pub gpu_frames: u64,
    /// Layers drawn on the GPU.
    pub gpu_layers: u64,
    /// Frames composed on the CPU by the plan executor because the GPU cannot draw them yet (effects, colour input, Dissolve, transitions).
    pub cpu_plans: u64,
    /// Frames the GPU failed on (error, lost device) and the CPU composed instead.
    pub fallbacks: u64,
    /// Frames that were too big for the memory budget and went to the CPU.
    pub over_budget: u64,
    pub last_error: String,
}

pub fn stats() -> ComposeStats {
    ComposeStats {
        gpu_frames: GPU_FRAMES.load(Ordering::Relaxed),
        gpu_layers: GPU_LAYERS.load(Ordering::Relaxed),
        cpu_plans: CPU_PLANS.load(Ordering::Relaxed),
        fallbacks: FALLBACKS.load(Ordering::Relaxed),
        over_budget: OVER_BUDGET.load(Ordering::Relaxed),
        last_error: LAST_ERROR.lock().map(|s| s.clone()).unwrap_or_default(),
    }
}

pub fn reset_stats() {
    for c in [&GPU_FRAMES, &GPU_LAYERS, &CPU_PLANS, &FALLBACKS, &OVER_BUDGET] {
        c.store(0, Ordering::Relaxed);
    }
    if let Ok(mut s) = LAST_ERROR.lock() {
        s.clear();
    }
}

pub(crate) fn note_gpu_frame(layers: usize) {
    GPU_FRAMES.fetch_add(1, Ordering::Relaxed);
    GPU_LAYERS.fetch_add(layers as u64, Ordering::Relaxed);
}

pub(crate) fn note_cpu_plan() {
    CPU_PLANS.fetch_add(1, Ordering::Relaxed);
}

pub(crate) fn note_over_budget() {
    OVER_BUDGET.fetch_add(1, Ordering::Relaxed);
}

pub(crate) fn note_fallback(why: &str) {
    FALLBACKS.fetch_add(1, Ordering::Relaxed);
    if let Ok(mut s) = LAST_ERROR.lock() {
        *s = why.to_string();
    }
}

/// Whether the user switched GPU compositing on (off by default). While off, no renderer is handed to the exporter.
pub fn set_enabled(on: bool) {
    ENABLED.store(on, Ordering::Relaxed);
}

pub fn enabled() -> bool {
    ENABLED.load(Ordering::Relaxed)
}
