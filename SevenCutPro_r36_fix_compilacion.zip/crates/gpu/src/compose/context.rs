//! The one GPU device the compositor uses. Created on first use, shared by every renderer the exporter asks for (one driver context, one set of
//! pipelines), checked with a parity test against the CPU before it is trusted, and switched off for the rest of the process if the device is
//! lost or misbehaves: from then on every frame goes to the CPU.

use super::shaders;
use std::sync::atomic::{AtomicBool, AtomicU64, Ordering};
use std::sync::{Arc, Mutex, PoisonError};

/// Canvas, layer pictures and mips: premultiplied linear f32, like the CPU renderer's `Image`, so GPU and CPU compute in the same precision.
pub(crate) const TARGET_FORMAT: wgpu::TextureFormat = wgpu::TextureFormat::Rgba32Float;

struct Shared {
    lost: AtomicBool,
    errors: Mutex<Vec<String>>,
}

pub(crate) struct GpuContext {
    pub device: wgpu::Device,
    pub queue: wgpu::Queue,
    pub adapter_name: String,
    pub backend: String,
    pub max_texture: u32,
    /// What all compositors together may hold (see `budget::recommend`).
    pub budget_bytes: u64,
    pub composite: wgpu::RenderPipeline,
    pub composite_layout: wgpu::BindGroupLayout,
    pub downsample: wgpu::RenderPipeline,
    pub downsample_layout: wgpu::BindGroupLayout,
    shared: Arc<Shared>,
}

impl GpuContext {
    pub fn is_lost(&self) -> bool {
        self.shared.lost.load(Ordering::Relaxed)
    }

    /// Errors wgpu reported outside any error scope since the last call.
    pub fn take_errors(&self) -> Vec<String> {
        std::mem::take(&mut *self.shared.errors.lock().unwrap_or_else(PoisonError::into_inner))
    }
}

enum State {
    Unset,
    Ready(Arc<GpuContext>),
    Failed(String),
}

static STATE: Mutex<State> = Mutex::new(State::Unset);
static RAM_MB: AtomicU64 = AtomicU64::new(0);

/// The phone's RAM, for the memory budget (call before the first use; 0 = unknown).
pub fn set_system_ram_mb(mb: u64) {
    RAM_MB.store(mb, Ordering::Relaxed);
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub enum ContextStatus {
    /// Nothing has asked for the GPU yet.
    NotStarted,
    Ready { adapter: String, backend: String },
    /// The GPU compositor is off for this run, and why.
    Failed(String),
}

pub fn context_status() -> ContextStatus {
    match &*STATE.lock().unwrap_or_else(PoisonError::into_inner) {
        State::Unset => ContextStatus::NotStarted,
        State::Ready(c) => ContextStatus::Ready { adapter: c.adapter_name.clone(), backend: c.backend.clone() },
        State::Failed(why) => ContextStatus::Failed(why.clone()),
    }
}

/// The shared context, created (and validated) on first call. `Err` = the GPU compositor is not available this run.
pub(crate) fn get() -> Result<Arc<GpuContext>, String> {
    let mut state = STATE.lock().unwrap_or_else(PoisonError::into_inner);
    if matches!(&*state, State::Ready(c) if c.is_lost()) {
        *state = State::Failed("the GPU device was lost".into());
    }
    match &*state {
        State::Ready(c) => return Ok(c.clone()),
        State::Failed(why) => return Err(why.clone()),
        State::Unset => {}
    }
    let made = std::panic::catch_unwind(create).unwrap_or_else(|_| Err("creating the GPU context panicked".into()));
    let checked = made.and_then(|c| {
        let c = Arc::new(c);
        super::validate::canary(&c).map(|()| c)
    });
    match checked {
        Ok(c) => {
            *state = State::Ready(c.clone());
            Ok(c)
        }
        Err(why) => {
            log::warn!("GPU compositor unavailable: {why}");
            *state = State::Failed(why.clone());
            Err(why)
        }
    }
}

/// Switch the compositor off for the rest of the run (a device that misbehaves is not asked again).
pub(crate) fn disable(why: &str) {
    log::warn!("GPU compositor switched off: {why}");
    *STATE.lock().unwrap_or_else(PoisonError::into_inner) = State::Failed(why.to_string());
}

/// Forget a failure and the device, to try again (the screen's "validate" button does this).
pub fn reset() {
    *STATE.lock().unwrap_or_else(PoisonError::into_inner) = State::Unset;
}

fn create() -> Result<GpuContext, String> {
    let instance = wgpu::Instance::default();
    let need = wgpu::TextureUsages::RENDER_ATTACHMENT | wgpu::TextureUsages::TEXTURE_BINDING | wgpu::TextureUsages::COPY_SRC | wgpu::TextureUsages::COPY_DST;
    let mut found = None;
    'search: for backends in [wgpu::Backends::VULKAN, wgpu::Backends::GL] {
        for adapter in instance.enumerate_adapters(backends) {
            let info = adapter.get_info();
            // a software rasteriser is slower than the CPU renderer
            if info.device_type == wgpu::DeviceType::Cpu {
                continue;
            }
            if !adapter.get_texture_format_features(TARGET_FORMAT).allowed_usages.contains(need) {
                continue;
            }
            found = Some((adapter, info));
            break 'search;
        }
    }
    let (adapter, info) = found.ok_or_else(|| "no GPU adapter that can draw into and read Rgba32Float".to_string())?;
    let limits = adapter.limits();
    let required_limits = wgpu::Limits::downlevel_defaults().using_resolution(limits.clone());
    let (device, queue) = pollster::block_on(adapter.request_device(
        &wgpu::DeviceDescriptor { label: Some("filmcraft-compositor"), required_features: wgpu::Features::empty(), required_limits, memory_hints: wgpu::MemoryHints::default() },
        None,
    ))
    .map_err(|e| format!("could not create the GPU device: {e}"))?;

    let shared = Arc::new(Shared { lost: AtomicBool::new(false), errors: Mutex::new(Vec::new()) });
    {
        let s = shared.clone();
        device.on_uncaptured_error(Box::new(move |e| {
            if let Ok(mut v) = s.errors.lock() {
                v.push(e.to_string());
            }
        }));
        let s = shared.clone();
        device.set_device_lost_callback(move |reason, message| {
            s.lost.store(true, Ordering::Relaxed);
            if let Ok(mut v) = s.errors.lock() {
                v.push(format!("device lost ({reason:?}): {message}"));
            }
        });
    }

    device.push_error_scope(wgpu::ErrorFilter::Validation);
    let (composite, composite_layout) = pipeline(&device, "composite", shaders::COMPOSITE, true);
    let (downsample, downsample_layout) = pipeline(&device, "downsample", shaders::DOWNSAMPLE, false);
    if let Some(e) = pollster::block_on(device.pop_error_scope()) {
        return Err(format!("the compositor's shaders were rejected: {e}"));
    }

    let ram = RAM_MB.load(Ordering::Relaxed);
    let budget = crate::budget::recommend((ram > 0).then_some(ram), "integrated_gpu", limits.max_texture_dimension_2d);
    Ok(GpuContext {
        device,
        queue,
        adapter_name: info.name.clone(),
        backend: format!("{:?}", info.backend).to_lowercase(),
        max_texture: limits.max_texture_dimension_2d,
        budget_bytes: budget.budget_bytes,
        composite,
        composite_layout,
        downsample,
        downsample_layout,
        shared,
    })
}

fn texture_entry(binding: u32) -> wgpu::BindGroupLayoutEntry {
    wgpu::BindGroupLayoutEntry {
        binding,
        visibility: wgpu::ShaderStages::FRAGMENT,
        // read with textureLoad only: Rgba32Float cannot be filtered, and the shader does its own bilinear (like the CPU renderer)
        ty: wgpu::BindingType::Texture { sample_type: wgpu::TextureSampleType::Float { filterable: false }, view_dimension: wgpu::TextureViewDimension::D2, multisampled: false },
        count: None,
    }
}

/// A full-screen-triangle pipeline writing `TARGET_FORMAT`; `with_params` adds the uniform block and the destination texture.
fn pipeline(device: &wgpu::Device, label: &str, wgsl: &str, with_params: bool) -> (wgpu::RenderPipeline, wgpu::BindGroupLayout) {
    let mut entries = Vec::new();
    if with_params {
        entries.push(wgpu::BindGroupLayoutEntry {
            binding: 0,
            visibility: wgpu::ShaderStages::FRAGMENT,
            ty: wgpu::BindingType::Buffer { ty: wgpu::BufferBindingType::Uniform, has_dynamic_offset: false, min_binding_size: None },
            count: None,
        });
        entries.push(texture_entry(1));
        entries.push(texture_entry(2));
    } else {
        entries.push(texture_entry(0));
    }
    let layout = device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor { label: Some(label), entries: &entries });
    let pipeline_layout = device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor { label: Some(label), bind_group_layouts: &[&layout], push_constant_ranges: &[] });
    let module = device.create_shader_module(wgpu::ShaderModuleDescriptor { label: Some(label), source: wgpu::ShaderSource::Wgsl(std::borrow::Cow::Borrowed(wgsl)) });
    let pipeline = device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
        label: Some(label),
        layout: Some(&pipeline_layout),
        vertex: wgpu::VertexState { module: &module, entry_point: Some("vs"), compilation_options: wgpu::PipelineCompilationOptions::default(), buffers: &[] },
        fragment: Some(wgpu::FragmentState {
            module: &module,
            entry_point: Some("fs"),
            compilation_options: wgpu::PipelineCompilationOptions::default(),
            targets: &[Some(wgpu::ColorTargetState { format: TARGET_FORMAT, blend: None, write_mask: wgpu::ColorWrites::ALL })],
        }),
        primitive: wgpu::PrimitiveState::default(),
        depth_stencil: None,
        multisample: wgpu::MultisampleState::default(),
        multiview: None,
        cache: None,
    });
    (pipeline, layout)
}
