//! Parity tests: the GPU compositor against the engine's CPU plan executor. They need a GPU adapter (CI uses Vulkan in software through
//! lavapipe); on a machine without one they say so and pass without testing anything.

use super::validate::{canary, validate};
use super::*;
use filmcraft_render::blend::Blend;

fn gpu() -> Option<Arc<GpuContext>> {
    match context::get() {
        Ok(c) => Some(c),
        Err(why) => {
            eprintln!("no GPU compositor on this machine, test skipped: {why}");
            None
        }
    }
}

#[test]
fn only_what_the_gpu_can_draw_is_marked_supported() {
    use filmcraft_geom::Affine;
    use filmcraft_frame::VideoFrame;
    let f = Arc::new(VideoFrame::rgba_f32(1, 1, vec![0.1, 0.1, 0.1, 1.0]));
    let ok = PlanLayer::new(f.clone(), Affine::scale(2.0, 2.0), 1.0, Blend::Multiply);
    let dissolve = PlanLayer::new(f, Affine::scale(2.0, 2.0), 1.0, Blend::Dissolve);
    assert!(exec::supported(&[ok.clone()]));
    assert!(!exec::supported(&[ok, dissolve]), "Dissolve needs a 64-bit hash: it stays on the CPU");
}

#[test]
fn the_memory_estimate_grows_with_the_canvas_and_the_biggest_layer() {
    use filmcraft_geom::Affine;
    use filmcraft_frame::VideoFrame;
    let big = PlanLayer::new(Arc::new(VideoFrame::rgba_f32(100, 100, vec![0.0; 100 * 100 * 4])), Affine::scale(1.0, 1.0), 1.0, Blend::Normal);
    let a = exec::estimate_bytes(1920, 1080, &[big.clone()]);
    let b = exec::estimate_bytes(3840, 2160, &[big]);
    assert!(b > 3 * a / 2);
    assert!(a >= 3 * 1920 * 1080 * 16);
}

#[test]
fn the_canary_passes_on_a_working_gpu() {
    let Some(ctx) = gpu() else { return };
    canary(&ctx).unwrap();
}

#[test]
fn every_blend_mode_and_geometry_case_matches_the_cpu() {
    if gpu().is_none() {
        return;
    }
    let v = validate();
    assert!(v.ok, "{} (worst: {} at {:.4})", v.detail, v.worst, v.max_diff);
    assert!(v.cpu_ms > 0.0 && v.gpu_ms > 0.0, "the timing ran");
}

#[test]
fn a_disabled_compositor_hands_out_no_renderer() {
    set_enabled(false);
    assert!(factory().is_none());
}
