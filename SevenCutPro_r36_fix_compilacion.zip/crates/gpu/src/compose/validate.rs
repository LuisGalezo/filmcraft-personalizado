//! Does the GPU compositor give the CPU renderer's picture? Runs the same plans through both and compares them, then times both on a 1080p
//! multi-layer frame. The screen's "Validar compositor GPU" button calls [`validate`]; the context calls [`canary`] (a small version) before it
//! trusts a device.

use super::context::GpuContext;
use super::Rig;
use filmcraft_frame::VideoFrame;
use filmcraft_geom::Affine;
use filmcraft_render::blend::Blend;
use filmcraft_render::plan::{execute_cpu, FramePlan, PlanLayer};
use filmcraft_render::Image;
use std::sync::Arc;
use std::time::Instant;

/// How far the GPU may be from the CPU: a pixel counts as different above `PIXEL`, and at most `BAD_FRACTION` of them may differ (blend modes with a hard
/// threshold such as Hard Mix flip whole pixels on f32 rounding, so a maximum alone would be too strict), and the mean difference must stay under `MEAN`.
pub const PIXEL: f32 = 0.01;
pub const BAD_FRACTION: f64 = 0.002;
pub const MEAN: f64 = 0.001;

#[derive(Clone, Debug, PartialEq)]
pub struct Validation {
    /// GPU and CPU agree within the tolerance on every test.
    pub ok: bool,
    /// Largest per-channel difference seen, and the blend mode or test it came from.
    pub max_diff: f32,
    pub worst: String,
    /// Time for one 1080p frame of 4 layers, the CPU executor and the GPU (including upload and read-back), in ms; 0 when not measured.
    pub cpu_ms: f64,
    pub gpu_ms: f64,
    pub adapter: String,
    pub detail: String,
}

struct Diff {
    max: f32,
    mean: f64,
    bad: f64,
}

fn compare(a: &Image, b: &Image) -> Diff {
    let n = a.px.len().min(b.px.len()).max(1);
    let (mut max, mut sum, mut bad) = (0f32, 0f64, 0usize);
    for (x, y) in a.px.iter().zip(&b.px) {
        let d = (x - y).abs();
        let d = if d.is_nan() { 1.0 } else { d };
        max = max.max(d);
        sum += f64::from(d);
        if d > PIXEL {
            bad += 1;
        }
    }
    Diff { max, mean: sum / n as f64, bad: bad as f64 / n as f64 }
}

fn pass(d: &Diff) -> bool {
    d.bad <= BAD_FRACTION && d.mean <= MEAN
}

struct Lcg(u64);
impl Lcg {
    fn next(&mut self) -> f32 {
        self.0 = self.0.wrapping_mul(6364136223846793005).wrapping_add(1442695040888963407);
        ((self.0 >> 40) as f32) / ((1u64 << 24) as f32)
    }
}

/// A deterministic picture with soft alpha, as premultiplied linear float (what the CPU decode produces).
pub(crate) fn frame(w: u32, h: u32, seed: u64) -> Arc<VideoFrame> {
    let mut r = Lcg(seed);
    let mut px = Vec::with_capacity(w as usize * h as usize * 4);
    for y in 0..h {
        for x in 0..w {
            // smooth in space so edges and resampling are tested, with some noise so colours are varied
            let a = 0.35 + 0.65 * ((x as f32 / w as f32) * 0.6 + (y as f32 / h as f32) * 0.4);
            let c = [(x as f32 / w as f32), (y as f32 / h as f32), 0.5 + 0.5 * r.next()];
            px.extend_from_slice(&[c[0] * a, c[1] * a, c[2] * a, a]);
        }
    }
    Arc::new(VideoFrame::rgba_f32(w, h, px))
}

fn layer(f: Arc<VideoFrame>, m: Affine, opacity: f32, blend: Blend) -> PlanLayer {
    PlanLayer::new(f, m, opacity, blend)
}

/// Matrix placing a `w` x `h` picture: scale about its centre, rotate by `deg` (clockwise), then put its centre at (`cx`, `cy`).
/// (`a.then_apply(b)` applies `b` first.)
fn place(w: f64, h: f64, scale: f64, deg: f64, cx: f64, cy: f64) -> Affine {
    Affine::translate(cx, cy).then_apply(&Affine::rotate_deg(deg)).then_apply(&Affine::scale(scale, scale)).then_apply(&Affine::translate(-w / 2.0, -h / 2.0))
}

fn cpu_image(width: usize, height: usize, layers: &[PlanLayer]) -> Image {
    execute_cpu(&FramePlan::Layers { width, height, layers: layers.to_vec() })
}

/// A base layer and one layer with `mode`, at an angle, partly transparent, so that blending, resampling and edges are all exercised.
fn mode_case(mode: Blend, seed: u64) -> (usize, usize, Vec<PlanLayer>) {
    let (w, h) = (64usize, 48usize);
    let base = layer(frame(32, 24, seed), place(32.0, 24.0, 2.0, 0.0, 32.0, 24.0), 1.0, Blend::Normal);
    let top = layer(frame(24, 24, seed + 1), place(24.0, 24.0, 1.4, 25.0, 30.0, 26.0), 0.8, mode);
    (w, h, vec![base, top])
}

fn transform_cases() -> Vec<(&'static str, usize, usize, Vec<PlanLayer>)> {
    let (w, h) = (96usize, 64usize);
    vec![
        ("rotation and scale", w, h, vec![layer(frame(40, 30, 7), place(40.0, 30.0, 1.7, 33.0, 48.0, 32.0), 1.0, Blend::Normal)]),
        ("shrink below 50% (mip halving)", w, h, vec![layer(frame(200, 150, 8), place(200.0, 150.0, 0.3, 12.0, 48.0, 32.0), 0.9, Blend::Normal)]),
        ("shrink below 25% (two halvings)", w, h, vec![layer(frame(320, 240, 9), place(320.0, 240.0, 0.18, 0.0, 40.0, 30.0), 1.0, Blend::Multiply)]),
        ("flat colour layer", w, h, vec![layer(Arc::new(VideoFrame::rgba_f32(1, 1, vec![0.2, 0.1, 0.05, 0.5])), Affine::scale(w as f64, h as f64), 0.7, Blend::Normal)]),
        ("layer order and opacity", w, h, vec![
            layer(frame(48, 32, 10), place(48.0, 32.0, 1.0, 0.0, 30.0, 30.0), 1.0, Blend::Normal),
            layer(frame(48, 32, 11), place(48.0, 32.0, 1.0, -15.0, 50.0, 34.0), 0.5, Blend::Screen),
            layer(frame(30, 30, 12), place(30.0, 30.0, 1.2, 70.0, 60.0, 30.0), 0.9, Blend::Overlay),
        ]),
        ("layer partly outside the canvas", w, h, vec![layer(frame(60, 60, 13), place(60.0, 60.0, 1.0, 20.0, 5.0, 60.0), 1.0, Blend::Normal)]),
    ]
}

/// The small parity check run before a device is trusted: Normal, Multiply, a non-separable mode, a rotated layer.
pub(crate) fn canary(ctx: &Arc<GpuContext>) -> Result<(), String> {
    let mut rig = Rig::new(ctx.clone());
    for (mode, seed) in [(Blend::Normal, 1u64), (Blend::Multiply, 2), (Blend::Luminosity, 3), (Blend::SoftLight, 4)] {
        let (w, h, layers) = mode_case(mode, seed);
        let gpu = rig.draw(w, h, &layers)?;
        let d = compare(&gpu, &cpu_image(w, h, &layers));
        if !pass(&d) {
            return Err(format!("the GPU's picture differs from the CPU's ({mode:?}: max {:.4}, mean {:.5}, {:.2}% of values off): GPU compositing is not trusted on this phone", d.max, d.mean, d.bad * 100.0));
        }
    }
    Ok(())
}

/// Parity on every blend mode the GPU draws and on the geometry cases, then a 1080p timing. Never panics.
pub fn validate() -> Validation {
    let ctx = match super::context::get() {
        Ok(c) => c,
        Err(why) => return Validation { ok: false, max_diff: 0.0, worst: String::new(), cpu_ms: 0.0, gpu_ms: 0.0, adapter: String::new(), detail: format!("el compositor GPU no está disponible: {why}") },
    };
    let adapter = format!("{} ({})", ctx.adapter_name, ctx.backend);
    let mut rig = Rig::new(ctx.clone());
    let mut ok = true;
    let (mut max_diff, mut worst) = (0f32, String::new());
    let mut notes = Vec::new();
    let mut check = |name: String, w: usize, h: usize, layers: &[PlanLayer], rig: &mut Rig| {
        match rig.draw(w, h, layers) {
            Ok(gpu) => {
                let d = compare(&gpu, &cpu_image(w, h, layers));
                if d.max > max_diff {
                    max_diff = d.max;
                    worst = name.clone();
                }
                if !pass(&d) {
                    ok = false;
                    notes.push(format!("{name}: máx {:.4}, media {:.5}, {:.2}% de valores distintos", d.max, d.mean, d.bad * 100.0));
                }
            }
            Err(e) => {
                ok = false;
                notes.push(format!("{name}: la GPU falló ({e})"));
            }
        }
    };
    for (i, mode) in Blend::ALL.iter().enumerate() {
        if *mode == Blend::Dissolve {
            continue; // stays on the CPU (64-bit hash)
        }
        let (w, h, layers) = mode_case(*mode, 100 + i as u64 * 2);
        check(format!("modo {mode:?}"), w, h, &layers, &mut rig);
    }
    for (name, w, h, layers) in transform_cases() {
        check(name.to_string(), w, h, &layers, &mut rig);
    }
    // timing: a 1080p frame of 4 layers, 3 runs after a warm-up, on both
    let (w, h) = (1920usize, 1080usize);
    let layers: Vec<PlanLayer> = (0..4)
        .map(|i| layer(frame(1920, 1080, 500 + i), place(1920.0, 1080.0, 0.8 + 0.05 * i as f64, 4.0 * i as f64, 960.0, 540.0), 0.85, if i == 0 { Blend::Normal } else { Blend::Multiply }))
        .collect();
    let (mut cpu_ms, mut gpu_ms) = (0.0, 0.0);
    if ok {
        let _ = rig.draw(w, h, &layers);
        let _ = cpu_image(w, h, &layers);
        let runs = 3;
        let t = Instant::now();
        for _ in 0..runs {
            let _ = cpu_image(w, h, &layers);
        }
        cpu_ms = t.elapsed().as_secs_f64() * 1000.0 / f64::from(runs);
        let t = Instant::now();
        for _ in 0..runs {
            if let Err(e) = rig.draw(w, h, &layers) {
                notes.push(format!("medición de tiempos: la GPU falló ({e})"));
                break;
            }
        }
        gpu_ms = t.elapsed().as_secs_f64() * 1000.0 / f64::from(runs);
    }
    let detail = if notes.is_empty() { "La GPU y la CPU coinciden en todos los modos de fusión, transformaciones y mips probados.".to_string() } else { notes.join("; ") };
    Validation { ok, max_diff, worst, cpu_ms, gpu_ms, adapter, detail }
}
