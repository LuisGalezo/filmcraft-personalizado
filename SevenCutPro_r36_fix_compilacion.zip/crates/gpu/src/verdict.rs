//! From what an adapter offers to what the engine could accelerate on it. Pure logic over the report: no GPU needed to test it.

use crate::report::{AdapterReport, Budget, FeatureVerdict, FormatSupport, Level, Verdict};

fn support<'a>(a: &'a AdapterReport, name: &str) -> Option<&'a FormatSupport> {
    a.formats.iter().find(|f| f.name == name).map(|f| &f.support)
}

fn fv(feature: &str, level: Level, reason: impl Into<String>) -> FeatureVerdict {
    FeatureVerdict { feature: feature.into(), level, reason: reason.into() }
}

fn alloc_failed(a: &AdapterReport, what_contains: &str) -> bool {
    a.allocations.iter().any(|t| t.what.contains(what_contains) && t.result == "failed")
}

/// Which parts of the engine this adapter could accelerate, and why not where it cannot.
// One flat list of independent rules: splitting it would only scatter them.
#[allow(clippy::cognitive_complexity)]
pub fn evaluate(a: &AdapterReport, budget: &Budget) -> Verdict {
    if !a.device.ok || budget.software_renderer {
        let why = if budget.software_renderer {
            "this adapter is a software rasteriser: slower than the CPU renderer".to_string()
        } else {
            format!("the GPU device could not be created{}", a.device.error.as_ref().map_or(String::new(), |e| format!(": {e}")))
        };
        let names = [
            "yuv8_input", "yuv16_input", "composition_f16", "filtered_scaling", "blend_modes", "readback_rgba8", "high_precision_f32",
            "color_and_blur_effects", "masks_and_keying", "transitions_simple", "text_layers", "frame_1080p", "frame_4k", "frame_8k", "hdr_wide_gamut",
        ];
        return Verdict { overall: Level::Unsupported, features: names.iter().map(|n| fv(n, Level::Unsupported, why.clone())).collect() };
    }

    let sampled = |n: &str| support(a, n).is_some_and(|s| s.sampled);
    let render = |n: &str| support(a, n).is_some_and(|s| s.render_attachment);
    let mut f = Vec::new();

    f.push(if sampled("R8Unorm") {
        fv("yuv8_input", Level::Supported, "Y, U and V upload as R8 textures and convert to RGB in the shader")
    } else {
        fv("yuv8_input", Level::Unsupported, "R8Unorm cannot be sampled: video would have to be converted to RGB on the CPU")
    });
    f.push(if sampled("R16Uint") {
        fv("yuv16_input", Level::Supported, "9-16 bit planes read as integers")
    } else {
        fv("yuv16_input", Level::Limited, "R16Uint cannot be sampled: 10-bit sources are converted on the CPU")
    });

    let f16_ok = sampled("Rgba16Float") && render("Rgba16Float");
    f.push(if f16_ok {
        fv("composition_f16", Level::Supported, "Rgba16Float can be drawn into and read back by a shader (ping-pong targets)")
    } else {
        fv("composition_f16", Level::Unsupported, "Rgba16Float cannot be both rendered to and sampled: no working targets for compositing")
    });
    f.push(if support(a, "Rgba16Float").is_some_and(|s| s.filterable) {
        fv("filtered_scaling", Level::Supported, "hardware bilinear filtering on the working format")
    } else {
        fv("filtered_scaling", Level::Limited, "no filtering on Rgba16Float: scaling and rotation need hand-written bilinear in the shader")
    });
    f.push(if f16_ok && a.limits.max_sampled_textures_per_shader_stage >= 4 {
        fv("blend_modes", Level::Supported, "the destination is read as a texture, so all 27 modes need no hardware blending")
    } else {
        fv("blend_modes", Level::Unsupported, "needs Rgba16Float targets and at least 4 sampled textures per stage")
    });
    let rgba8_read = support(a, "Rgba8Unorm").is_some_and(|s| s.render_attachment && s.copy_src);
    f.push(if rgba8_read {
        fv("readback_rgba8", Level::Supported, "the GPU can convert to 8-bit and read back 8 bits (4x less than f32)")
    } else {
        fv("readback_rgba8", Level::Limited, "Rgba8Unorm cannot be rendered and copied: frames come back as f16/f32 and are converted on the CPU")
    });
    let f32_ok = sampled("Rgba32Float") && render("Rgba32Float") && !alloc_failed(a, "Rgba32Float");
    f.push(if f32_ok {
        fv("high_precision_f32", Level::Supported, "Rgba32Float targets (read without filtering) for effects that accumulate")
    } else {
        fv("high_precision_f32", Level::Limited, "no usable Rgba32Float target: large blurs and levels would run at half precision, or stay on the CPU")
    });

    f.push(if !f16_ok {
        fv("color_and_blur_effects", Level::Unsupported, "needs the Rgba16Float working targets")
    } else if f32_ok {
        fv("color_and_blur_effects", Level::Supported, "the 34 standard effects can run in the working format, f32 where precision matters")
    } else {
        fv("color_and_blur_effects", Level::Limited, "colour effects fine; effects that accumulate need f32 and would be less precise or stay on the CPU")
    });
    f.push(if f16_ok && a.limits.max_sampled_textures_per_shader_stage >= 6 && a.limits.max_bind_groups >= 2 {
        fv("masks_and_keying", Level::Supported, "enough textures per stage for source planes, destination and a mask")
    } else if f16_ok {
        fv("masks_and_keying", Level::Limited, "few textures per shader stage: masks and keying need extra passes")
    } else {
        fv("masks_and_keying", Level::Unsupported, "needs the Rgba16Float working targets")
    });
    f.push(if f16_ok {
        fv("transitions_simple", Level::Supported, "dissolve, dip and push (the ones the plan already describes)")
    } else {
        fv("transitions_simple", Level::Unsupported, "needs the Rgba16Float working targets")
    });
    f.push(if sampled("Rgba8Unorm") {
        fv("text_layers", Level::Supported, "glyphs are rasterised on the CPU and composited as an RGBA texture (rasterising stays on the CPU by design)")
    } else {
        fv("text_layers", Level::Unsupported, "Rgba8Unorm cannot be sampled")
    });

    for (name, side) in [("frame_1080p", 1920u32), ("frame_4k", 3840), ("frame_8k", 7680)] {
        let texture_ok = a.limits.max_texture_dimension_2d >= side;
        let memory_ok = budget.max_frame_side >= side;
        f.push(match (texture_ok, memory_ok) {
            (true, true) => fv(name, Level::Supported, format!("{side} px long side: texture limit {} and memory budget allow it", a.limits.max_texture_dimension_2d)),
            (false, _) => fv(name, Level::Unsupported, format!("texture limit {} px is below {side}", a.limits.max_texture_dimension_2d)),
            (true, false) => fv(name, Level::Unsupported, format!("the memory budget ({} MB) is too small for {side} px with 3 working targets: this size stays on the CPU", budget.budget_bytes / (1 << 20))),
        });
    }
    f.push(fv("hdr_wide_gamut", Level::Unsupported, "by design: HDR and wide-gamut frames stay on the CPU renderer"));

    let level_of = |n: &str| f.iter().find(|x| x.feature == n).map_or(Level::Unsupported, |x| x.level);
    let core = ["yuv8_input", "composition_f16", "blend_modes", "frame_1080p"];
    let overall = if core.iter().any(|n| level_of(n) == Level::Unsupported) {
        Level::Unsupported
    } else if ["readback_rgba8", "filtered_scaling", "high_precision_f32", "yuv16_input"].iter().all(|n| level_of(n) == Level::Supported) {
        Level::Supported
    } else {
        Level::Limited
    };
    Verdict { overall, features: f }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::budget::recommend;
    use crate::report::{AllocTest, DeviceReport, FormatReport, LimitsReport};

    fn fs(sampled: bool, render: bool, filterable: bool, copy_src: bool) -> FormatSupport {
        FormatSupport { sampled, render_attachment: render, copy_src, copy_dst: true, storage: false, filterable, blendable: render }
    }

    fn adapter(formats: &[(&str, FormatSupport)], limits: LimitsReport, device_ok: bool, device_type: &str) -> AdapterReport {
        AdapterReport {
            backend: "vulkan".into(),
            name: "test gpu".into(),
            vendor_id: 0,
            device_id: 0,
            device_type: device_type.into(),
            driver: String::new(),
            driver_info: String::new(),
            features: vec![],
            limits,
            formats: formats.iter().map(|(n, s)| FormatReport { name: (*n).into(), role: String::new(), required: false, support: s.clone() }).collect(),
            device: DeviceReport { attempted: true, ok: device_ok, error: if device_ok { None } else { Some("boom".into()) }, ..Default::default() },
            allocations: vec![],
            verdict: None,
            budget: None,
        }
    }

    fn limits(tex: u32, sampled: u32, groups: u32) -> LimitsReport {
        LimitsReport { max_texture_dimension_2d: tex, max_sampled_textures_per_shader_stage: sampled, max_bind_groups: groups, ..Default::default() }
    }

    fn full_formats() -> Vec<(&'static str, FormatSupport)> {
        vec![
            ("R8Unorm", fs(true, true, true, true)),
            ("R16Uint", fs(true, true, false, true)),
            ("Rgba8Unorm", fs(true, true, true, true)),
            ("Rgba16Float", fs(true, true, true, true)),
            ("Rgba32Float", fs(true, true, false, true)),
        ]
    }

    fn level(v: &Verdict, name: &str) -> Level {
        v.features.iter().find(|f| f.feature == name).unwrap_or_else(|| panic!("no feature {name}")).level
    }

    #[test]
    fn a_capable_phone_can_accelerate_everything_except_hdr() {
        let a = adapter(&full_formats(), limits(16384, 16, 4), true, "integrated_gpu");
        let b = recommend(Some(8192), "integrated_gpu", 16384);
        let v = evaluate(&a, &b);
        assert_eq!(v.overall, Level::Supported);
        for n in ["yuv8_input", "yuv16_input", "composition_f16", "filtered_scaling", "blend_modes", "readback_rgba8", "high_precision_f32", "color_and_blur_effects", "masks_and_keying", "transitions_simple", "text_layers", "frame_1080p", "frame_4k"] {
            assert_eq!(level(&v, n), Level::Supported, "{n}");
        }
        assert_eq!(level(&v, "frame_8k"), Level::Unsupported, "8K does not fit a phone's memory model");
        assert_eq!(level(&v, "hdr_wide_gamut"), Level::Unsupported);
    }

    #[test]
    fn without_a_renderable_f16_nothing_can_be_composed() {
        let mut f = full_formats();
        f.retain(|(n, _)| *n != "Rgba16Float");
        f.push(("Rgba16Float", fs(true, false, true, true)));
        let a = adapter(&f, limits(8192, 16, 4), true, "integrated_gpu");
        let v = evaluate(&a, &recommend(Some(4096), "integrated_gpu", 8192));
        assert_eq!(v.overall, Level::Unsupported);
        assert_eq!(level(&v, "composition_f16"), Level::Unsupported);
        assert_eq!(level(&v, "blend_modes"), Level::Unsupported);
        assert_eq!(level(&v, "yuv8_input"), Level::Supported, "reading video planes is separate");
    }

    #[test]
    fn missing_optional_parts_make_it_limited_with_reasons() {
        let mut f = full_formats();
        f.retain(|(n, _)| !matches!(*n, "Rgba32Float" | "R16Uint"));
        let a = adapter(&f, limits(8192, 8, 4), true, "integrated_gpu");
        let v = evaluate(&a, &recommend(Some(4096), "integrated_gpu", 8192));
        assert_eq!(v.overall, Level::Limited);
        assert_eq!(level(&v, "high_precision_f32"), Level::Limited);
        assert_eq!(level(&v, "yuv16_input"), Level::Limited);
        assert_eq!(level(&v, "color_and_blur_effects"), Level::Limited);
        assert_eq!(level(&v, "composition_f16"), Level::Supported);
    }

    #[test]
    fn a_failed_f32_allocation_counts_against_f32() {
        let mut a = adapter(&full_formats(), limits(16384, 16, 4), true, "integrated_gpu");
        a.allocations.push(AllocTest { what: "4K Rgba32Float target".into(), bytes: 1, result: "failed".into(), detail: Some("out of memory".into()) });
        let v = evaluate(&a, &recommend(Some(8192), "integrated_gpu", 16384));
        assert_eq!(level(&v, "high_precision_f32"), Level::Limited);
    }

    #[test]
    fn few_textures_per_stage_limit_masks_but_not_composition() {
        let a = adapter(&full_formats(), limits(8192, 4, 4), true, "integrated_gpu");
        let v = evaluate(&a, &recommend(Some(4096), "integrated_gpu", 8192));
        assert_eq!(level(&v, "blend_modes"), Level::Supported);
        assert_eq!(level(&v, "masks_and_keying"), Level::Limited);
    }

    #[test]
    fn a_failed_device_or_a_software_rasteriser_accelerates_nothing() {
        let bad = adapter(&full_formats(), limits(8192, 16, 4), false, "integrated_gpu");
        let v = evaluate(&bad, &recommend(Some(4096), "integrated_gpu", 8192));
        assert_eq!(v.overall, Level::Unsupported);
        assert!(v.features.iter().all(|f| f.level == Level::Unsupported && f.reason.contains("boom")));
        let sw = adapter(&full_formats(), limits(8192, 16, 4), true, "cpu");
        let v = evaluate(&sw, &recommend(Some(4096), "cpu", 8192));
        assert_eq!(v.overall, Level::Unsupported);
        assert!(v.features[0].reason.contains("software rasteriser"));
    }

    #[test]
    fn the_texture_limit_and_the_memory_budget_each_cap_the_frame_size() {
        let a = adapter(&full_formats(), limits(2048, 16, 4), true, "integrated_gpu");
        let v = evaluate(&a, &recommend(Some(8192), "integrated_gpu", 2048));
        assert_eq!(level(&v, "frame_1080p"), Level::Supported);
        assert!(v.features.iter().find(|f| f.feature == "frame_4k").unwrap().reason.contains("texture limit"));
        let small = adapter(&full_formats(), limits(16384, 16, 4), true, "integrated_gpu");
        let v = evaluate(&small, &recommend(Some(1024), "integrated_gpu", 16384));
        assert_eq!(level(&v, "frame_4k"), Level::Unsupported);
        assert!(v.features.iter().find(|f| f.feature == "frame_4k").unwrap().reason.contains("memory budget"));
    }
}
