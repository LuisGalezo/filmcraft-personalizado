//! FilmCraft GPU acceleration — **stage 1: detect and diagnose** the device's GPU.
//!
//! Nothing here renders, composes or touches the export or the CPU renderer. [`run_probe`] asks wgpu which graphics backends
//! and adapters the device has (Vulkan first, then OpenGL ES), what each can do (limits, features, the texture formats a compositor
//! would need), whether a device can really be created and a few frame-sized textures allocated, and turns that into a
//! [`GpuReport`] that says which parts of the engine could be accelerated on this phone and which must stay on the CPU.
//!
//! Layout: [`report`] (the data), [`formats`] (what is asked), [`verdict`] (what the answers mean), [`budget`] (memory model),
//! [`guard`] (survive a driver that kills the process). The only code that touches wgpu is `probe_wgpu`, behind the
//! `wgpu-probe` feature; without it the probe returns a report saying so.

pub mod budget;
pub mod formats;
pub mod guard;
pub mod report;
pub mod stages;
pub mod verdict;

#[cfg(feature = "wgpu-probe")]
mod probe_wgpu;

/// The GPU compositor (feature `compositor`).
#[cfg(feature = "compositor")]
pub mod compose;

/// Whether the GPU compositor is built into this binary.
pub const fn compositor_built() -> bool {
    cfg!(feature = "compositor")
}

use report::{AdapterReport, GpuReport, Issue, Level, Selected, Status};
use std::path::PathBuf;
use std::time::{Duration, Instant};

/// What to probe and how.
#[derive(Clone, Debug)]
pub struct ProbeOptions {
    /// The phone's RAM in MB, to size the memory budget (unknown: a mid-range phone is assumed).
    pub system_ram_mb: Option<u64>,
    /// How long the probe may take before it is given up on (a hanging driver).
    pub timeout: Duration,
    /// Where the crash marker lives (see [`guard`]); `None` = no protection (tests).
    pub state_dir: Option<PathBuf>,
    /// Identifies the app build: a build that crashed in the probe is blocked until the build changes.
    pub build_id: String,
    /// Allocate frame-sized textures to see what the device really accepts (1080p and 4K working targets).
    pub allocation_tests: bool,
}

impl Default for ProbeOptions {
    fn default() -> Self {
        ProbeOptions { system_ram_mb: None, timeout: Duration::from_secs(20), state_dir: None, build_id: "dev".into(), allocation_tests: true }
    }
}

/// Whether the wgpu probe is built into this binary.
pub const fn wgpu_compiled() -> bool {
    cfg!(feature = "wgpu-probe")
}

/// Rank for choosing the adapter the compositor would use: a real GPU on Vulkan first, then on GL; software rasterisers last.
fn rank(backend: &str, device_type: &str) -> u32 {
    let kind = match device_type {
        "integrated_gpu" => 3,
        "discrete_gpu" => 3,
        "virtual_gpu" => 2,
        "other" => 1,
        _ => 0, // "cpu": software
    };
    let api = if backend == "vulkan" { 2 } else { 1 };
    kind * 10 + api
}

/// The usable adapter with the best rank, as (backend index, adapter index).
pub fn select_best(backends: &[report::BackendReport]) -> Option<(usize, usize)> {
    let mut best: Option<(u32, usize, usize)> = None;
    for (bi, b) in backends.iter().enumerate() {
        for (ai, a) in b.adapters.iter().enumerate() {
            let usable = a.verdict.as_ref().is_some_and(|v| v.overall != Level::Unsupported);
            if !usable {
                continue;
            }
            let r = rank(&b.backend, &a.device_type);
            if best.is_none_or(|(br, _, _)| r > br) {
                best = Some((r, bi, ai));
            }
        }
    }
    best.map(|(_, b, a)| (b, a))
}

/// Verdict and memory budget for one adapter, from what the probe found.
pub fn assess(a: &mut AdapterReport, system_ram_mb: Option<u64>) {
    let budget = budget::recommend(system_ram_mb, &a.device_type, a.limits.max_texture_dimension_2d);
    a.verdict = Some(verdict::evaluate(a, &budget));
    a.budget = Some(budget);
}

/// Finish a report: assess every adapter, pick the one to use, note when there is none.
pub fn finalize(report: &mut GpuReport) {
    let ram = report.system_ram_mb;
    for b in &mut report.backends {
        for a in &mut b.adapters {
            assess(a, ram);
        }
    }
    report.selected = select_best(&report.backends).map(|(b, a)| {
        let bk = &report.backends[b];
        Selected { backend: bk.backend.clone(), name: bk.adapters[a].name.clone() }
    });
    if report.status == Status::Ran && report.selected.is_none() {
        let any_adapter = report.backends.iter().any(|b| !b.adapters.is_empty());
        report.issues.push(Issue::new(
            "select",
            "warning",
            if any_adapter { "no adapter can accelerate the engine's core (see each adapter's verdict): everything stays on the CPU" } else { "no GPU adapter found: everything stays on the CPU" },
        ));
    }
}

/// A report for a probe that did not run.
fn not_run(opts: &ProbeOptions, status: Status) -> GpuReport {
    let mut r = GpuReport::new(wgpu_compiled(), opts.system_ram_mb);
    r.status = status;
    r
}

/// Probe the device's GPU. Never panics, never takes longer than `opts.timeout` to answer, and never changes anything else in
/// the engine. Safe to call from any thread.
pub fn run_probe(opts: &ProbeOptions) -> GpuReport {
    let started = Instant::now();
    if !wgpu_compiled() {
        let mut r = not_run(opts, Status::Skipped("this build does not include wgpu (feature wgpu-probe off): nothing was probed".into()));
        r.issues.push(Issue::new("build", "info", "build with `--features gpu-probe` (the Android build does by default; Gradle -Pfilmcraft.gpuProbe=false turns it off) to probe the device"));
        return r;
    }
    let armed = match &opts.state_dir {
        None => None,
        Some(dir) => match guard::begin(dir, &opts.build_id) {
            Ok(guard::Begin::Go(a)) => Some(a),
            Ok(guard::Begin::Blocked(why)) => return not_run(opts, Status::Skipped(why)),
            Err(e) => {
                // cannot write the marker: probing without protection could crash the app unnoticed, so do not
                let mut r = not_run(opts, Status::Skipped(format!("could not write the crash marker: {e}")));
                r.issues.push(Issue::new("guard", "error", e.to_string()));
                return r;
            }
        },
    };
    let (tx, rx) = std::sync::mpsc::channel();
    let thread_opts = opts.clone();
    let spawned = std::thread::Builder::new().name("gpu-probe".into()).spawn(move || {
        let r = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| probe_in_thread(&thread_opts)));
        let _ = tx.send(r);
    });
    if let Err(e) = spawned {
        if let Some(a) = armed {
            let _ = a.finish();
        }
        let mut r = not_run(opts, Status::Skipped("could not start the probe thread".into()));
        r.issues.push(Issue::new("probe", "error", e.to_string()));
        return r;
    }
    let mut report = match rx.recv_timeout(opts.timeout) {
        Ok(Ok(report)) => {
            if let Some(a) = armed {
                let _ = a.finish();
            }
            report
        }
        Ok(Err(panic)) => {
            // a Rust panic is not a crash of the driver: the marker is cleared
            if let Some(a) = armed {
                let _ = a.finish();
            }
            let mut r = not_run(opts, Status::Ran);
            r.issues.push(Issue::new("probe", "error", format!("the probe panicked: {}", panic_message(&*panic))));
            r
        }
        Err(_) => {
            // the thread is stuck in the driver: the marker STAYS, so the next start knows
            not_run(opts, Status::TimedOut(format!("the GPU probe did not answer within {} s (the driver may hang)", opts.timeout.as_secs())))
        }
    };
    report.elapsed_ms = started.elapsed().as_millis() as u64;
    if report.status == Status::Ran {
        finalize(&mut report);
    }
    log::info!("{}", report.summary());
    report
}

fn panic_message(p: &(dyn std::any::Any + Send)) -> String {
    p.downcast_ref::<&str>().map(|s| (*s).to_string()).or_else(|| p.downcast_ref::<String>().cloned()).unwrap_or_else(|| "unknown".into())
}

#[cfg(feature = "wgpu-probe")]
fn probe_in_thread(opts: &ProbeOptions) -> GpuReport {
    let mut r = GpuReport::new(true, opts.system_ram_mb);
    probe_wgpu::probe_all(opts, &mut r);
    r
}

#[cfg(not(feature = "wgpu-probe"))]
fn probe_in_thread(opts: &ProbeOptions) -> GpuReport {
    GpuReport::new(false, opts.system_ram_mb)
}

#[cfg(test)]
mod tests;
