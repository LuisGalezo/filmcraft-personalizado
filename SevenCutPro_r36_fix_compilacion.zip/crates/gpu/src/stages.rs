//! The steps of the progressive GPU integration, and what this phone allows for each. The GPU is switched on step by step: a step is
//! only offered once the device can do it ([`StagePlan::device_level`]) AND the engine implements and has validated it
//! ([`StageDef::implemented`]). Today nothing is implemented, so every step reads "device ready / not implemented yet" and all rendering
//! stays on the CPU. When a stage lands, its `implemented` flag is the only thing that changes here.

use crate::report::{Level, Verdict};

pub struct StageDef {
    pub id: &'static str,
    pub title: &'static str,
    /// The [`crate::verdict`] features the device must offer.
    pub needs: &'static [&'static str],
    /// Written, validated against the CPU renderer and switched on in the engine. All false in stage 1.
    pub implemented: bool,
}

pub const STAGES: &[StageDef] = &[
    StageDef { id: "composition", title: "Composición de capas y modos de fusión", needs: &["yuv8_input", "composition_f16", "blend_modes", "frame_1080p"], implemented: true },
    StageDef { id: "effects", title: "Efectos (color, desenfoque, transformación)", needs: &["composition_f16", "color_and_blur_effects"], implemented: false },
    StageDef { id: "filters", title: "Filtros y corrección de color", needs: &["composition_f16", "color_and_blur_effects"], implemented: false },
    StageDef { id: "transitions", title: "Transiciones (disolvencia, inmersión, empuje)", needs: &["composition_f16", "transitions_simple"], implemented: false },
    StageDef { id: "masks_keying", title: "Máscaras y croma", needs: &["composition_f16", "masks_and_keying"], implemented: false },
    StageDef { id: "text", title: "Texto (se rasteriza en CPU y se compone en GPU)", needs: &["composition_f16", "text_layers"], implemented: false },
    StageDef { id: "readback", title: "Lectura en 8 bits para el codificador", needs: &["readback_rgba8"], implemented: false },
];

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct StagePlan {
    pub id: String,
    pub title: String,
    /// The worst level among the features the step needs.
    pub device_level: Level,
    pub implemented: bool,
    pub note: String,
}

fn severity(l: Level) -> u8 {
    match l {
        Level::Supported => 0,
        Level::Limited => 1,
        Level::Unsupported => 2,
    }
}

/// What each step could do on the adapter `v` describes, and whether the engine has it yet.
pub fn plan(v: &Verdict) -> Vec<StagePlan> {
    STAGES
        .iter()
        .map(|s| {
            let mut worst = Level::Supported;
            let mut why = String::new();
            for need in s.needs {
                // a feature the verdict does not mention is a feature the device cannot be shown to have
                let (level, reason) = v.features.iter().find(|f| f.feature == *need).map_or((Level::Unsupported, "no se pudo comprobar".to_string()), |f| (f.level, f.reason.clone()));
                if severity(level) > severity(worst) {
                    worst = level;
                    why = reason;
                }
            }
            let device = match worst {
                Level::Supported => "el teléfono puede hacerlo".to_string(),
                Level::Limited => format!("el teléfono puede hacerlo con limitaciones ({why})"),
                Level::Unsupported => format!("el teléfono no puede ({why})"),
            };
            let engine = if s.implemented { "conectado al motor (validar la paridad con la CPU en este teléfono)" } else { "aún sin implementar en el motor: sigue en CPU" };
            StagePlan { id: s.id.into(), title: s.title.into(), device_level: worst, implemented: s.implemented, note: format!("{device}; {engine}") }
        })
        .collect()
}

/// The name of a [`crate::verdict`] feature in the app's language.
pub fn feature_title(id: &str) -> &'static str {
    match id {
        "yuv8_input" => "Entrada de vídeo YUV 8 bits",
        "yuv16_input" => "Entrada de vídeo YUV 10-16 bits",
        "composition_f16" => "Composición con destinos de media precisión (f16)",
        "filtered_scaling" => "Escalado y rotación con filtrado",
        "blend_modes" => "Los 27 modos de fusión",
        "readback_rgba8" => "Lectura de fotogramas en 8 bits",
        "high_precision_f32" => "Alta precisión (f32) para efectos acumulativos",
        "color_and_blur_effects" => "Efectos de color y desenfoque",
        "masks_and_keying" => "Máscaras y croma",
        "transitions_simple" => "Transiciones simples",
        "text_layers" => "Capas de texto",
        "frame_1080p" => "Fotogramas hasta 1080p",
        "frame_4k" => "Fotogramas hasta 4K",
        "frame_8k" => "Fotogramas hasta 8K",
        "hdr_wide_gamut" => "HDR y gran gama de color",
        _ => "Función desconocida",
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::report::FeatureVerdict;

    fn verdict(levels: &[(&str, Level)]) -> Verdict {
        Verdict { overall: Level::Supported, features: levels.iter().map(|(f, l)| FeatureVerdict { feature: (*f).into(), level: *l, reason: format!("razón de {f}") }).collect() }
    }

    fn all(level: Level) -> Verdict {
        let ids: Vec<&str> = STAGES.iter().flat_map(|s| s.needs.iter().copied()).collect();
        verdict(&ids.iter().map(|i| (*i, level)).collect::<Vec<_>>())
    }

    #[test]
    fn only_the_composition_is_connected_so_every_other_step_says_it_stays_on_the_cpu() {
        let implemented: Vec<_> = STAGES.iter().filter(|s| s.implemented).map(|s| s.id).collect();
        assert_eq!(implemented, vec!["composition"], "when a stage lands, flip its flag and update this test");
        let p = plan(&all(Level::Supported));
        assert_eq!(p.len(), STAGES.len());
        assert!(p.iter().all(|s| s.device_level == Level::Supported));
        assert!(p.iter().filter(|s| !s.implemented).all(|s| s.note.contains("el teléfono puede hacerlo") && s.note.contains("sigue en CPU")));
        assert!(p.iter().find(|s| s.id == "composition").unwrap().note.contains("conectado al motor"));
    }

    #[test]
    fn a_step_is_as_good_as_the_worst_thing_it_needs() {
        let mut v = all(Level::Supported);
        v.features.iter_mut().find(|f| f.feature == "color_and_blur_effects").unwrap().level = Level::Limited;
        v.features.iter_mut().find(|f| f.feature == "transitions_simple").unwrap().level = Level::Unsupported;
        let p = plan(&v);
        let level = |id: &str| p.iter().find(|s| s.id == id).unwrap().device_level;
        assert_eq!(level("composition"), Level::Supported);
        assert_eq!(level("effects"), Level::Limited);
        assert_eq!(level("filters"), Level::Limited);
        assert_eq!(level("transitions"), Level::Unsupported);
        assert!(p.iter().find(|s| s.id == "transitions").unwrap().note.contains("razón de transitions_simple"));
    }

    #[test]
    fn a_feature_the_verdict_does_not_mention_counts_as_unsupported() {
        let p = plan(&verdict(&[("composition_f16", Level::Supported)]));
        let c = p.iter().find(|s| s.id == "composition").unwrap();
        assert_eq!(c.device_level, Level::Unsupported);
        assert!(c.note.contains("no se pudo comprobar"));
    }

    #[test]
    fn every_feature_the_verdict_can_name_has_a_title() {
        for id in ["yuv8_input", "yuv16_input", "composition_f16", "filtered_scaling", "blend_modes", "readback_rgba8", "high_precision_f32", "color_and_blur_effects", "masks_and_keying", "transitions_simple", "text_layers", "frame_1080p", "frame_4k", "frame_8k", "hdr_wide_gamut"] {
            assert_ne!(feature_title(id), "Función desconocida", "{id}");
        }
        assert_eq!(feature_title("nope"), "Función desconocida");
    }
}
