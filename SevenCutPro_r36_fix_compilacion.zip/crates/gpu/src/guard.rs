//! Protection against a driver that kills the process. A native crash cannot be caught, so before the probe touches the GPU a
//! "running" marker is written to disk and it is removed when the probe ends. If the next start finds the marker, the previous probe
//! never finished: that build is blocked from probing again (and, in later stages, from using the GPU) until the app is updated,
//! because the marker holds the build id.

use std::fs;
use std::io;
use std::path::{Path, PathBuf};

const RUNNING: &str = "gpu_probe.running";
const CRASHED: &str = "gpu_probe.crashed";

#[derive(Debug)]
pub enum Begin {
    /// Go ahead; call [`Armed::finish`] when the probe ends.
    Go(Armed),
    /// This build already crashed or hung in the probe.
    Blocked(String),
}

/// The marker is on disk; dropping this without [`Armed::finish`] leaves it there on purpose.
#[derive(Debug)]
pub struct Armed {
    running: PathBuf,
}

impl Armed {
    /// The probe ended normally: take the marker away.
    pub fn finish(self) -> io::Result<()> {
        fs::remove_file(&self.running)
    }
}

fn read(path: &Path) -> Option<String> {
    fs::read_to_string(path).ok().map(|s| s.trim().to_string())
}

/// Decide whether the probe may run on this `build_id`, and arm the marker if so.
pub fn begin(dir: &Path, build_id: &str) -> io::Result<Begin> {
    fs::create_dir_all(dir)?;
    let running = dir.join(RUNNING);
    let crashed = dir.join(CRASHED);
    // an unfinished earlier probe becomes a crash record for the build that ran it
    if let Some(prev) = read(&running) {
        fs::write(&crashed, &prev)?;
        fs::remove_file(&running)?;
    }
    if let Some(bad) = read(&crashed) {
        if bad == build_id {
            return Ok(Begin::Blocked(format!("an earlier GPU probe of build {build_id} never finished (the driver crashed or hung); not trying again until the app is updated")));
        }
        // a different build: the record is stale
        let _ = fs::remove_file(&crashed);
    }
    fs::write(&running, build_id)?;
    Ok(Begin::Go(Armed { running }))
}

/// Forget a crash record (for testing on purpose, or after a driver update).
pub fn reset(dir: &Path) {
    let _ = fs::remove_file(dir.join(RUNNING));
    let _ = fs::remove_file(dir.join(CRASHED));
}

#[cfg(test)]
mod tests {
    use super::*;

    fn go(b: Begin) -> Armed {
        match b {
            Begin::Go(a) => a,
            Begin::Blocked(w) => panic!("blocked: {w}"),
        }
    }

    #[test]
    fn a_probe_that_finishes_leaves_nothing_behind() {
        let d = tempfile::tempdir().unwrap();
        let a = go(begin(d.path(), "b1").unwrap());
        assert!(d.path().join(RUNNING).exists());
        a.finish().unwrap();
        assert!(!d.path().join(RUNNING).exists());
        assert!(!d.path().join(CRASHED).exists());
        go(begin(d.path(), "b1").unwrap()).finish().unwrap();
    }

    #[test]
    fn a_probe_that_never_finished_blocks_the_same_build_but_not_a_new_one() {
        let d = tempfile::tempdir().unwrap();
        let armed = go(begin(d.path(), "b1").unwrap());
        drop(armed); // the process died: no finish()
        match begin(d.path(), "b1").unwrap() {
            Begin::Blocked(w) => assert!(w.contains("b1") && w.contains("never finished")),
            Begin::Go(_) => panic!("must be blocked"),
        }
        // and it stays blocked on the next start too
        assert!(matches!(begin(d.path(), "b1").unwrap(), Begin::Blocked(_)));
        // an updated app tries again
        go(begin(d.path(), "b2").unwrap()).finish().unwrap();
        assert!(!d.path().join(CRASHED).exists());
    }

    #[test]
    fn reset_clears_a_block() {
        let d = tempfile::tempdir().unwrap();
        drop(go(begin(d.path(), "b1").unwrap()));
        assert!(matches!(begin(d.path(), "b1").unwrap(), Begin::Blocked(_)));
        reset(d.path());
        go(begin(d.path(), "b1").unwrap()).finish().unwrap();
    }
}
