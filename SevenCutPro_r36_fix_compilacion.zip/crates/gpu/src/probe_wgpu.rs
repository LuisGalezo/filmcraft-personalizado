//! The only code that touches wgpu (written against wgpu 24: `enumerate_adapters`, `request_device(desc, None)`, error scopes).
//! It asks questions and allocates a few textures; it draws nothing. Every call into the driver is wrapped so that a panic
//! becomes a line in the report; a hang is caught by the timeout in `run_probe`, a crash by the marker in `guard`.

use crate::budget;
use crate::formats::NEEDED;
use crate::report::{AdapterReport, AllocTest, BackendReport, DeviceReport, FormatReport, FormatSupport, GpuReport, Issue, LimitsReport};
use crate::ProbeOptions;
use std::panic::{catch_unwind, AssertUnwindSafe};
use std::sync::{Arc, Mutex};
use std::time::Instant;

pub(crate) fn probe_all(opts: &ProbeOptions, report: &mut GpuReport) {
    let instance = match catch_unwind(wgpu::Instance::default) {
        Ok(i) => i,
        Err(_) => {
            report.issues.push(Issue::new("instance", "error", "creating the wgpu instance panicked"));
            return;
        }
    };
    for (name, backends) in [("vulkan", wgpu::Backends::VULKAN), ("gl", wgpu::Backends::GL)] {
        let t0 = Instant::now();
        let mut br = BackendReport { backend: name.into(), adapters: Vec::new(), error: None, elapsed_ms: 0 };
        match catch_unwind(AssertUnwindSafe(|| instance.enumerate_adapters(backends))) {
            Ok(adapters) => {
                for adapter in &adapters {
                    br.adapters.push(probe_adapter(adapter, opts, &mut report.issues));
                }
            }
            Err(_) => {
                br.error = Some("enumerating adapters panicked".into());
                report.issues.push(Issue::new("enumerate", "error", format!("{name}: enumerating adapters panicked")));
            }
        }
        br.elapsed_ms = t0.elapsed().as_millis() as u64;
        report.backends.push(br);
    }
}

fn backend_name(b: wgpu::Backend) -> String {
    match b {
        wgpu::Backend::Vulkan => "vulkan".into(),
        wgpu::Backend::Gl => "gl".into(),
        other => format!("{other:?}").to_lowercase(),
    }
}

fn device_type_name(t: wgpu::DeviceType) -> String {
    match t {
        wgpu::DeviceType::IntegratedGpu => "integrated_gpu",
        wgpu::DeviceType::DiscreteGpu => "discrete_gpu",
        wgpu::DeviceType::VirtualGpu => "virtual_gpu",
        wgpu::DeviceType::Cpu => "cpu",
        wgpu::DeviceType::Other => "other",
    }
    .into()
}

fn texture_format(name: &str) -> Option<wgpu::TextureFormat> {
    Some(match name {
        "R8Unorm" => wgpu::TextureFormat::R8Unorm,
        "Rg8Unorm" => wgpu::TextureFormat::Rg8Unorm,
        "R16Uint" => wgpu::TextureFormat::R16Uint,
        "Rgba8Unorm" => wgpu::TextureFormat::Rgba8Unorm,
        "Rgba8UnormSrgb" => wgpu::TextureFormat::Rgba8UnormSrgb,
        "Rgba16Float" => wgpu::TextureFormat::Rgba16Float,
        "Rgba32Float" => wgpu::TextureFormat::Rgba32Float,
        _ => return None,
    })
}

fn feature_names(f: wgpu::Features) -> Vec<String> {
    const LIST: &[(&str, wgpu::Features)] = &[
        ("FLOAT32_FILTERABLE", wgpu::Features::FLOAT32_FILTERABLE),
        ("TEXTURE_FORMAT_16BIT_NORM", wgpu::Features::TEXTURE_FORMAT_16BIT_NORM),
        ("TEXTURE_ADAPTER_SPECIFIC_FORMAT_FEATURES", wgpu::Features::TEXTURE_ADAPTER_SPECIFIC_FORMAT_FEATURES),
        ("SHADER_F16", wgpu::Features::SHADER_F16),
        ("TIMESTAMP_QUERY", wgpu::Features::TIMESTAMP_QUERY),
        ("PUSH_CONSTANTS", wgpu::Features::PUSH_CONSTANTS),
        ("MAPPABLE_PRIMARY_BUFFERS", wgpu::Features::MAPPABLE_PRIMARY_BUFFERS),
    ];
    LIST.iter().filter(|(_, flag)| f.contains(*flag)).map(|(n, _)| (*n).to_string()).collect()
}

fn format_support(adapter: &wgpu::Adapter, name: &str) -> FormatSupport {
    let Some(fmt) = texture_format(name) else { return FormatSupport::default() };
    let f = adapter.get_texture_format_features(fmt);
    FormatSupport {
        sampled: f.allowed_usages.contains(wgpu::TextureUsages::TEXTURE_BINDING),
        render_attachment: f.allowed_usages.contains(wgpu::TextureUsages::RENDER_ATTACHMENT),
        copy_src: f.allowed_usages.contains(wgpu::TextureUsages::COPY_SRC),
        copy_dst: f.allowed_usages.contains(wgpu::TextureUsages::COPY_DST),
        storage: f.allowed_usages.contains(wgpu::TextureUsages::STORAGE_BINDING),
        filterable: f.flags.contains(wgpu::TextureFormatFeatureFlags::FILTERABLE),
        blendable: f.flags.contains(wgpu::TextureFormatFeatureFlags::BLENDABLE),
    }
}

fn probe_adapter(adapter: &wgpu::Adapter, opts: &ProbeOptions, issues: &mut Vec<Issue>) -> AdapterReport {
    let info = adapter.get_info();
    let limits = adapter.limits();
    let mut features = feature_names(adapter.features());
    // the downlevel flags tell what a GLES adapter lacks (compute, storage in fragment shaders, independent blending ...)
    let downlevel = adapter.get_downlevel_capabilities();
    features.push(format!("downlevel_flags={:?}", downlevel.flags));
    features.push(format!("shader_model={:?}", downlevel.shader_model));
    let mut a = AdapterReport {
        backend: backend_name(info.backend),
        name: info.name.clone(),
        vendor_id: info.vendor,
        device_id: info.device,
        device_type: device_type_name(info.device_type),
        driver: info.driver.clone(),
        driver_info: info.driver_info.clone(),
        features,
        limits: LimitsReport {
            max_texture_dimension_2d: limits.max_texture_dimension_2d,
            max_buffer_size: limits.max_buffer_size,
            max_storage_buffer_binding_size: limits.max_storage_buffer_binding_size,
            max_uniform_buffer_binding_size: limits.max_uniform_buffer_binding_size,
            max_bind_groups: limits.max_bind_groups,
            max_color_attachments: limits.max_color_attachments,
            max_sampled_textures_per_shader_stage: limits.max_sampled_textures_per_shader_stage,
            max_texture_array_layers: limits.max_texture_array_layers,
        },
        formats: Vec::new(),
        device: DeviceReport::default(),
        allocations: Vec::new(),
        verdict: None,
        budget: None,
    };
    for n in NEEDED {
        let support = catch_unwind(AssertUnwindSafe(|| format_support(adapter, n.name))).unwrap_or_else(|_| {
            issues.push(Issue::new("formats", "error", format!("{} {}: asking about {} panicked", a.backend, a.name, n.name)));
            FormatSupport::default()
        });
        a.formats.push(FormatReport { name: n.name.into(), role: n.role.into(), required: n.required, support });
    }

    // a device, with the plainest limits first (the compositor needs little), then the even plainer GLES ones
    a.device.attempted = true;
    let t0 = Instant::now();
    let attempts = [
        ("downlevel_defaults", wgpu::Limits::downlevel_defaults().using_resolution(limits.clone())),
        ("downlevel_webgl2_defaults", wgpu::Limits::downlevel_webgl2_defaults().using_resolution(limits.clone())),
    ];
    let mut last_error: Option<String> = None;
    let mut made = None;
    for (label, required_limits) in attempts {
        let desc = wgpu::DeviceDescriptor { label: Some("filmcraft-gpu-probe"), required_features: wgpu::Features::empty(), required_limits, memory_hints: wgpu::MemoryHints::default() };
        match catch_unwind(AssertUnwindSafe(|| pollster::block_on(adapter.request_device(&desc, None)))) {
            Ok(Ok((device, _queue))) => {
                made = Some((label, device));
                break;
            }
            Ok(Err(e)) => last_error = Some(format!("{label}: {e}")),
            Err(_) => last_error = Some(format!("{label}: creating the device panicked")),
        }
    }
    a.device.elapsed_ms = t0.elapsed().as_millis() as u64;
    let Some((profile, device)) = made else {
        let err = last_error.unwrap_or_else(|| "no device".into());
        issues.push(Issue::new("device", "error", format!("{} {}: {err}", a.backend, a.name)));
        a.device.error = Some(err);
        return a;
    };
    a.device.ok = true;
    a.device.limits_profile = Some(profile.into());

    let uncaptured = Arc::new(Mutex::new(Vec::<String>::new()));
    let lost = Arc::new(Mutex::new(Vec::<String>::new()));
    {
        let sink = uncaptured.clone();
        device.on_uncaptured_error(Box::new(move |e| {
            if let Ok(mut v) = sink.lock() {
                v.push(e.to_string());
            }
        }));
        let sink = lost.clone();
        device.set_device_lost_callback(move |reason, message| {
            if let Ok(mut v) = sink.lock() {
                v.push(format!("{reason:?}: {message}"));
            }
        });
    }

    if opts.allocation_tests {
        let plan = budget::recommend(opts.system_ram_mb, &a.device_type, a.limits.max_texture_dimension_2d);
        a.allocations = allocation_tests(&device, &a, plan.budget_bytes);
        for t in a.allocations.iter().filter(|t| t.result == "failed") {
            issues.push(Issue::new("alloc", "warning", format!("{} {}: {} failed ({})", a.backend, a.name, t.what, t.detail.clone().unwrap_or_default())));
        }
    }
    a.device.uncaptured_errors = uncaptured.lock().map(|v| v.clone()).unwrap_or_default();
    a.device.lost = lost.lock().map(|v| v.clone()).unwrap_or_default();
    for e in &a.device.uncaptured_errors {
        issues.push(Issue::new("device", "warning", format!("{} {}: uncaptured wgpu error: {e}", a.backend, a.name)));
    }
    drop(device);
    a
}

fn skipped(what: &str, bytes: u64, why: &str) -> AllocTest {
    AllocTest { what: what.into(), bytes, result: "skipped".into(), detail: Some(why.into()) }
}

/// Run `make` between an out-of-memory and a validation error scope and turn the outcome into a test result.
fn scoped<T>(device: &wgpu::Device, what: &str, bytes: u64, make: impl FnOnce() -> T, destroy: impl FnOnce(T)) -> AllocTest {
    device.push_error_scope(wgpu::ErrorFilter::OutOfMemory);
    device.push_error_scope(wgpu::ErrorFilter::Validation);
    let made = catch_unwind(AssertUnwindSafe(make));
    let validation = pollster::block_on(device.pop_error_scope());
    let oom = pollster::block_on(device.pop_error_scope());
    match made {
        Err(_) => AllocTest { what: what.into(), bytes, result: "failed".into(), detail: Some("the driver call panicked".into()) },
        Ok(thing) => {
            destroy(thing);
            match (validation, oom) {
                (None, None) => AllocTest { what: what.into(), bytes, result: "ok".into(), detail: None },
                (v, o) => {
                    let detail = [v.map(|e| format!("validation: {e}")), o.map(|e| format!("out of memory: {e}"))].into_iter().flatten().collect::<Vec<_>>().join("; ");
                    AllocTest { what: what.into(), bytes, result: "failed".into(), detail: Some(detail) }
                }
            }
        }
    }
}

fn texture_test(device: &wgpu::Device, what: &str, w: u32, h: u32, format: &str, usage: wgpu::TextureUsages) -> AllocTest {
    let bytes = budget::frame_bytes(w, h, format);
    let Some(fmt) = texture_format(format) else { return skipped(what, bytes, "unknown format") };
    scoped(
        device,
        what,
        bytes,
        || {
            device.create_texture(&wgpu::TextureDescriptor {
                label: Some("filmcraft-gpu-probe"),
                size: wgpu::Extent3d { width: w, height: h, depth_or_array_layers: 1 },
                mip_level_count: 1,
                sample_count: 1,
                dimension: wgpu::TextureDimension::D2,
                format: fmt,
                usage,
                view_formats: &[],
            })
        },
        |t| t.destroy(),
    )
}

fn buffer_test(device: &wgpu::Device, what: &str, size: u64) -> AllocTest {
    scoped(
        device,
        what,
        size,
        || {
            device.create_buffer(&wgpu::BufferDescriptor {
                label: Some("filmcraft-gpu-probe"),
                size,
                usage: wgpu::BufferUsages::MAP_READ | wgpu::BufferUsages::COPY_DST,
                mapped_at_creation: false,
            })
        },
        |b| b.destroy(),
    )
}

/// What the device really accepts: working targets at 1080p and 4K, a 4K luma plane and read-back buffers. Big allocations are
/// skipped when the memory model says they would not fit (this is a probe, not a stress test).
fn allocation_tests(device: &wgpu::Device, a: &AdapterReport, budget_bytes: u64) -> Vec<AllocTest> {
    let target = wgpu::TextureUsages::RENDER_ATTACHMENT | wgpu::TextureUsages::TEXTURE_BINDING | wgpu::TextureUsages::COPY_SRC;
    let tex_limit = a.limits.max_texture_dimension_2d;
    let mut out = vec![texture_test(device, "1080p Rgba16Float working target", 1920, 1080, "Rgba16Float", target)];

    let name = "4K Rgba16Float working target";
    let bytes = budget::frame_bytes(3840, 2160, "Rgba16Float");
    out.push(if tex_limit < 3840 {
        skipped(name, bytes, "texture size limit below 3840")
    } else if bytes * 3 > budget_bytes {
        skipped(name, bytes, "three targets would not fit the memory budget")
    } else {
        texture_test(device, name, 3840, 2160, "Rgba16Float", target)
    });

    let name = "4K Rgba32Float working target";
    let bytes = budget::frame_bytes(3840, 2160, "Rgba32Float");
    let f32_ok = a.formats.iter().any(|f| f.name == "Rgba32Float" && f.support.sampled && f.support.render_attachment);
    out.push(if !f32_ok {
        skipped(name, bytes, "Rgba32Float cannot be rendered to and sampled")
    } else if tex_limit < 3840 {
        skipped(name, bytes, "texture size limit below 3840")
    } else if bytes * 3 > budget_bytes {
        skipped(name, bytes, "three targets would not fit the memory budget")
    } else {
        texture_test(device, name, 3840, 2160, "Rgba32Float", target)
    });

    let name = "4K R8Unorm luma plane";
    let bytes = budget::frame_bytes(3840, 2160, "R8Unorm");
    out.push(if tex_limit < 3840 { skipped(name, bytes, "texture size limit below 3840") } else { texture_test(device, name, 3840, 2160, "R8Unorm", wgpu::TextureUsages::TEXTURE_BINDING | wgpu::TextureUsages::COPY_DST) });

    for (name, w, h) in [("1080p RGBA8 read-back buffer", 1920u64, 1080u64), ("4K RGBA8 read-back buffer", 3840, 2160)] {
        let size = w * h * 4;
        out.push(if size > a.limits.max_buffer_size { skipped(name, size, "larger than the buffer size limit") } else { buffer_test(device, name, size) });
    }
    out
}
