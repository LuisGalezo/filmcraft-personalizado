//! What the probe finds, as plain data: serialised to JSON for the app and printed as text for the log.

use serde::Serialize;

pub const SCHEMA: u32 = 1;

#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize)]
#[serde(rename_all = "snake_case")]
pub enum Level {
    Supported,
    Limited,
    Unsupported,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize)]
#[serde(tag = "state", content = "why", rename_all = "snake_case")]
pub enum Status {
    /// The probe ran to the end (it may have found no GPU at all).
    Ran,
    /// Not run: wgpu is not built in, or an earlier probe never finished on this build.
    Skipped(String),
    /// The probe did not answer in time (a driver that hangs).
    TimedOut(String),
}

#[derive(Clone, Debug, PartialEq, Serialize)]
pub struct Issue {
    /// Where it happened: "instance", "enumerate", "device", "alloc", "probe" ...
    pub stage: String,
    /// "error", "warning" or "info".
    pub severity: String,
    pub message: String,
}

impl Issue {
    pub fn new(stage: &str, severity: &str, message: impl Into<String>) -> Self {
        Issue { stage: stage.into(), severity: severity.into(), message: message.into() }
    }
}

#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize)]
pub struct FormatSupport {
    /// Can be read by a shader (`TEXTURE_BINDING`).
    pub sampled: bool,
    /// Can be drawn into (`RENDER_ATTACHMENT`).
    pub render_attachment: bool,
    pub copy_src: bool,
    pub copy_dst: bool,
    pub storage: bool,
    /// Linear filtering when sampled.
    pub filterable: bool,
    /// Hardware blending when drawn into.
    pub blendable: bool,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize)]
pub struct FormatReport {
    pub name: String,
    /// What the compositor would use it for.
    pub role: String,
    pub required: bool,
    pub support: FormatSupport,
}

#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize)]
pub struct LimitsReport {
    pub max_texture_dimension_2d: u32,
    pub max_buffer_size: u64,
    pub max_storage_buffer_binding_size: u32,
    pub max_uniform_buffer_binding_size: u32,
    pub max_bind_groups: u32,
    pub max_color_attachments: u32,
    pub max_sampled_textures_per_shader_stage: u32,
    pub max_texture_array_layers: u32,
}

#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize)]
pub struct DeviceReport {
    /// A device was asked for (the adapter looked usable).
    pub attempted: bool,
    pub ok: bool,
    /// Which limit set the device was created with.
    pub limits_profile: Option<String>,
    pub error: Option<String>,
    pub elapsed_ms: u64,
    /// "Device lost" notices received while probing.
    pub lost: Vec<String>,
    /// Errors wgpu reported outside any error scope.
    pub uncaptured_errors: Vec<String>,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize)]
pub struct AllocTest {
    pub what: String,
    pub bytes: u64,
    /// "ok", "failed" or "skipped".
    pub result: String,
    pub detail: Option<String>,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize)]
pub struct FeatureVerdict {
    pub feature: String,
    pub level: Level,
    pub reason: String,
}

#[derive(Clone, Debug, PartialEq, Serialize)]
pub struct Verdict {
    pub overall: Level,
    pub features: Vec<FeatureVerdict>,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize)]
pub struct Budget {
    /// Memory the compositor may use on this device, from the phone's RAM (a model, not a measurement).
    pub budget_bytes: u64,
    /// Longest side of a 16:9 frame the budget and the texture limit allow.
    pub max_frame_side: u32,
    /// How many compositors fit (export: at most 2, preview: 1).
    pub max_compositors: u32,
    /// Model of one compositor at 1080p with f16 targets / with f32 targets.
    pub compositor_1080p_f16_bytes: u64,
    pub compositor_1080p_f32_bytes: u64,
    /// A software rasteriser (llvmpipe, SwiftShader): never recommended.
    pub software_renderer: bool,
}

#[derive(Clone, Debug, PartialEq, Serialize)]
pub struct AdapterReport {
    pub backend: String,
    pub name: String,
    pub vendor_id: u32,
    pub device_id: u32,
    /// "integrated_gpu", "discrete_gpu", "virtual_gpu", "cpu" or "other".
    pub device_type: String,
    pub driver: String,
    pub driver_info: String,
    /// wgpu features the adapter offers, among the ones that matter here.
    pub features: Vec<String>,
    pub limits: LimitsReport,
    pub formats: Vec<FormatReport>,
    pub device: DeviceReport,
    pub allocations: Vec<AllocTest>,
    pub verdict: Option<Verdict>,
    pub budget: Option<Budget>,
}

#[derive(Clone, Debug, PartialEq, Serialize)]
pub struct BackendReport {
    pub backend: String,
    pub adapters: Vec<AdapterReport>,
    pub error: Option<String>,
    pub elapsed_ms: u64,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize)]
pub struct Selected {
    pub backend: String,
    pub name: String,
}

#[derive(Clone, Debug, PartialEq, Serialize)]
pub struct GpuReport {
    pub schema: u32,
    pub crate_version: String,
    /// Whether the build includes wgpu (feature `wgpu-probe`).
    pub wgpu_compiled: bool,
    pub status: Status,
    pub elapsed_ms: u64,
    pub system_ram_mb: Option<u64>,
    pub backends: Vec<BackendReport>,
    /// The adapter the compositor would use, if any is usable.
    pub selected: Option<Selected>,
    pub issues: Vec<Issue>,
}

impl GpuReport {
    pub fn new(wgpu_compiled: bool, system_ram_mb: Option<u64>) -> Self {
        GpuReport {
            schema: SCHEMA,
            crate_version: env!("CARGO_PKG_VERSION").to_string(),
            wgpu_compiled,
            status: Status::Ran,
            elapsed_ms: 0,
            system_ram_mb,
            backends: Vec::new(),
            selected: None,
            issues: Vec::new(),
        }
    }

    pub fn to_json(&self) -> String {
        serde_json::to_string_pretty(self).unwrap_or_else(|e| format!("{{\"error\":\"report could not be written: {e}\"}}"))
    }

    /// The selected adapter's report, if any.
    pub fn selected_adapter(&self) -> Option<&AdapterReport> {
        let s = self.selected.as_ref()?;
        self.backends.iter().filter(|b| b.backend == s.backend).flat_map(|b| &b.adapters).find(|a| a.name == s.name)
    }

    /// A readable report for the log and for a person: what was found, what can be accelerated and why not.
    pub fn summary(&self) -> String {
        use std::fmt::Write;
        let mut s = String::new();
        let _ = writeln!(s, "FilmCraft GPU diagnostics (schema {}, filmcraft-gpu {}, wgpu built in: {})", self.schema, self.crate_version, self.wgpu_compiled);
        let _ = writeln!(s, "status: {:?}; took {} ms; system RAM: {}", self.status, self.elapsed_ms, self.system_ram_mb.map_or("unknown".into(), |m| format!("{m} MB")));
        for b in &self.backends {
            let _ = writeln!(s, "backend {}: {} adapter(s){} [{} ms]", b.backend, b.adapters.len(), b.error.as_ref().map_or(String::new(), |e| format!(", error: {e}")), b.elapsed_ms);
            for a in &b.adapters {
                let _ = writeln!(s, "  adapter: {} ({}), vendor 0x{:04x} device 0x{:04x}, driver \"{}\" {}", a.name, a.device_type, a.vendor_id, a.device_id, a.driver, a.driver_info);
                let _ = writeln!(
                    s,
                    "    device: {}{}",
                    if a.device.ok { "created" } else { "NOT created" },
                    a.device.error.as_ref().map_or(String::new(), |e| format!(" ({e})"))
                );
                let _ = writeln!(s, "    limits: texture2d {} px, buffer {} B, bind groups {}, sampled textures/stage {}", a.limits.max_texture_dimension_2d, a.limits.max_buffer_size, a.limits.max_bind_groups, a.limits.max_sampled_textures_per_shader_stage);
                for f in &a.formats {
                    let _ = writeln!(
                        s,
                        "    {:<15} sampled={} render={} blend={} filter={} copy_src={}{}",
                        f.name,
                        f.support.sampled as u8,
                        f.support.render_attachment as u8,
                        f.support.blendable as u8,
                        f.support.filterable as u8,
                        f.support.copy_src as u8,
                        if f.required { "  (required)" } else { "" }
                    );
                }
                for t in &a.allocations {
                    let _ = writeln!(s, "    alloc {}: {} ({} B){}", t.what, t.result, t.bytes, t.detail.as_ref().map_or(String::new(), |d| format!(" - {d}")));
                }
                if let Some(b) = &a.budget {
                    let _ = writeln!(s, "    budget: {} MB, up to {} px long side, {} compositor(s){}", b.budget_bytes / (1 << 20), b.max_frame_side, b.max_compositors, if b.software_renderer { ", SOFTWARE RENDERER" } else { "" });
                }
                if let Some(v) = &a.verdict {
                    let _ = writeln!(s, "    verdict: {:?}", v.overall);
                    for f in &v.features {
                        let _ = writeln!(s, "      {:<22} {:?}: {}", f.feature, f.level, f.reason);
                    }
                }
            }
        }
        match &self.selected {
            Some(sel) => {
                let _ = writeln!(s, "selected: {} on {}", sel.name, sel.backend);
            }
            None => {
                let _ = writeln!(s, "selected: none (everything stays on the CPU)");
            }
        }
        for i in &self.issues {
            let _ = writeln!(s, "{} [{}]: {}", i.severity, i.stage, i.message);
        }
        s
    }
}
