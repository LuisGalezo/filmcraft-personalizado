"""Reference for the multi-point keyframe curve: the same algorithm that is ported to Rust (keyframe.rs) and Kotlin (KeyCurve.kt)."""
import math, random

MAX_POINTS = 16

def clamp(v, lo, hi): return max(lo, min(hi, v))

def sanitize(mid):
    """mid: list of (x,y,inx,iny,outx,outy). Strictly inside, sorted, distinct in time, handles on their side, y in -1..2."""
    out = []
    for p in mid:
        if not all(math.isfinite(v) for v in p): continue
        x, y, ix, iy, ox, oy = p
        if not (0.001 < x < 0.999): continue
        out.append((x, clamp(y, -1, 2), clamp(ix, 0.0, x), clamp(iy, -1, 2), clamp(ox, x, 1.0), clamp(oy, -1, 2)))
    out.sort(key=lambda p: p[0])
    res = []
    for p in out:
        if res and p[0] - res[-1][0] < 0.002: continue
        res.append(p)
    return res[:MAX_POINTS]

def nodes(x1, y1, x2, y2, mid):
    return [(0.0, 0.0, 0.0, 0.0, x1, y1)] + sanitize(mid) + [(1.0, 1.0, x2, y2, 1.0, 1.0)]

def seg_y(p0, p1, p2, p3, x):
    """y of the cubic bezier p0..p3 at time x; the time axis is monotone because handle x's lie between the ends."""
    if p3[0] - p0[0] < 1e-9: return p3[1]
    lo, hi = 0.0, 1.0
    s = 0.5
    for _ in range(60):
        s = (lo + hi) / 2
        bx = 3*(1-s)**2*s*p1[0] + 3*(1-s)*s*s*p2[0] + s**3*p3[0] + (1-s)**3*p0[0]
        if bx < x: lo = s
        else: hi = s
    s = (lo + hi) / 2
    return (1-s)**3*p0[1] + 3*(1-s)**2*s*p1[1] + 3*(1-s)*s*s*p2[1] + s**3*p3[1]

def curve_y(x1, y1, x2, y2, mid, u):
    u = clamp(u, 0.0, 1.0)
    n = nodes(x1, y1, x2, y2, mid)
    for i in range(len(n) - 1):
        a, b = n[i], n[i+1]
        if u <= b[0] or i == len(n) - 2:
            p0 = (a[0], a[1]); p3 = (b[0], b[1])
            p1 = (a[4], a[5]); p2 = (b[2], b[3])
            return seg_y(p0, p1, p2, p3, u)
    return 1.0

def old_cubic(x1, y1, x2, y2, x):
    return seg_y((0, 0), (x1, y1), (x2, y2), (1, 1), x)

def add_point(x1, y1, x2, y2, mid, x):
    """Insert a point at time x ON the curve, splitting the sub-segment exactly (de Casteljau). Returns (x1,y1,x2,y2,mid, index)."""
    n = nodes(x1, y1, x2, y2, mid)
    for i in range(len(n) - 1):
        a, b = n[i], n[i+1]
        if x <= b[0] or i == len(n) - 2:
            break
    p0 = (a[0], a[1]); p3 = (b[0], b[1])
    p1 = (a[4], a[5]); p2 = (b[2], b[3])
    lo, hi = 0.0, 1.0
    for _ in range(60):
        s = (lo + hi) / 2
        bx = (1-s)**3*p0[0] + 3*(1-s)**2*s*p1[0] + 3*(1-s)*s*s*p2[0] + s**3*p3[0]
        if bx < x: lo = s
        else: hi = s
    s = (lo + hi) / 2
    L = lambda p, q: (p[0] + (q[0]-p[0])*s, p[1] + (q[1]-p[1])*s)
    A, B, C = L(p0, p1), L(p1, p2), L(p2, p3)
    D, E = L(A, B), L(B, C)
    F = L(D, E)
    nn = list(n)
    # left node keeps its in handle, its out handle becomes A; right node's in handle becomes C
    nn[i] = (a[0], a[1], a[2], a[3], A[0], A[1])
    nn[i+1] = (b[0], b[1], C[0], C[1], b[4], b[5])
    nn.insert(i+1, (F[0], F[1], D[0], D[1], E[0], E[1]))
    first, last = nn[0], nn[-1]
    mids = nn[1:-1]
    return first[4], first[5], last[2], last[3], mids, i

if __name__ == "__main__":
    random.seed(7)
    # 1. no mid point == the old single cubic
    for _ in range(2000):
        x1, x2 = random.uniform(0.01, 1), random.uniform(0, 0.99)
        y1, y2 = random.uniform(-1, 2), random.uniform(-1, 2)
        u = random.random()
        assert abs(curve_y(x1, y1, x2, y2, [], u) - old_cubic(x1, y1, x2, y2, u)) < 1e-12
    print("1 ok: empty mid == old cubic")
    # 2. exact split: adding a point changes nothing
    worst = 0
    for _ in range(300):
        x1, x2 = random.uniform(0.05, 0.95), random.uniform(0.05, 0.95)
        y1, y2 = random.uniform(-0.5, 1.5), random.uniform(-0.5, 1.5)
        mid = []
        c = (x1, y1, x2, y2)
        for k in range(random.randint(1, 4)):
            x = random.uniform(0.05, 0.95)
            if any(abs(x - p[0]) < 0.02 for p in mid): continue
            before = [curve_y(*c, mid, u / 50) for u in range(51)]
            nx1, ny1, nx2, ny2, nm, idx = add_point(*c, mid, x)
            c, mid = (nx1, ny1, nx2, ny2), nm
            after = [curve_y(*c, mid, u / 50) for u in range(51)]
            worst = max(worst, max(abs(a - b) for a, b in zip(before, after)))
    print("2 ok: worst change after inserting points = %.2e" % worst)
    assert worst < 1e-6
    # 3. passes through its points, continuous at the nodes
    mid = [(0.5, 0.8, 0.4, 0.8, 0.6, 0.8)]
    v = curve_y(1/3, 0, 2/3, 1, mid, 0.5)
    print("3 value at the point:", v); assert abs(v - 0.8) < 1e-9
    # 4. clamping: a handle past a neighbour cannot make time go backwards
    mid = [(0.5, 0.5, 0.0, 0.0, 5.0, 5.0)]
    prev = -9
    for u in range(101):
        y = curve_y(1/3, 0, 2/3, 1, mid, u / 100)
        assert math.isfinite(y)
    print("4 ok: wild handles stay finite")
    # table for the unit tests
    t = [0.0, 0.1, 0.25, 0.5, 0.75, 0.9, 1.0]
    mid = [(0.5, 0.8, 0.4, 0.8, 0.6, 0.8)]
    print("TABLE A (x1,y1,x2,y2 = 1/3,0,2/3,1; mid at .5,.8 flat):", [round(curve_y(1/3, 0, 2/3, 1, mid, u), 6) for u in t])
    mid2 = [(0.3, 0.9, 0.2, 0.9, 0.4, 0.9), (0.7, 0.1, 0.6, 0.1, 0.8, 0.1)]
    print("TABLE B (1/3,1/3,2/3,2/3; two mids):", [round(curve_y(1/3, 1/3, 2/3, 2/3, mid2, u), 6) for u in t])
    r = add_point(1/3, 0, 2/3, 1, [], 0.5)
    print("SPLIT at .5 of (1/3,0,2/3,1):", [round(v, 6) for v in r[:4]], [[round(v, 6) for v in p] for p in r[4]])
