use super::*;
use crate::tests::project;
use crate::{Progress, export};
use std::sync::Mutex;
use std::sync::atomic::{AtomicUsize, Ordering};

const SPS: [u8; 12] = [0x67, 0x64, 0x00, 0x28, 0xAC, 0xD9, 0x40, 0x78, 0x02, 0x27, 0xE5, 0xC0];
const PPS: [u8; 5] = [0x68, 0xEB, 0xE3, 0xCB, 0x22];

fn annexb(nals: &[&[u8]]) -> Vec<u8> {
    let mut v = Vec::new();
    for n in nals {
        v.extend_from_slice(&[0, 0, 0, 1]);
        v.extend_from_slice(n);
    }
    v
}

fn config_packet() -> HwPacket {
    HwPacket { data: annexb(&[&SPS, &PPS]), pts_us: 0, key: false, config: true }
}

/// Parameter sets of a Main-profile encoder (profile_idc 77), or a second, different SPS.
fn config_with_profile(profile: u8) -> HwPacket {
    let mut sps = SPS;
    sps[1] = profile;
    HwPacket { data: annexb(&[&sps, &PPS]), pts_us: 0, key: false, config: true }
}

/// A picture as an encoder would return it: key frames carry an IDR slice, the others a non-IDR slice.
fn picture(pts_us: i64, key: bool) -> HwPacket {
    let slice: &[u8] = if key { &[0x65, 0x88, 0x84, 0x00, 0x10] } else { &[0x41, 0x9A, 0x24, 0x6C] };
    HwPacket { data: annexb(&[&[0x09, 0xF0], slice]), pts_us, key, config: false }
}

#[derive(Default)]
struct Counters {
    opened: AtomicUsize,
    encoded: AtomicUsize,
    finished: AtomicUsize,
}

#[derive(Clone, Copy, PartialEq)]
enum Behaviour {
    Good,
    /// Returns pictures this many pictures late (a real encoder's pipeline), all of them at the end.
    Late(usize),
    FailAt(usize),
    DropPicture(usize),
    Reorder,
    NoConfig,
    /// An encoder that quietly used Main profile although High was asked for.
    MainProfile,
    /// An encoder that sends a different SPS part-way.
    ChangedSps,
}

struct Mock {
    c: Arc<Counters>,
    supported: bool,
    open_fails: bool,
    b: Behaviour,
    seen: Mutex<Vec<HwConfig>>,
}

impl Mock {
    fn with(b: Behaviour, supported: bool, open_fails: bool) -> (Arc<Mock>, Arc<Counters>) {
        let c = Arc::new(Counters::default());
        (Arc::new(Mock { c: c.clone(), supported, open_fails, b, seen: Mutex::new(Vec::new()) }), c)
    }

    fn new(b: Behaviour) -> (Arc<Mock>, Arc<Counters>) {
        Mock::with(b, true, false)
    }
}

impl H264Backend for Mock {
    fn supports(&self, cfg: &HwConfig) -> bool {
        self.seen.lock().unwrap().push(cfg.clone());
        self.supported
    }
    fn open(&self, _cfg: &HwConfig) -> std::result::Result<Box<dyn H264Session>, String> {
        if self.open_fails {
            return Err("no codec".into());
        }
        self.c.opened.fetch_add(1, Ordering::Relaxed);
        Ok(Box::new(MockSession { c: self.c.clone(), b: self.b, n: 0, held: Vec::new() }))
    }
}

struct MockSession {
    c: Arc<Counters>,
    b: Behaviour,
    n: usize,
    held: Vec<HwPacket>,
}

impl H264Session for MockSession {
    fn encode(&mut self, yuv: &[u8], pts_us: i64) -> std::result::Result<Vec<HwPacket>, String> {
        // planar 4:2:0 of 320x180
        assert_eq!(yuv.len(), 320 * 180 + 2 * 160 * 90);
        self.c.encoded.fetch_add(1, Ordering::Relaxed);
        let i = self.n;
        self.n += 1;
        if self.b == Behaviour::FailAt(i) {
            return Err("codec died".into());
        }
        let mut out = Vec::new();
        if i == 0 && self.b == Behaviour::MainProfile {
            out.push(config_with_profile(77));
        } else if i == 0 && self.b != Behaviour::NoConfig {
            out.push(config_packet());
        }
        if i == 5 && self.b == Behaviour::ChangedSps {
            out.push(config_with_profile(110));
        }
        let mut pts = pts_us;
        match self.b {
            Behaviour::DropPicture(k) if k == i => return Ok(out), // swallowed
            Behaviour::Reorder if i == 2 => pts += 41_666 * 2,
            _ => {}
        }
        let p = picture(pts, i == 0);
        match self.b {
            Behaviour::Late(depth) => {
                self.held.push(p);
                if self.held.len() > depth {
                    out.push(self.held.remove(0));
                }
            }
            _ => out.push(p),
        }
        Ok(out)
    }
    fn finish(&mut self) -> std::result::Result<Vec<HwPacket>, String> {
        self.c.finished.fetch_add(1, Ordering::Relaxed);
        Ok(std::mem::take(&mut self.held))
    }
}

fn h264_settings(path: &str) -> ExportSettings {
    ExportSettings { format: Format::H264, path: path.into(), bitrate_mode: BitrateMode::Crf, crf: 22.0, ..Default::default() }
}

fn tmp(name: &str) -> String {
    let d = std::env::temp_dir().join(format!("fc-hw-{}", std::process::id()));
    std::fs::create_dir_all(&d).unwrap();
    d.join(name).to_string_lossy().to_string()
}

fn contains(hay: &[u8], needle: &[u8]) -> bool {
    hay.windows(needle.len()).any(|w| w == needle)
}

// ---- pure pieces ------------------------------------------------------------------------------

#[test]
fn annexb_is_split_on_three_and_four_byte_start_codes_and_trailing_zeros_are_dropped() {
    let mut data = vec![0, 0, 1, 0x67, 1, 2, 0];
    data.extend_from_slice(&[0, 0, 0, 1, 0x68, 9]);
    data.extend_from_slice(&[0, 0, 1, 0x65, 7, 7, 7]);
    let nals = split_annexb(&data);
    assert_eq!(nals, vec![&[0x67u8, 1, 2][..], &[0x68, 9][..], &[0x65, 7, 7, 7][..]]);
    assert!(split_annexb(&[]).is_empty());
    assert!(split_annexb(&[5, 5, 5]).is_empty()); // no start code: nothing to trust
}

#[test]
fn samples_are_length_prefixed_without_parameter_sets_or_delimiters() {
    let au = annexb(&[&[0x09, 0xF0], &SPS, &PPS, &[0x65, 1, 2, 3]]);
    let mut seen = Vec::new();
    let sample = to_length_prefixed(&au, |t, nal| seen.push((t, nal.len())));
    assert_eq!(sample, vec![0, 0, 0, 4, 0x65, 1, 2, 3]);
    assert_eq!(seen, vec![(7, SPS.len()), (8, PPS.len())]);
}

#[test]
fn the_hardware_bitrate_follows_crf_and_is_never_a_cut() {
    let kbps = |crf| hardware_bitrate_kbps(1080, 1920, 30.0, crf);
    assert_eq!(kbps(18.0), 18_662); // 0.30 bits per pixel per frame
    assert!(kbps(18.0) > kbps(22.0) && kbps(22.0) > kbps(26.0));
    assert!((kbps(24.0) as f64 / kbps(18.0) as f64 - 0.5).abs() < 0.01); // +6 CRF = half
    // always above what the old single-pass budgets (0.2 / 0.1 / 0.05 bits per pixel) gave for the same level
    assert!(kbps(18.0) as f64 > 1080.0 * 1920.0 * 30.0 * 0.2 / 1000.0);
    assert!(kbps(22.0) as f64 > 1080.0 * 1920.0 * 30.0 * 0.1 / 1000.0);
    assert!(kbps(26.0) as f64 > 1080.0 * 1920.0 * 30.0 * 0.05 / 1000.0);
    assert_eq!(hardware_bitrate_kbps(16, 16, 1.0, 51.0), 500);
    assert_eq!(hardware_bitrate_kbps(1080, 1920, 30.0, f64::NAN), kbps(18.0));
}

// ---- choosing hardware or software --------------------------------------------------------------

fn pick(s: &ExportSettings, w: u32, h: u32) -> bool {
    hardware_h264_factory(Format::H264, w, h, FrameRate::FPS_24, s).is_some()
}

#[test]
fn without_a_backend_the_software_encoder_is_used() {
    set_test_backend(None);
    assert!(!pick(&h264_settings("x.mp4"), 320, 180));
}

#[test]
fn the_backend_is_used_only_when_it_supports_the_request_and_opens() {
    let (m, c) = Mock::new(Behaviour::Good);
    set_test_backend(Some(m.clone()));
    assert!(pick(&h264_settings("x.mp4"), 320, 180));
    assert_eq!(c.opened.load(Ordering::Relaxed), 1);
    // it was asked for the same size and rate, and for at least the bitrate CRF 22 needs
    let cfg = m.seen.lock().unwrap()[0].clone();
    assert_eq!((cfg.width, cfg.height, cfg.fps_num, cfg.fps_den), (320, 180, 24, 1));
    assert_eq!(cfg.bitrate_kbps, hardware_bitrate_kbps(320, 180, 24.0, 22.0));
    assert_eq!(cfg.keyint, 48);

    set_test_backend(Some(Mock::with(Behaviour::Good, false, false).0));
    assert!(!pick(&h264_settings("x.mp4"), 320, 180));
    assert!(hardware_status().starts_with("software: the phone's hardware encoder does not support 320x180"));

    set_test_backend(Some(Mock::with(Behaviour::Good, true, true).0));
    assert!(!pick(&h264_settings("x.mp4"), 320, 180));
    assert!(hardware_status().contains("could not be opened (no codec)"));
}

#[test]
fn what_only_software_can_do_stays_in_software() {
    let (m, _) = Mock::new(Behaviour::Good);
    set_test_backend(Some(m));
    let base = h264_settings("x.mp4");
    assert!(pick(&base, 320, 180));
    assert!(!pick(&base, 321, 180), "odd sizes");
    assert!(!pick(&ExportSettings { h264_pass: H264Pass::First, ..h264_settings("x.mp4") }, 320, 180), "two passes");
    assert!(!pick(&ExportSettings { pixel_aspect: Some((4, 3)), ..h264_settings("x.mp4") }, 320, 180), "non-square pixels");
    with_software_only(|| assert!(!pick(&base, 320, 180), "switched off"));
    assert!(pick(&base, 320, 180), "and back on");
}

// ---- the encoder ------------------------------------------------------------------------------

fn encode_all(b: Behaviour) -> (Result<Vec<EncodedPacket>>, Arc<Counters>) {
    let (m, c) = Mock::new(b);
    set_test_backend(Some(m));
    let s = h264_settings("x.mp4");
    let mut enc = hardware_h264_factory(Format::H264, 320, 180, FrameRate::FPS_24, &s).unwrap().unwrap();
    let rgba = vec![200u8; 320 * 180 * 4];
    let mut all = Vec::new();
    for i in 0..10u64 {
        let f = EncoderFrame { width: 320, height: 180, rgba: &rgba, hdr: None, index: i };
        match enc.encode(&f) {
            Ok(p) => all.extend(p),
            Err(e) => return (Err(e), c),
        }
    }
    let r = enc.flush().map(|p| {
        all.extend(p);
        all
    });
    (r, c)
}

#[test]
fn packets_keep_every_picture_in_order_with_durations_keys_and_no_composition_offset() {
    for b in [Behaviour::Good, Behaviour::Late(3)] {
        let (r, c) = encode_all(b);
        let p = r.unwrap();
        assert_eq!(p.len(), 10);
        assert_eq!(c.finished.load(Ordering::Relaxed), 1);
        assert!(p[0].key && p[1..].iter().all(|x| !x.key));
        assert!(p.iter().all(|x| x.duration == 1 && x.composition_offset == 0));
        assert_eq!(p[0].data, vec![0, 0, 0, 5, 0x65, 0x88, 0x84, 0x00, 0x10]);
        assert_eq!(&p[1].data[..5], &[0, 0, 0, 4, 0x41]);
    }
}

#[test]
fn the_sample_entry_carries_the_encoders_sps_and_pps_once_the_first_picture_is_in() {
    let (m, _) = Mock::new(Behaviour::Good);
    set_test_backend(Some(m));
    let s = h264_settings("x.mp4");
    let mut enc = hardware_h264_factory(Format::H264, 320, 180, FrameRate::FPS_24, &s).unwrap().unwrap();
    let rgba = vec![9u8; 320 * 180 * 4];
    enc.encode(&EncoderFrame { width: 320, height: 180, rgba: &rgba, hdr: None, index: 0 }).unwrap();
    assert_eq!(enc.timescale(), 24);
    assert!(enc.media_start().is_none(), "no B-frames, no edit list");
}

#[test]
fn a_dropped_a_reordered_or_a_parameterless_encoder_is_an_error_not_a_damaged_file() {
    let (r, _) = encode_all(Behaviour::DropPicture(4));
    assert!(matches!(&r, Err(e) if is_hardware_error(e)), "{r:?}");
    let (r, _) = encode_all(Behaviour::Reorder);
    assert!(matches!(&r, Err(e) if is_hardware_error(e)), "{r:?}");
    let (r, _) = encode_all(Behaviour::NoConfig);
    assert!(matches!(&r, Err(e) if is_hardware_error(e)), "{r:?}");
    let (r, _) = encode_all(Behaviour::FailAt(3));
    assert!(matches!(&r, Err(e) if is_hardware_error(e)), "{r:?}");
}

// ---- whole exports ----------------------------------------------------------------------------

#[test]
fn an_export_through_the_hardware_backend_writes_all_pictures_with_its_parameter_sets() {
    for b in [Behaviour::Good, Behaviour::Late(3)] {
        let (m, c) = Mock::new(b);
        set_test_backend(Some(m));
        let (p, seq, src) = project();
        let path = tmp("hw.mp4");
        let r = export(&p, seq, &h264_settings(&path), &src, &Progress::default()).unwrap();
        assert_eq!(r.frames, 24);
        assert_eq!(c.encoded.load(Ordering::Relaxed), 24);
        assert_eq!(c.finished.load(Ordering::Relaxed), 1);
        assert!(hardware_status().starts_with("hardware: 320x180 at 24.000 fps"));
        let bytes = std::fs::read(&path).unwrap();
        assert!(contains(&bytes, b"avcC") && contains(&bytes, &SPS) && contains(&bytes, &PPS));
        assert!(contains(&bytes, b"mdat"));
    }
}

#[test]
fn when_the_hardware_encoder_fails_midway_the_export_is_redone_in_software() {
    let (m, c) = Mock::new(Behaviour::FailAt(7));
    set_test_backend(Some(m));
    let (p, seq, src) = project();
    let path = tmp("fallback.mp4");
    let prog = Progress::default();
    let r = export(&p, seq, &h264_settings(&path), &src, &prog).unwrap();
    assert_eq!(r.frames, 24, "every picture is in the file");
    assert_eq!(c.opened.load(Ordering::Relaxed), 1, "hardware was tried once, not again");
    assert!(hardware_status().starts_with("software: the hardware encoder failed"));
    let bytes = std::fs::read(&path).unwrap();
    assert!(contains(&bytes, b"avcC"));
    assert!(!contains(&bytes, &SPS), "the file is the software encoder's, not a half-written hardware one");
    assert_eq!(prog.done.load(Ordering::Relaxed), 24);
    assert!(prog.error.lock().unwrap().is_none());
}

#[test]
fn a_cancelled_export_is_not_retried() {
    let (m, c) = Mock::new(Behaviour::FailAt(2));
    set_test_backend(Some(m));
    let (p, seq, src) = project();
    let prog = Progress::default();
    prog.cancel.store(true, Ordering::Relaxed);
    let r = export(&p, seq, &h264_settings(&tmp("cancel.mp4")), &src, &prog);
    assert!(r.is_err());
    assert!(c.opened.load(Ordering::Relaxed) <= 1);
}

#[test]
fn the_avcc_record_has_the_iso_layout() {
    let v = build_avcc(&SPS, &PPS);
    assert_eq!(&v[..6], &[1, 0x64, 0x00, 0x28, 0xFF, 0xE1]);
    assert_eq!(&v[6..8], &(SPS.len() as u16).to_be_bytes());
    assert_eq!(&v[8..8 + SPS.len()], &SPS);
    let p = 8 + SPS.len();
    assert_eq!(v[p], 1);
    assert_eq!(&v[p + 1..p + 3], &(PPS.len() as u16).to_be_bytes());
    assert_eq!(&v[p + 3..p + 3 + PPS.len()], &PPS);
    // High profile: chroma format 4:2:0 and 8-bit depths follow
    assert_eq!(&v[p + 3 + PPS.len()..], &[0xFD, 0xF8, 0xF8, 0]);
    // Main profile has no extension
    let mut main = SPS;
    main[1] = 77;
    assert_eq!(build_avcc(&main, &PPS).len(), v.len() - 4);
}

#[test]
fn an_encoder_that_used_another_profile_or_changed_its_parameter_sets_is_refused() {
    let (r, _) = encode_all(Behaviour::MainProfile);
    assert!(matches!(&r, Err(e) if is_hardware_error(e) && e.to_string().contains("profile 77")), "{r:?}");
    let (r, _) = encode_all(Behaviour::ChangedSps);
    assert!(matches!(&r, Err(e) if is_hardware_error(e) && e.to_string().contains("changed its parameter sets")), "{r:?}");
}

#[test]
fn a_file_handed_in_by_the_app_is_emptied_and_rewound_for_the_software_retry() {
    use std::io::Read;
    let (m, _) = Mock::new(Behaviour::FailAt(9));
    set_test_backend(Some(m));
    let (p, seq, src) = project();
    let path = tmp("handed-in.mp4");
    let file = std::fs::OpenOptions::new().read(true).write(true).create(true).truncate(true).open(&path).unwrap();
    let settings = ExportSettings { output_file: Some(Arc::new(file)), ..h264_settings(&path) };
    let r = export(&p, seq, &settings, &src, &Progress::default()).unwrap();
    assert_eq!(r.frames, 24);
    let mut bytes = Vec::new();
    std::fs::File::open(&path).unwrap().read_to_end(&mut bytes).unwrap();
    assert_eq!(&bytes[4..8], b"ftyp", "the file starts with a proper header, nothing of the failed run before it");
    assert!(!contains(&bytes, &SPS), "and holds only the software encoder's video");
}
